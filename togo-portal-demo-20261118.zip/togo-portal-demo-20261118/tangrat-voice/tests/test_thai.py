import unittest
from fastapi.testclient import TestClient
from server import app as server
from server.domain import FLOOD,CHILD,INTAKE,field_schema,next_question,validate_patch
from server.intent import YES,NO,keyword_intent
from server.configuration import DEFAULTS,speech_config
from server.voice import WAKE,VoiceProtocol,make_tts
from server.iflytek import tts_request,ProviderError


class ThaiSupport(unittest.TestCase):
    def test_thai_routing_confirmation_and_negations(self):
        self.assertEqual(keyword_intent('ต้องการลงทะเบียนช่วยเหลือผู้ประสบอุทกภัย')[0],FLOOD)
        self.assertEqual(keyword_intent('ขอเงินอุดหนุนเด็กแรกเกิด')[0],CHILD)
        for text in ('ไม่ต้องการเงินอุดหนุนเด็ก','ไม่ใช่เรื่องน้ำท่วม','เงินอุดหนุนเด็กและน้ำท่วม'):
            self.assertIsNone(keyword_intent(text)[0])
        for text in ('ยืนยัน','ยืนยันค่ะ','ใช่ครับ','ตกลงค่ะ'):self.assertIsNotNone(YES.fullmatch(text))
        for text in ('ไม่ยืนยัน','ใช่ แต่ขอยกเลิก','ยืนยัน แต่ไม่ต้องการ'):self.assertIsNone(YES.fullmatch(text))
        self.assertIsNotNone(NO.fullmatch('ยกเลิกค่ะ'))
        self.assertIsNotNone(WAKE.search('สวัสดี ผู้ช่วย'))
        self.assertIsNotNone(WAKE.search('สวัสดีผู้ช่วย'))

    def test_thai_labels_prompts_dates_and_numeric_fields(self):
        for service in (CHILD,FLOOD):
            for field in field_schema(service):
                self.assertTrue(field['th'])
                for option in field.get('options',[]):self.assertTrue(option['th'])
            self.assertRegex(next_question({},'th',service),r'[ก-๙]')
        accepted,errors=validate_patch({'flood_start_date':'๒๕๖๙-๐๙-๒๖','flood_duration_days':'๕',
                                       'phone':'๐๘๑๒๓๔๕๖๗๘','residence_type':'บ้านเช่า'},FLOOD)
        self.assertEqual(errors,{})
        self.assertEqual(accepted['flood_start_date'],'2026-09-26')
        self.assertEqual(accepted['flood_duration_days'],'5')
        self.assertEqual(accepted['phone'],'0812345678')
        self.assertEqual(accepted['residence_type'],'rented')
        _,errors=validate_patch({'flood_duration_days':'๐'},FLOOD)
        self.assertIn('flood_duration_days',errors)

    def test_thai_has_independent_provider_configuration_and_supported_model(self):
        original=dict(DEFAULTS,asr_provider='iflytek',tts_provider='iflytek',iflytek_asr_model='iat')
        thai=speech_config(original,'th')
        self.assertEqual((thai['asr_provider'],thai['tts_provider']),('elevenlabs','elevenlabs'))
        self.assertEqual(original['asr_provider'],'iflytek')
        original.update(th_asr_provider='iflytek',th_tts_provider='iflytek')
        thai=speech_config(original,'th')
        self.assertEqual(thai['iflytek_asr_model'],'mul_cn')
        self.assertEqual(thai['iflytek_tts_model'],'tts')
        with self.assertRaises(ProviderError):tts_request(thai,'ทดสอบ','th')
        thai['iflytek_standard_voice_th']='synthetic-authorized-thai-voice'
        self.assertEqual(tts_request(thai,'ทดสอบ','th')[2]['business']['vcn'],'synthetic-authorized-thai-voice')
        tts=make_tts(dict(DEFAULTS,elevenlabs_key='synthetic-only'),'th',VoiceProtocol())
        self.assertEqual(tts._settings.model,'eleven_v4_turbo')

    def test_thai_bootstrap_and_confirmed_two_service_flow(self):
        client=TestClient(server.app)
        bootstrap=client.get('/api/bootstrap').json();headers={'x-csrf-token':bootstrap['csrf']}
        self.assertIn('th',bootstrap['providers']['realtime_by_language'])
        for phrase,service in [('ลงทะเบียนช่วยเหลือผู้ประสบอุทกภัย',FLOOD),('เงินอุดหนุนเด็กแรกเกิด',CHILD)]:
            draft=client.post('/api/drafts',headers=headers,json={'consent':True}).json();url='/api/drafts/'+draft['id']+'/turn'
            draft=client.post(url,headers=headers,json={'mode':'rehearsal','lang':'th','text':phrase}).json()['draft']
            self.assertEqual(draft['service'],INTAKE)
            self.assertEqual(draft['fields'],{})
            self.assertIn('ยืนยัน',draft['questions']['th'])
            draft=client.post(url,headers=headers,json={'mode':'rehearsal','lang':'th','text':'ยืนยันค่ะ'}).json()['draft']
            self.assertEqual(draft['service'],service)
            self.assertRegex(draft['questions']['th'],r'[ก-๙]')
