import asyncio
import json
import unittest
from urllib.parse import urlparse,parse_qs
from unittest.mock import AsyncMock
from pipecat.frames.frames import StartFrame,InputTransportMessageFrame,OutputAudioRawFrame,OutputTransportMessageFrame
from pipecat.processors.frame_processor import FrameDirection
from server.turn_audio import SeparatedSTT,TurnAudioFrame,TurnTranscript,TurnInterim
from server.voice import FormAssistant,VoiceProtocol,VoiceSerializer

class AudioTurns(unittest.IsolatedAsyncioTestCase):
    async def test_asr_sessions_filter_background_and_never_share_audio_across_epochs(self):
        class Socket:
            def __init__(self):self.sent=[];self.closed=False;self.messages=asyncio.Queue()
            async def recv(self):return json.dumps({'message_type':'session_started'})
            async def send(self,message):self.sent.append(json.loads(message))
            async def close(self):self.closed=True
            def __aiter__(self):return self
            async def __anext__(self):return await self.messages.get()
        sessions=[];urls=[]
        async def connect(url,**kwargs):
            urls.append(url);socket=Socket();sessions.append(socket);return socket
        errors=[]
        async def error(message):errors.append(message)
        router=SeparatedSTT('synthetic-test-key','zh',error,connector=connect)
        emitted=[]
        async def emit(frame,direction=FrameDirection.DOWNSTREAM):emitted.append(frame)
        router.push_frame=emit
        try:
            await router.set_channel('wake',1)
            await router.process_frame(TurnAudioFrame(audio=bytes(640),sample_rate=16000,num_channels=1,input_epoch=1),FrameDirection.DOWNSTREAM)
            self.assertEqual(len(sessions[0].sent),1)
            await router.set_channel('answer',2)
            self.assertTrue(sessions[0].closed)
            await router.process_frame(TurnAudioFrame(audio=bytes(640),sample_rate=16000,num_channels=1,input_epoch=1),FrameDirection.DOWNSTREAM)
            self.assertEqual(sessions[1].sent,[])
            await router.process_frame(TurnAudioFrame(audio=(2000).to_bytes(2,'little',signed=True)*1600,sample_rate=16000,num_channels=1,input_epoch=2),FrameDirection.DOWNSTREAM)
            self.assertEqual(len(sessions[1].sent),1)
            await sessions[1].messages.put(json.dumps({'message_type':'committed_transcript','text':'张琳'}))
            for _ in range(5):await asyncio.sleep(0)
            result=next(frame for frame in emitted if isinstance(frame,TurnTranscript))
            self.assertEqual((result.input_epoch,result.channel),(2,'answer'))
            for url in urls:
                params=parse_qs(urlparse(url).query)
                self.assertEqual(params['filter_background_audio'],['true'])
                self.assertEqual(params['language_code'],['zh'])
                self.assertEqual(params['secondary_languages'],['en','th'])
                self.assertGreaterEqual(float(params['vad_threshold'][0]),.4)
                self.assertNotIn('synthetic-test-key',url)
            self.assertEqual(errors,[])
        finally:await router.cleanup()

    async def test_wake_and_stale_finals_cannot_write_or_cancel_a_valid_answer(self):
        class Socket:
            def __init__(self):self.messages=[]
            async def send_json(self,message):self.messages.append(message)
        class Router:
            channel='wake'
            async def set_channel(self,channel,epoch):self.channel=channel
        socket=Socket();router=Router();protocol=VoiceProtocol(input_epoch=3,speech_id=1)
        started=asyncio.Event();finish=asyncio.Event();writes=[]
        async def apply(*args):
            started.set();await finish.wait();writes.append(args[2]);return {'draft':{},'reply':'Next question'}
        assistant=FormAssistant(socket,'d','s','zh',lambda *a:None,apply,router,protocol)
        assistant.broadcast_interruption=AsyncMock()
        assistant.push_frame=AsyncMock()
        assistant.phase='speaking'
        async def transcript(text,epoch,channel):
            await assistant.process_frame(TurnTranscript(text=text,user_id='u',timestamp='',input_epoch=epoch,channel=channel),FrameDirection.DOWNSTREAM)
        await transcript('旁边电视在讲话',3,'wake')
        self.assertEqual(socket.messages,[])
        await transcript('你好助手',3,'wake')
        self.assertEqual(assistant.phase,'stopping')
        await transcript('旧播报尾音，我叫错误名字',3,'answer')
        self.assertEqual(writes,[])
        async def ack(kind,epoch):
            await assistant.process_frame(InputTransportMessageFrame(message={'type':kind,'epoch':epoch,'speech_id':1}),FrameDirection.DOWNSTREAM)
        await ack('playback_stopped',0)
        self.assertEqual(assistant.phase,'stopping')
        await ack('playback_stopped',1)
        self.assertEqual(assistant.phase,'listening')
        current=protocol.input_epoch
        await transcript('张琳',current,'answer')
        await started.wait()
        pending=assistant.pending
        await transcript('旁边又有人讲话',current,'answer')
        self.assertIs(assistant.pending,pending)
        self.assertFalse(pending.cancelled())
        finish.set();await pending
        self.assertEqual(writes,['张琳'])
        self.assertEqual([message['text'] for message in socket.messages if message.get('type')=='transcript'],['张琳'])
        await assistant.cleanup()

    async def test_only_matching_completed_playback_can_open_answer(self):
        socket=type('Socket',(),{'send_json':AsyncMock()})()
        protocol=VoiceProtocol(output_epoch=4,speech_id=8)
        assistant=FormAssistant(socket,'d','s','en',lambda *a:None,AsyncMock(),protocol=protocol)
        assistant.phase='speaking';assistant.arm_answer=AsyncMock()
        async def ack(epoch,speech):
            await assistant.process_frame(InputTransportMessageFrame(message={'type':'playback_ended','epoch':epoch,'speech_id':speech}),FrameDirection.DOWNSTREAM)
        await ack(4,8);await ack(3,8);await ack(4,7)
        assistant.arm_answer.assert_not_awaited()
        protocol.completed.add((4,8));await ack(4,8)
        assistant.arm_answer.assert_awaited_once()
        await assistant.cleanup()

    async def test_serializer_cancels_old_output_and_versions_microphone_packets(self):
        protocol=VoiceProtocol();serializer=VoiceSerializer(protocol)
        audio=OutputAudioRawFrame(audio=bytes(20),sample_rate=24000,num_channels=1)
        self.assertIsNone(await serializer.serialize(audio))
        await serializer.serialize(OutputTransportMessageFrame(message={'type':'audio_begin','epoch':0,'speech_id':5}))
        packet=await serializer.serialize(audio)
        self.assertEqual(packet[:8],bytes(4)+(5).to_bytes(4,'little'))
        protocol.output_epoch=1
        self.assertIsNone(await serializer.serialize(audio))
        frame=await serializer.deserialize((9).to_bytes(4,'little')+bytes(640))
        self.assertEqual(frame.input_epoch,9)
        self.assertEqual(len(frame.audio),640)
        self.assertIsNone(await serializer.deserialize('[]'))
        self.assertIsNone(await serializer.deserialize('{"type":"playback_stopped","epoch":-1,"speech_id":0}'))
