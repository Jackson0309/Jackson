import asyncio,copy,unittest
from unittest.mock import AsyncMock
from pipecat.frames.frames import TTSStartedFrame,OutputAudioRawFrame
from pipecat.processors.frame_processor import FrameDirection
from server import speech_policy,workflow
from server.domain import FLOOD,INTAKE,validate_patch
from server.voice import FormAssistant,VoiceProtocol,SpeechMarkers
from server.turn_audio import TurnTranscript,TurnInterim
class CompletionPolicy(unittest.TestCase):
 def test_address_lead_in_has_no_business_side_effect(self):
  d=dict(id='t',version=0,service=INTAKE,fields={},provenance={},documents=[],status='draft',messages=[],intent={})
  workflow.initialize(d,prefill_gate=True);workflow.select_service(d,FLOOD);d['workflow']['prefill_consent']=True
  d['fields']={'citizen_id':'9876543210123','applicant_name':'Niran','phone':'0812345678'}
  before=copy.deepcopy(d['fields'])
  r=asyncio.run(workflow.process_turn(d,'My address is...','en','live',{}))
  self.assertEqual(d['fields'],before);self.assertNotIn('address',d['fields']);self.assertIn('continue with the full address',r['reply'])
  self.assertEqual(d['workflow'].get('checks',{}).get('area'),None)
  self.assertIn('address',validate_patch({'address':'My address is...'},FLOOD)[1])
 def test_mobile_prefix_needs_ten_digits(self):
  for value in ('081234567','08123456789','+6681234567'):
   self.assertIn('phone',validate_patch({'phone':value},FLOOD)[1])
  for value in ('0812345678','021234567','+66812345678'):
   self.assertFalse(validate_patch({'phone':value},FLOOD)[1])
 def test_sensitive_fields_allow_three_second_pause(self):
  for key in ('phone','citizen_id','address'):
   self.assertEqual(speech_policy.answer_pause({'service':FLOOD,'fields':{},'workflow':{'errors':{key:'test'}}}),3.0)
  self.assertTrue(speech_policy.incomplete_address('ที่อยู่คือ...'))
class FragmentBuffer(unittest.IsolatedAsyncioTestCase):
 def make(self,key):
  d={'service':FLOOD,'fields':{},'workflow':{'errors':{key:'pending'}}}
  router=type('Router',(),{'channel':'answer','set_channel':AsyncMock()})()
  apply=AsyncMock(return_value={'draft':d,'reply':'Next question'})
  a=FormAssistant(type('Socket',(),{'send_json':AsyncMock()})(),'d','s','en',lambda *args:d,apply,router,VoiceProtocol(input_epoch=1))
  a.phase='listening';a.push_frame=AsyncMock();a.broadcast_interruption=AsyncMock()
  return a,apply
 async def final(self,a,text):
  await a.process_frame(TurnTranscript(text=text,user_id='u',timestamp='',input_epoch=1,channel='answer'),FrameDirection.DOWNSTREAM)
 async def test_phone_fragments_are_one_answer(self):
  a,apply=self.make('phone')
  try:
   await self.final(a,'08123');apply.assert_not_awaited();self.assertEqual(a.phase,'listening')
   await self.final(a,'45678');await a.pending
   self.assertEqual(apply.await_args.args[2],'0812345678');self.assertEqual(apply.await_count,1)
  finally:await a.cleanup()
 async def test_address_intro_waits_for_real_address(self):
  a,apply=self.make('address')
  try:
   await self.final(a,'My address is...');apply.assert_not_awaited()
   address='88/12 Anusawari, Bang Khen, Bangkok'
   await self.final(a,address);await a.pending
   self.assertEqual(apply.await_args.args[2],address)
  finally:await a.cleanup()
 async def test_interrupt_clears_short_number_and_timer(self):
  a,apply=self.make('citizen_id')
  try:
   await self.final(a,'12345');await a.interrupt()
   self.assertIsNone(a.fragment_key);self.assertIsNone(a.fragment_timer);apply.assert_not_awaited()
  finally:await a.cleanup()
 async def test_one_second_silence_only_once_per_reply(self):
  p=VoiceProtocol();p.contexts={'a':(0,1),'b':(0,1),'c':(0,2)}
  markers=SpeechMarkers(p);markers.push_frame=AsyncMock()
  try:
   for context in ('a','b','c'):
    await markers.process_frame(TTSStartedFrame(context_id=context),FrameDirection.DOWNSTREAM)
   silence=[c.args[0] for c in markers.push_frame.await_args_list if isinstance(c.args[0],OutputAudioRawFrame)]
   self.assertEqual(len(silence),2)
   self.assertTrue(all(f.audio==bytes(48000) and f.sample_rate==24000 for f in silence))
  finally:await markers.cleanup()
