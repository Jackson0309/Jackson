import unittest
from unittest.mock import patch
from aiohttp import web,ClientSession
from aiohttp.test_utils import TestServer
from server import https_gateway
class HttpsGateway(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  async def upstream(request):
   if request.path=='/ws':
    ws=web.WebSocketResponse(compress=True);await ws.prepare(request)
    async for message in ws:
     if isinstance(message.data,bytes):await ws.send_bytes(message.data)
     else:await ws.send_str(message.data)
    return ws
   return web.Response(text='data: hello\n\n',content_type='text/event-stream')
  app=web.Application();app.router.add_route('*','/{path:.*}',upstream);self.upstream=TestServer(app);await self.upstream.start_server()
  self.patch=patch.object(https_gateway,'UPSTREAM',str(self.upstream.make_url('')).rstrip('/'));self.patch.start()
  gateway=web.Application();gateway.cleanup_ctx.append(https_gateway.lifecycle);gateway.router.add_route('*','/{path:.*}',https_gateway.forward)
  self.gateway=TestServer(gateway);await self.gateway.start_server();self.client=ClientSession()
 async def asyncTearDown(self):
  await self.client.close();await self.gateway.close();await self.upstream.close();self.patch.stop()
 async def test_ws_regenerates_compression_headers_and_relays_binary(self):
  async with self.client.ws_connect(self.gateway.make_url('/ws'),compress=15) as ws:
   await ws.send_str('hello');self.assertEqual((await ws.receive(timeout=3)).data,'hello')
   await ws.send_bytes(b'pcm-test');self.assertEqual((await ws.receive(timeout=3)).data,b'pcm-test')
 async def test_sse_and_microphone_permission_header(self):
  async with self.client.get(self.gateway.make_url('/events')) as result:
   self.assertEqual(await result.text(),'data: hello\n\n');self.assertEqual(result.headers['Permissions-Policy'],'microphone=(self)')
 async def test_foreign_origin_is_rejected(self):
  async with self.client.get(self.gateway.make_url('/events'),headers={'Origin':'https://foreign.invalid'}) as result:self.assertEqual(result.status,403)
