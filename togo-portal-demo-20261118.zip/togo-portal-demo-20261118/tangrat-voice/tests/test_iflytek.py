import asyncio
import base64
import json
import unittest
from unittest.mock import patch
from urllib.parse import urlsplit,parse_qs
from pipecat.processors.frame_processor import FrameDirection
from server.configuration import DEFAULTS
from server.iflytek import signed_url,asr_packet,TranscriptAccumulator,IflytekSTT,synthesize,tts_request,ProviderError
from server.turn_audio import TurnAudioFrame,TurnTranscript


CONFIG=dict(DEFAULTS,iflytek_app_id='synthetic-app',iflytek_api_key='synthetic-key',iflytek_api_secret='synthetic-secret')


class Socket:
    def __init__(self):self.messages=asyncio.Queue();self.sent=[];self.closed=False
    async def send(self,message):self.sent.append(json.loads(message))
    async def close(self):self.closed=True
    def __aiter__(self):return self
    async def __anext__(self):return await self.messages.get()


class IflytekTests(unittest.IsolatedAsyncioTestCase):
    async def test_auth_and_each_model_request_matches_its_protocol(self):
        url=signed_url('wss://iat-api.xfyun.cn/v2/iat',CONFIG,'Thu, 05 Nov 2026 00:00:00 GMT')
        query=parse_qs(urlsplit(url).query)
        self.assertEqual(query['host'],['iat-api.xfyun.cn'])
        self.assertIn('api_key="synthetic-key"',base64.b64decode(query['authorization'][0]).decode())
        self.assertNotIn('synthetic-secret',url)
        for lang,language in [('en','en_us'),('zh','zh_cn')]:
            packet=asr_packet(CONFIG,lang,bytes(1280),0,0)
            self.assertEqual(packet['business']['language'],language)
            self.assertEqual(len(base64.b64decode(packet['data']['audio'])),1280)
        for model,domain,language in [('spark_asr_v2','spark_asr_v2','zh_cn'),('mul_cn','slm','mul_cn')]:
            packet=asr_packet(dict(CONFIG,iflytek_asr_model=model),'en',bytes(1280),0,0)
            self.assertEqual(packet['parameter']['iat']['domain'],domain)
            self.assertEqual(packet['parameter']['iat']['language'],language)
            self.assertEqual(packet['payload']['audio']['sample_rate'],16000)

    async def test_dynamic_replacement_and_encoded_finals_do_not_duplicate_words(self):
        accumulator=TranscriptAccumulator()
        def part(sn,text,**extra):return {'sn':sn,'ws':[{'cw':[{'w':text}]}],**extra}
        self.assertEqual(accumulator.accept({'data':{'result':part(1,'张林'),'status':1}}),('张林',False))
        self.assertEqual(accumulator.accept({'data':{'result':part(2,'张琳',pgs='rpl',rg=[1,1]),'status':2}}),('张琳',True))
        final=base64.b64encode(json.dumps(part(0,'flood relief',ls=True)).encode()).decode()
        self.assertEqual(TranscriptAccumulator().accept({'header':{'code':0,'status':2},'payload':{'result':{'text':final}}}),('flood relief',True))
        with self.assertRaises(ProviderError) as error:accumulator.accept({'header':{'code':11200,'message':'secret upstream URL'}})
        self.assertNotIn('secret',str(error.exception))

    async def test_asr_renews_completed_wake_session_and_rejects_prior_epoch_audio(self):
        sockets=[]
        async def connector(*args,**kwargs):
            socket=Socket();sockets.append(socket);return socket
        errors=[]
        async def notify(text):errors.append(text)
        router=IflytekSTT(CONFIG,'zh',notify,connector)
        emitted=[]
        async def push(frame,direction=FrameDirection.DOWNSTREAM):emitted.append(frame)
        router.push_frame=push
        try:
            await router.set_channel('wake',1)
            await router.process_frame(TurnAudioFrame(audio=b'\x01\x02'*640,sample_rate=16000,num_channels=1,input_epoch=1),FrameDirection.DOWNSTREAM)
            await asyncio.sleep(.07)
            self.assertTrue(sockets[0].sent)
            final={'code':0,'data':{'status':2,'result':{'sn':0,'ws':[{'cw':[{'w':'你好助手'}]}]}}}
            await sockets[0].messages.put(json.dumps(final))
            for _ in range(15):await asyncio.sleep(0)
            self.assertEqual(len(sockets),2)
            self.assertTrue(sockets[0].closed)
            transcript=next(frame for frame in emitted if isinstance(frame,TurnTranscript))
            self.assertEqual((transcript.text,transcript.input_epoch,transcript.channel),('你好助手',1,'wake'))
            await router.set_channel('answer',2)
            before=router.audio_bytes['answer']
            await router.process_frame(TurnAudioFrame(audio=bytes(640),sample_rate=16000,num_channels=1,input_epoch=1),FrameDirection.DOWNSTREAM)
            self.assertEqual(router.audio_bytes['answer'],before)
            self.assertEqual(router.audio_bytes['stale'],640)
            self.assertTrue(sockets[1].closed)
            self.assertEqual(errors,[])
        finally:await router.cleanup()
        self.assertTrue(all(socket.closed for socket in sockets))

    async def test_tts_streams_pcm_for_both_products_and_closes_on_cancellation(self):
        for model,rate in [('tts',16000),('super_tts',24000)]:
            socket=Socket();config=dict(CONFIG,iflytek_tts_model=model)
            async def connector(*args,**kwargs):return socket
            if model=='tts':message={'code':0,'data':{'status':2,'audio':base64.b64encode(bytes(640)).decode()}}
            else:message={'header':{'code':0,'status':2},'payload':{'audio':{'status':2,'audio':base64.b64encode(bytes(640)).decode()}}}
            await socket.messages.put(json.dumps(message))
            result=[chunk async for chunk in synthesize(config,'您好','zh',connector)]
            self.assertEqual(result,[(rate,bytes(640))])
            self.assertTrue(socket.closed)
            endpoint,actual_rate,request=tts_request(config,'您好','zh')
            self.assertEqual(actual_rate,rate)
            self.assertTrue(socket.sent)
        socket=Socket()
        async def connector(*args,**kwargs):return socket
        async def consume():
            async for _ in synthesize(CONFIG,'test','en',connector):pass
        task=asyncio.create_task(consume());await asyncio.sleep(0)
        task.cancel();await asyncio.gather(task,return_exceptions=True)
        self.assertTrue(socket.closed)

    async def test_actual_tts_pipeline_keeps_audio_markers_ordered_and_resamples(self):
        from server import voice
        from starlette.websockets import WebSocketState
        from pipecat.processors.frame_processor import FrameProcessor
        class Router(FrameProcessor):
            channel='closed'
            def __init__(self,*args):super().__init__()
            async def set_channel(self,channel,epoch):self.channel=channel
            async def process_frame(self,frame,direction):
                await super().process_frame(frame,direction);await self.push_frame(frame,direction)
        class Client:
            headers={'origin':'http://testserver'}
            query_params={'lang':'zh','protocol':'2'}
            application_state=WebSocketState.CONNECTED
            client_state=WebSocketState.CONNECTED
            def __init__(self):self.input=asyncio.Queue();self.output=asyncio.Queue()
            async def receive(self):return await self.input.get()
            async def send_json(self,message):await self.output.put(message)
            async def send_text(self,message):await self.output.put(json.loads(message))
            async def send_bytes(self,message):await self.output.put(message)
            async def close(self):self.application_state=WebSocketState.DISCONNECTED
        async def audio(*args):
            # 100 ms of nonzero 16kHz PCM must reach the 24kHz client transport.
            yield 16000,b'\x00\x10'*1600
        config=dict(CONFIG,tts_provider='iflytek',iflytek_tts_model='tts',elevenlabs_key='synthetic')
        client=Client();workers={}
        async def apply(*args):raise AssertionError('No LLM expected')
        with patch.object(voice,'SeparatedSTT',Router),patch('server.iflytek.synthesize',audio):
            task=asyncio.create_task(voice.run_voice(client,'draft','sid',config,lambda *a:{'fields':{}},apply,workers))
            seen=[]
            try:
                async with asyncio.timeout(8):
                    while True:
                        message=await client.output.get();seen.append(message)
                        if isinstance(message,dict) and message.get('type')=='audio_end':break
                self.assertTrue(any(isinstance(message,bytes) and len(message)>8 for message in seen))
                begin=next(i for i,item in enumerate(seen) if isinstance(item,dict) and item.get('type')=='audio_begin')
                self.assertTrue(all(i>begin for i,item in enumerate(seen) if isinstance(item,bytes)))
                self.assertTrue(all(item[:8]==bytes(4)+(1).to_bytes(4,'little') for item in seen if isinstance(item,bytes)))
                await client.input.put({'type':'websocket.receive','text':json.dumps({'type':'playback_ended','epoch':0,'speech_id':1})})
                async with asyncio.timeout(5):
                    while True:
                        message=await client.output.get()
                        if isinstance(message,dict) and message.get('type')=='listening':break
            finally:
                await client.input.put({'type':'websocket.disconnect'})
                await asyncio.wait_for(task,8)
