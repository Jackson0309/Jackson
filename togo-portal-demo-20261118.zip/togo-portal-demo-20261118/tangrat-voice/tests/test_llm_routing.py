import unittest
from server import llm
from server.configuration import voice_ready,validate_update,DEFAULTS,SECRET_FIELDS
class LlmRouting(unittest.TestCase):
 def test_deepseek_uses_its_own_endpoint_and_key(self):
  c={**DEFAULTS,'llm_provider':'deepseek','deepseek_key':'test-deepseek','openrouter_key':'test-router'}
  self.assertEqual(llm.endpoint(c),'https://api.deepseek.com/chat/completions')
  self.assertEqual(llm.headers(c),{'Authorization':'Bearer test-deepseek'})
  self.assertEqual(llm.options(c),{'thinking':{'type':'disabled'}})
  self.assertIn('deepseek_key',SECRET_FIELDS)
 def test_voice_readiness_follows_selected_business_provider(self):
  c={**DEFAULTS,'llm_provider':'deepseek','deepseek_key':'test-deepseek','openrouter_key':'','elevenlabs_key':'test-speech'}
  self.assertTrue(voice_ready(c));c['deepseek_key']='';c['openrouter_key']='test-router'
  self.assertFalse(voice_ready(c))
 def test_previous_configuration_stays_compatible(self):
  c={'openrouter_key':'test-router','elevenlabs_key':'test-speech'}
  self.assertEqual(llm.endpoint(c),'https://openrouter.ai/api/v1/chat/completions')
  self.assertTrue(voice_ready(c));self.assertEqual(llm.options(c),{})
  self.assertEqual(validate_update(DEFAULTS,{'llm_provider':'deepseek'})['llm_provider'],'deepseek')
  with self.assertRaises(ValueError):validate_update(DEFAULTS,{'llm_provider':'unknown'})
