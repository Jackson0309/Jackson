import asyncio
import copy
import datetime as dt
import json
import unittest
from unittest.mock import AsyncMock, patch
import httpx

from server import workflow, business_clock
from server.domain import CHILD, INTAKE, validate_patch


def draft(service=CHILD):
    value={'id':'unit','service':INTAKE,'status':'draft','fields':{},'provenance':{},'documents':[],
           'version':0,'messages':[],'intent':{}}
    return workflow.initialize(value,service)


class ConversationDates(unittest.TestCase):
    reference=dt.date(2026,11,12)

    def turn(self,value,text,lang='zh',mode='rehearsal'):
        with patch.object(business_clock,'today',return_value=self.reference):
            return asyncio.run(workflow.process_turn(value,text,lang,mode,{}))

    def test_identity_and_help_preserve_intake_and_business_undo_history(self):
        for lang,question,answer in [('zh','你是谁','AI助手'),('en','Who are you?','AI assistant'),('th','คุณคือใคร','ผู้ช่วย AI')]:
            with self.subTest(lang=lang):
                value=draft(INTAKE);before=workflow.snapshot_business(value)
                result=self.turn(value,question,lang)
                self.assertIn(answer,result['reply'])
                self.assertEqual(before,workflow.snapshot_business(value))
                self.assertEqual(len(value['messages']),2)
                self.assertEqual(value['_event']['kind'],'answer')
                self.assertFalse(result['confirm_requested'])

    def test_explanation_never_becomes_name_or_moves_to_other_service(self):
        value=draft();before=workflow.snapshot_business(value)
        result=self.turn(value,'什么是监护人？')
        self.assertIn('家长或监护人',result['reply'])
        self.assertEqual(before,workflow.snapshot_business(value))
        self.assertEqual(value['fields'],{})
        self.assertEqual(value['workflow']['history'],[])

    def test_help_at_review_preserves_review_and_confirmation_state(self):
        value=draft();value['workflow']['state']='review';value['workflow']['review_confirmed']=True
        before=workflow.snapshot_business(value)
        self.turn(value,'你是谁')
        self.assertEqual(before,workflow.snapshot_business(value))
        self.assertTrue(value['workflow']['review_confirmed'])

    def test_service_explanation_does_not_select_or_switch_a_service(self):
        value=draft(INTAKE);before=workflow.snapshot_business(value)
        result=self.turn(value,'什么是儿童补贴？')
        self.assertIn('监护人',result['reply'])
        self.assertNotIn('演示',result['reply'])
        self.assertEqual(before,workflow.snapshot_business(value))

    def test_model_answer_is_read_only_even_with_injected_fields_and_service(self):
        value=draft();before=workflow.snapshot_business(value)
        directive={'action':'answer','topic':'capabilities','fields':{'guardian_name':'wrong'},'service':'water-bill-query','acknowledgement':'已经正式提交'}
        with patch.object(workflow,'interpret_live',new=AsyncMock(return_value=directive)):
            result=self.turn(value,'能跟我说说你的本领么','zh','live')
        self.assertEqual(before,workflow.snapshot_business(value))
        self.assertNotIn('正式提交',result['reply'])

    def test_relative_birthdate_answers_and_acknowledgements_in_three_languages(self):
        for lang,utterance in [('zh','昨天'),('zh','孩子是昨天出生的'),('en','Yesterday.'),('en','She was born yesterday'),('th','เกิดเมื่อวานค่ะ')]:
            with self.subTest(utterance=utterance):
                value=draft();value['fields']={'guardian_name':'Demo Parent','relationship':'mother','child_name':'Demo Baby'}
                result=self.turn(value,utterance,lang)
                self.assertEqual(value['fields']['child_birth_date'],'2026-11-11')
                self.assertEqual(value['fields']['guardian_name'],'Demo Parent')
                self.assertIn('2026',result['reply'])
                self.assertEqual(value['provenance']['child_birth_date']['reference_date'],'2026-11-12')

    def test_relative_date_without_date_question_is_not_recorded_as_name(self):
        value=draft();result=self.turn(value,'昨天')
        self.assertEqual(value['fields'],{})
        self.assertIn('哪一项资料',result['reply'])

    def test_explain_then_answer_keeps_same_pending_birth_question(self):
        value=draft();value['fields']={'guardian_name':'Demo Parent','relationship':'mother','child_name':'Demo Baby'}
        before=copy.deepcopy(value['fields'])
        answer=self.turn(value,'这个是农历还是阳历？')
        self.assertIn('公历',answer['reply']);self.assertEqual(before,value['fields'])
        self.turn(value,'前天')
        self.assertEqual(value['fields']['child_birth_date'],'2026-11-10')

    def test_relative_validation_handles_month_year_and_thai_digits(self):
        self.assertEqual(business_clock.relative_date('yesterday',dt.date(2027,1,1)),'2026-12-31')
        self.assertEqual(business_clock.relative_date('前天',dt.date(2026,3,1)),'2026-02-27')
        self.assertEqual(business_clock.relative_date('๓ วันที่แล้ว',self.reference),'2026-11-09')
        for language in ['昨天','yesterday','เมื่อวาน']:
            accepted,errors=validate_patch({'child_birth_date':language},CHILD,reference_date=self.reference)
            self.assertFalse(errors);self.assertEqual(accepted['child_birth_date'],'2026-11-11')
        accepted,errors=validate_patch({'child_birth_date':'明天'},CHILD,reference_date=self.reference)
        self.assertFalse(accepted);self.assertIn('child_birth_date',errors)

    def test_clock_uses_thailand_date_at_utc_boundary(self):
        self.assertEqual(business_clock.BANGKOK.utcoffset(None),dt.timedelta(hours=7))
        self.assertEqual(dt.datetime(2026,11,11,18,tzinfo=dt.timezone.utc).astimezone(business_clock.BANGKOK).date(),self.reference)

    def test_live_interpreter_receives_server_clock_and_answer_contract(self):
        response=httpx.Response(200,json={'choices':[{'message':{'content':json.dumps({'action':'answer','topic':'identity','fields':{}})}}]})
        client=AsyncMock();client.post.return_value=response
        manager=AsyncMock();manager.__aenter__.return_value=client
        with patch.object(workflow.httpx,'AsyncClient',return_value=manager):
            asyncio.run(workflow.interpret_live('Who are you?',draft(),'en',{'openrouter_key':'unit-key','llm_model':'unit-model'},self.reference))
        body=client.post.call_args.kwargs['json'];context=json.loads(body['messages'][1]['content'])
        self.assertEqual(context['reference_clock']['today'],'2026-11-12')
        self.assertEqual(context['reference_clock']['timezone'],'Asia/Bangkok')
        self.assertIn('action:answer',body['messages'][0]['content'])
