"""Semantic fallback at the consent gate, with server-owned mutation boundaries."""
import asyncio
import copy
import json
import unittest
from unittest.mock import AsyncMock, patch

import httpx

from server import workflow, service_intro
from server.domain import FLOOD, CHILD, INTAKE


def draft(service=FLOOD):
    return workflow.initialize(dict(service=INTAKE, status='draft', fields={},
        provenance={}, documents=[], version=0, messages=[], intent={}),
        service, prefill_gate=True)


def turn(value, text, directive, lang='en'):
    model=AsyncMock(return_value=directive)
    with patch.object(workflow, 'interpret_live', new=model):
        result=asyncio.run(workflow.process_turn(value, text, lang, 'live', {}))
    return result,model


class SemanticIntent(unittest.TestCase):
    def test_obvious_agreement_stays_on_the_fast_path(self):
        for lang,text in [('en',"Okay, let's start."),('zh','好的，开始吧。'),('th','ได้เลยค่ะ')]:
            value=draft()
            result,model=turn(value,text,{'action':'clarify'},lang)
            model.assert_not_awaited()
            self.assertEqual(value['workflow']['state'],'collecting')
            self.assertFalse(result['confirm_requested'])

    def test_unlisted_natural_agreement_reaches_the_model(self):
        for lang,text in [('en','You can ask me the questions now.'),
                          ('zh','你来问吧，我把资料告诉你。'),
                          ('th','ถามข้อมูลฉันได้เลยค่ะ พร้อมให้ข้อมูลแล้ว')]:
            value=draft()
            result,model=turn(value,text,{'action':'accept_prefill','fields':{}},lang)
            model.assert_awaited_once()
            self.assertTrue(value['workflow']['prefill_consent'])
            self.assertEqual(value['workflow']['state'],'collecting')
            self.assertNotIn(service_intro.summary(FLOOD,lang),result['reply'])

    def test_explanation_before_agreement_is_read_only_not_refusal(self):
        for lang,text in [('en',"I don't understand what I am agreeing to."),
                          ('zh','我还不明白，先给我讲讲需要什么资料。'),
                          ('th','ฉันยังไม่เข้าใจ ช่วยบอกก่อนได้ไหมว่าต้องใช้ข้อมูลอะไร')]:
            value=draft();before=workflow.snapshot_business(value)
            result,model=turn(value,text,{'action':'answer','topic':'service_info'},lang)
            self.assertEqual(before,workflow.snapshot_business(value))
            self.assertIn(service_intro.summary(FLOOD,lang),result['reply'])
            self.assertFalse(value['workflow'].get('prefill_declined'))

    def test_unlisted_role_question_gets_a_semantic_answer_at_the_gate(self):
        value=draft();before=workflow.snapshot_business(value)
        result,model=turn(value,'Could you tell me your role on this call?',
                         {'action':'answer','topic':'identity'})
        model.assert_awaited_once()
        self.assertIn('AI assistant',result['reply'])
        self.assertEqual(before,workflow.snapshot_business(value))

    def test_consent_and_facts_in_one_turn_are_validated_and_read_back(self):
        value=draft()
        result,model=turn(value,'Yes, you can begin. My name is Somchai Jaidee and my phone is 0812345678.',
            {'action':'accept_prefill','service':FLOOD,
             'fields':{'applicant_name':'Somchai Jaidee','phone':'0812345678'}})
        model.assert_awaited_once()
        self.assertEqual(value['fields'],{'applicant_name':'Somchai Jaidee','phone':'0812345678'})
        self.assertIn('Somchai Jaidee',result['reply']);self.assertIn('0812345678',result['reply'])
        self.assertEqual(value['workflow']['state'],'collecting')

    def test_facts_without_consent_do_not_start_collection_or_replay_intro(self):
        value=draft()
        result,model=turn(value,'My name is Somchai Jaidee.',
                         {'action':'provide','fields':{'applicant_name':'Somchai Jaidee'}})
        model.assert_awaited_once()
        self.assertEqual(value['fields'],{})
        self.assertFalse(value['workflow']['prefill_consent'])
        self.assertEqual(result['reply'],service_intro.ask('en'))

    def test_conditional_agreement_is_not_overridden_by_service_keywords(self):
        value=draft()
        result,model=turn(value,'I want to apply for flood relief, but only if my landlord agrees.',
                         {'action':'clarify','service':FLOOD,'fields':{}})
        model.assert_awaited_once()
        self.assertFalse(value['workflow']['prefill_consent'])
        self.assertEqual(value['fields'],{})
        self.assertEqual(result['reply'],service_intro.ask('en'))

    def test_natural_deferral_does_not_save_injected_facts(self):
        value=draft()
        result,model=turn(value,'I would rather do the questions another day.',
            {'action':'decline_prefill','fields':{'applicant_name':'wrong'}})
        model.assert_awaited_once()
        self.assertTrue(value['workflow']['prefill_declined'])
        self.assertEqual(value['fields'],{})
        self.assertNotIn(service_intro.summary(FLOOD,'en'),result['reply'])

    def test_semantic_consent_is_scoped_to_stage_and_service(self):
        for stage,service in [('service_intro',CHILD),('collecting',FLOOD),('review',FLOOD)]:
            value=draft();value['workflow']['state']=stage
            if stage!='service_intro':value['workflow']['prefill_consent']=True
            original=copy.deepcopy(value['fields'])
            result,model=turn(value,'You have my agreement to go ahead.',
                {'action':'accept_prefill','service':service,'fields':{'phone':'0999999999'}})
            model.assert_awaited_once()
            self.assertEqual(value['service'],FLOOD)
            self.assertEqual(value['fields'],original)
            self.assertFalse(result['confirm_requested'])
            if stage=='service_intro':self.assertFalse(value['workflow']['prefill_consent'])

    def test_new_service_still_needs_its_own_consent(self):
        value=draft()
        result,model=turn(value,'Could we look at support for a newborn baby instead?',
            {'action':'provide','service':CHILD,'fields':{'guardian_name':'wrong'}})
        model.assert_awaited_once()
        self.assertEqual(value['service'],CHILD)
        self.assertFalse(value['workflow']['prefill_consent'])
        self.assertEqual(value['fields'],{})
        self.assertEqual(value['workflow']['state'],'service_intro')

    def test_negated_or_explanatory_controls_reach_semantics_without_mutation(self):
        for text in ['Do not clear the form.', 'How do I delete my phone number?',
                     '不要清空表单。','先解释一下如何删除联系电话。',
                     'อย่าล้างแบบฟอร์มค่ะ','ถ้าล้างแบบฟอร์มจะเกิดอะไรขึ้นคะ']:
            value=draft();value['workflow'].update(prefill_consent=True,state='collecting')
            value['fields']={'applicant_name':'Somchai Jaidee','phone':'0812345678'}
            before=workflow.snapshot_business(value)
            result,model=turn(value,text,{'action':'answer','topic':'capabilities'})
            # Some obvious explanation questions are answered locally.
            self.assertEqual(before,workflow.snapshot_business(value))
            self.assertFalse(result['confirm_requested'])

    def test_model_cannot_authorize_clearing_all_drafts_or_submission(self):
        for directive in [{'action':'clear_all'}, {'action':'confirm'}]:
            value=draft();value['workflow'].update(prefill_consent=True,state='collecting')
            value['fields']={'phone':'0812345678'}
            value['workflow']['archives'][CHILD]={'fields':{'guardian_name':'Mali'}}
            result,_=turn(value,'Do whatever you think is best.',directive)
            self.assertEqual(value['fields'],{'phone':'0812345678'})
            self.assertIn(CHILD,value['workflow']['archives'])
            self.assertFalse(result['confirm_requested'])

    def test_explicit_keep_instruction_protects_data_from_a_bad_model_action(self):
        for text in ['Do not clear the form or remove my phone number.',
                     '不要清空表单，也别删除我的联系电话。',
                     'อย่าล้างแบบฟอร์มหรือลบเบอร์โทรของฉันค่ะ']:
            value=draft();value['workflow'].update(prefill_consent=True,state='collecting')
            value['fields']={'applicant_name':'Somchai Jaidee','phone':'0812345678'}
            before=workflow.snapshot_business(value)
            result,model=turn(value,text,{'action':'remove_fields','remove_fields':['applicant_name']})
            model.assert_not_awaited()
            self.assertEqual(before,workflow.snapshot_business(value))
            self.assertIn('unchanged',result['reply'])

    def test_mixed_negative_and_positive_correction_still_reaches_the_model(self):
        value=draft();value['workflow'].update(prefill_consent=True,state='collecting')
        value['fields']={'phone':'0812345678'}
        result,model=turn(value,"Don't use the old number; change it to 0899999999.",
                         {'action':'provide','fields':{'phone':'0899999999'}})
        model.assert_awaited_once()
        self.assertEqual(value['fields']['phone'],'0899999999')

    def test_provider_failure_leaves_business_data_and_consent_unchanged(self):
        value=draft();before=copy.deepcopy(value)
        with patch.object(workflow,'interpret_live',new=AsyncMock(side_effect=httpx.ReadTimeout('test timeout'))):
            with self.assertRaises(httpx.ReadTimeout):
                asyncio.run(workflow.process_turn(value,'You may ask your questions.','en','live',{}))
        self.assertEqual(value,before)

    def test_interpreter_receives_gate_context_and_accepts_semantic_actions(self):
        client=AsyncMock()
        client.post.return_value=httpx.Response(200,json={'choices':[{'message':{'content':json.dumps(
            {'action':'provide','prefill_decision':'accept','prefill_evidence':'Ask me your questions',
             'fields':{'applicant_name':'Somchai Jaidee'}})}}]})
        manager=AsyncMock();manager.__aenter__.return_value=client
        with patch.object(workflow.httpx,'AsyncClient',return_value=manager):
            result=asyncio.run(workflow.interpret_live('Ask me your questions.',draft(),'en',
                {'openrouter_key':'unit-key','llm_model':'unit-model'}))
        body=client.post.call_args.kwargs['json'];context=json.loads(body['messages'][1]['content'])
        self.assertEqual(context['workflow_state'],'service_intro')
        self.assertFalse(context['prefill_consent'])
        self.assertIn('prefill_decision',body['messages'][0]['content'])
        self.assertEqual(result['action'],'accept_prefill')

    def test_collection_ignores_spurious_prefill_metadata_without_losing_facts(self):
        for decision in ('accept','decline'):
            response={'action':'provide','prefill_decision':decision,'fields':{'phone':'0897654321'}}
            client=AsyncMock();client.post.return_value=httpx.Response(200,json={
                'choices':[{'message':{'content':json.dumps(response)}}]})
            manager=AsyncMock();manager.__aenter__.return_value=client
            with patch.object(workflow.httpx,'AsyncClient',return_value=manager):
                value=draft();value['workflow'].update(state='collecting',prefill_consent=True)
                result=asyncio.run(workflow.process_turn(value,'My phone number is 0897654321.',
                    'en','live',{'openrouter_key':'unit-key','llm_model':'unit-model'}))
            self.assertEqual(value['fields']['phone'],'0897654321')
            self.assertTrue(value['workflow']['prefill_consent'])
            self.assertFalse(result['confirm_requested'])

    def test_semantic_consent_cannot_quote_an_earlier_or_invented_agreement(self):
        for action in ('provide','accept_prefill'):
            response={'action':action,'prefill_decision':'accept','prefill_evidence':'Yes, please start',
                      'fields':{'phone':'0812345678'}}
            client=AsyncMock();client.post.return_value=httpx.Response(200,json={
                'choices':[{'message':{'content':json.dumps(response)}}]})
            manager=AsyncMock();manager.__aenter__.return_value=client
            with patch.object(workflow.httpx,'AsyncClient',return_value=manager):
                value=draft()
                result=asyncio.run(workflow.process_turn(value,'My phone number is 0812345678.',
                    'en','live',{'openrouter_key':'unit-key','llm_model':'unit-model'}))
            self.assertFalse(value['workflow']['prefill_consent'])
            self.assertEqual(value['fields'],{})
            self.assertFalse(result['confirm_requested'])
