import unittest,asyncio,copy
from unittest.mock import AsyncMock,patch
from server import address_normalization,workflow
from server.domain import FLOOD,INTAKE,validate_patch
class AddressNormalization(unittest.TestCase):
 def test_full_address_does_not_repeat_administrative_parts(self):
  original='88/12 Anusawari subdistrict, Bang Khen district, Bangkok'
  p=dict(address=original,subdistrict='Anusawari',district='Bang Khen',province='Bangkok')
  self.assertEqual(address_normalization.full_address(p),original)
  p=dict(address='12 Suthep Road',subdistrict='Suthep',district='Mueang Chiang Mai',province='Chiang Mai')
  self.assertEqual(address_normalization.full_address(p),'12 Suthep Road, Suthep, Mueang Chiang Mai, Chiang Mai')
 def test_both_chiang_mai_transcriptions_become_the_same_address(self):
  for district in ('Muang Chiang Mai','Mueang Chiang Mai','Mueng Chiang Mai','Muang Chiang Mai District'):
   p={'address':'12 Sothepp Road','province':'Chiang Mai','district':district,'subdistrict':'Sothepp Subdistrict'}
   accepted,changes=address_normalization.normalize(p,{})
   self.assertEqual(accepted,dict(address='12 Suthep Road',province='Chiang Mai',district='Mueang Chiang Mai',subdistrict='Suthep'))
   self.assertEqual(validate_patch(accepted,FLOOD)[1],{})
 def test_second_target_and_house_numbers_are_preserved(self):
  p=dict(address='88/13 Anusawaree, Bang Ken, Bangkok',province='Bangkok',district='Bang Ken',subdistrict='Anusawaree')
  result,_=address_normalization.normalize(p,{})
  self.assertEqual(result['address'],'88/13 Anusawari, Bang Khen, Bangkok')
  self.assertEqual(result['district'],'Bang Khen');self.assertEqual(result['subdistrict'],'Anusawari')
 def test_existing_different_places_and_insufficient_evidence_are_not_repaired(self):
  for p in (dict(province='Chiang Rai',district='Muang Chiang Mai',subdistrict='Sothepp'),dict(province='Chiang Mai',district='Mueang Chiang Rai',subdistrict='Sothepp'),dict(province='Bangkok',district='Bang Khae',subdistrict='Anusawaree'),dict(subdistrict='Sothepp'),dict(province='Chiang Mai',district='Mae Rim',address='12 Sothepp Road')):
   result,changes=address_normalization.normalize(p,{})
   self.assertEqual(result,p);self.assertEqual(changes,{})
 def test_missing_components_are_not_invented(self):
  p=dict(province='Chiang Mai',district='Muang Chiang Mai')
  result,_=address_normalization.normalize(p,{})
  self.assertNotIn('subdistrict',result);self.assertNotIn('address',result)
 def test_thai_fields_remain_thai(self):
  p=dict(province='เชียงใหม่',district='เมืองเชียงใหม่',subdistrict='สุเทพ',address='12 ถนนสุเทพ')
  self.assertEqual(address_normalization.normalize(p,{})[0],p)
 def test_workflow_normalizes_before_validation_and_preserves_transcript(self):
  d=dict(id='t',version=0,service=INTAKE,fields={},provenance={},documents=[],status='draft',messages=[],intent={})
  workflow.initialize(d,prefill_gate=True);workflow.select_service(d,FLOOD);d['workflow']['prefill_consent']=True
  text='My affected address is 12 Sothepp Road, Sothepp Subdistrict, Muang Chiang Mai District, Chiang Mai Province.'
  proposal=dict(action='provide',fields=dict(address='12 Sothepp Road',province='Chiang Mai',district='Muang Chiang Mai',subdistrict='Sothepp'))
  with patch.object(workflow,'interpret_live',new=AsyncMock(return_value=proposal)):
   result=asyncio.run(workflow.process_turn(d,text,'en','live',{}))
  self.assertEqual(result['errors'],{});self.assertEqual(d['workflow']['checks']['area']['code'],'not_open')
  self.assertEqual(d['messages'][-2]['content'],text)
  self.assertEqual(d['provenance']['district']['normalization']['before'],'Muang Chiang Mai')
