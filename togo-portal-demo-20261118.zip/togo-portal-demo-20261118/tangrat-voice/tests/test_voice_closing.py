import unittest
from unittest.mock import AsyncMock
from pipecat.frames.frames import InputTransportMessageFrame,EndFrame
from pipecat.processors.frame_processor import FrameDirection
from server.voice import FormAssistant,VoiceProtocol
from server import togo
class VoiceClosing(unittest.IsolatedAsyncioTestCase):
 async def test_goodbye_waits_for_matching_playback_end_and_does_not_listen_again(self):
  socket=type('Socket',(),{'send_json':AsyncMock()})()
  router=type('Router',(),{'set_channel':AsyncMock(),'channel':'wake'})()
  protocol=VoiceProtocol(output_epoch=3,speech_id=7);protocol.completed.add((3,7))
  assistant=FormAssistant(socket,'draft','session','en',lambda *a:{},AsyncMock(),router,protocol)
  assistant.phase='speaking';assistant.end_after_speech=True;assistant.last_prompt='Goodbye.'
  assistant.push_frame=AsyncMock();assistant.arm_answer=AsyncMock()
  stale=InputTransportMessageFrame(message={'type':'playback_ended','epoch':2,'speech_id':7})
  await assistant.process_frame(stale,FrameDirection.DOWNSTREAM)
  assistant.push_frame.assert_not_awaited();self.assertEqual(assistant.phase,'speaking')
  await assistant.process_frame(InputTransportMessageFrame(message={'type':'playback_ended','epoch':3,'speech_id':7}),FrameDirection.DOWNSTREAM)
  assistant.arm_answer.assert_not_awaited();router.set_channel.assert_awaited_once_with('closed',1)
  self.assertEqual(assistant.phase,'ended');self.assertTrue(any(call.args[0]['type']=='call_ended' for call in socket.send_json.await_args_list))
  self.assertIsInstance(assistant.push_frame.await_args.args[0],EndFrame)
class SpokenDates(unittest.TestCase):
 def test_birth_date_prompt_uses_words_not_storage_format(self):
  values={**togo.SAMPLES['passport']};values.pop('birthDate')
  for lang in ('en','zh','th'):
   prompt=togo.question(values,lang,'passport');self.assertNotIn('YYYY',prompt);self.assertNotIn('yyyy',prompt)
  self.assertIn('year, month and day',togo.question(values,'en','passport'))
  for field in togo.schema('passport'):
   if field['key']=='birthDate':self.assertNotIn('YYYY',field['en'])
