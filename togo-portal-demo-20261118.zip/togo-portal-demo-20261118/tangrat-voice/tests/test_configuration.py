import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient
from server import app as server
from server.configuration import LocalConfigStore, DEFAULTS, SECRET_FIELDS, ConfigurationError, voice_ready


class ConfigurationTests(unittest.TestCase):
    def test_encrypted_round_trip_and_fresh_process(self):
        with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ, {}, clear=True):
            path=Path(directory)/'credentials.local'
            store=LocalConfigStore(path)
            values=dict(DEFAULTS,openrouter_key='SYNTHETIC-CONFIG-TEST',iflytek_api_secret='SYNTHETIC-SECRET-TEST',asr_provider='iflytek')
            store.save(values)
            if os.name=='nt':
                self.assertNotIn('SYNTHETIC-',path.read_text())
            self.assertEqual(LocalConfigStore(path).load(),values)
            script="from server.configuration import LocalConfigStore; import sys; c=LocalConfigStore(sys.argv[1]).load(); assert c['openrouter_key']=='SYNTHETIC-CONFIG-TEST'; assert c['asr_provider']=='iflytek'; print('fresh process loaded successfully')"
            result=subprocess.run([sys.executable,'-c',script,str(path)],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('successfully',result.stdout)
            values.update({key:'' for key in SECRET_FIELDS})
            store.save(values)
            restored=LocalConfigStore(path).load()
            self.assertTrue(all(not restored[key] for key in SECRET_FIELDS))

    def test_corrupt_file_is_preserved_and_save_is_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'bad.local';path.write_text('corrupt')
            store=LocalConfigStore(path);store.load()
            self.assertTrue(store.error)
            with self.assertRaises(ConfigurationError):store.save(DEFAULTS)
            self.assertEqual(path.read_text(),'corrupt')

    def test_operator_masks_all_credentials_and_saves_before_applying(self):
        with tempfile.TemporaryDirectory() as directory:
            values=dict(DEFAULTS)
            store=LocalConfigStore(Path(directory)/'config.local')
            with patch.object(server,'config',values),patch.object(server,'config_store',store):
                client=TestClient(server.app)
                headers={'x-csrf-token':client.get('/api/bootstrap').json()['csrf']}
                body={key:'SYNTHETIC-'+key for key in SECRET_FIELDS}
                body.update(asr_provider='iflytek',tts_provider='iflytek')
                response=client.post('/api/operator',headers=headers,json=body)
                self.assertEqual(response.status_code,200)
                status=client.get('/api/operator').json()
                for key in SECRET_FIELDS:self.assertIs(status[key],True)
                self.assertNotIn('SYNTHETIC',json.dumps(status))
                self.assertTrue(client.get('/api/bootstrap').json()['providers']['realtime'])
                self.assertEqual(store.load()['iflytek_api_secret'],body['iflytek_api_secret'])
                self.assertEqual(client.post('/api/operator',headers=headers,json={'asr_provider':'bad'}).status_code,422)
                self.assertEqual(values['asr_provider'],'iflytek')
                with patch.object(store,'save',side_effect=ConfigurationError('write failed')):
                    self.assertEqual(client.post('/api/operator',headers=headers,json={'tts_provider':'elevenlabs'}).status_code,503)
                self.assertEqual(values['tts_provider'],'iflytek')
                self.assertEqual(client.get('/api/operator',headers={'host':'lan.example'}).status_code,403)

    def test_mixed_providers_require_only_the_selected_credentials(self):
        values=dict(DEFAULTS,openrouter_key='synthetic',elevenlabs_key='synthetic')
        self.assertTrue(voice_ready(values))
        values['tts_provider']='iflytek'
        self.assertFalse(voice_ready(values))
        values.update(iflytek_app_id='test',iflytek_api_key='test',iflytek_api_secret='test')
        self.assertTrue(voice_ready(values))
        values['elevenlabs_key']=''
        self.assertFalse(voice_ready(values))
        values['asr_provider']='iflytek'
        self.assertTrue(voice_ready(values))
