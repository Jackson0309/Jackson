import asyncio
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
from server import app as server
from server.domain import SAMPLE, FLOOD_SAMPLE, CHILD, FLOOD, INTAKE

class ApplicationFlow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        cls.old_db=server.DB
        server.DB=Path(cls.temp.name)/'test.sqlite3'
        with sqlite3.connect(server.DB) as con:
            con.execute('CREATE TABLE drafts(id TEXT PRIMARY KEY,owner TEXT,payload TEXT)')
            con.execute('CREATE TABLE sessions(session_hash TEXT PRIMARY KEY,payload TEXT)')
        con.close()

    @classmethod
    def tearDownClass(cls):
        server.DB=cls.old_db
        cls.temp.cleanup()

    def setUp(self):
        self.a=TestClient(server.app)
        self.b=TestClient(server.app)
        self.headers={'x-csrf-token':self.a.get('/api/bootstrap').json()['csrf']}
        self.bheaders={'x-csrf-token':self.b.get('/api/bootstrap').json()['csrf']}

    def create(self):
        r=self.a.post('/api/drafts',headers=self.headers,json={'consent':True,'service':CHILD})
        self.assertEqual(r.status_code,200)
        result=self.a.post('/api/drafts/'+r.json()['id']+'/turn',headers=self.headers,json={'text':'yes','mode':'rehearsal'}).json()
        return result['draft']

    def test_intent_confirmation_gates_fields_and_retains_separate_schemas(self):
        for text,service in [('我想办理洪灾补贴',FLOOD),('I need child subsidy',CHILD)]:
            draft=self.a.post('/api/drafts',headers=self.headers,json={'consent':True}).json()
            url='/api/drafts/'+draft['id']
            pending=self.a.post(url+'/turn',headers=self.headers,json={'text':text,'mode':'rehearsal','lang':'zh'}).json()['draft']
            self.assertEqual(pending['service'],INTAKE)
            self.assertEqual(pending['intent']['candidate'],service)
            self.assertEqual(pending['fields'],{})
            self.assertEqual(self.a.patch(url,headers=self.headers,json={'version':pending['version'],'fields':SAMPLE}).status_code,409)
            self.assertEqual(self.a.post(url+'/sample',headers=self.headers,json={}).status_code,409)
            confirmed=self.a.post(url+'/turn',headers=self.headers,json={'text':'确认','mode':'rehearsal'}).json()['draft']
            self.assertEqual(confirmed['service'],service)
            schema={field['key'] for field in confirmed['schema']}
            self.assertEqual('child_name' in schema,service==CHILD)
            self.assertEqual('damage_description' in schema,service==FLOOD)

    def test_ambiguous_unsupported_and_cancelled_intents_do_not_collect_data(self):
        draft=self.a.post('/api/drafts',headers=self.headers,json={'consent':True}).json()
        url='/api/drafts/'+draft['id']
        for text in ['我想办理儿童补贴和洪灾救助','pay a traffic fine','not flood relief']:
            result=self.a.post(url+'/turn',headers=self.headers,json={'text':text,'mode':'rehearsal'}).json()['draft']
            self.assertEqual(result['intent']['state'],'unresolved')
            self.assertEqual(result['fields'],{})
        self.a.post(url+'/turn',headers=self.headers,json={'text':'flood relief','mode':'rehearsal'})
        result=self.a.post(url+'/turn',headers=self.headers,json={'text':'cancel','mode':'rehearsal'}).json()['draft']
        self.assertIsNone(result['intent']['candidate'])

    def test_explicit_english_confirmations_accept_politeness_but_not_negated_qualifiers(self):
        for answer in ('Yes, confirm.','Yes, please.','I confirm.','Yes, but do not confirm.','Yes, cancel.'):
            draft=self.a.post('/api/drafts',headers=self.headers,json={'consent':True,'service':FLOOD}).json()
            result=self.a.post('/api/drafts/'+draft['id']+'/turn',headers=self.headers,
                               json={'text':answer,'lang':'en','mode':'rehearsal'}).json()['draft']
            self.assertEqual(result['service'],FLOOD if answer in ('Yes, confirm.','Yes, please.','I confirm.') else INTAKE)
            self.assertEqual(result['fields'],{})
        self.assertEqual(result['service'],INTAKE)

    def test_live_confirmation_extracts_original_utterance_only_after_confirmation(self):
        draft=self.a.post('/api/drafts',headers=self.headers,json={'consent':True}).json()
        url='/api/drafts/'+draft['id']
        from unittest.mock import AsyncMock
        with patch.object(server,'llm_extract',new=AsyncMock(return_value={'fields':{'applicant_name':'Maya Chen','child_name':'must be ignored'}})) as extract, patch.dict(server.config,{'openrouter_key':'test-placeholder'}):
            pending=self.a.post(url+'/turn',headers=self.headers,json={'text':'I need flood relief. My name is Maya Chen.','mode':'live'}).json()['draft']
            extract.assert_not_awaited()
            self.assertEqual(pending['fields'],{})
            result=self.a.post(url+'/turn',headers=self.headers,json={'text':'yes','mode':'live'}).json()['draft']
            extract.assert_awaited_once()
            self.assertEqual(result['fields'],{'applicant_name':'Maya Chen'})

    def test_flood_validation_submission_and_service_isolation(self):
        draft=self.a.post('/api/drafts',headers=self.headers,json={'consent':True,'service':FLOOD}).json()
        url='/api/drafts/'+draft['id']
        draft=self.a.post(url+'/turn',headers=self.headers,json={'text':'yes','mode':'rehearsal'}).json()['draft']
        result=self.a.patch(url,headers=self.headers,json={'version':draft['version'],'fields':{**FLOOD_SAMPLE,'child_name':'must not appear','flood_duration_days':'0'}}).json()
        self.assertIn('flood_duration_days',result['errors'])
        self.assertNotIn('child_name',result['draft']['fields'])
        draft=self.a.post(url+'/sample',headers=self.headers,json={}).json()
        self.a.post('/api/login',headers=self.headers,json={'name':'Flood demo','acknowledge_demo':True})
        result=self.a.post(url+'/submit',headers=self.headers,json={'version':draft['version'],'confirmed':True,'demo_acknowledged':True}).json()
        self.assertTrue(result['receipt'].startswith('DEMO-FLD-'))
        self.assertEqual(result['service'],FLOOD)
        self.assertEqual(self.a.post(url+'/submit',headers=self.headers,json={}).json()['receipt'],result['receipt'])

    def test_confirmed_submission_is_idempotent_and_immutable(self):
        draft=self.create(); url='/api/drafts/'+draft['id']
        self.assertEqual(self.b.get(url).status_code,404)
        self.assertEqual(self.a.post(url+'/submit',headers=self.headers,json={}).status_code,401)
        r=self.a.post(url+'/sample',headers=self.headers,json={}); draft=r.json()
        self.a.post('/api/login',headers=self.headers,json={'name':'Demo citizen','acknowledge_demo':True})
        self.assertEqual(self.a.post(url+'/submit',headers=self.headers,json={'version':draft['version']}).status_code,422)
        payload={'version':draft['version'],'confirmed':True,'demo_acknowledged':True}
        result=self.a.post(url+'/submit',headers=self.headers,json=payload).json()
        self.assertEqual(result['status'],'demo_submitted')
        self.assertTrue(result['receipt'].startswith('DEMO-CSG-'))
        repeated=self.a.post(url+'/submit',headers=self.headers,json=payload).json()
        self.assertEqual(repeated['receipt'],result['receipt'])
        self.assertEqual(self.a.patch(url,headers=self.headers,json={'version':result['version'],'fields':{'phone':'0999999999'}}).status_code,409)
        self.assertEqual(self.a.post(url+'/turn',headers=self.headers,json={'mode':'rehearsal','text':'change phone'}).status_code,409)

    def test_validation_and_stale_version(self):
        draft=self.create(); url='/api/drafts/'+draft['id']
        result=self.a.patch(url,headers=self.headers,json={'version':draft['version'],'fields':{'phone':'abc','child_birth_date':'2999-01-01','guardian_name':'Maya','status':'approved'}}).json()
        self.assertIn('phone',result['errors'])
        self.assertIn('child_birth_date',result['errors'])
        self.assertEqual(result['draft']['fields'],{'guardian_name':'Maya'})
        self.assertEqual(result['draft']['status'],'draft')
        self.assertEqual(self.a.patch(url,headers=self.headers,json={'version':0,'fields':SAMPLE}).status_code,409)

    def test_one_time_continuation_requires_login(self):
        draft=self.create(); url='/api/drafts/'+draft['id']
        link=self.a.post(url+'/link',headers=self.headers,json={}).json()
        self.assertEqual(link['delivery'],'copy_link_only')
        token=link['path'].split('claim=')[1]
        self.assertEqual(self.b.post('/api/claim',headers=self.bheaders,json={'token':token}).status_code,401)
        self.b.post('/api/login',headers=self.bheaders,json={'name':'Demo phone','acknowledge_demo':True})
        self.assertEqual(self.b.post('/api/claim',headers=self.bheaders,json={'token':token}).status_code,200)
        self.assertEqual(self.b.post('/api/claim',headers=self.bheaders,json={'token':token}).status_code,404)
        self.assertEqual(self.a.get(url).status_code,404)
        self.assertEqual(self.b.get(url).status_code,200)

    def test_csrf_origin_and_operator_protection(self):
        self.assertEqual(self.a.post('/api/drafts',json={'consent':True}).status_code,403)
        self.assertEqual(self.a.post('/api/drafts',headers={**self.headers,'origin':'https://evil.test'},json={'consent':True}).status_code,403)
        self.assertEqual(self.a.get('/api/operator',headers={'host':'other.example'}).status_code,403)
        self.assertEqual(self.a.post('/api/drafts',headers=self.headers,json={'consent':False}).status_code,400)

    def test_rehearsal_is_explicit_and_corrections_persist(self):
        draft=self.create(); url='/api/drafts/'+draft['id']
        result=self.a.post(url+'/turn',headers=self.headers,json={'mode':'rehearsal','text':'Maya Srisuk'}).json()
        self.assertEqual(result['mode'],'rehearsal')
        self.assertEqual(result['draft']['fields']['guardian_name'],'Maya Srisuk')
        result=self.a.post(url+'/turn',headers=self.headers,json={'mode':'rehearsal','text':'guardian_name=Maya Chen'}).json()
        self.assertEqual(result['draft']['fields']['guardian_name'],'Maya Chen')

    def test_no_credentials_is_not_silent_fake_ai(self):
        saved=server.config['openrouter_key']; saved_deepseek=server.config.get('deepseek_key',''); server.config['openrouter_key']=''; server.config['deepseek_key']=''
        try:
            draft=self.create()
            r=self.a.post('/api/drafts/'+draft['id']+'/turn',headers=self.headers,json={'mode':'live','text':'Maya'})
            self.assertEqual(r.status_code,503)
            self.assertEqual(self.a.get('/api/drafts/'+draft['id']).json()['fields'],{})
        finally:
            server.config['openrouter_key']=saved
            server.config['deepseek_key']=saved_deepseek

    def test_browser_session_survives_backend_memory_reset(self):
        draft=self.create()
        sid=self.a.cookies.get('tr_session')
        server.sessions.pop(sid)
        result=self.a.get('/api/drafts/'+draft['id'])
        self.assertEqual(result.status_code,200)
        self.assertEqual(result.json()['id'],draft['id'])

class VoiceCancellation(unittest.IsolatedAsyncioTestCase):
    async def test_actual_pipecat_transport_with_mock_providers(self):
        from server import voice
        from starlette.websockets import WebSocketState
        from pipecat.processors.frame_processor import FrameProcessor
        from pipecat.frames.frames import TTSAudioRawFrame,TTSSpeakFrame,TTSStartedFrame,TTSStoppedFrame
        routers=[]
        class FakeRouter(FrameProcessor):
            channel='closed'
            def __init__(self,*args):super().__init__();routers.append(self)
            async def set_channel(self,channel,epoch):self.channel=channel
            async def process_frame(self,frame,direction):
                await super().process_frame(frame,direction);await self.push_frame(frame,direction)
        def fake_tts(config,lang,protocol):
            class FakeTTS(FrameProcessor):
                async def process_frame(self,frame,direction):
                    await super().process_frame(frame,direction)
                    if isinstance(frame,TTSSpeakFrame):
                        context='test-'+str(protocol.speech_id)
                        protocol.contexts[context]=(protocol.output_epoch,protocol.speech_id)
                        await self.push_frame(TTSStartedFrame(context_id=context))
                        await self.push_frame(TTSAudioRawFrame(audio=bytes(1920),sample_rate=24000,num_channels=1,context_id=context))
                        await self.push_frame(TTSStoppedFrame(context_id=context))
                    else:await self.push_frame(frame,direction)
            return FakeTTS()
        class Socket:
            headers={'origin':'http://testserver'}
            query_params={'lang':'en','protocol':'2'}
            application_state=WebSocketState.CONNECTED
            client_state=WebSocketState.CONNECTED
            def __init__(self):self.input=asyncio.Queue();self.output=asyncio.Queue()
            async def receive(self):return await self.input.get()
            async def send_json(self,data):await self.output.put(data)
            async def send_text(self,data):await self.output.put(json.loads(data))
            async def send_bytes(self,data):await self.output.put(data)
            async def close(self):self.application_state=WebSocketState.DISCONNECTED
        socket=Socket();workers={}
        async def forbidden_apply(*a):raise AssertionError('No actual provider should be called')
        async def until(kind):
            seen=[]
            while True:
                message=await asyncio.wait_for(socket.output.get(),8);seen.append(message)
                if isinstance(message,dict) and message.get('type')==kind:return seen
        async def control(message):await socket.input.put({'type':'websocket.receive','text':json.dumps(message)})
        with patch.object(voice,'SeparatedSTT',FakeRouter),patch.object(voice,'make_tts',fake_tts):
            task=asyncio.create_task(voice.run_voice(socket,'test-draft','test-session',{'elevenlabs_key':'test-only-placeholder','voice_id':'test'},lambda *a:{'fields':{}},forbidden_apply,workers))
            try:
                seen=await until('audio_end')
                self.assertEqual(routers[0].channel,'wake')
                audio=next(message for message in seen if isinstance(message,bytes))
                self.assertEqual(int.from_bytes(audio[:4],'little'),0)
                self.assertEqual(int.from_bytes(audio[4:8],'little'),1)
                await control({'type':'playback_ended','epoch':0,'speech_id':1})
                await until('listening');self.assertEqual(routers[0].channel,'answer')
                await control({'type':'interrupt'})
                stopped=await until('input_state')
                self.assertTrue(any(isinstance(message,dict) and message.get('type')=='stop_required' for message in stopped))
                self.assertEqual(routers[0].channel,'closed')
                await control({'type':'playback_stopped','epoch':1,'speech_id':1})
                await until('listening');self.assertEqual(routers[0].channel,'answer')
            finally:
                await socket.input.put({'type':'websocket.disconnect'})
                await asyncio.wait_for(task,8)

    async def test_interrupt_cancels_pending_extraction_without_late_write(self):
        from server.voice import FormAssistant,VoiceSerializer,VoiceControl,WAKE
        from pipecat.frames.frames import InputAudioRawFrame,InputTransportMessageFrame
        class Socket:
            def __init__(self): self.messages=[]
            async def send_json(self,p): self.messages.append(p)
        socket=Socket(); writes=[]; started=asyncio.Event(); interrupted=[]
        async def slow_apply(*args):
            started.set()
            await asyncio.sleep(30)
            writes.append('bad late write')
        assistant=FormAssistant(socket,'draft','owner','en',lambda *a:None,slow_apply)
        async def interrupt_frame(): interrupted.append(True)
        assistant.broadcast_interruption=interrupt_frame
        assistant.pending=asyncio.create_task(assistant.respond('My name is Maya'))
        await started.wait()
        await assistant.interrupt()
        await asyncio.gather(assistant.pending,return_exceptions=True)
        self.assertTrue(assistant.pending.cancelled())
        self.assertEqual(writes,[])
        self.assertEqual(interrupted,[True])
        serializer=VoiceSerializer()
        self.assertIsInstance(await serializer.deserialize(bytes(4)+bytes(640)),InputAudioRawFrame)
        self.assertIsNone(await serializer.deserialize(bytes(3)))
        self.assertIsInstance(await serializer.deserialize('{"type":"interrupt"}'),VoiceControl)
        self.assertTrue(WAKE.search('Hey Assistant, change the date'))
        self.assertTrue(WAKE.search('Hey, assistant.'))
        self.assertTrue(WAKE.search('你好助手'))
        self.assertTrue(WAKE.search('你好，助手，把电话改一下'))
        self.assertFalse(WAKE.search('助手暂停'))

if __name__=='__main__':unittest.main(verbosity=2)
