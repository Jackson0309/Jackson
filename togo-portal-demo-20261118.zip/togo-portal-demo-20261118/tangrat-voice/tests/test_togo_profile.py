"""Run with TANGRAT_COUNTRY=togo; no external model or voice calls."""
import asyncio, copy, unittest
from unittest.mock import AsyncMock, patch
from server import domain, workflow, togo

def draft(service='duplicate'):
 return workflow.initialize(dict(service=domain.INTAKE,status='draft',fields={},provenance={},documents=[],version=0,messages=[],intent={}),service,prefill_gate=True)
def turn(d,text,proposal=None):
 with patch.object(workflow,'interpret_live',new=AsyncMock(return_value=proposal or {'action':'clarify'})):
  return asyncio.run(workflow.process_turn(d,text,'zh','live',{}))
@unittest.skipUnless(togo.ACTIVE,'Togo profile only')
class TogoProfile(unittest.TestCase):
 def test_catalog_and_duplicate_routing(self):
  self.assertEqual(set(domain.SERVICES),set(togo.ORDER))
  self.assertEqual(workflow.detect_services('我要申请国籍证明副本'),['duplicate'])
  self.assertEqual(workflow.detect_services('我要首次申请国籍证明'),['nationality'])
 def test_permission_precedes_collection(self):
  d=draft();self.assertEqual(d['workflow']['state'],'service_intro')
  turn(d,'我叫测试人',{'action':'provide','fields':{'applicantName':'测试人'}})
  self.assertEqual(d['fields'],{})
  turn(d,'好的，开始吧。');self.assertEqual(d['workflow']['state'],'collecting')
  turn(d,'新版',{'action':'provide','fields':{'certificateFormat':'new'}})
  self.assertEqual(d['fields']['certificateFormat'],'new')
 def test_conditional_fields_and_dormant_values(self):
  self.assertNotIn('holderName',domain.missing({'applicantRole':'self'},'duplicate'))
  self.assertIn('holderName',domain.missing({'applicantRole':'relative'},'duplicate'))
  values,errors=domain.validate_patch({'delivery':'post'},'duplicate',{'pickupLocation':'Demo centre'})
  self.assertEqual(values['pickupLocation'],'');self.assertFalse(errors)
  self.assertIn('postalAddress',domain.missing({'delivery':'post'},'duplicate'))
 def test_undo_and_service_archives(self):
  d=draft();turn(d,'好的，开始吧。')
  turn(d,'新版',{'action':'provide','fields':{'certificateFormat':'new'}})
  turn(d,'旧版',{'action':'provide','fields':{'certificateFormat':'old'}})
  turn(d,'撤销上一轮');self.assertEqual(d['fields']['certificateFormat'],'new')
  turn(d,'我要申请护照');self.assertEqual(d['service'],'passport');self.assertEqual(d['workflow']['state'],'service_intro')
  turn(d,'恢复国籍证明副本');self.assertEqual(d['service'],'duplicate');self.assertEqual(d['fields']['certificateFormat'],'new')
 def test_consult_does_not_write_fields(self):
  d=draft();before=copy.deepcopy(d['fields']);r=turn(d,'申请费用是多少？')
  self.assertIn('1,000',r['reply']);self.assertEqual(before,d['fields']);self.assertFalse(r['confirm_requested'])
 def test_materials_are_specific_to_service_branch(self):
  d=draft();d['fields']=togo.SAMPLES['duplicate'];self.assertFalse(togo.material_missing(d))
  d=draft('passport');d['fields']=togo.SAMPLES['passport'];self.assertEqual({s['key'] for s in togo.material_missing(d)},{'birth','nationality','photo'})
  d['fields']={**d['fields'],'applicationType':'renew'};self.assertIn('oldPassport',{s['key'] for s in togo.material_missing(d)})
 def test_fee_and_old_certificate(self):
  self.assertEqual(togo.fee('duplicate',togo.SAMPLES['duplicate'])['amount'],2000)
  self.assertIsNone(togo.fee('duplicate',{**togo.SAMPLES['duplicate'],'certificateFormat':'old'})['amount'])
  self.assertIsNone(togo.fee('courtfees',{})['amount'])
 def test_criminal_document_choices_and_dates(self):
  _,e=domain.validate_patch({'documentType':'passport'},'criminal',{'applicantStatus':'bornTogo'})
  self.assertIn('documentType',e)
  v,e=domain.validate_patch({'birthDate':'1990年1月2日','phone':'+228 90 00 00 00'},'passport')
  self.assertFalse(e);self.assertEqual(v['birthDate'],'1990-01-02');self.assertEqual(v['phone'],'+22890000000')
