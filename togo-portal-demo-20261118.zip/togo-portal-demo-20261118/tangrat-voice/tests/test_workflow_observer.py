import asyncio
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import AsyncMock, patch

from fastapi.testclient import TestClient
from server import app as server, observer, workflow
from server.domain import FLOOD, CHILD, INTAKE, SERVICES


class WorkflowObserver(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        cls.old_db=server.DB
        server.DB=Path(cls.temp.name)/'workflow.sqlite3'
        with server.db() as con:
            con.execute('CREATE TABLE drafts(id TEXT PRIMARY KEY,owner TEXT,payload TEXT)')
            con.execute('CREATE TABLE sessions(session_hash TEXT PRIMARY KEY,payload TEXT)')
            observer.init_tables(con)

    @classmethod
    def tearDownClass(cls):
        server.DB=cls.old_db
        cls.temp.cleanup()

    def setUp(self):
        self.phone=TestClient(server.app);self.screen=TestClient(server.app);self.other=TestClient(server.app)
        self.headers={'x-csrf-token':self.phone.get('/api/bootstrap').json()['csrf']}
        self.screen_headers={'x-csrf-token':self.screen.get('/api/bootstrap').json()['csrf']}
        self.other_headers={'x-csrf-token':self.other.get('/api/bootstrap').json()['csrf']}
        observer.attempts.clear()
        self.draft=self.create()

    def create(self,service=INTAKE):
        response=self.phone.post('/api/drafts',headers=self.headers,json={'consent':True,'flow':workflow.MODEL,'service':service})
        self.assertEqual(response.status_code,200,response.text)
        draft=response.json()
        if service in SERVICES:
            draft=self.phone.post('/api/drafts/'+draft['id']+'/turn',headers=self.headers,json={'text':'yes please','mode':'rehearsal','lang':'en'}).json()['draft']
        return draft

    def turn(self,text,mode='rehearsal'):
        response=self.phone.post('/api/drafts/'+self.draft['id']+'/turn',headers=self.headers,json={'text':text,'mode':mode,'lang':'zh'})
        self.assertEqual(response.status_code,200,response.text)
        self.draft=response.json()['draft'];return self.draft

    def sample(self):
        response=self.phone.post('/api/drafts/'+self.draft['id']+'/sample',headers=self.headers,json={})
        self.assertEqual(response.status_code,200,response.text)
        self.draft=response.json();return self.draft

    def pair(self):
        code=self.phone.post('/api/drafts/'+self.draft['id']+'/observe-code',headers=self.headers,json={}).json()['code']
        response=self.screen.post('/api/observer/pair',headers=self.screen_headers,json={'code':code})
        self.assertEqual(response.status_code,200,response.text)
        return code

    def test_clear_intent_opens_overview_and_requires_prefill_permission(self):
        draft=self.turn('我想申请洪灾救助，我叫李明，电话是0812345678。')
        self.assertEqual(draft['workflow']['state'],'service_intro')
        self.assertEqual(draft['fields'],{})
        self.turn('yes please')
        draft=self.turn('我叫李明，电话是0812345678。')
        self.assertEqual(draft['service'],FLOOD)
        self.assertEqual(draft['workflow']['state'],'collecting')
        self.assertEqual(draft['fields']['applicant_name'],'李明')
        self.assertEqual(draft['fields']['phone'],'0812345678')
        self.assertNotIn('child_name',{f['key'] for f in draft['schema']})

    def test_retraction_undo_clear_and_restoration_follow_system_validation(self):
        self.turn('洪灾救助');self.turn('yes please');self.sample()
        original=dict(self.draft['fields'])
        self.assertEqual(self.draft['workflow']['state'],'review')
        self.turn('刚才的联系电话先撤回')
        self.assertEqual(self.draft['workflow']['state'],'collecting')
        self.assertNotIn('phone',self.draft['fields'])
        self.turn('撤销上一轮')
        self.assertEqual(self.draft['fields'],original)
        self.assertEqual(self.draft['workflow']['state'],'review')
        self.turn('把表单全部清空')
        self.assertEqual(self.draft['service'],FLOOD)
        self.assertEqual(self.draft['fields'],{})
        self.turn('撤销上一轮')
        self.assertEqual(self.draft['fields'],original)

    def test_switch_isolates_fields_auto_queries_and_restores_draft(self):
        self.turn('洪灾救助');self.turn('yes please');self.sample();original=dict(self.draft['fields'])
        self.turn('改办查询我的交通罚单')
        self.assertEqual(self.draft['service'],'traffic-fines-query')
        self.assertEqual(self.draft['workflow']['state'],'service_intro')
        self.turn('yes please');self.turn('query_subject=Demo self')
        self.assertEqual(self.draft['workflow']['state'],'completed')
        self.assertEqual(set(self.draft['fields']),{'query_subject'})
        self.assertEqual(self.draft['workflow']['result']['mode'],'simulation_only')
        self.assertIn(FLOOD,self.draft['workflow']['archives'])
        self.turn('恢复洪灾救助申请')
        self.assertEqual(self.draft['fields'],original)
        self.assertEqual(self.draft['workflow']['state'],'review')

    def test_cancel_keeps_draft_and_explicit_clear_all_removes_it(self):
        self.turn('洪灾救助');self.turn('yes please');self.sample();original=dict(self.draft['fields'])
        self.turn('取消办理')
        self.assertEqual(self.draft['service'],INTAKE)
        self.assertEqual(self.draft['fields'],{})
        self.assertIn(FLOOD,self.draft['workflow']['archives'])
        self.turn('恢复之前的草稿')
        self.assertEqual(self.draft['fields'],original)
        self.turn('取消办理');self.turn('清空所有事项草稿')
        self.assertEqual(self.draft['workflow']['archives'],{})
        self.assertEqual(self.draft['workflow']['state'],'intent')

    def test_navigation_words_do_not_advance_or_fill_a_field(self):
        self.turn('洪灾救助');self.turn('yes please')
        for text in ('下一步','返回上一步','next step','yes'):
            self.turn(text)
            self.assertEqual(self.draft['fields'],{})
            self.assertEqual(self.draft['workflow']['state'],'collecting')

    def test_ambiguous_service_does_not_choose_a_branch(self):
        self.turn('我想办洪灾救助和儿童补贴')
        self.assertEqual(self.draft['service'],INTAKE)
        self.assertEqual(self.draft['fields'],{})
        self.turn('我要申请驾照')
        self.assertEqual(self.draft['service'],INTAKE)

    def test_missing_fields_do_not_undo_a_clear_service_intent(self):
        result={'action':'clarify','service':FLOOD,'fields':{'applicant_name':'มาลี ใจดี','phone':'0812345678'}}
        with patch.object(workflow,'interpret_live',new=AsyncMock(return_value=result)):
            self.turn('ต้องการลงทะเบียนช่วยเหลือน้ำท่วม ชื่อมาลี ใจดี','live')
        self.assertEqual(self.draft['service'],FLOOD)
        self.assertEqual(self.draft['workflow']['state'],'service_intro')
        self.assertEqual(self.draft['fields'],{})
        with patch.object(workflow,'interpret_live',new=AsyncMock(return_value={'action':'clarify','service':None,'fields':{}})):
            self.turn('Instead, check my traffic fines.','live')
        self.assertEqual(self.draft['service'],'traffic-fines-query')
        self.assertEqual(self.draft['workflow']['state'],'service_intro')
        self.turn('yes please');self.turn('query_subject=Demo self')
        self.assertEqual(self.draft['workflow']['state'],'completed')

    def test_trailing_negation_does_not_select_an_unwanted_service(self):
        self.assertEqual(workflow.detect_services('Flood relief is not what I want.'),[])
        self.assertEqual(workflow.detect_services('洪灾救助不是我想办的。'),[])

    def test_all_ten_schemas_and_system_completion_are_available(self):
        self.assertEqual(len(SERVICES),10)
        for service in SERVICES:
            with self.subTest(service=service):
                self.draft=self.create(service)
                self.assertEqual(self.draft['service'],service)
                self.sample()
                self.assertEqual(self.draft['missing'],[])
                self.assertEqual(self.draft['workflow']['state'],'completed' if SERVICES[service].get('mode')=='query' else 'review')
                self.assertTrue(all(f['zh'] and f['en'] and f['th'] for f in self.draft['schema']))

    def test_invalid_correction_blocks_review_until_fixed(self):
        self.turn('洪灾救助');self.turn('yes please');self.sample();self.turn('phone=bad')
        self.assertIn('phone',self.draft['workflow']['errors'])
        self.assertEqual(self.draft['workflow']['state'],'collecting')
        self.turn('phone=0999999999')
        self.assertEqual(self.draft['workflow']['state'],'review')

    def test_model_cannot_authorize_submit_or_add_non_schema_fields(self):
        self.turn('洪灾救助');self.turn('yes please');self.sample()
        with patch.object(workflow,'interpret_live',new=AsyncMock(return_value={'action':'confirm','fields':{}})):
            self.turn('请根据模型自行处理','live')
        self.assertEqual(self.draft['status'],'draft')
        self.assertNotIn('receipt',self.draft)
        with patch.object(workflow,'interpret_live',new=AsyncMock(return_value={'action':'provide','fields':{'status':'demo_submitted','bank_account':'forbidden','phone':'0999999999'}})):
            self.turn('修改信息','live')
        self.assertEqual(self.draft['status'],'draft')
        self.assertNotIn('bank_account',self.draft['fields'])

    def test_final_voice_confirmation_requires_login_and_is_explicit(self):
        self.turn('洪灾救助');self.turn('yes please');self.sample();self.turn('确认')
        self.assertEqual(self.draft['status'],'draft')
        self.turn('确认演示提交')
        self.assertEqual(self.draft['status'],'draft')
        self.phone.post('/api/login',headers=self.headers,json={'name':'Demo presenter','acknowledge_demo':True})
        self.turn('确认演示提交')
        self.assertEqual(self.draft['status'],'demo_submitted')
        self.assertEqual(self.draft['workflow']['state'],'completed')
        self.assertTrue(self.draft['receipt'].startswith('DEMO-FLD-'))
        self.assertEqual(self.draft['workflow']['history'],[])

    def test_pair_is_single_use_and_observer_cannot_write_or_claim_ownership(self):
        self.turn('洪灾救助');self.turn('yes please');code=self.pair()
        observed=self.screen.get('/api/observer/snapshot').json()
        self.assertEqual(observed['snapshot']['id'],self.draft['id'])
        encoded=json.dumps(observed)
        for key in ('claim_hash','claim_expiry','owner_hash','openrouter_key','history','provenance'):
            self.assertNotIn('"'+key+'"',encoded)
        self.assertEqual(self.screen.get('/api/drafts/'+self.draft['id']).status_code,404)
        self.assertEqual(self.screen.patch('/api/drafts/'+self.draft['id'],headers=self.screen_headers,json={'version':self.draft['version'],'fields':{'phone':'0999999999'}}).status_code,404)
        self.assertEqual(self.other.get('/api/observer/snapshot').status_code,403)
        self.assertEqual(self.other.post('/api/observer/pair',headers=self.other_headers,json={'code':code}).status_code,403)

    def test_observer_events_are_ordered_atomic_and_survive_memory_reset(self):
        self.turn('洪灾救助');self.turn('yes please');self.pair();self.sample();self.turn('删除电话')
        data=self.screen.get('/api/observer/snapshot').json()
        self.assertEqual(data['snapshot']['state'],'collecting')
        self.assertNotIn('phone',data['snapshot']['fields'])
        seqs=[e['seq'] for e in data['events']]
        self.assertEqual(seqs,list(range(1,len(seqs)+1)))
        self.assertEqual(data['events'][-1]['changes']['phone']['after'],None)
        sid=self.screen.cookies.get('tr_session');server.sessions.pop(sid)
        again=self.screen.get('/api/observer/snapshot').json()
        self.assertEqual(again['snapshot']['event_seq'],data['snapshot']['event_seq'])

    def test_expired_codes_and_revoked_grants_do_not_reveal_snapshot(self):
        code=self.phone.post('/api/drafts/'+self.draft['id']+'/observe-code',headers=self.headers,json={}).json()['code']
        with server.db() as con:con.execute('UPDATE observe_codes SET expires=0 WHERE draft_id=?',(self.draft['id'],))
        self.assertEqual(self.screen.post('/api/observer/pair',headers=self.screen_headers,json={'code':code}).status_code,403)
        self.pair()
        self.screen.delete('/api/observer/session',headers=self.screen_headers)
        self.assertEqual(self.screen.get('/api/observer/snapshot').status_code,403)

    def test_late_model_write_is_rejected_atomically(self):
        self.turn('洪灾救助');self.turn('yes please')
        sid=self.phone.cookies.get('tr_session')
        async def competing(*args):
            fresh=server.read_draft(self.draft['id'],sid)
            server.update_fields(fresh,{'phone':'0999999999'},'user_form');server.save_draft(fresh,sid)
            return {'action':'provide','fields':{'phone':'0811111111'}}
        with patch.object(workflow,'interpret_live',new=competing):
            response=self.phone.post('/api/drafts/'+self.draft['id']+'/turn',headers=self.headers,json={'text':'change the phone','mode':'live','lang':'en'})
        self.assertEqual(response.status_code,409,response.text)
        current=self.phone.get('/api/drafts/'+self.draft['id']).json()
        self.assertEqual(current['fields']['phone'],'0999999999')
        self.assertEqual(current['event_seq'],self.draft['event_seq']+1)

    def test_bare_service_names_do_not_depend_on_model_classification(self):
        cases=[('儿童补贴。',CHILD,'zh'),('儿童 补贴',CHILD,'zh'),('Child subsidy.',CHILD,'en'),
               ('เงินอุดหนุนเด็กแรกเกิดค่ะ',CHILD,'th'),('洪灾救助。',FLOOD,'zh'),('flood relief',FLOOD,'en'),
               ('เงินช่วยเหลือน้ำท่วม',FLOOD,'th'),('交通罚单查询','traffic-fines-query','zh')]
        for utterance,service,lang in cases:
            with self.subTest(utterance=utterance):
                self.draft=self.create()
                with patch.object(workflow,'interpret_live',new=AsyncMock(return_value={'action':'clarify','service':None,'fields':{}})) as model:
                    response=self.phone.post('/api/drafts/'+self.draft['id']+'/turn',headers=self.headers,json={'text':utterance,'lang':lang,'mode':'live'})
                self.assertEqual(response.status_code,200,response.text)
                draft=response.json()['draft']
                self.assertEqual(draft['service'],service)
                self.assertEqual(draft['workflow']['state'],'service_intro')
                self.assertEqual(draft['fields'],{})
                model.assert_not_awaited()
                self.assertNotIn('意图还不够明确',response.json()['reply'])

    def test_acknowledgement_reads_back_only_accepted_stored_facts(self):
        self.draft=self.create(CHILD)
        interpretation={'action':'provide','fields':{'guardian_name':'李明','phone':'0812345678'},'acknowledgement':'ignored model prose'}
        with patch.object(workflow,'interpret_live',new=AsyncMock(return_value=interpretation)):
            response=self.phone.post('/api/drafts/'+self.draft['id']+'/turn',headers=self.headers,json={'text':'我叫李明，电话是0812345678。','lang':'zh','mode':'live'})
        data=response.json();self.draft=data['draft']
        self.assertIn('监护人姓名已记录为李明',data['reply'])
        self.assertIn('联系电话已记录为0812345678',data['reply'])
        self.assertIn('母亲',data['reply'])
        self.assertNotIn('已更新资料',data['reply']);self.assertNotIn('系统重新',data['reply'])
        self.assertEqual(self.draft['messages'][-1]['content'],data['reply'])
        data=self.phone.post('/api/drafts/'+self.draft['id']+'/turn',headers=self.headers,json={'text':'phone=0999999999','lang':'zh','mode':'rehearsal'}).json()
        self.assertIn('联系电话已更新为0999999999',data['reply'])
        self.assertNotIn('0812345678',data['reply'])

    def test_invalid_values_and_untrusted_acknowledgement_are_not_read_back(self):
        self.draft=self.create(CHILD)
        interpreted={'action':'provide','fields':{'guardian_name':'李明','phone':'bad','bank_account':'forbidden'},'acknowledgement':'已经正式提交政府'}
        with patch.object(workflow,'interpret_live',new=AsyncMock(return_value=interpreted)):
            result=self.phone.post('/api/drafts/'+self.draft['id']+'/turn',headers=self.headers,json={'text':'这里是测试信息','lang':'zh','mode':'live'}).json()
        self.assertIn('监护人姓名已记录为李明',result['reply'])
        self.assertIn('8至15位数字',result['reply'])
        for value in ('bad','forbidden','已经正式提交政府','联系电话已记录'):
            self.assertNotIn(value,result['reply'])
        self.assertNotIn('phone',result['draft']['fields'])

    def test_undo_acknowledges_the_restored_value(self):
        self.turn('洪灾救助');self.turn('yes please');self.sample();self.turn('撤回电话')
        result=self.phone.post('/api/drafts/'+self.draft['id']+'/turn',headers=self.headers,json={'text':'撤销上一轮','mode':'rehearsal','lang':'zh'}).json()
        self.assertIn('已恢复联系电话为0812345678',result['reply'])

    def test_english_and_thai_acknowledge_values_in_the_selected_language(self):
        for lang,phrase,name in [('en','My name is Maya Chen.','Maya Chen'),('th','ผู้ปกครองชื่อมาลี ใจดี','มาลี ใจดี')]:
            with self.subTest(lang=lang):
                self.draft=self.create(CHILD)
                with patch.object(workflow,'interpret_live',new=AsyncMock(return_value={'action':'provide','fields':{'guardian_name':name,'phone':'0812345678'}})):
                    result=self.phone.post('/api/drafts/'+self.draft['id']+'/turn',headers=self.headers,json={'text':phrase,'mode':'live','lang':lang}).json()
                self.assertIn(name,result['reply']);self.assertIn('0812345678',result['reply'])
                self.assertIn('was recorded' if lang=='en' else 'บันทึก',result['reply'])
                self.assertEqual(result['draft']['messages'][-1]['lang'],lang)

    def test_full_conversation_survives_more_than_thirty_turns_and_reconnect(self):
        self.turn('儿童补贴。');self.turn('yes please');self.pair()
        for index in range(35):self.turn(f'phone=08{index:08d}')
        result=self.screen.get('/api/observer/conversation')
        self.assertEqual(result.status_code,200)
        data=result.json();self.assertEqual(data['total'],75)
        self.assertEqual(data['messages'][0]['role'],'assistant')
        self.assertEqual(data['messages'][1]['content'],'儿童补贴。')
        self.assertEqual([m['id'] for m in data['messages']],list(range(1,76)))
        current=self.screen.get('/api/observer/snapshot').json()['snapshot']
        self.assertEqual(current['message_count'],75)
        self.assertEqual(len(current['messages']),2)
        self.assertEqual(current['messages'][-1]['id'],75)
        sid=self.screen.cookies.get('tr_session');server.sessions.pop(sid)
        self.assertEqual(self.screen.get('/api/observer/conversation').json()['total'],75)
        self.assertEqual(self.other.get('/api/observer/conversation').status_code,403)

    def test_cancel_and_clear_do_not_erase_conversation_history(self):
        self.turn('儿童补贴。');self.turn('yes please');self.turn('guardian_name=李明');self.turn('清空表单');self.turn('取消办理')
        self.pair();history=self.screen.get('/api/observer/conversation').json()['messages']
        self.assertEqual(len(history),11)
        self.assertEqual(history[1]['content'],'儿童补贴。')
        self.assertTrue(any('李明' in m['content'] for m in history))


if __name__=='__main__':unittest.main()
