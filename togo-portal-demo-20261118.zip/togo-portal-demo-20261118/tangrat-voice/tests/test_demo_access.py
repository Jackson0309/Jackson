import os
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient
from starlette.websockets import WebSocketDisconnect
from server import access, app as server


class DemoAccess(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_db = server.DB
        server.DB = Path(self.temp.name)/'access.sqlite3'
        with sqlite3.connect(server.DB) as con:
            con.execute('CREATE TABLE drafts(id TEXT PRIMARY KEY,owner TEXT,payload TEXT)')
            con.execute('CREATE TABLE sessions(session_hash TEXT PRIMARY KEY,payload TEXT)')
            server.observer.init_tables(con)
        con.close()
        self.env = patch.dict(os.environ, {'DEMO_ACCESS_CODE':'sample-demo-access-code'})
        self.env.start()
        self.client = TestClient(server.app,base_url='https://testserver')

    def tearDown(self):
        self.client.close()
        self.env.stop()
        server.DB = self.old_db
        self.temp.cleanup()

    def login(self,**extra):
        return self.client.post('/demo-access',data={'code':'sample-demo-access-code',**extra},follow_redirects=False)

    def test_gate_blocks_api_without_creating_a_business_session(self):
        self.assertIn('name="code"',self.client.get('/observer').text)
        self.assertEqual(self.client.get('/api/bootstrap').status_code,401)
        self.assertNotIn('tr_session',self.client.cookies)
        self.assertEqual(self.client.post('/demo-access',data={'code':'wrong'}).status_code,401)

    def test_default_entry_is_english_and_prioritizes_thai_before_chinese(self):
        page=self.client.get('/observer').text
        self.assertIn('<html lang="en">',page)
        self.assertIn('Voice government services',page)
        self.assertLess(page.index('>English</a>'),page.index('>ไทย</a>'))
        self.assertLess(page.index('>ไทย</a>'),page.index('>中文</a>'))

    def test_cookie_and_observer_destination_work_over_https(self):
        response=self.login(next='/observer')
        self.assertEqual(response.status_code,303)
        self.assertEqual(response.headers['location'],'/observer')
        cookie=response.headers['set-cookie']
        self.assertTrue(all(value in cookie for value in ['HttpOnly','Secure','SameSite=strict']))
        self.assertNotIn('sample-demo-access-code',cookie)
        self.assertEqual(self.client.get('/api/bootstrap').status_code,200)
        self.assertEqual(self.client.get('/observer').status_code,200)

    def test_external_origin_and_external_redirect_are_rejected(self):
        self.assertEqual(self.client.post('/demo-access',data={'code':'sample-demo-access-code'},headers={'Origin':'https://evil.example'}).status_code,403)
        self.assertEqual(self.login(next='//evil.example').headers['location'],'/')

    def test_code_rotation_invalidates_cookie_and_websocket(self):
        self.login()
        self.assertEqual(self.client.get('/api/bootstrap').status_code,200)
        with patch.dict(os.environ,{'DEMO_ACCESS_CODE':'rotated-demo-code'}):
            self.assertEqual(self.client.get('/api/bootstrap').status_code,401)
            with self.assertRaises(WebSocketDisconnect):
                with self.client.websocket_connect('/api/voice/example'):
                    pass

    def test_unconfigured_local_development_remains_available(self):
        with patch.dict(os.environ,{'DEMO_ACCESS_CODE':''}):
            self.assertEqual(self.client.get('/api/bootstrap').status_code,200)

    def test_public_logo_does_not_create_a_business_session_or_open_other_assets(self):
        response=self.client.get('/assets/brand/tangrat-logo.png')
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.headers['content-type'],'image/png')
        self.assertNotIn('tr_session',self.client.cookies)
        self.assertEqual(self.client.get('/api/bootstrap').status_code,401)
        self.assertTrue(self.client.get('/assets/app.js').headers['content-type'].startswith('text/html'))

    def test_login_display_language_is_whitelisted_and_forwarded_to_the_observer(self):
        for lang,title in [('zh','语音政务服务'),('en','Voice government services'),('th','บริการภาครัฐด้วยเสียง')]:
            with TestClient(server.app,base_url='https://testserver') as client:
                response=client.get('/observer?ui_lang='+lang)
                self.assertIn(title,response.text)
                response=client.post('/demo-access',data={'code':'sample-demo-access-code','next':'/observer','ui_lang':lang},follow_redirects=False)
                self.assertEqual(response.headers['location'],'/observer?ui_lang='+lang)


if __name__=='__main__':
    unittest.main()
