import asyncio
import io
import json
import unittest
from urllib.parse import parse_qs,urlparse
from unittest.mock import AsyncMock,patch

import httpx
from fastapi import HTTPException,UploadFile
from pipecat.processors.frame_processor import FrameDirection

from server import speech_policy,app as server
from server.turn_audio import SeparatedSTT,TurnAudioFrame,TurnTranscript,TurnInterim
from server.voice import FormAssistant,VoiceProtocol


class SpeechPolicy(unittest.TestCase):
    def test_place_hints_cover_selected_province_and_only_the_district_question(self):
        value={'service':'flood-relief-preparation','fields':{'citizen_id':'0123456789012','address':'88 Anusawari','applicant_name':'Test','phone':'0812345678','province':'Bangkok'},'workflow':{'errors':{}}}
        english=speech_policy.place_hints(value,'en');thai=speech_policy.place_hints(value,'th')
        self.assertEqual(len(english),50);self.assertEqual(len(thai),50)
        self.assertIn('Phaya Thai',english);self.assertIn('พญาไท',thai)
        self.assertNotIn('Hat Yai',english)
        value['fields']['district']='Phaya Thai'
        self.assertEqual(speech_policy.place_hints(value,'en'),[])
        self.assertEqual(speech_policy.place_hints(None,'en'),[])

    def test_ui_bounds_keep_chinese_and_exclude_it_from_english_thai(self):
        self.assertEqual(speech_policy.languages('en'),('en','th'))
        self.assertEqual(speech_policy.languages('th'),('th','en'))
        self.assertEqual(speech_policy.languages('zh'),('zh','en','th'))
        self.assertEqual(speech_policy.languages('unknown'),('en','th'))
        for ui in ('en','th'):
            for text in ('阿智呀。','جاش، نستأنف.','Jason 黄','١٢٣٤٥'):
                self.assertFalse(speech_policy.transcript_allowed(text,ui))
            for text in ('Jason Huang。',"Okay, let’s start.",'สวัสดีค่ะ','0812345678','๐๘๑๒๓๔๕๖๗๘','José'):
                self.assertTrue(speech_policy.transcript_allowed(text,ui))
        self.assertTrue(speech_policy.transcript_allowed('我要办理洪灾救助，姓名Jason Huang。','zh'))
        self.assertFalse(speech_policy.transcript_allowed('جاش','zh'))
        self.assertFalse(speech_policy.transcript_allowed('...','en'))

    def test_segmented_asr_has_ui_hint_and_blocks_wrong_scripts(self):
        async def run(ui,text):
            client=AsyncMock();client.post.return_value=httpx.Response(200,json={'text':text})
            manager=AsyncMock();manager.__aenter__.return_value=client
            with patch.dict(server.config,{'openrouter_key':'SYNTHETIC','asr_model':'unit'}),patch.object(server.httpx,'AsyncClient',return_value=manager):
                result=await server.asr(None,UploadFile(io.BytesIO(b'audio'),filename='test.wav'),ui)
            return result,client
        for ui,text in [('en','Jason Huang。'),('th','ชื่อสมชายค่ะ'),('zh','张琳')]:
            result,client=asyncio.run(run(ui,text))
            self.assertEqual(result['text'],text)
            self.assertEqual(client.post.call_args.kwargs['data']['language'],speech_policy.languages(ui)[0])
        for ui in ('en','th'):
            with self.assertRaises(HTTPException) as error:asyncio.run(run(ui,'阿智呀。'))
            self.assertEqual(error.exception.status_code,422)


class SpeechFrames(unittest.IsolatedAsyncioTestCase):
    async def test_wrong_script_never_becomes_caption_or_business_turn(self):
        for ui,text in [('en','阿智呀。'),('th','جاش، نستأنف.')]:
            socket=type('Socket',(),{'send_json':AsyncMock()})()
            apply=AsyncMock();assistant=FormAssistant(socket,'d','s',ui,lambda *args:None,apply,
                protocol=VoiceProtocol(input_epoch=7))
            assistant.phase='listening';assistant.say=AsyncMock();assistant.last_prompt='Which district was affected?'
            try:
                await assistant.process_frame(TurnInterim(text=text,user_id='u',timestamp='',input_epoch=7,channel='answer'),FrameDirection.DOWNSTREAM)
                self.assertEqual(socket.send_json.await_count,0)
                await assistant.process_frame(TurnTranscript(text=text,user_id='u',timestamp='',input_epoch=7,channel='answer'),FrameDirection.DOWNSTREAM)
                await assistant.pending
                apply.assert_not_awaited()
                self.assertNotIn(text,json.dumps(socket.send_json.call_args_list,default=str,ensure_ascii=False))
                assistant.say.assert_awaited_once_with(speech_policy.retry_prompt(ui))
                self.assertEqual(assistant.last_prompt,'Which district was affected?')
            finally:await assistant.cleanup()

    async def test_chinese_ui_accepts_chinese_and_english_text_is_not_silently_corrected(self):
        for ui,text in [('zh','张琳'),('en',"Yes, let's talk."),('th','สมชาย ใจดี')]:
            socket=type('Socket',(),{'send_json':AsyncMock()})()
            assistant=FormAssistant(socket,'d','s',ui,lambda *args:None,AsyncMock(),protocol=VoiceProtocol(input_epoch=3))
            assistant.phase='listening';assistant.respond=AsyncMock()
            try:
                await assistant.process_frame(TurnTranscript(text=text,user_id='u',timestamp='',input_epoch=3,channel='answer'),FrameDirection.DOWNSTREAM)
                await assistant.pending
                assistant.respond.assert_awaited_once_with(text)
            finally:await assistant.cleanup()

    async def test_provider_context_is_first_chunk_only_and_silence_cannot_write(self):
        class Socket:
            def __init__(self):self.messages=asyncio.Queue();self.sent=[]
            async def recv(self):return json.dumps({'message_type':'session_started'})
            async def send(self,data):self.sent.append(json.loads(data))
            async def close(self):pass
            def __aiter__(self):return self
            async def __anext__(self):return await self.messages.get()
        sessions=[];urls=[]
        async def connect(url,**kwargs):
            urls.append(url);socket=Socket();sessions.append(socket);return socket
        router=SeparatedSTT('SYNTHETIC','en',AsyncMock(),connector=connect)
        router.set_context('Would you like to prefill the form by voice now?')
        emitted=[]
        async def push(frame,direction=FrameDirection.DOWNSTREAM):emitted.append(frame)
        router.push_frame=push
        async def send(pcm):
            await router.process_frame(TurnAudioFrame(audio=pcm,sample_rate=16000,num_channels=1,input_epoch=1),FrameDirection.DOWNSTREAM)
        try:
            await router.set_channel('answer',1)
            params=parse_qs(urlparse(urls[0]).query)
            self.assertEqual(params['language_code'],['en']);self.assertEqual(params['secondary_languages'],['th'])
            await send(bytes(3200));await send(bytes(3200))
            self.assertLessEqual(len(sessions[0].sent[0]['previous_text']),49)
            self.assertNotIn('previous_text',sessions[0].sent[1])
            await sessions[0].messages.put(json.dumps({'message_type':'partial_transcript','text':'Which service would you like?'}))
            await sessions[0].messages.put(json.dumps({'message_type':'committed_transcript','text':'Hallucinated speech'}))
            for _ in range(5):await asyncio.sleep(0)
            self.assertFalse(any(isinstance(frame,(TurnTranscript,TurnInterim)) for frame in emitted))
            await send((2000).to_bytes(2,'little',signed=True)*1600)
            await sessions[0].messages.put(json.dumps({'message_type':'committed_transcript','text':"Let's start."}))
            for _ in range(5):await asyncio.sleep(0)
            self.assertEqual([frame.text for frame in emitted if isinstance(frame,TurnTranscript)],["Let's start."])
            router.set_keyterms(['Phaya Thai'])
            await router.set_channel('wake',2)
            await router.process_frame(TurnAudioFrame(audio=(2000).to_bytes(2,'little',signed=True)*1600,sample_rate=16000,num_channels=1,input_epoch=2),FrameDirection.DOWNSTREAM)
            self.assertNotIn('keyterms',parse_qs(urlparse(urls[1]).query))
            self.assertNotIn('previous_text',sessions[1].sent[0])
        finally:await router.cleanup()
