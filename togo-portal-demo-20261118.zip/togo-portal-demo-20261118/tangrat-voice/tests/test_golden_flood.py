import asyncio,copy,unittest
from unittest.mock import AsyncMock,patch
from server import workflow,flood_checks
from server.domain import INTAKE,FLOOD,FLOOD_SAMPLE,field_schema,validate_patch
class GoldenFlood(unittest.TestCase):
 def fresh(self):
  d=dict(id='test',version=0,service=INTAKE,fields={},provenance={},documents=[],status='draft',messages=[],intent={})
  return workflow.initialize(d,prefill_gate=True)
 def turn(self,d,text,proposal=None):
  if proposal is None:return asyncio.run(workflow.process_turn(d,text,'en','rehearsal',{}))
  with patch.object(workflow,'interpret_live',new=AsyncMock(return_value=proposal)):
   return asyncio.run(workflow.process_turn(d,text,'en','live',{}))
 def test_flood_golden_red_then_green_and_review(self):
  d=self.fresh();self.turn(d,'What documents do I need for flood relief?')
  self.assertEqual(d['workflow']['state'],'government_qa');self.assertEqual(d['fields'],{})
  self.turn(d,"Okay, let's start.");self.assertEqual(d['workflow']['state'],'collecting')
  self.turn(d,'0123456789012')
  self.turn(d,'My name is Somchai Jaidee.',dict(action='provide',fields={'applicant_name':'Somchai Jaidee'}))
  self.assertEqual(d['workflow']['checks']['identity']['status'],'passed')
  fields={**FLOOD_SAMPLE,'province':'Chiang Mai','district':'Mueang Chiang Mai','subdistrict':'Suthep','address':'12 Suthep Road'}
  self.turn(d,'My affected address is 12 Suthep Road, Chiang Mai.',dict(action='provide',fields=fields))
  self.assertEqual(d['workflow']['state'],'collecting');self.assertEqual(d['workflow']['checks']['area']['code'],'not_open')
  self.assertIn('not open',d['messages'][-1]['content'])
  self.turn(d,'Please change my address.',dict(action='provide',fields={k:FLOOD_SAMPLE[k] for k in ('address','province','district','subdistrict')}))
  self.assertEqual(d['workflow']['checks']['area']['status'],'passed');self.assertEqual(d['workflow']['state'],'review')
  self.assertIn('local government service office',d['messages'][-1]['content'])
  self.turn(d,'Remove my phone number');self.assertEqual(d['workflow']['state'],'collecting')
  self.turn(d,'undo last turn');self.assertEqual(d['workflow']['state'],'review')
 def test_unknown_area_blocks_but_any_name_and_number_pass_identity(self):
  d=self.fresh();workflow.select_service(d,FLOOD);d['workflow']['prefill_consent']=True
  d['fields']=dict(FLOOD_SAMPLE,province='Songkhla',district='Hat Yai',applicant_name='Other Person')
  d['fields']['citizen_id']='9876543210123'
  workflow.evaluate(d);self.assertEqual(d['workflow']['checks']['identity']['status'],'passed')
  self.assertEqual(d['workflow']['checks']['identity']['mode'],'simulation')
  self.assertEqual(d['workflow']['checks']['area']['status'],'unknown');self.assertEqual(d['workflow']['state'],'collecting')
 def test_duration_required_and_boundaries(self):
  schema={f['key']:f for f in field_schema(FLOOD)}
  self.assertNotIn('flood_end_date',schema);self.assertTrue(schema['flood_duration_days']['required'])
  for invalid in ('0','-1','1.5','367'):
   _,errors=validate_patch({'flood_duration_days':invalid},FLOOD);self.assertIn('flood_duration_days',errors)
  self.assertEqual(validate_patch({'flood_duration_days':'๕'},FLOOD)[0]['flood_duration_days'],'5')
 def test_arbitrary_names_and_ids_continue_to_phone_and_existing_failure_clears(self):
  for name in ('Niran Chaiyaporn','กิตติพงษ์ วัฒนชัย','李明'):
   d=self.fresh();workflow.select_service(d,FLOOD);d['workflow']['prefill_consent']=True
   d['fields']={'citizen_id':'9876543210123','applicant_name':name}
   d['workflow']['checks']={'identity':{'status':'failed','code':'name_match'}}
   workflow.evaluate(d)
   self.assertEqual(d['workflow']['checks']['identity']['status'],'passed')
   self.assertIn('contact phone number',workflow.question(d,'en'))
  for number in ('123','12345678901234'):
   self.assertIn('citizen_id',validate_patch({'citizen_id':number},FLOOD)[1])
 def test_thai_corrected_district_boundary(self):
  from server.geography import explicit_patch
  value=explicit_patch('แขวงอนุสาวรีย์ เขตบางเขน กรุงเทพมหานครค่ะ')
  self.assertEqual(value['district'],'บางเขน')

 def test_spoken_digits_preserve_count_and_alias_matches(self):
  d=self.fresh();workflow.select_service(d,FLOOD);d['workflow']['prefill_consent']=True
  for utterance in ('Zero one two three, four five six seven, eight nine zero one two.', 'ศูนย์หนึ่งสองสามสี่ห้าหกเจ็ดแปดเก้าศูนย์หนึ่งสอง'):
   self.assertEqual(flood_checks.direct_patch(utterance,d),{'citizen_id':'0123456789012'})
  from server.geography import check
  accepted,errors=check({'province':'Bangkok','district':'Bang Khaen'}, {})
  self.assertFalse(errors);self.assertEqual(accepted['district'],'Bang Khen')
