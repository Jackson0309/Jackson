import asyncio
import math
import time
import unittest
from array import array
from unittest.mock import AsyncMock,patch
from server import workflow,geography
from server.domain import FLOOD,CHILD,INTAKE,validate_patch
from server.turn_audio import NearSpeechGate
from server import service_intro,conversation
from server.domain import SERVICES
import re

def draft(service=INTAKE):
    return workflow.initialize(dict(service=INTAKE,status='draft',fields={},provenance={},documents=[],version=0,messages=[],intent={}),service,prefill_gate=True)

def turn(d,text,lang='en'):
    return asyncio.run(workflow.process_turn(d,text,lang,'rehearsal',{}))

class PrefillAndGeography(unittest.TestCase):
    def test_natural_confirmation_does_not_repeat_the_service_introduction(self):
        cases={'en':["Okay, let's start.","Okay. Let's start.",'OK, let’s begin.','Yes, go ahead.',"All right, let's start now.","Let's do it.",'Please start.',"Okay, let's get started.","Yes, I'm ready."],
               'zh':['好的，开始吧。','可以，我们开始填写吧。','开始预填。'],
               'th':['ตกลง เริ่มเลยค่ะ','ตกลงค่ะ เริ่มเลยค่ะ','เริ่มกรอกข้อมูลได้เลยครับ','ได้เลยค่ะ','โอเคค่ะ เริ่มเลยค่ะ']}
        for lang,phrases in cases.items():
            for phrase in phrases:
                with self.subTest(phrase=phrase):
                    d=draft(FLOOD);r=turn(d,phrase,lang)
                    self.assertEqual(d['workflow']['state'],'collecting')
                    self.assertEqual(d['fields'],{})
                    self.assertNotIn(service_intro.summary(FLOOD,lang),r['reply'])
        for phrase in ["Okay, don't start.",'Yes, but not now.','Maybe later.','好的，先等等。','ตกลง แต่ยังไม่กรอกค่ะ']:
            d=draft(FLOOD);turn(d,phrase)
            self.assertFalse(d['workflow']['prefill_consent'])
        d=draft(FLOOD);r=turn(d,'hmm')
        self.assertEqual(r['reply'],service_intro.ask('en'))

    def test_routine_spoken_templates_do_not_repeat_demo_disclaimers(self):
        banned=r'\bdemo\b|\bofficial\b|演示|正式办理|สาธิต'
        for service in SERVICES:
            for lang in ('en','zh','th'):
                d=draft(service)
                for text in [workflow.question(d,lang),turn(d,'yes',lang)['reply']]:self.assertIsNone(re.search(banned,text,re.I),text)
                for topic in ('identity','capabilities','explain_field','service_info','handoff','privacy'):
                    text=conversation.reply(d,{'topic':topic},lang,workflow.question(d,lang))
                    self.assertIsNone(re.search(banned,text,re.I),text)
                for state in ('review','completed'):
                    d['workflow']['state']=state
                    self.assertIsNone(re.search(banned,workflow.question(d,lang),re.I))

    def test_selection_intro_and_explicit_consent_in_three_languages(self):
        for lang,yes,contains in [('en','yes please','prefill'),('th','ใช่ค่ะ','กรอก'),('zh','好的','预填')]:
            d=draft();r=turn(d,'Flood relief;phone=0812345678',lang)
            self.assertEqual(d['workflow']['state'],'service_intro');self.assertEqual(d['fields'],{})
            self.assertIn(contains,r['reply'])
            turn(d,'phone=0812345678',lang);self.assertEqual(d['fields'],{})
            turn(d,yes,lang);self.assertEqual(d['workflow']['state'],'collecting')
            turn(d,'phone=0812345678',lang);self.assertEqual(d['fields']['phone'],'0812345678')

    def test_decline_ambiguous_yes_explanations_and_switch(self):
        d=draft(FLOOD)
        turn(d,'yes, but do not prefill');self.assertFalse(d['workflow']['prefill_consent'])
        turn(d,'not now');self.assertTrue(d['workflow']['prefill_declined']);self.assertEqual(d['fields'],{})
        turn(d,'Who are you?');self.assertFalse(d['workflow']['prefill_consent'])
        turn(d,'start prefilling');turn(d,'phone=0812345678')
        turn(d,'Child subsidy');self.assertEqual(d['workflow']['state'],'service_intro');self.assertEqual(d['fields'],{})

    def test_invalid_places_and_parent_child_mismatch_in_both_languages(self):
        for p,d in [('Songkhla','Hat Yai'),('จังหวัดสงขลา','อำเภอหาดใหญ่'),('BANGKOK','Khet Phaya Thai')]:
            accepted,errors=validate_patch({'province':p,'district':d},FLOOD)
            self.assertFalse(errors);self.assertTrue(accepted['district'])
        for p,d in [('Bangkok','Hat Yai'),('กรุงเทพมหานคร','หาดใหญ่'),('Moon Province','Unknown District')]:
            accepted,errors=validate_patch({'province':p,'district':d},FLOOD)
            self.assertTrue(errors);self.assertNotIn('district',accepted)
        accepted,errors=validate_patch({'province':'song-khla province','district':'hat-yai'},FLOOD)
        self.assertEqual(accepted,{'province':'Songkhla','district':'Hat Yai'})
        start=time.perf_counter()
        for _ in range(1000):geography.check({'province':'Songkhla','district':'Hat Yai'},{})
        self.assertLess(time.perf_counter()-start,1)

    def test_changing_province_does_not_allow_stale_district_to_pass(self):
        d=draft(FLOOD);turn(d,'yes')
        turn(d,'province=Bangkok;district=Hat Yai')
        self.assertIn('district',d['workflow']['errors']);self.assertNotIn('district',d['fields'])
        turn(d,'province=Songkhla;district=Hat Yai')
        turn(d,'province=Bangkok');self.assertIn('district',d['workflow']['errors'])
        turn(d,'district=Phaya Thai');self.assertNotIn('district',d['workflow']['errors'])
        turn(d,'district=Unknown District');self.assertEqual(d['fields']['district'],'Phaya Thai')
        self.assertIn('district',d['workflow']['errors'])

    def test_noise_gate_suppresses_weak_audio_and_keeps_speech_tail(self):
        gate=NearSpeechGate()
        pcm=lambda amp:array('h',[int(amp*math.sin(i*.15)) for i in range(1600)]).tobytes()
        quiet=pcm(40);speech=pcm(4000)
        self.assertEqual(gate.filter(quiet),bytes(len(quiet)))
        self.assertEqual(gate.filter(speech),speech)
        self.assertEqual(gate.filter(quiet),quiet)
        for _ in range(4):last=gate.filter(quiet)
        self.assertEqual(last,bytes(len(quiet)))

    def test_explicit_place_names_are_not_silently_repaired_by_the_model(self):
        d=draft(FLOOD);turn(d,'yes')
        for text in ['The affected province is Bangkok and the district is Hat Yai.','จังหวัดกรุงเทพมหานคร อำเภอหาดใหญ่ค่ะ']:
            interpreted={'action':'provide','fields':{'province':'Songkhla','district':'Hat Yai'}}
            with patch.object(workflow,'interpret_live',new=AsyncMock(return_value=interpreted)):
                asyncio.run(workflow.process_turn(d,text,'en','live',{}))
            self.assertIn(d['fields']['province'],('Bangkok','กรุงเทพมหานคร'))
            self.assertIn('district',d['workflow']['errors'])

    def test_clear_registration_and_labelled_places_do_not_wait_for_a_model(self):
        d=draft()
        with patch.object(workflow,'interpret_live',new=AsyncMock(side_effect=AssertionError('Unnecessary model call'))) as model:
            asyncio.run(workflow.process_turn(d,'I would like to register for flood relief.','th','live',{}))
            self.assertEqual(d['workflow']['state'],'service_intro')
            turn(d,'Yes, please.')
            asyncio.run(workflow.process_turn(d,'The affected province is Bangkok and the district is Hat Yai.','th','live',{}))
            self.assertIn('district',d['workflow']['errors'])
            model.assert_not_awaited()
