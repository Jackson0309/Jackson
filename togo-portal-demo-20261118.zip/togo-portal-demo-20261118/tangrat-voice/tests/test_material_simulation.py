import sqlite3,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
from server import app as server,togo,observer
@unittest.skipUnless(togo.ACTIVE,'Togo profile only')
class MaterialSimulation(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.database=patch.object(server,'DB',Path(self.tmp.name)/'demo.sqlite3');self.database.start()
  with sqlite3.connect(server.DB) as con:
   con.execute('CREATE TABLE drafts(id TEXT PRIMARY KEY,owner TEXT,payload TEXT)');con.execute('CREATE TABLE sessions(session_hash TEXT PRIMARY KEY,payload TEXT)');observer.init_tables(con)
  self.client=TestClient(server.app);self.headers={'x-csrf-token':self.client.get('/api/bootstrap').json()['csrf']}
 def tearDown(self):self.client.close();self.database.stop();self.tmp.cleanup()
 def create(self):
  d=self.client.post('/api/drafts',headers=self.headers,json={'consent':True,'service':'passport','flow':'intent-graph-v1','lang':'en'}).json();return d,'/api/drafts/'+d['id']
 def prepared(self):
  d,p=self.create();self.client.post(p+'/turn',headers=self.headers,json={'text':'yes please','mode':'rehearsal','lang':'en'});d=self.client.post(p+'/sample',headers=self.headers).json();return d,p
 def test_simulation_is_marked_idempotent_and_does_not_submit(self):
  d,p=self.prepared();r=self.client.post(p+'/documents/simulate',headers=self.headers,json={'version':d['version']});self.assertEqual(r.status_code,200);result=r.json()
  self.assertEqual(result['missing_documents'],[]);self.assertEqual(result['status'],'draft');self.assertNotIn('receipt',result)
  self.assertTrue(all(x['mode']=='simulated_demo' and x['verified'] is False and x['bytes']==0 for x in result['documents']))
  again=self.client.post(p+'/documents/simulate',headers=self.headers,json={'version':result['version']}).json();self.assertEqual(len(again['documents']),len(result['documents']));self.assertEqual(again['version'],result['version'])
  stale=self.client.post(p+'/documents/simulate',headers=self.headers,json={'version':d['version']});self.assertEqual(stale.status_code,409)
 def test_preserves_uploaded_file_and_adds_new_conditional_slot(self):
  d,p=self.prepared();d=self.client.post(p+'/documents',headers=self.headers,data={'slot':'nationality'},files={'file':('real-test.pdf',b'%PDF-1.4\ntest only','application/pdf')}).json()
  d=self.client.post(p+'/documents/simulate',headers=self.headers,json={'version':d['version']}).json();first=next(x for x in d['documents'] if x['slot']=='nationality');self.assertEqual(first['name'],'real-test.pdf');self.assertEqual(first['mode'],'metadata_only_demo')
  d=self.client.patch(p,headers=self.headers,json={'version':d['version'],'fields':{'applicationType':'renew','oldPassportNumber':'DEMO-OLD-001'}}).json()['draft'];self.assertIn('oldPassport',d['missing_documents'])
  d=self.client.post(p+'/documents/simulate',headers=self.headers,json={'version':d['version']}).json();self.assertEqual(d['missing_documents'],[])
 def test_requires_prefill_consent_and_rejects_submitted_case(self):
  d,p=self.create();self.assertEqual(self.client.post(p+'/documents/simulate',headers=self.headers,json={'version':d['version']}).status_code,409)
  d,p=self.prepared();d=self.client.post(p+'/documents/simulate',headers=self.headers,json={'version':d['version']}).json();self.client.post('/api/login',headers=self.headers,json={'name':'Demo Tester','acknowledge_demo':True});d=self.client.post(p+'/submit',headers=self.headers,json={'version':d['version'],'confirmed':True,'demo_acknowledged':True}).json();self.assertEqual(d['status'],'demo_submitted')
  self.assertEqual(self.client.post(p+'/documents/simulate',headers=self.headers,json={'version':d['version']}).status_code,409)
