# 安装与启动

Windows：Python 3.12、Node.js 和 npm；鸿蒙端需要 DevEco Studio、API 23 SDK 和 devecocli。

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\start-local.ps1
```
打开 http://127.0.0.1:4190/ ，观察台 /observer，操作员配置 /operator。真实语音及 LLM 需要使用者自行提供服务商凭据。脚本监听 0.0.0.0，请在可信网络使用。Ctrl+C 停止。

观察台源码构建：`cd observer-ui; npm ci; npm run build`；包内包含现成的 web/observer 构建资源。

鸿蒙源码在 harmony/，使用 `build-harmony.ps1` 或 devecocli 构建；安装需要自行配置有效签名。手机连接本机需配置 USB 反向转发；参见 connect-phone.ps1。具体环境及真机联动本轮未复验。
