# 多哥业务适配：原版 Tang Rat 运行链路

启动 Mac：`./start-togo.sh`；Windows：`./start-togo.ps1`。默认端口8080。未设置 TANGRAT_COUNTRY 时仍为原有泰国业务，设置为 togo 启用六项业务。

门户 http://localhost:4175/ 的 AI坐席弹窗现在嵌入 `/tangrat/`，由同源 HTTP / WebSocket 代理接到8080原版服务。独立访问 http://localhost:8080/?ui_lang=zh 。本机 API 配置在 http://localhost:8080/operator ，配置页不经门户代理开放。

保留原版 app.js 的页面结构、通话控件和调度，保留 voice.py、turn_audio.py、voice-playback.js、pcm-worklet.js、语音模式、打断、同意预填门控、状态机、撤销、归档切换、登录、续办、观察台及鸿蒙音频桥。新增国家业务配置，不另建替代应用。

业务依据为工作区 AI坐席业务方向.md，profiles/togo-schema.json 来源于已有多哥 case-schema.mjs，profiles/togo-knowledge.json 来源于 V2 country-resources.json。六项稳定标识：duplicate、nationality、passport、criminal、residence、courtfees。条件字段、附件槽位与费用计算在 togo.py，缺少适用必填材料不能演示提交；副本附件可选。旧版副本费用待确认并提示主管线下窗口。费用、时限和知识均为2026-11-06历史参考。

附件继续沿用原 Tang Rat 的元数据演示能力：保存文件名、大小、摘要与材料槽位，原始附件不保留。没有宣称迁移为门户另一套原文件存储能力。实时语音和分段语音继续使用原服务商配置；凭据配置与接口验证结果以 provider-configuration-audit.md 最新检查为准；完整业务通话仍待验收。

验证：原版126项测试通过；多哥专用8项测试通过（TANGRAT_COUNTRY=togo python -m unittest discover -s tests -p test_togo_profile.py）。经4175代理验证cookie/CSRF、预填门控、登录门控、示例、回执、护照缺件阻止、续办链接、观察台配对及原语音WebSocket握手。浏览器验证门户弹窗→原版主页→事项详情→开始申请→单独同意预填→原通话页→示例→草稿核对。

此前制作的简化页面已从web目录移出，保留在工作区 backups/2026-11-15-superseded-tangrat-adapter/rule-page，不再作为入口使用。


## 旧观察台地址兼容

当前4190改为兼容跳转入口，所有旧链接以307跳转8080同一路径；办理端与观察台统一使用多哥运行进程。启动兼容入口：`.venv/bin/python -m uvicorn server.legacy_redirect:app --host 0.0.0.0 --port 4190`。多哥办理端 `/` 与观察台 `/observer` 都在8080。原泰国业务源码仍保留，不能再与当前多哥演示共用4190造成混淆。


iOS局域网语音请改用8443 HTTPS门户；证书安装、启动和验证范围见 ios-voice-setup.md。
