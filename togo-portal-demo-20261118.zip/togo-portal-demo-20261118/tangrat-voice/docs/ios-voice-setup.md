# iPhone语音与局域网HTTPS

当前HTTPS门户：https://192.168.43.101:8443/ 。手机与电脑应在同一网络。

一次性准备页：http://192.168.43.101:8080/assets/ios/setup.html 。页面默认英语，包含仅有本地CA证书的配置描述文件，不包含VPN、设备管理或账户。

由用户在iPhone操作：下载Togo Demo HTTPS描述文件，在设置→通用→VPN与设备管理中安装；到设置→通用→关于本机→证书信任设置，启用Togo Demo Local CA的完全信任。它让该本地CA可以认证TLS证书；只用于本地Demo，使用后可在设备管理中删除该描述文件。操作依据：https://support.apple.com/en-us/102390 。本次未自动更改任何设备的信任设置。

之后打开HTTPS门户，选择AI agent并点击麦克风，在Safari提示时授权。不要继续使用局域网HTTP地址进行语音，不需绕过证书警告。

实现：server/https_gateway.py为4175门户提供8443 TLS、同源HTTP、WebSocket和观察台SSE转发。先运行8080多哥服务和4175门户，再执行./start-https.sh。证书私钥仅在被Git忽略的data/tls目录，权限0600；公开CA和安装描述文件位于web/ios。证书含当前局域网IP、localhost和127.0.0.1；换IP后需重新签发叶证书并重启网关。

iOS音频调整：在用户点击启动时请求麦克风并唤醒AudioContext，不再等WebSocket建立后才申请；使用设备原生采样率，继续由现有重采样逻辑转换；仍保留原录音模式、音频协议与打断时序。HTTP页面提供证书配置指引，权限拒绝与设备缺失分别提示。

门户三按钮共用同一尺寸、颜色、圆角和24px图标，顺序Text assistant、AI agent、Observer；桌面184×48，手机156×44。三个入口默认英语，原有语言切换保留。

验证：CA校验通过的HTTPS请求访问门户、办理端、观察台、AudioWorklet与描述文件均返回200；HTTPS会话及CSRF通过；WSS建立并收到语音事件和二进制音频；网关3项测试（压缩协商与文字/二进制转发、SSE和麦克风策略、跨源拒绝）通过；浏览器确认按钮尺寸顺序、办理端/文字助手英语。尚未代替用户在实际iPhone上安装证书或完成真人通话验收。
