# 业务 LLM 调用节点遍历

检查日期：2026-11-15。范围：tangrat-voice当前源码、多哥8080使用的原版状态机；静态调用链核对，未发起外部模型请求。

## 当前页面的实际入口

web/app.js create()固定发送 flow=intent-graph-v1。

文字实时模式 / 分段录音转写文本 → POST /api/drafts/{id}/turn → app.apply_turn → workflow.process_turn。

实时流式语音 → ASR最终回答 → voice.FormAssistant.respond → app.apply_turn(mode=live) → 同一个 workflow.process_turn。

文字演练模式mode=rehearsal使用本地演练解析，不调用业务LLM。按键、表单PATCH、附件上传、样例、登录、回执和观察台均不独立调用业务LLM。

## 状态与调用条件

| 状态/操作 | 何时使用业务LLM | 规则直接处理的部分 |
|---|---|---|
| intent 用户意图 | 口语需求未被本地目录与指令规则识别时，判定事项、澄清或问答动作 | 明确事项名称、部分明确办理指令直接路由；首次欢迎语无LLM |
| government_qa 政务问答 | 进入此状态时，未匹配本地问答/同意规则的自然语言走解释器 | 原洪灾材料问答本地回答；多哥该专用入口被禁用，多哥咨询在当前事项状态内完成 |
| service_intro 事项介绍及预填确认 | 理解非固定表达的同意、拒绝、暂缓、咨询或换事项，可提取同时明确提供的资料 | 事项介绍文本由服务资料拼接；明确同意/拒绝短句本地处理，单独介绍不是LLM生成 |
| collecting 采集资料 | 通常用来把自然表达转换成字段、理解多字段补充、更正、删除、插话、撤销或恢复意图 | 明确控制指令、本地问答、部分日期表达等先行处理；字段格式与条件由后端校验 |
| review 核对确认 | 继续口语更正、复杂撤回、咨询等未命中规则时，仍可能进入同一解释器 | 是否资料齐全、是否回退、明确提交口令与登录检查由本地代码处理 |
| completed 结果 | 多哥演示提交成功后不可继续编辑，该办件的对话入口被拒绝；结果显示无LLM | 本地生成回执和结果；原查询模式另有可修改查询条件的路径 |
| 跨状态操作 | 语义复杂的换事项、撤销、删除字段、恢复草稿等可交给LLM分类 | 明确命令走本地规则；具体归档/撤销/清空/恢复由后端执行 |
| 材料、校验、费用、提交 | 无独立业务LLM调用 | 条件字段/材料、参考费用、提交资格、用户确认、版本检查、存储与回执均由代码执行 |
| 观察台 | 不调用 | 从后端读取快照、历史对话、事件、语音状态及实时更新 |

## 唯一主要解释器

server/workflow.py interpret_live()调用 https://openrouter.ai/api/v1/chat/completions，使用openrouter_key和llm_model。每次落到该解释器的主流程输入轮次发出一次业务模型请求，没有额外的规划模型、审核模型、摘要模型或独立问答模型。

请求：当前用户话语、当前事项、当前字段、当前问题、状态、预填同意状态、最近6条消息、服务器时间参考、事项目录/表单；多哥另含事项知识快照与业务边界。

service_intro/government_qa使用service_intro.interpreter_prompt()，其余状态使用通用业务解释提示词。所有节点共用同一个model ID，没有按节点独立配置模型。

输出为JSON动作提议：provide、answer、clarify、cancel、clear、clear_all、undo、remove_fields、resume、accept_prefill、decline_prefill，以及service、fields、remove_fields、topic、prefill_decision等。后端核对动作、事项、字段与同意证据，再执行规则。

重要：模型主要负责“理解和结构化”，不是自由生成所有回答。主流程最终回复由conversation.reply、responses.compose_reply、workflow.question及业务知识拼接。即使模型返回acknowledgement，主状态机也不直接采用它作为整段回复。模型不能自行授权最终提交。

配置参数：temperature=0、max_tokens=1600、HTTP超时40秒。没有配置密钥时，真正落到interpret_live会返回503；前端通常已把默认模式降为文字演练。规则命中的单轮可能完全不触发模型。

## 仍保留的旧兼容调用点

1. server/app.py route_intent()：没有启用intent-graph-v1、且事项未确认的旧草稿路径。关键词无法识别时调用chat/completions分类；确认旧候选后还可能用llm_extract提取首轮资料。
2. server/app.py llm_extract()：没有启用工作流、事项已明确、mode=live的旧表单流程，提取字段和短确认语。temperature=0.1、max_tokens=600。

当前新建页面总是启用工作流，apply_turn优先转入workflow.process_turn，因此正常不走上述两处兼容路径。旧路径仍残留泰国两事项分类与泰国字段提示，不能视为已完成多哥适配。

## 与语音模型的边界

分段ASR的 /audio/transcriptions 和TTS的 /audio/speech 也可能使用OpenRouter Key，但它们不属于业务chat/completions模型。实时ASR和TTS由选定语音供应商执行；语音打断、停止确认、音频队列、聆听时机是语音协议/调度逻辑，业务LLM不控制这些时序。

## 本次发现的边界

- 观察台的government_qa节点仍存在，但多哥没有独立进入该节点的业务分支；不能仅凭图上有节点认定每一节点都由LLM驱动。
- 知识问答主要是已有资料和模板回复，不是独立RAG检索或自由问答生成链。
- 旧兼容调用提示仍含泰国业务，需要维护该旧API时另做适配；当前主路径与它隔离。
- 多哥主解释提示仍通过追加覆盖条款排除原泰国样例，预填提示保留部分泰国示例；本轮只核对调用位置，没有修改运行逻辑。


## DeepSeek更新

业务调用点不变，改由server/llm.py按llm_provider选择供应商。当前deepseek / deepseek-v4-pro，使用deepseek_key与DeepSeek官方chat/completions地址，关闭thinking以返回业务JSON。兼容旧路径也复用同一路由。OpenRouter语音端点独立保留。
