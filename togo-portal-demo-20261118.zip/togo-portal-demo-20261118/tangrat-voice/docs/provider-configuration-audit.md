# 外部服务配置检查

检查日期：2026-11-15。依据本项目代码、文档及8080/4190的只读运行状态；没有向外部服务发起付费调用，没有验证服务商当前产品或账户授权，没有写入密钥。

## 首次检查状态（已由文末最新检查更新）

8080（多哥）与4190（原版）均无已保存的本机配置：`data/operator-config.local` 不存在，`.env` 不存在。运行中 `openrouter_configured=false`、`realtime_configured=false`，没有配置读取错误。

| 用途 | 配置字段 | 当前值或状态 | 影响 |
|---|---|---|---|
| 业务LLM | openrouter_key / OPENROUTER_API_KEY | 未配置 | 自然语言模型理解不可用 |
| LLM模型 | llm_model / LLM_MODEL | openai/gpt-4.1-mini（代码默认） | 需要账户授权、余额和真实调用验证 |
| 默认实时ASR | asr_provider | elevenlabs | 需要 elevenlabs_key |
| 默认实时TTS | tts_provider | elevenlabs | 与实时ASR共用 elevenlabs_key |
| ElevenLabs密钥 | elevenlabs_key / ELEVENLABS_API_KEY | 未配置 | 当前实时语音识别、合成不可用 |
| ElevenLabs音色 | voice_id、zh_voice_id、th_voice_id | EXAVITQu4vr4xnSDxMaL（代码默认） | 非空不代表账户有权限，需试听验证 |
| 英文TTS模型 | en_tts_model | eleven_flash_v2_5（代码默认） | 需账户可用性验证 |
| 中文/泰语TTS模型 | zh_tts_model、th_tts_model | eleven_v4_turbo（代码默认） | 需账户可用性验证 |
| 讯飞应用 | iflytek_app_id / IFLYTEK_APP_ID | 未配置 | 选择讯飞时必需 |
| 讯飞密钥 | iflytek_api_key / IFLYTEK_API_KEY | 未配置 | 选择讯飞时必需 |
| 讯飞签名密钥 | iflytek_api_secret / IFLYTEK_API_SECRET | 未配置 | 选择讯飞时必需 |
| 讯飞ASR/TTS产品 | iflytek_asr_model、iflytek_tts_model | iat、super_tts（代码默认） | 需应用开通对应产品；填写凭据本身不代表已授权 |
| 讯飞中英文发音人 | iflytek_voice_zh/en、iflytek_standard_voice_zh/en | 已有默认名称 | 需产品匹配、授权与试听验证 |
| 讯飞泰语发音人 | iflytek_standard_voice_th | configure-authorized-thai-voice（占位值） | 如选讯飞泰语TTS，必须替换为已授权音色 |

## 按现有实现接入

- 当前默认实时方案：填写 OpenRouter Key 和 ElevenLabs Key，再核实 LLM模型、TTS模型和音色权限。ASR与TTS不需要各自另一把ElevenLabs Key。
- 讯飞方案：保留OpenRouter业务LLM，填讯飞APPID、APIKey、APISecret，并把需要的实时ASR和TTS供应商切换成iflytek；支持ASR/TTS混用不同平台。
- 分段录音：ASR固定由 `/api/asr` 调用 OpenRouter，使用 asr_model=elevenlabs/scribe-v2；实时ASR平台选择不影响该路径。需要独立验证此端点、模型及账户权限。分段TTS使用所选TTS供应商。

配置入口：http://localhost:8080/operator （仅本机可用）。保存后结束原通话，刷新办理端并建立新通话。

8080与4190使用同一个磁盘配置路径，但各自有独立的内存配置；在一个端口保存，不会即时更新另一个进程。另一个进程需重启才能重新读取。

## 配置文件与指引缺口

1. `.env.example` 只有注释，没有参数模板；程序也没有调用load_dotenv，因此只把参数写入`.env`不会生效。使用本机配置页，或在启动进程前实际导出受支持的环境变量。
2. 环境变量覆盖本机文件；若启动时有同名环境变量，在网页保存其他值后，重启仍会被环境变量覆盖。
3. ENV映射只支持 OPENROUTER_API_KEY、ELEVENLABS_API_KEY、LLM_MODEL、ELEVENLABS_VOICE_ID、ZH_TTS_MODEL、ZH_VOICE_ID、IFLYTEK_APP_ID、IFLYTEK_API_KEY、IFLYTEK_API_SECRET。不要自行假设 ASR_PROVIDER、TTS_PROVIDER、ASR_MODEL 等环境变量会被读取；这些设置应使用配置页，asr_model等未在页面暴露的字段需专门补充配置入口。
4. 业务LLM和分段ASR的OpenRouter地址在代码中固定，没有可配置的LLM_BASE_URL；不能只替换密钥就直接接任意OpenAI兼容服务。
5. 默认模型ID、音色ID只是代码默认值，没有经过当前账户验证；系统ready状态仅判断必填项非空，不是外部连通性或授权验证。
6. 语言仍沿用原项目中/英/泰；多哥法语ASR/TTS尚无独立配置及完整链路支持。这是适配能力缺口，不能仅填写密钥解决。
7. 手机目前使用局域网HTTP；浏览器真实麦克风权限仍需要HTTPS等安全上下文。服务凭据齐全也不能代替该访问条件。

## 其他尚未真实对接的能力

身份匹配、原洪灾地区登记状态为演示规则；多哥政府受理、官方状态同步、真实缴费、正式身份核验及短信通知尚未接入。当前没有这些服务的可填写参数入口，也不应把本地回执理解为正式受理。

## 依据

- server/configuration.py：默认值、环境变量映射、文件加载/保存、ready判定。
- server/app.py：/api/operator、/api/health、分段ASR及TTS、OpenRouter调用地址。
- server/voice.py、server/iflytek.py：原实时语音与讯飞实现。
- web/operator.html、web/operator.js：当前配置表单、保存及试听。
- docs/setup.md、docs/deployment.md、docs/togo-adaptation.md、.env.example：现有指引。


## 最新配置与连通性检查（2026-11-15）

已通过本机配置API将用户提供的OpenRouter、ElevenLabs和讯飞凭据保存到data/operator-config.local，并同步到8080与4190两个当前进程。文件权限0600。本文不记录凭据内容。ASR/TTS选择保持ElevenLabs。

| 服务 | 实测结果 | 验证范围 |
|---|---|---|
| OpenRouter业务LLM | HTTP 401认证失败 | 通过当前多哥业务/turn入口实际请求，业务数据未变更；需核对有效Key |
| ElevenLabs账户及默认音色 | HTTP 200 | 账户查询和默认中文音色查询通过 |
| ElevenLabs当前模型 | 模型目录包含当前中英文默认模型 | 不代表所有语言效果已验收 |
| ElevenLabs中文TTS | HTTP 200，返回15089字节音频 | 使用当前中文模型和默认音色，合成简短测试文本；未人工听音 |
| ElevenLabs实时ASR | session_started | 已验证认证和WebSocket会话；未做真人语音识别准确性测试 |
| 讯飞ASR | 服务返回code=0 | 标准中文iat静音测试请求通过；未做真人识别准确性测试 |
| 讯飞中文TTS | 返回11200 | 当前super_tts与当前默认音色未通过，需核对该产品/音色授权及额度，具体原因未确认 |

当前完整业务语音对话仍受OpenRouter认证失败阻塞。不能仅凭配置非空或界面ready状态认定已完成端到端验收。


### 二次复查

- OpenRouter：/api/v1/key 与 /api/v1/chat/completions 都返回401及 `API key expired.`，确认为服务端报告密钥过期，需在OpenRouter控制台更新有效Key。
- 讯飞超拟人super_tts：11200，`LiccCheck failed, unauthenticated, err: licc limit`；该产品/音色授权或额度未通过。
- 讯飞标准tts：使用当前凭据、中文xiaoyan音色，合成测试文本成功返回音频。说明标准TTS链路和现有凭据可用，不是整体凭据无效。未人工听音验收。
- 两运行端iflytek_tts_model已保存为tts；主用tts_provider仍为elevenlabs。
- 官方解释： https://www.xfyun.cn/doc/spark/super%20smart-tts.html （11200功能未授权）； https://static.xfyun.cn/doc/tts/online_tts/API.html （发音人授权、授权有效期及总合成交互量检查）。


### 更新OpenRouter Key后的验证

用户指定的新Key已保存并同步到8080和4190，密钥认证接口返回200。当前llm_model仍为openai/gpt-4.1-mini；业务入口及最小模型请求返回403，服务明确提示 `This model is not available in your region.`。密钥过期问题已消除，目前阻塞为当前模型的地区可用性，尚未擅自更换模型。


### DeepSeek业务LLM替换

已新增业务供应商路由，选中deepseek，模型deepseek-v4-pro，调用https://api.deepseek.com/chat/completions；使用独立deepseek_key（不记录在文档），保持语音供应商与其凭据独立。官方与账户/models均只列出deepseek-flash、deepseek-v4-pro，没有v4.1 pro独立ID。

实测多哥/turn主流程：口语识别护照事项→自然表达同意预填→一次提取申请类型、护照类型、姓名、出生日期及境内递交区域，均通过；三轮约2.7–3.4秒。业务JSON使用thinking disabled。配置页新增平台和DeepSeek Key，并支持DEEPSEEK_API_KEY、LLM_PROVIDER环境变量。

分段ASR仍保留原OpenRouter路径；DeepSeek只替换业务LLM。完整真人语音通话仍需独立验收。
