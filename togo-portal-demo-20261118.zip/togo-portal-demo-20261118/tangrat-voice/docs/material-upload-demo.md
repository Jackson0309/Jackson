# Itemized document upload

The Togo review page renders every currently applicable attachment slot as a separate row, with localized required/optional labels, status, file names and its own custom upload button. Browser-native file controls are visually hidden so their OS language cannot conflict with the selected page language.

Simulate all missing uploads saves the latest form fields, then POSTs to /api/drafts/{id}/documents/simulate with the current version. The server enforces ownership, editable status and prefill consent. It adds only missing applicable slots, preserves existing files, marks every placeholder simulated_demo and verified=false, and does not submit the draft. Repeated operations are idempotent; newly applicable branches can be simulated separately.

Real uploads continue the existing metadata-only demo contract. No document is claimed to be officially verified. Reference fee information remains visible.

Validation: 3 profile API tests cover consent, readonly submissions, stale versions, idempotence, preservation of existing uploaded metadata, conditional renewal slots and no automatic submission. Browser verification confirms English upload controls, expanded required/optional rows, per-file simulation badges and an unsubmitted draft after one-click simulation.
