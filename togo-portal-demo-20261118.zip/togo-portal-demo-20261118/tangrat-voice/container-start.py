import json, os
from pathlib import Path
path=Path('/app/data/operator-config.local')
if not path.exists():
    path.parent.mkdir(parents=True,exist_ok=True)
    values=json.loads(Path('/app/provider-settings.json').read_text())
    path.write_text(json.dumps({'version':1,'storage':'owner_only_file','values':values}))
    path.chmod(0o600)
os.execvp('python',['python','-m','uvicorn','server.app:app','--host','0.0.0.0','--port','8080','--loop','asyncio'])
