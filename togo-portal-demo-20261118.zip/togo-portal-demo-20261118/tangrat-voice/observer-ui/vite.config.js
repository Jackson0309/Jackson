import {defineConfig} from 'vite';
export default defineConfig({base:'/assets/observer/',build:{outDir:'../web/observer',emptyOutDir:true}});
