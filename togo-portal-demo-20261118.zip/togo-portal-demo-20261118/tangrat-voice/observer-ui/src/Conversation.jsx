import React,{useEffect,useLayoutEffect,useMemo,useRef,useState} from 'react';
import {locales} from './i18n.js';

export default function Conversation({messages,snapshot,voice,uiLang,t}){
  const thread=useRef(null),[following,setFollowing]=useState(true),programmatic=useRef(false),followingRef=useRef(true),scrollIntentUntil=useRef(0);
  const last=messages.at(-1),language=voice?.language||snapshot?.language||'en';
  const turns=useMemo(()=>{
    const grouped=[];
    for(const message of messages){
      if(message.role==='user')grouped.push({id:message.id,user:message});
      else if(grouped.at(-1)?.user&&!grouped.at(-1).assistant)grouped.at(-1).assistant=message;
      else grouped.push({id:message.id,assistant:message});
    }
    return grouped;
  },[messages]);
  const lastUser=messages.findLast(message=>message.role==='user');
  const recognition=voice?.text&&voice.text.trim()!==lastUser?.content?.trim()?voice.text:'';
  function bottom(){
    const el=thread.current;if(!el)return;
    programmatic.current=true;el.scrollTop=el.scrollHeight;
    requestAnimationFrame(()=>{programmatic.current=false});
  }
  useLayoutEffect(()=>{if(followingRef.current)bottom()},[messages.length,last?.id,recognition]);
  useEffect(()=>{const observer=new ResizeObserver(()=>{if(followingRef.current)bottom()});if(thread.current)observer.observe(thread.current);return()=>observer.disconnect()},[]);
  function follow(){followingRef.current=true;setFollowing(true);bottom()}
  function scrollIntent(){scrollIntentUntil.current=performance.now()+1200}
  function scroll(){
    const el=thread.current;if(!el||programmatic.current)return;
    const active=el.scrollHeight-el.scrollTop-el.clientHeight<35;
    // Layout resizing must not be mistaken for a user browsing older messages.
    if(!active&&performance.now()>scrollIntentUntil.current)return;
    followingRef.current=active;setFollowing(active);
  }
  function messageCard(message){
    return <article key={message.id} data-message-id={message.id} data-message-role={message.role} className={`conversation-message ${message.role==='user'?'user':'assistant'}`}>
      <div className="message-meta"><strong>{t(message.role==='user'?'you':'assistant')}</strong><time>{message.at?new Date(message.at*1000).toLocaleTimeString(locales[uiLang],{hour12:false}):t('historical')}</time><span>{message.lang?t(({zh:'chinese',en:'english',th:'thai'})[message.lang]||message.lang):''}</span></div>
      <p className="message-text" lang={message.lang==='zh'?'zh-CN':message.lang}>{message.content}</p>
    </article>;
  }
  return <div className="speech-panel conversation-panel">
    <div className="section-heading"><h2>{t('conversation')}</h2><span className="conversation-view-mode">{t(following?'latestTurn':'browsingHistory')}</span><span className="message-count">{messages.length?t('messageCount',{turns:Math.floor(messages.length/2),count:messages.length}):t('waitingInput')}</span>{!following&&<button className="quiet-button" type="button" onClick={follow}>{t('follow')}</button>}</div>
    <div className="conversation-thread" ref={thread} onScroll={scroll} onWheel={scrollIntent} onTouchMove={scrollIntent} onPointerDown={scrollIntent} onKeyDown={event=>{if(['ArrowUp','ArrowDown','PageUp','PageDown','Home','End',' '].includes(event.key))scrollIntent()}} tabIndex={0} aria-label={t('conversationAria')} data-following={following}>
      {!messages.length&&<p className="conversation-empty">{t('conversationEmpty')}</p>}
      {turns.map((turn,index)=><div key={turn.id} className={`conversation-turn ${turn.user?'':'opening-turn'}`} data-turn-id={turn.id} data-latest-turn={index===turns.length-1&&!recognition||undefined}>{turn.user&&messageCard(turn.user)}{turn.assistant&&messageCard(turn.assistant)}</div>)}
      {recognition&&<div className="conversation-turn recognition-turn" data-live-recognition>
        <article className="conversation-message user"><div className="message-meta"><strong>{t('you')}</strong><span>{t(voice.final?'recognitionFinal':'recognitionInterim')}</span></div><p className="message-text" data-utterance lang={language}>{recognition}</p></article>
        <article className="conversation-message assistant pending-response" role="status"><div className="message-meta"><strong>{t('assistant')}</strong></div><p className="message-text">{t(voice.final?'preparingReply':'waitingUtterance')}</p></article>
      </div>}
    </div>
    <div className="next-question"><span>{t('prompt')}</span><p lang={uiLang}>{snapshot?.questions?.[uiLang]||t('promptEmpty')}</p></div>
  </div>;
}
