export const locales={zh:'zh-CN',en:'en-GB',th:'th-TH'};
export const languages=[['en','English'],['th','ไทย'],['zh','中文']];

const zh={
 service_intro:'服务介绍与预填确认',service_introNote:'介绍要求 · 询问是否预填',acceptPrefill:'同意预填',
 title:'语音政务观察台',subtitle:'手机对话，系统办理，电脑实时呈现。',demo:'体验演示',
 loading:'正在加载',unpaired:'等待手机配对',connecting:'正在连接',live:'实时连接',reconnecting:'正在重新连接',disconnect:'解除配对',
 pairTitle:'连接手机上的语音会话',pairText:'手机进入语音办事，点击“连接电脑演示屏”获取配对码。',pairLabel:'手机上的八位配对码',pairPlaceholder:'输入 8 位配对码',pairButton:'连接会话',
 readOnly:'只读观察',session:'会话',currentService:'当前事项',currentState:'当前状态',waitingIntent:'等待识别事项',notConnected:'尚未连接',waitingVoice:'等待语音连接',enterCode:'请输入配对码',
 intent:'用户意图',service:'当前事项',collecting:'采集资料',review:'核对确认',completed:'办理结果',state:'业务状态',
 speaking:'助手正在播报',listening:'手机正在聆听',thinking:'正在理解您的回答',ready:'语音已连接',disconnected:'语音未连接',voiceError:'语音连接异常',
 services:'事项入口',serviceCount:'10 项演示服务',query:'查询',application:'申请准备',savedDraft:'草稿',scope:'选自官方热门目录及相关服务，非办理量排名。',
 graph:'意图驱动的状态迁移',graphHint:'自动推进，也可更正、撤回或改办',graphAria:'意图驱动的有向状态图',forward:'推进',backward:'回退 / 改办',identify:'识别',open:'进入',queryReady:'条件齐全 · 模拟查询',detailsReady:'资料齐全 · 自动推进',confirm:'用户明确确认',retract:'撤回必填字段',update:'补充 / 更正',cancelSaved:'取消 · 保留草稿',chooseAgain:'重新选择事项',cancelSwitch:'取消 / 改办 · 保留草稿',zoomIn:'放大',zoomOut:'缩小',fit:'适应画布',
 intentNote:'识别需求 · 10 项入口',serviceNote:'只展开当前事项',collectingNote:'提取、更正与撤回',reviewNote:'资料齐全后自动进入',completedNote:'模拟查询 / 演示回执',queryNote:'查询条件 · 模拟结果',applicationNote:'申请准备 · 演示确认',
 intentDescription:'系统识别明确事项；需求不清楚时继续询问。',serviceDescription:'当前事项由手机输入决定；其他事项保留在左侧目录。',collectingDescription:'补充和更正资料；资料齐全后系统自动推进。',reviewDescription:'用户核对并明确确认。撤回必填项会返回资料采集。',completedDescription:'显示模拟查询或演示回执，政府业务系统尚未接入。',inspectNote:'演示字段见当前事项面板。',official:'官方事项说明 ↗',
 queryForm:'查询条件',applicationForm:'申请草稿',filled:'{filled} / {total} 已填',waitingService:'等待明确事项',startSentence:'从一句话开始',formNote:'演示表单，非官方表单定版。',formEmpty:'识别事项后，表单及已提供的资料会实时显示。',optional:'可选',empty:'待填写',correctValue:'请更正此项资料。',queryDone:'模拟查询已完成',queryBoundary:'未连接政府数据库，不代表真实个人记录、资格、欠款或账单。',receipt:'本地演示回执',notSubmitted:'尚未提交政府。',draftsSaved:'已保留 {count} 项独立草稿，可在手机说出事项名称恢复。',
 conversation:'历史对话',conversationAria:'本次会话的完整历史对话',messageCount:'{turns} 轮 · {count} 条消息',waitingInput:'等待手机输入',follow:'回到最新对话 ↓',conversationEmpty:'用户输入与助手回复将依次保留在这里。',you:'您',assistant:'助手',historical:'历史记录',recognitionFinal:'正在整理本轮回答',recognitionInterim:'正在识别 · 尚未保存',prompt:'当前提示',promptEmpty:'明确事项后显示对应表单。',
 events:'最近迁移',eventsAria:'历史对话与状态迁移',eventNumber:'事件 #{number}',waitingEvents:'等待会话事件',fieldChanges:'{count} 项字段变化',eventCreated:'会话已创建',eventSelected:'已选择{service}',eventUpdated:'已更新{fields}',eventRemoved:'已撤回{fields}',eventCancelled:'已取消办理，草稿保留',eventClear:'已清空当前表单',eventClearAll:'已清空全部草稿',eventUndo:'已撤销上一轮更改',eventCompleted:'办理结果已显示',eventProcessed:'已处理本轮回答',
 footer:'演示观察台仅展示会话。政府身份认证、正式申请、支付及真实个人记录尚未接入。',
 connectionFailed:'连接失败，请稍后重试。',historyFailed:'历史对话加载失败，请刷新重试。',snapshotFailed:'无法读取会话快照，请重连。',eventFailed:'无法读取迁移事件，请重连。',pairExpired:'配对授权已失效，请重新输入配对码。',pairInvalid:'配对码无效、已使用或已过期，请在手机重新生成。',pairRate:'尝试过于频繁，请稍后重试。',
 chinese:'中文',english:'English',thai:'ไทย',displayLanguage:'界面语言',
};

const en={
 service_intro:'Service overview',service_introNote:'Overview · ask to prefill',acceptPrefill:'Accept prefill',
 title:'Voice service observer',subtitle:'Speak on your phone. Follow the service as it happens.',demo:'Demo',
 loading:'Loading',unpaired:'Waiting to pair',connecting:'Connecting',live:'Connected live',reconnecting:'Reconnecting',disconnect:'Unpair',
 pairTitle:'Connect your phone conversation',pairText:'Open voice services on your phone and choose “Connect a presentation screen” to get a code.',pairLabel:'Eight-digit code from your phone',pairPlaceholder:'8-digit pairing code',pairButton:'Connect session',
 readOnly:'Read-only view',session:'Session',currentService:'Service',currentState:'State',waitingIntent:'Waiting for a service',notConnected:'Not connected',waitingVoice:'Waiting for voice',enterCode:'Enter a pairing code',
 intent:'User intent',service:'Current service',collecting:'Collect details',review:'Review & confirm',completed:'Service result',state:'Service state',
 speaking:'Assistant is speaking',listening:'Phone is listening',thinking:'Understanding your answer',ready:'Voice connected',disconnected:'Voice disconnected',voiceError:'Voice connection error',
 services:'Service directory',serviceCount:'10 demo services',query:'Query',application:'Application preparation',savedDraft:'Draft',scope:'Selected from official popular and related services; not a usage ranking.',
 graph:'Intent-driven state changes',graphHint:'Automatic progress, with corrections and return paths',graphAria:'Directed graph of service states',forward:'Progress',backward:'Return / switch',identify:'Identify',open:'Open',queryReady:'Conditions complete · query',detailsReady:'Details complete · advance',confirm:'Explicit confirmation',retract:'Retract required detail',update:'Add / correct',cancelSaved:'Cancel · keep draft',chooseAgain:'Choose another service',cancelSwitch:'Cancel / switch · keep draft',zoomIn:'Zoom in',zoomOut:'Zoom out',fit:'Fit diagram',
 intentNote:'Identify one of 10 services',serviceNote:'Expand the selected service',collectingNote:'Fill, correct or retract',reviewNote:'Opens when details are complete',completedNote:'Simulated result / demo receipt',queryNote:'Query conditions · simulated result',applicationNote:'Prepare details · demo confirmation',
 intentDescription:'The system selects a clear service and asks again when the request is ambiguous.',serviceDescription:'Your phone selects the service. Other services remain in the directory.',collectingDescription:'Add or correct details. The system advances when the required information is complete.',reviewDescription:'The user reviews and explicitly confirms. Retracting required details returns to collection.',completedDescription:'Shows a simulated query or demo receipt. No government system is connected.',inspectNote:'Demo fields appear in the current service panel.',official:'Official service information ↗',
 queryForm:'Query conditions',applicationForm:'Application draft',filled:'{filled} / {total} filled',waitingService:'Waiting for a service',startSentence:'Start with a conversation',formNote:'Demo fields; not an official form.',formEmpty:'Once the service is identified, its form and your details appear here.',optional:'Optional',empty:'Not provided',correctValue:'Please correct this value.',queryDone:'Simulated query complete',queryBoundary:'No government database was accessed. This is not a real personal record, eligibility, balance or bill.',receipt:'Local demo receipt',notSubmitted:'Not submitted to the government.',draftsSaved:'{count} separate drafts saved. Say a service name on your phone to resume.',
 conversation:'Conversation history',conversationAria:'Complete conversation history',messageCount:'{turns} turns · {count} messages',waitingInput:'Waiting for phone input',follow:'Back to latest ↓',conversationEmpty:'User inputs and assistant replies are kept here in order.',you:'You',assistant:'Assistant',historical:'Earlier message',recognitionFinal:'Processing this answer',recognitionInterim:'Recognizing · not saved yet',prompt:'Current question',promptEmpty:'Name a service to display its form.',
 events:'Recent transitions',eventsAria:'Conversation history and state changes',eventNumber:'Event #{number}',waitingEvents:'Waiting for events',fieldChanges:'{count} field changes',eventCreated:'Conversation started',eventSelected:'Selected: {service}',eventUpdated:'Updated: {fields}',eventRemoved:'Retracted: {fields}',eventCancelled:'Cancelled; draft kept',eventClear:'Current form cleared',eventClearAll:'All drafts cleared',eventUndo:'Last change undone',eventCompleted:'Service result displayed',eventProcessed:'Answer processed',
 footer:'Read-only demo view. Government identity, official applications, payments and real personal records are not connected.',
 connectionFailed:'Connection failed. Please try again.',historyFailed:'Could not load the conversation. Please refresh.',snapshotFailed:'Could not read the session. Please reconnect.',eventFailed:'Could not read the transition. Please reconnect.',pairExpired:'Pairing expired. Generate a new code on your phone.',pairInvalid:'Invalid, expired or used code. Generate a new one on your phone.',pairRate:'Too many attempts. Please try again later.',
 chinese:'Chinese',english:'English',thai:'Thai',displayLanguage:'Display language',
};

const th={
 service_intro:'แนะนำบริการ',service_introNote:'อธิบายและขออนุญาตกรอก',acceptPrefill:'ยินยอมกรอก',
 title:'จอแสดงสถานะบริการด้วยเสียง',subtitle:'พูดคุยบนมือถือ ติดตามบริการบนจอได้ทันที',demo:'สาธิต',
 loading:'กำลังโหลด',unpaired:'รอจับคู่มือถือ',connecting:'กำลังเชื่อมต่อ',live:'เชื่อมต่อแล้ว',reconnecting:'กำลังเชื่อมต่อใหม่',disconnect:'ยกเลิกการจับคู่',
 pairTitle:'เชื่อมต่อบทสนทนาจากมือถือ',pairText:'เปิดบริการด้วยเสียงบนมือถือ แล้วเลือก “เชื่อมต่อจอการนำเสนอ” เพื่อรับรหัส',pairLabel:'รหัสจับคู่ 8 หลักจากมือถือ',pairPlaceholder:'กรอกรหัสจับคู่ 8 หลัก',pairButton:'เชื่อมต่อ',
 readOnly:'แสดงข้อมูลเท่านั้น',session:'บทสนทนา',currentService:'บริการปัจจุบัน',currentState:'สถานะปัจจุบัน',waitingIntent:'รอระบุบริการ',notConnected:'ยังไม่เชื่อมต่อ',waitingVoice:'รอการเชื่อมต่อเสียง',enterCode:'กรอกรหัสจับคู่',
 intent:'ความต้องการ',service:'บริการปัจจุบัน',collecting:'รวบรวมข้อมูล',review:'ตรวจสอบและยืนยัน',completed:'ผลการดำเนินการ',state:'สถานะบริการ',
 speaking:'ผู้ช่วยกำลังพูด',listening:'มือถือกำลังฟัง',thinking:'กำลังทำความเข้าใจคำตอบ',ready:'เชื่อมต่อเสียงแล้ว',disconnected:'ยังไม่เชื่อมต่อเสียง',voiceError:'การเชื่อมต่อเสียงผิดพลาด',
 services:'รายการบริการ',serviceCount:'10 บริการสาธิต',query:'ตรวจสอบข้อมูล',application:'เตรียมใบสมัคร',savedDraft:'ฉบับร่าง',scope:'เลือกจากบริการยอดนิยมและบริการที่เกี่ยวข้อง ไม่ใช่อันดับจำนวนผู้ใช้',
 graph:'เปลี่ยนสถานะตามความต้องการ',graphHint:'ดำเนินการอัตโนมัติ พร้อมแก้ไข ย้อนกลับ หรือเปลี่ยนบริการ',graphAria:'แผนภาพสถานะบริการแบบมีทิศทาง',forward:'ดำเนินการ',backward:'ย้อนกลับ / เปลี่ยน',identify:'ระบุบริการ',open:'เปิดแบบฟอร์ม',queryReady:'ข้อมูลครบ · ตรวจสอบ',detailsReady:'ข้อมูลครบ · ดำเนินการต่อ',confirm:'ผู้ใช้ยืนยัน',retract:'ลบข้อมูลที่จำเป็น',update:'เพิ่ม / แก้ไข',cancelSaved:'ยกเลิก · เก็บฉบับร่าง',chooseAgain:'เลือกบริการใหม่',cancelSwitch:'ยกเลิก / เปลี่ยน · เก็บฉบับร่าง',zoomIn:'ขยาย',zoomOut:'ย่อ',fit:'แสดงทั้งแผนภาพ',
 intentNote:'ระบุความต้องการจาก 10 บริการ',serviceNote:'แสดงเฉพาะบริการที่เลือก',collectingNote:'กรอก แก้ไข หรือลบข้อมูล',reviewNote:'เปิดเมื่อข้อมูลครบถ้วน',completedNote:'ผลสาธิต / ใบรับสาธิต',queryNote:'เงื่อนไข · ผลตรวจสอบสาธิต',applicationNote:'เตรียมข้อมูล · ยืนยันสาธิต',
 intentDescription:'ระบบเลือกบริการที่ชัดเจน หากยังไม่ชัดเจนจะถามเพิ่มเติม',serviceDescription:'ข้อมูลจากมือถือเป็นตัวกำหนดบริการปัจจุบัน บริการอื่นยังอยู่ในรายการ',collectingDescription:'เพิ่มหรือแก้ไขข้อมูล ระบบจะดำเนินการต่อเมื่อข้อมูลที่จำเป็นครบ',reviewDescription:'ผู้ใช้ตรวจสอบและยืนยัน หากลบข้อมูลที่จำเป็นจะกลับไปกรอกข้อมูล',completedDescription:'แสดงผลตรวจสอบหรือใบรับสาธิต ยังไม่เชื่อมต่อระบบรัฐบาล',inspectNote:'ดูข้อมูลสาธิตในแผงบริการปัจจุบัน',official:'ข้อมูลบริการอย่างเป็นทางการ ↗',
 queryForm:'เงื่อนไขการตรวจสอบ',applicationForm:'ฉบับร่างคำขอ',filled:'กรอกแล้ว {filled} / {total}',waitingService:'รอระบุบริการ',startSentence:'เริ่มจากการสนทนา',formNote:'แบบฟอร์มสาธิต ไม่ใช่แบบฟอร์มทางราชการ',formEmpty:'เมื่อระบุบริการได้ แบบฟอร์มและข้อมูลที่แจ้งจะแสดงที่นี่',optional:'ไม่บังคับ',empty:'ยังไม่กรอก',correctValue:'กรุณาแก้ไขข้อมูลนี้',queryDone:'ตรวจสอบสาธิตเสร็จแล้ว',queryBoundary:'ไม่ได้เชื่อมต่อฐานข้อมูลรัฐบาล ไม่ใช่ข้อมูลส่วนบุคคล สิทธิ ยอดค้าง หรือใบแจ้งหนี้จริง',receipt:'ใบรับสาธิต',notSubmitted:'ยังไม่ได้ส่งให้หน่วยงานรัฐ',draftsSaved:'เก็บฉบับร่างไว้ {count} บริการ บอกชื่อบริการบนมือถือเพื่อดำเนินการต่อ',
 conversation:'ประวัติการสนทนา',conversationAria:'ประวัติการสนทนาทั้งหมด',messageCount:'{turns} รอบ · {count} ข้อความ',waitingInput:'รอข้อมูลจากมือถือ',follow:'กลับสู่ข้อความล่าสุด ↓',conversationEmpty:'คำตอบของผู้ใช้และผู้ช่วยจะเก็บไว้ที่นี่ตามลำดับ',you:'คุณ',assistant:'ผู้ช่วย',historical:'ข้อความก่อนหน้า',recognitionFinal:'กำลังประมวลผลคำตอบ',recognitionInterim:'กำลังรู้จำเสียง · ยังไม่บันทึก',prompt:'คำถามปัจจุบัน',promptEmpty:'ระบุบริการเพื่อแสดงแบบฟอร์ม',
 events:'การเปลี่ยนสถานะล่าสุด',eventsAria:'ประวัติการสนทนาและการเปลี่ยนสถานะ',eventNumber:'เหตุการณ์ #{number}',waitingEvents:'รอเหตุการณ์',fieldChanges:'เปลี่ยนข้อมูล {count} รายการ',eventCreated:'เริ่มบทสนทนาแล้ว',eventSelected:'เลือกบริการ {service}',eventUpdated:'อัปเดต {fields}',eventRemoved:'ลบข้อมูล {fields}',eventCancelled:'ยกเลิกแล้ว เก็บฉบับร่างไว้',eventClear:'ล้างแบบฟอร์มปัจจุบันแล้ว',eventClearAll:'ล้างฉบับร่างทั้งหมดแล้ว',eventUndo:'ย้อนกลับการแก้ไขล่าสุดแล้ว',eventCompleted:'แสดงผลการดำเนินการแล้ว',eventProcessed:'ประมวลผลคำตอบแล้ว',
 footer:'จอสาธิตสำหรับแสดงข้อมูลเท่านั้น ยังไม่เชื่อมต่อการยืนยันตัวตน คำขอทางราชการ การชำระเงิน หรือข้อมูลส่วนบุคคลจริง',
 connectionFailed:'เชื่อมต่อไม่สำเร็จ กรุณาลองใหม่',historyFailed:'โหลดประวัติไม่ได้ กรุณารีเฟรช',snapshotFailed:'อ่านบทสนทนาไม่ได้ กรุณาเชื่อมต่อใหม่',eventFailed:'อ่านการเปลี่ยนสถานะไม่ได้ กรุณาเชื่อมต่อใหม่',pairExpired:'การจับคู่หมดอายุ กรุณาสร้างรหัสใหม่บนมือถือ',pairInvalid:'รหัสไม่ถูกต้อง หมดอายุ หรือถูกใช้แล้ว กรุณาสร้างรหัสใหม่',pairRate:'ลองบ่อยเกินไป กรุณารอสักครู่',
 chinese:'จีน',english:'อังกฤษ',thai:'ไทย',displayLanguage:'ภาษาแสดงผล',
};

Object.assign(zh,{eventAnswered:'已回答问题，保留当前办理进度',explain:'解释 / 答疑'});
Object.assign(en,{eventAnswered:'Question answered; application progress kept',explain:'Ask / explain'});
Object.assign(th,{eventAnswered:'ตอบคำถามแล้ว คงขั้นตอนเดิมไว้',explain:'ถาม / อธิบาย'});
export const dictionaries={zh,en,th};
Object.assign(en,{services:'Services',review:'Review',confirm:'Confirm',retract:'Retract detail',detailsReady:'Details ready',queryReady:'Query ready',cancelSwitch:'Cancel / switch',cancelSaved:'Draft saved',intentNote:'Choose a service',applicationNote:'Prepare draft',queryNote:'Demo lookup',collectingNote:'Fill or correct',reviewNote:'Check details',completedNote:'Demo result / receipt',fieldChanges:'{count} updated'});
const serviceNames={
 'flood-relief-preparation':'Flood relief','child-subsidy-preparation':'Child subsidy','health-entitlement-query':'Healthcare',
 'traffic-fines-query':'Traffic fines','vehicle-registration-query':'Vehicle records','social-security-query':'Social security',
 'credit-summary-query':'Credit summary','elderly-allowance-query':'Elderly allowance','student-loan-query':'Student loan','water-bill-query':'Water bill',
};
const fieldNames={applicant_name:'Applicant name',guardian_name:'Guardian name',child_name:'Child name',child_birth_date:'Birth date',
 province:'Province',district:'District',subdistrict:'Subdistrict',phone:'Contact number',residence_type:'Home type',address:'Home address',
 flood_start_date:'Flood start',flood_end_date:'Flood end',damage_description:'Damage and impact',household_members:'Household size',annual_household_income:'Annual income (THB)'};
export function serviceLabel(item,lang){return lang==='en'?(serviceNames[item?.id]||label(item,lang)):label(item,lang)}
export function fieldLabel(item,lang){return lang==='en'?(fieldNames[item?.key]||label(item,lang)):label(item,lang)}
Object.assign(zh,{latestTurn:'最新一轮',browsingHistory:'查看历史中',preparingReply:'正在整理您的回答…',waitingUtterance:'等待您说完…',fieldUpdated:'刚更新',fieldRetracted:'已撤回',resizeForm:'拖动调整表单宽度，双击恢复默认',resizeConversation:'拖动调整对话区高度，双击恢复默认'});
Object.assign(en,{latestTurn:'Latest turn',browsingHistory:'Reading history',preparingReply:'Preparing your reply…',waitingUtterance:'Waiting for you to finish…',fieldUpdated:'Updated',fieldRetracted:'Retracted',resizeForm:'Resize the form; double-click to reset',resizeConversation:'Resize conversation height; double-click to reset'});
Object.assign(th,{latestTurn:'บทสนทนาล่าสุด',browsingHistory:'กำลังดูประวัติ',preparingReply:'กำลังเตรียมคำตอบ…',waitingUtterance:'รอให้คุณพูดจบ…',fieldUpdated:'อัปเดตแล้ว',fieldRetracted:'ลบแล้ว',resizeForm:'ลากปรับความกว้างแบบฟอร์ม ดับเบิลคลิกเพื่อคืนค่า',resizeConversation:'ลากปรับความสูงบทสนทนา ดับเบิลคลิกเพื่อคืนค่า'});
export function translator(lang){const words=dictionaries[lang]||zh;return(key,values={})=>String(words[key]??zh[key]??key).replace(/\{(\w+)\}/g,(_,name)=>values[name]??'');}
export function label(item,lang){return item?.[lang]||item?.en||item?.zh||'';}
export function eventSummary(event,catalog,fields,lang){
 const t=translator(lang),changes=Object.entries(event.changes||{});
 if(event.kind==='answer')return t('eventAnswered');
 if(event.kind==='created')return t('eventCreated');
 if(event.to_state==='intent')return t(event.kind==='cancel'?'eventCancelled':event.kind==='clear_all'?'eventClearAll':'chooseAgain');
 if(event.from_service!==event.to_service)return t('eventSelected',{service:label(catalog.find(s=>s.id===event.to_service),lang)});
 if(event.kind?.includes('clear'))return t(event.kind.includes('all')?'eventClearAll':'eventClear');
 if(event.kind?.includes('undo'))return t('eventUndo');
 if(changes.length){const removed=changes.every(([,v])=>!v.after);return t(removed?'eventRemoved':'eventUpdated',{fields:changes.slice(0,3).map(([key])=>fieldLabel(fields.find(f=>f.key===key),lang)||key).join(lang==='zh'?'、':', ')});}
 return t(event.to_state==='completed'?'eventCompleted':'eventProcessed');
}

Object.assign(en,{government_qa:'Service Q&A',government_qaNote:'Documents and requirements',government_qaDescription:'Explain requirements, then offer prefilling.',askPolicy:'Ask about documents',identityCheck:'Name / citizen ID',areaCheck:'Area registration',check_name_match_passed:'Name matches ID',check_name_match_failed:'Name and ID do not match',check_open_passed:'Registration open',check_not_open_failed:'Not open yet',check_unknown_unknown:'Availability unconfirmed',check_invalid_address_failed:'Check province and district',serviceCount:'Flood relief',formNote:'Details update as you speak.',footer:'',completedNote:'Saved details / next steps',applicationNote:'Prepare and review',queryNote:'Lookup',intentNote:'Ask or apply',inspectNote:'See the application details.'});
Object.assign(zh,{government_qa:'政务问答',government_qaNote:'了解材料与要求',government_qaDescription:'介绍办理要求，然后询问是否预填。',askPolicy:'咨询办理材料',identityCheck:'姓名与身份证号',areaCheck:'地区登记状态',check_name_match_passed:'姓名与号码匹配',check_name_match_failed:'姓名与号码不匹配',check_open_passed:'登记已开放',check_not_open_failed:'登记尚未开放',check_unknown_unknown:'暂时无法确认',check_invalid_address_failed:'请核对府和区县',serviceCount:'洪灾救助登记',formNote:'资料随对话实时更新。',footer:'',completedNote:'已保存资料与后续办理',applicationNote:'预填与核对',intentNote:'咨询或办理',inspectNote:'请查看当前申请资料。'});
Object.assign(th,{government_qa:'สอบถามบริการ',government_qaNote:'เอกสารและเงื่อนไข',government_qaDescription:'อธิบายเงื่อนไขแล้วเสนอกรอกข้อมูลล่วงหน้า',askPolicy:'สอบถามเอกสาร',identityCheck:'ชื่อและเลขบัตรประชาชน',areaCheck:'สถานะพื้นที่',check_name_match_passed:'ชื่อและเลขบัตรตรงกัน',check_name_match_failed:'ชื่อและเลขบัตรไม่ตรงกัน',check_open_passed:'เปิดลงทะเบียนแล้ว',check_not_open_failed:'ยังไม่เปิดลงทะเบียน',check_unknown_unknown:'ยังยืนยันไม่ได้',check_invalid_address_failed:'ตรวจสอบจังหวัดและอำเภอ',serviceCount:'ช่วยเหลือน้ำท่วม',formNote:'ข้อมูลอัปเดตตามการสนทนา',footer:'',completedNote:'บันทึกข้อมูลและดำเนินการต่อ',applicationNote:'กรอกและตรวจสอบ',intentNote:'สอบถามหรือยื่นคำขอ'});

Object.assign(en,{completedDescription:'Review saved information and follow the next steps.',receipt:'Saved application',notSubmitted:'',queryBoundary:'Check the service details before continuing.',queryReady:'Result ready',queryNote:'Query result',inspectNote:'See the current service details.'});
Object.assign(zh,{completedDescription:'查看保存的信息及后续办理指引。',receipt:'已保存申请',notSubmitted:'',queryBoundary:'请核对信息后继续。',queryReady:'查询结果',queryNote:'查询信息'});
Object.assign(th,{completedDescription:'ตรวจสอบข้อมูลและขั้นตอนถัดไป',receipt:'บันทึกคำขอแล้ว',notSubmitted:'',queryBoundary:'ตรวจสอบข้อมูลก่อนดำเนินการต่อ',queryReady:'ผลพร้อมแล้ว',queryNote:'ผลการตรวจสอบ',inspectNote:'ดูรายละเอียดบริการปัจจุบัน'});

Object.assign(en,{serviceCount:'10 services',serviceIdentified:'Service identified',serviceIdentifiedNote:'Match request to a service'});
Object.assign(zh,{serviceCount:'10 项服务',serviceIdentified:'已识别办理事项',serviceIdentifiedNote:'根据用户输入识别事项'});
Object.assign(th,{serviceCount:'10 บริการ',serviceIdentified:'ระบุบริการ',serviceIdentifiedNote:'เลือกบริการจากความต้องการ'});

Object.assign(en,{fromAddress:'From address'});
Object.assign(zh,{fromAddress:'由地址解析'});
Object.assign(th,{fromAddress:'จากที่อยู่'});
