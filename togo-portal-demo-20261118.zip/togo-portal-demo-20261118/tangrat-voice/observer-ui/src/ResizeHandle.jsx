import React,{useRef} from 'react';

export default function ResizeHandle({axis,label,value,min,max,onChange,onReset,className=''}){
  const drag=useRef(null);
  function start(event){
    if(event.button!==0)return;
    event.preventDefault();event.currentTarget.setPointerCapture(event.pointerId);
    drag.current={position:axis==='x'?event.clientX:event.clientY,value};
    document.documentElement.classList.add('resizing-'+axis);
  }
  function move(event){
    if(!drag.current)return;
    const position=axis==='x'?event.clientX:event.clientY;
    onChange(Math.max(min,Math.min(max,drag.current.value+drag.current.position-position)));
  }
  function stop(){drag.current=null;document.documentElement.classList.remove('resizing-'+axis)}
  return <div className={`resize-handle resize-${axis} ${className}`} role="separator" title={label} aria-label={label} aria-orientation={axis==='x'?'vertical':'horizontal'} aria-valuenow={Math.round(value)} aria-valuemin={min} aria-valuemax={Math.round(max)} tabIndex={0} onPointerDown={start} onPointerMove={move} onPointerUp={stop} onPointerCancel={stop} onLostPointerCapture={stop} onDoubleClick={onReset} onKeyDown={event=>{
    const step=event.shiftKey?40:16;
    const direction=axis==='x'?{ArrowLeft:step,ArrowRight:-step}:{ArrowUp:step,ArrowDown:-step};
    if(event.key in direction){event.preventDefault();onChange(Math.max(min,Math.min(max,value+direction[event.key])))}
    if(event.key==='Home'){event.preventDefault();onReset()}
  }}><span/></div>;
}
