import React,{useCallback,useEffect,useMemo,useRef,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {ReactFlow,ReactFlowProvider,Background,Controls,Handle,Position,BaseEdge,EdgeLabelRenderer,getBezierPath,MarkerType,useNodesState} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import './style.css';
import './brand.css';
import './projection.css';
import './english-demo.css';
import Conversation from './Conversation.jsx';
import ResizeHandle from './ResizeHandle.jsx';
import {languages,locales,translator,label,serviceLabel,fieldLabel,eventSummary} from './i18n.js';

const stateKeys=['intent','government_qa','service_intro','collecting','review','completed'];
const serviceIcon=id=>'/assets/brand/'+({
 duplicate:'documents',nationality:'documents',passport:'documents',criminal:'social',residence:'vehicle',courtfees:'credit',
 'flood-relief-preparation':'flood','child-subsidy-preparation':'child','health-entitlement-query':'health',
 'traffic-fines-query':'traffic','vehicle-registration-query':'vehicle','social-security-query':'social',
 'credit-summary-query':'credit','elderly-allowance-query':'elderly','student-loan-query':'student','water-bill-query':'water'
}[id]||'services')+'.svg';

function StateNode({data}){
  return <div className={`state-node ${data.active?'active':''} ${data.kind==='service'?'service-node':''} ${data.pulse?'arrived':''}`}>
    <Handle type="target" position={Position.Left} id="left"/>
    <Handle type="target" position={Position.Top} id="top"/>
    <Handle type="source" position={Position.Top} id="top-progress" style={{left:'72%'}}/>
    <Handle type="target" position={Position.Bottom} id="bottom-progress" style={{left:'72%'}}/>
    <Handle type="source" position={Position.Bottom} id="bottom-back" style={{left:'28%'}}/>
    <Handle type="target" position={Position.Top} id="top-back" style={{left:'28%'}}/>
    <Handle type="source" position={Position.Left} id="left-return"/>
    <Handle type="source" position={Position.Right} id="loop-out" style={{top:'30%'}}/>
    <Handle type="target" position={Position.Right} id="loop-in" style={{top:'70%'}}/>
    <div className="node-kicker">{data.kicker}</div>
    <strong>{data.label}</strong><small>{data.note}</small>
    <Handle type="source" position={Position.Right} id="right"/>
    <Handle type="source" position={Position.Bottom} id="bottom"/>
    <Handle type="target" position={Position.Bottom} id="return"/>
  </div>;
}

function MotionEdge(props){
  const {id,sourceX,sourceY,targetX,targetY,sourcePosition,targetPosition,data={},markerEnd}=props;
  let [path,labelX,labelY]=getBezierPath({sourceX,sourceY,targetX,targetY,sourcePosition,targetPosition,curvature:.4});
  if(data.route==='return-right'){
    const right=Math.max(sourceX+30,900);
    path=`M ${sourceX} ${sourceY} H ${right-12} Q ${right} ${sourceY} ${right} ${sourceY+12} V 318 Q ${right} 330 ${right-12} 330 H ${targetX+12} Q ${targetX} 330 ${targetX} 318 V ${targetY}`;
    labelX=310;labelY=330;
  }else if(data.route==='return-left'){
    path=`M ${sourceX} ${sourceY} H -6 Q -18 ${sourceY} -18 ${sourceY+12} V 318 Q -18 330 -6 330 H ${targetX-12} Q ${targetX} 330 ${targetX} 318 V ${targetY}`;
    labelX=310;labelY=330;
  }else if(data.route==='return-bottom'){
    path=`M ${sourceX} ${sourceY} V 318 Q ${sourceX} 330 ${sourceX-12} 330 H ${targetX+12} Q ${targetX} 330 ${targetX} 318 V ${targetY}`;
    labelX=(sourceX+targetX)/2;labelY=330;
  }else if(data.route==='back'){
    path=`M ${sourceX} ${sourceY} V ${targetY}`;
    labelX=sourceX-52;labelY=(sourceY+targetY)/2;
  }else if(data.route==='loop'){
    path=`M ${sourceX} ${sourceY} C ${sourceX+58} ${sourceY-20} ${targetX+58} ${targetY+20} ${targetX} ${targetY}`;
    labelX=sourceX+54;labelY=(sourceY+targetY)/2;
  }else if(data.route==='query'){
    path=`M ${sourceX} ${sourceY} V 145 Q ${sourceX} 135 ${sourceX+10} 135 H ${targetX-10} Q ${targetX} 135 ${targetX} 125 V ${targetY}`;
    labelX=(sourceX+targetX)/2;labelY=135;
  }
  if(id==='choose'||id==='open')labelY=155;
  if(id==='complete'){labelX=sourceX+46;labelY=(sourceY+targetY)/2}
  return <>
    <BaseEdge id={id} path={path} markerEnd={markerEnd} style={{stroke:data.pulse?(data.back?'#b46d23':'#078963'):'#d9e5de',strokeWidth:data.pulse?3:1.5}}/>
    {data.label&&<EdgeLabelRenderer><span className={`edge-text ${data.pulse?'lit':''} ${data.back?'back':''}`} style={{transform:`translate(-50%,-50%) translate(${labelX}px,${labelY}px)`}}>{data.label}</span></EdgeLabelRenderer>}
    {data.pulse&&<circle key={data.pulse} className="flow-packet" r="5.5" fill={data.back?'#b46d23':'#078963'} stroke="white" strokeWidth="2"><animateMotion dur=".75s" path={path} fill="freeze"/><animate attributeName="opacity" values="1;1;0" keyTimes="0;.88;1" dur=".75s" fill="freeze"/></circle>}
  </>;
}
const nodeTypes={state:StateNode},edgeTypes={motion:MotionEdge};
function Transitions({events,catalog,fields,lang,t,titles}){
  const latest=events.at(-1);
  return <div className="event-panel"><div className="section-heading"><h2>{t('events')}</h2><span>{latest?t('eventNumber',{number:String(latest.seq).padStart(3,'0')}):t('waitingEvents')}</span></div><ol className="event-list">{events.slice(-3).reverse().map(item=>{
    const summary=eventSummary(item,catalog,catalog.find(s=>s.id===item.to_service)?.schema||fields,lang);
    return <li key={item.seq}><time>{new Date(item.at*1000).toLocaleTimeString(locales[lang],{hour12:false})}</time><div><p title={summary}>{summary}</p><small>{titles[item.from_state]} → {titles[item.to_state]}{Object.keys(item.changes||{}).length?' · '+t('fieldChanges',{count:Object.keys(item.changes).length}):''}</small></div></li>;
  })}</ol></div>;
}

function Diagram({snapshot,event,onInspect,catalog,lang,t}){
  const titles=Object.fromEntries(stateKeys.map(key=>[key,t(key)]));
  const graphContainer=useRef(null),flowInstance=useRef(null),fitTimer=useRef(null);
  const fitDiagram=useCallback(()=>{clearTimeout(fitTimer.current);fitTimer.current=setTimeout(()=>flowInstance.current?.fitBounds({x:-30,y:-20,width:950,height:375},{padding:.025,duration:0}),80)},[]);
  useEffect(()=>{const observer=new ResizeObserver(fitDiagram);if(graphContainer.current)observer.observe(graphContainer.current);return()=>{observer.disconnect();clearTimeout(fitTimer.current)}},[fitDiagram]);
  const selected=catalog.find(s=>s.id===snapshot?.service),active=snapshot?.state==='service_intro'?'service':snapshot?.state||'intent';
  const pulseIds=useMemo(()=>{
    if(!event)return [];
    if(event.to_state==='government_qa')return ['askPolicy'];
    if(event.from_state==='government_qa')return ['startFromQA',...(event.to_state==='collecting'?['open']:[])];
    if(event.kind==='answer')return event.to_state==='collecting'?['update']:[];
    if(event.to_state==='intent')return ['restart'];
    if(event.from_service!==event.to_service)return ['choose',...(event.to_state==='service_intro'?[]:['open']),...(event.to_state==='review'?['complete']:event.to_state==='completed'?['query']:[])];
    if(event.from_state==='service_intro'&&event.to_state!=='service_intro')return ['open'];
    if(event.from_state==='review'&&event.to_state==='collecting')return ['back'];
    if(event.to_state==='completed')return [selected?.mode==='query'?'query':'submit'];
    if(event.from_state==='collecting'&&event.to_state==='review')return ['complete'];
    if(event.to_state==='collecting')return ['update'];
    return [];
  },[event,selected?.mode]);
  const desiredNodes=useMemo(()=>[
    {id:'government_qa',position:{x:0,y:15},label:t('government_qa')},
    {id:'intent',position:{x:0,y:175},label:t('intent')},
    {id:'service',position:{x:215,y:175},label:t('serviceIdentified')},
    {id:'collecting',position:{x:430,y:175},label:t('collecting')},
    {id:'review',position:{x:430,y:15},label:t('review')},
    {id:'completed',position:{x:680,y:15},label:t('completed')},
  ].map(n=>({...n,type:'state',data:{kind:n.id,label:n.label,kicker:t(n.id==='service'?'currentService':n.id===active?'currentState':'state'),note:n.id==='service'?(selected?serviceLabel(selected,lang):t('serviceIdentifiedNote')):t(n.id+'Note'),active:!!snapshot&&(n.id===active||(n.id==='service'&&!!selected)),pulse:!!event&&n.id===active}})),[selected,active,snapshot,event,lang,t]);
  const [nodes,setNodes,onNodesChange]=useNodesState([]);
  // Preserve React Flow's measured dimensions across event/data updates. Dropping
  // them hides unchanged-size nodes because ResizeObserver has nothing to remeasure.
  useEffect(()=>{setNodes(current=>desiredNodes.map(node=>({...current.find(old=>old.id===node.id),...node})))},[desiredNodes,setNodes]);
  const edge=useCallback((id,source,target,label,extra={})=>({id,source,target,type:'motion',sourceHandle:'right',targetHandle:'left',markerEnd:{type:MarkerType.ArrowClosed,color:pulseIds.includes(id)?extra.back?'#b46d23':'#078963':'#d9e5de'},data:{label,pulse:pulseIds.includes(id)?event?.seq:0,...extra}}),[pulseIds,event]);
  const edges=useMemo(()=>{
    const items=[{...edge('askPolicy','intent','government_qa',t('askPolicy')),sourceHandle:'top-progress',targetHandle:'bottom-progress'},edge('startFromQA','government_qa','service',''),edge('choose','intent','service',t('identify')),edge('open','service','collecting',t('acceptPrefill'))];
    if(selected?.mode==='query')items.push({...edge('query','collecting','completed',t('queryReady'),{route:'query'}),sourceHandle:'top-progress',targetHandle:'bottom-progress'});
    else items.push({...edge('complete','collecting','review',t('detailsReady')),sourceHandle:'top-progress',targetHandle:'bottom-progress'},edge('submit','review','completed',t('confirm')));
    if(selected?.mode!=='query')items.push({...edge('back','review','collecting',t('retract'),{route:'back',back:true}),sourceHandle:'bottom-back',targetHandle:'top-back'});
    if(pulseIds.includes('update'))items.push({...edge('update','collecting','collecting',t(event?.kind==='answer'?'explain':'update'),{route:'loop'}),sourceHandle:'loop-out',targetHandle:'loop-in'});
    const rawFrom=event?.to_state==='intent'?event.from_state:'collecting';
    const from=rawFrom==='service_intro'?'service':rawFrom;
    const route=from==='review'?'return-left':from==='completed'?'return-right':'return-bottom';
    items.push({...edge('restart',titles[from]||from==='service'?from:'collecting','intent',t(event?.to_state==='intent'?(event.kind==='cancel'?'cancelSaved':'chooseAgain'):'cancelSwitch'),{route,back:true}),sourceHandle:from==='review'?'left-return':from==='completed'?'right':'bottom',targetHandle:'return'});
    return items;
  },[selected,active,event,edge,pulseIds,t]);
  return <div className="diagram-container" ref={graphContainer}><ReactFlow nodes={nodes} edges={edges} onNodesChange={onNodesChange} nodeTypes={nodeTypes} edgeTypes={edgeTypes} nodesDraggable={false} nodesConnectable={false} elementsSelectable={false} onNodeClick={(_,node)=>onInspect(node.id)} onInit={instance=>{flowInstance.current=instance;fitDiagram()}} fitViewOptions={{padding:.3}} minZoom={.25} maxZoom={1.6} ariaLabelConfig={{'controls.zoomIn.ariaLabel':t('zoomIn'),'controls.zoomOut.ariaLabel':t('zoomOut'),'controls.fitView.ariaLabel':t('fit')}}><Background gap={22} size={1} color="#dfe9e2"/><Controls showInteractive={false} onFitView={fitDiagram}/></ReactFlow></div>;
}

function App(){
  const [lang,setLang]=useState(()=>{if(!localStorage.getItem('tr_observer_defaults_v2')){localStorage.setItem('tr_observer_lang','en');localStorage.setItem('tr_observer_defaults_v2','1')}const hint=new URLSearchParams(location.search).get('ui_lang');const saved=hint||localStorage.getItem('tr_observer_lang')||'en';return ['en','th','zh'].includes(saved)?saved:'en'});
  const t=useMemo(()=>translator(lang),[lang]);
  const titles=Object.fromEntries(stateKeys.map(key=>[key,t(key)]));
  useEffect(()=>{localStorage.setItem('tr_observer_lang',lang);document.documentElement.lang=locales[lang];document.title=t('title')+' · Tang Rat Voice';if(new URLSearchParams(location.search).has('ui_lang')){const url=new URL(location.href);url.searchParams.delete('ui_lang');history.replaceState(null,'',url.pathname+url.search+url.hash)}},[lang,t]);
  const [catalog,setCatalog]=useState([]),[snapshot,setSnapshot]=useState(null),[events,setEvents]=useState([]),[event,setEvent]=useState(null),[voice,setVoice]=useState(null),[connection,setConnection]=useState('loading'),[code,setCode]=useState(''),[error,setError]=useState(''),[inspect,setInspect]=useState('collecting');
  const [conversation,setConversation]=useState([]);
  const [pairing,setPairing]=useState(false);
  const [fieldHighlights,setFieldHighlights]=useState({}),fieldTimer=useRef(null),formPanel=useRef(null);
  const [viewport,setViewport]=useState(()=>({width:innerWidth,height:innerHeight}));
  const [sizes,setSizes]=useState(()=>{try{return JSON.parse(localStorage.getItem('tr_observer_layout')||'{}')}catch{return {}}});
  useEffect(()=>{const resize=()=>setViewport({width:innerWidth,height:innerHeight});window.addEventListener('resize',resize);return()=>window.removeEventListener('resize',resize)},[]);
  const formWidth=Math.max(310,Math.min(sizes.form||Math.min(420,viewport.width*.28),viewport.width*.37));
  const conversationHeight=Math.max(180,Math.min(sizes.conversation||Math.max(215,Math.min(250,viewport.height*.26)),Math.max(215,viewport.height-430)));
  function resizePanel(key,value){setSizes(current=>{const next={...current};if(value==null)delete next[key];else next[key]=value;localStorage.setItem('tr_observer_layout',JSON.stringify(next));return next})}
  useEffect(()=>{
    const panel=formPanel.current,key=Object.keys(fieldHighlights)[0];if(!panel||!key)return;
    const field=panel.querySelector(`[data-field="${key}"]`);if(!field)return;
    const parent=panel.getBoundingClientRect(),rect=field.getBoundingClientRect();
    if(rect.top<parent.top+48||rect.bottom>parent.bottom)panel.scrollTo({top:panel.scrollTop+rect.top-parent.top-55,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
  },[fieldHighlights]);
  const csrf=useRef(''),source=useRef(null),sequence=useRef(0),currentId=useRef(null),pulseTimer=useRef(null),mounted=useRef(true);
  const request=useCallback(async(path,options={})=>{
    const response=await fetch(path,{credentials:'same-origin',...options,headers:{'Content-Type':'application/json','x-csrf-token':csrf.current,...options.headers}});
    const data=await response.json();if(!response.ok){const error=Error(response.status===429?'pairRate':[400,404].includes(response.status)?'pairInvalid':response.status===403?'pairExpired':'connectionFailed');error.status=response.status;throw error}return data;
  },[]);
  const mergeConversation=useCallback((draftId,messages)=>{
    if(draftId!==currentId.current)return;
    setConversation(current=>{const byId=new Map(current.map(message=>[message.id,message]));for(const message of messages||[])byId.set(message.id,message);return [...byId.values()].sort((a,b)=>a.id-b.id)});
  },[]);
  const loadConversation=useCallback(()=>request('/api/observer/conversation').then(data=>mergeConversation(data.draft_id,data.messages)).catch(error=>{if(error.status!==403)setError('historyFailed')}),[request,mergeConversation]);
  const accept=useCallback((next,transition=null)=>{
    if(currentId.current===next.id&&next.event_seq<sequence.current)return;
    const newTransition=transition&&(currentId.current!==next.id||transition.seq>sequence.current);
    if(currentId.current!==next.id){setEvents([]);setVoice(null);setConversation([]);setFieldHighlights({})}
    currentId.current=next.id;sequence.current=next.event_seq||0;setSnapshot(next);
    mergeConversation(next.id,next.messages);
    clearTimeout(pulseTimer.current);setEvent(transition);
    if(transition){setEvents(old=>[...old.filter(e=>e.seq!==transition.seq),transition].slice(-20));pulseTimer.current=setTimeout(()=>setEvent(null),950);}
    if(newTransition){
      const allowed=new Set((next.schema||[]).map(field=>field.key));
      const changed=Object.fromEntries(Object.entries(transition.changes||{}).filter(([key,change])=>allowed.has(key)&&change.before!==change.after).map(([key,change])=>[key,{...change,token:`${next.id}-${transition.seq}-${key}`} ]));
      if(Object.keys(changed).length){clearTimeout(fieldTimer.current);setFieldHighlights(changed);fieldTimer.current=setTimeout(()=>setFieldHighlights({}),2800)}
    }
  },[mergeConversation]);
  const connect=useCallback(()=>{
    source.current?.close();const stream=new EventSource('/api/observer/stream');source.current=stream;setConnection('connecting');
    stream.addEventListener('open',()=>{setConnection('live');setError('')});
    stream.addEventListener('snapshot',message=>{try{const data=JSON.parse(message.data);accept(data.snapshot);setEvents(data.events||[]);loadConversation()}catch{setError('snapshotFailed')}});
    stream.addEventListener('update',message=>{try{const data=JSON.parse(message.data);accept(data.snapshot,data.event)}catch{setError('eventFailed')}});
    stream.addEventListener('voice',message=>{try{setVoice(JSON.parse(message.data))}catch{}});
    stream.addEventListener('revoked',()=>{stream.close();setConnection('unpaired');setSnapshot(null);setConversation([]);currentId.current=null;setError('pairExpired')});
    stream.onerror=()=>{setConnection('reconnecting');request('/api/observer/snapshot').catch(error=>{if(error.status===403){stream.close();setConnection('unpaired');setSnapshot(null);setConversation([]);currentId.current=null;setError('pairExpired')}})};
  },[accept,request,loadConversation]);
  useEffect(()=>{
    mounted.current=true;
    request('/api/observer/bootstrap').then(data=>{if(!mounted.current)return;csrf.current=data.csrf;setCatalog(data.catalog);if(data.snapshot){accept(data.snapshot);connect()}else setConnection('unpaired')}).catch(e=>{setError(e.status?e.message:'connectionFailed');setConnection('unpaired')});
    return ()=>{mounted.current=false;source.current?.close();clearTimeout(pulseTimer.current);clearTimeout(fieldTimer.current)};
  },[request,accept,connect]);
  async function pair(e){e.preventDefault();if(!csrf.current||pairing)return;setPairing(true);setError('');try{const data=await request('/api/observer/pair',{method:'POST',body:JSON.stringify({code})});accept(data.snapshot);setCode('');connect()}catch(e){setError(e.status?e.message:'connectionFailed')}finally{setPairing(false)}}
  async function unpair(){try{await request('/api/observer/session',{method:'DELETE'});source.current?.close();setSnapshot(null);setEvents([]);setEvent(null);setVoice(null);setConversation([]);currentId.current=null;sequence.current=0;setConnection('unpaired')}catch(e){setError(e.status?e.message:'connectionFailed')}}
  const meta=catalog.find(s=>s.id===snapshot?.service),fields=snapshot?.schema||[],filled=fields.filter(f=>snapshot.fields?.[f.key]).length;
  const connected=!!snapshot;
  return <div className="observer-app" data-paired={connected} style={{'--form-width':formWidth+'px','--conversation-height':conversationHeight+'px'}}>
    <div className="observer-top">
    <header className="app-header"><div className="heading"><span className="demo-label">TANG RAT VOICE · {t('service')}</span><h1>{t('title')}</h1><p>{t('subtitle')}</p></div><div className="observer-tools"><div className="language-switch" role="group" aria-label={t('displayLanguage')}>{languages.map(([value,name])=><button type="button" key={value} data-lang={value} aria-pressed={lang===value} onClick={()=>setLang(value)}>{name}</button>)}</div><span className={`connection ${connection==='live'?'live':''}`}><i/>{t(connection)}</span>{connected&&<button className="quiet-button" onClick={unpair}>{t('disconnect')}</button>}</div></header>
    {!connected&&<form className="pair-bar" onSubmit={pair}><img className="pair-illustration" src="/assets/brand/ai.svg" alt=""/><div><strong>{t('pairTitle')}</strong><span>{t('pairText')}</span></div><label htmlFor="pair-code" className="sr-only">{t('pairLabel')}</label><input id="pair-code" disabled={!csrf.current||pairing} inputMode="numeric" autoComplete="off" value={code} onChange={e=>setCode(e.target.value)} placeholder={t('pairPlaceholder')} maxLength={12} required/><button className="primary-button" type="submit" disabled={!csrf.current||pairing}>{t(pairing?'connecting':'pairButton')}</button></form>}
    {error&&<div role="alert" className="error-message">{t(error)}</div>}
    <div className="session-strip"><span className="readonly-badge">{t('readOnly')}</span><span>{t('session')} <b>{snapshot?.id?.slice(-6).toUpperCase()||'—'}</b></span><span>{t('currentService')} <b>{label(meta,lang)||t('waitingIntent')}</b></span><span>{t('currentState')} <b data-current-state>{connected?titles[snapshot.state]:t('notConnected')}</b></span><span className="voice-status">{connected?(voice?.phase?t(voice.phase==='error'?'voiceError':voice.phase):t('waitingVoice')):t('enterCode')}</span></div>
    </div>
    <main className="main-layout">
      <aside className="service-list"><div className="section-heading"><h2>{t('services')}</h2><span>{catalog.length} {lang==='zh'?'项服务':lang==='th'?'บริการ':'services'}</span></div><div className="service-tree"><div className="tree-root">{t('intent')}</div>{catalog.map(item=><button key={item.id} title={label(item,lang)} aria-label={label(item,lang)} className={`service-choice ${snapshot?.service===item.id?'selected':''}`} onClick={()=>setInspect(item.id)}><img src={serviceIcon(item.id)} alt=""/><span>{serviceLabel(item,lang)}</span><small>{t(item.mode==='query'?'query':'application')}</small>{snapshot?.archives?.some(d=>d.service===item.id)&&<em>{t('savedDraft')}</em>}</button>)}</div><p className="scope-note">{t('scope')}</p></aside>
      <section className="graph-panel" aria-label={t('graphAria')}><div className="section-heading graph-title"><div><h2>{t('graph')}</h2><span>{t('graphHint')}</span></div><span className="legend"><i/>{t('forward')} <i className="back"/>{t('backward')}</span></div><div className="graph-area"><ReactFlowProvider><Diagram snapshot={snapshot} event={event} onInspect={setInspect} catalog={catalog} lang={lang} t={t}/></ReactFlowProvider></div><div className="node-inspector">{[...stateKeys,'service'].includes(inspect)?t(inspect+'Description'):<><strong>{label(catalog.find(s=>s.id===inspect),lang)}</strong> · {t('inspectNote')} <a href={catalog.find(s=>s.id===inspect)?.source} target="_blank" rel="noreferrer">{t('official')}</a></>}</div></section>
      <ResizeHandle axis="x" className="form-resizer" label={t('resizeForm')} value={formWidth} min={310} max={viewport.width*.37} onChange={value=>resizePanel('form',value)} onReset={()=>resizePanel('form',null)}/>
      <aside className="right-sidebar"><section className="form-panel" ref={formPanel}><div className="section-heading"><h2>{t(meta?.mode==='query'?'queryForm':'applicationForm')}</h2><span>{fields.length?t('filled',{filled,total:fields.length}):t('waitingService')}</span></div><div className="form-service-title">{meta&&<img src={serviceIcon(meta.id)} alt=""/>}<h3>{label(meta,lang)||t('startSentence')}</h3></div><p className="form-note">{t(meta?'formNote':'formEmpty')}</p><div className="verification-list" aria-live="polite">{Object.entries(snapshot?.checks||{}).map(([key,check])=><div key={key} className={`verification-item ${check.status}`} data-check={key} data-status={check.status}><span className="verification-dot"/><div><strong>{t(key==='identity'?'identityCheck':'areaCheck')}</strong><small>{t('check_'+check.code+'_'+check.status)}</small></div></div>)}</div><dl className="live-fields">{fields.map(field=>{
        const change=fieldHighlights[field.key];
        const option=field.options?.find(item=>item.value===snapshot.fields[field.key]);
        return <div key={`${snapshot.service}-${field.key}-${change?.token||'stable'}`} data-field={field.key} data-change-token={change?.token} className={`live-field ${change?'field-updated':''} ${field.key==='address'||field.type==='textarea'?'field-long':''}`}>
          <dt title={label(field,lang)}>{fieldLabel(field,lang)}{['province','district','subdistrict'].includes(field.key)&&snapshot.service==='flood-relief-preparation'&&<small className="derived-label">{t('fromAddress')}</small>}{!field.required&&<small>{t('optional')}</small>}{change&&<span className="field-update-label" title={t(change.after?'fieldUpdated':'fieldRetracted')}>{t(change.after?'fieldUpdated':'fieldRetracted')}</span>}</dt>
          <dd key={change?.token||'stable'} className={!snapshot.fields[field.key]?'empty':''}>{label(option,lang)||(field.type==='date'&&/^\d{4}-\d{2}-\d{2}$/.test(snapshot.fields[field.key]||'')?new Intl.DateTimeFormat(lang==='th'?'th-TH-u-ca-gregory':locales[lang],{year:'numeric',month:'long',day:'numeric',timeZone:'UTC'}).format(new Date(snapshot.fields[field.key]+'T00:00:00Z')):snapshot.fields[field.key])||t('empty')}</dd>
          {snapshot.errors?.[field.key]&&<small className="field-error">{t('correctValue')}</small>}
        </div>;
      })}</dl>{snapshot?.result&&<div className="result-panel" data-query-result><strong>{t('queryDone')}</strong><p>{t('queryBoundary')}</p></div>}{snapshot?.receipt&&<div className="result-panel"><strong>{t('receipt')}</strong><p>{snapshot.receipt}</p><p>{t('notSubmitted')}</p></div>}{snapshot?.archives?.length>0&&<p className="draft-note">{t('draftsSaved',{count:snapshot.archives.length})}</p>}{meta&&<a className="official-source" href={meta.source} target="_blank" rel="noreferrer">{t('official')}</a>}</section><Transitions events={events} catalog={catalog} fields={fields} lang={lang} t={t} titles={titles}/></aside>
    </main>
    <ResizeHandle axis="y" className="conversation-resizer" label={t('resizeConversation')} value={conversationHeight} min={180} max={Math.max(180,viewport.height-430)} onChange={value=>resizePanel('conversation',value)} onReset={()=>resizePanel('conversation',null)}/>
    <section className="live-bottom" aria-label={t('conversationAria')}><Conversation key={snapshot?.id||'unpaired'} messages={conversation} snapshot={snapshot} voice={voice} uiLang={lang} t={t}/></section>
    <footer>{t('footer')}</footer>
  </div>;
}

createRoot(document.getElementById('root')).render(<App/>);
