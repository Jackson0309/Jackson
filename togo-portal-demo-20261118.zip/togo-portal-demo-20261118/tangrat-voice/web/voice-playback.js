// Playback completion is acknowledged only after the local output queue drains.
export class TurnPlayback {
  constructor(context,send,onError,muted=()=>false,onDone=()=>{}) {
    this.context=context;this.send=send;this.onError=onError;this.muted=muted;this.onDone=onDone;
    this.nodes=new Set();this.next=0;this.version=0;this.epoch=-1;this.speech=-1;this.done=false;this.acked=false;this.waitingStop=null;
    this.native=typeof window.HarmonyAudio?.beginPlayback==='function';
    this.nativeHandler=event=>this.nativeEvent(event);
    if(this.native)window.nativePlaybackEvent=this.nativeHandler;
  }
  matches(epoch,speech){return epoch===this.epoch&&speech===this.speech}
  begin(epoch,speech){
    this.version++;this.epoch=epoch;this.speech=speech;this.done=false;this.acked=false;this.started=false;this.next=0;this.waitingStop=null;this.nativeDrained=false;
    if(this.native)window.HarmonyAudio.beginPlayback(epoch,speech);
  }
  packet(buffer){
    if(buffer.byteLength<10)return;
    const view=new DataView(buffer),epoch=view.getUint32(0,true),speech=view.getUint32(4,true);
    if(!this.matches(epoch,speech)||this.acked||this.waitingStop)return;
    if(this.muted())return;
    const pcm=new Int16Array(buffer.slice(8));
    if(this.native){
      const bytes=new Uint8Array(buffer,8);let raw='';for(const value of bytes)raw+=String.fromCharCode(value);
      window.HarmonyAudio.writePlayback(btoa(raw),epoch,speech);return;
    }
    if(!this.started){this.started=true;this.send({type:'playback_started',epoch,speech_id:speech})}
    const output=this.context.createBuffer(1,pcm.length,24000),channel=output.getChannelData(0);
    for(let i=0;i<pcm.length;i++)channel[i]=pcm[i]/32768;
    const node=this.context.createBufferSource();node.buffer=output;node.connect(this.context.destination);
    const version=this.version;this.next=Math.max(this.context.currentTime+.025,this.next);node.start(this.next);this.next+=output.duration;
    this.nodes.add(node);
    node.onended=()=>{this.nodes.delete(node);if(version===this.version)this.maybeEnd()};
    if(this.nodes.size>200){this.stopLocal();this.onError('Playback queue exceeded its limit. Reconnect the call. / 播放队列过长，请重新开启通话。')}
  }
  finish(epoch,speech){
    if(!this.matches(epoch,speech)||this.waitingStop)return;
    this.done=true;
    if(this.native&&!this.muted())window.HarmonyAudio.finishPlayback(epoch,speech);
    else this.maybeEnd();
  }
  maybeEnd(){
    if(!this.done||this.acked||this.nodes.size||this.waitingStop)return;
    if(this.native&&!this.muted()&&!this.nativeDrained)return;
    this.acked=true;this.send({type:'playback_ended',epoch:this.epoch,speech_id:this.speech});this.onDone();
  }
  stopLocal(){
    this.version++;this.done=false;this.acked=true;this.next=0;
    for(const node of this.nodes){node.onended=null;try{node.stop()}catch{}node.disconnect()}
    this.nodes.clear();
    if(this.native)window.HarmonyAudio.stopPlayback(this.epoch,this.speech);
  }
  stopRequired(epoch,speech){
    this.stopLocal();this.epoch=epoch;this.speech=speech;this.waitingStop={epoch,speech};
    if(this.native)window.HarmonyAudio.stopPlayback(epoch,speech);
    else this.ackStop(epoch,speech);
  }
  ackStop(epoch,speech){
    if(this.waitingStop?.epoch!==epoch||this.waitingStop?.speech!==speech)return;
    this.waitingStop=null;this.send({type:'playback_stopped',epoch,speech_id:speech});
  }
  nativeEvent(event){
    if(event.type==='stopped'){this.ackStop(event.epoch,event.speechId);return}
    if(!this.matches(event.epoch,event.speechId))return;
    if(event.type==='started')this.send({type:'playback_started',epoch:event.epoch,speech_id:event.speechId});
    if(event.type==='ended'){this.nativeDrained=true;this.maybeEnd()}
    if(event.type==='error')this.onError('Native playback failed. Reconnect the call. / 原生播放失败，请重新开启通话。');
  }
  dispose(){this.stopLocal();if(window.nativePlaybackEvent===this.nativeHandler)window.nativePlaybackEvent=null}
}

export function inputPacket(pcm,turnId){
  const bytes=new Uint8Array(4+pcm.byteLength);new DataView(bytes.buffer).setUint32(0,turnId,true);bytes.set(new Uint8Array(pcm),4);return bytes.buffer;
}
