let csrf='';
const feedback=document.querySelector('#feedback');
const secrets={deepseek_key:'deepseekStatus',openrouter_key:'openrouterStatus',elevenlabs_key:'elevenlabsStatus',iflytek_app_id:'iflytekAppStatus',iflytek_api_key:'iflytekKeyStatus',iflytek_api_secret:'iflytekSecretStatus'};
function message(text,error=false){feedback.textContent=text;feedback.style.background=error?'#fff0ec':'#e9f6ee';feedback.style.color=error?'#a0473f':'#17674f';}
async function request(path,options={}){
 const response=await fetch(path,{credentials:'same-origin',cache:'no-store',...options});
 let data;try{data=await response.json()}catch{throw Error('后台未返回有效数据，请检查服务是否正在运行。')}
 if(!response.ok)throw Error(typeof data.detail==='string'?data.detail:'请求失败，HTTP '+response.status);
 return data;
}
async function readStatus(){
 const bootstrap=await request('/api/bootstrap');csrf=bootstrap.csrf;
 const status=await request('/api/operator');
 for(const element of document.querySelectorAll('#config [name]')){
  if(element.name in secrets)document.getElementById(secrets[element.name]).textContent=status[element.name]?'✓ 已保存，留空保留':'尚未配置';
  else if(typeof status[element.name]==='string')element.value=status[element.name];
 }
 document.querySelector('#storageStatus').textContent=status.storage_error||(status.storage==='windows_dpapi_current_user'?'Windows 当前账户加密保存；重启后自动加载。文件位于本项目 data/operator-config.local，不能直接迁移给其他账户。':'服务端以仅当前用户可读的配置文件保存；重启后自动加载。');
 if(status.storage_error)throw Error(status.storage_error);
 return status;
}
async function save(body){
 const buttons=document.querySelectorAll('button');buttons.forEach(button=>button.disabled=true);
 const saveButton=document.querySelector('#save');saveButton.textContent='正在保存…';message('正在加密并保存配置…');
 try{
  if(!csrf)await readStatus();
  await request('/api/operator',{method:'POST',headers:{'content-type':'application/json','x-csrf-token':csrf},body:JSON.stringify(body)});
  document.querySelectorAll('input[type=password]').forEach(input=>input.value='');
  const status=await readStatus();
  message(`✓ 已保存到本机（${new Date().toLocaleTimeString()}），重启后自动加载。ASR：${status.asr_provider}；TTS：${status.tts_provider}。请结束原通话，再刷新应用并重新开始。`);
 }catch(error){message('保存失败：'+error.message,true)}
 finally{buttons.forEach(button=>button.disabled=false);saveButton.textContent='保存到本机'}
}
document.querySelector('#config').onsubmit=event=>{
 event.preventDefault();const body=Object.fromEntries(new FormData(event.target));
 for(const key of Object.keys(secrets))if(!body[key].trim())delete body[key];
 save(body);
};
document.querySelector('#clear').onclick=()=>{
 if(confirm('清除本机保存的所有平台凭据？配置文件中的凭据将清空。'))save(Object.fromEntries(Object.keys(secrets).map(key=>[key,''])));
};
let previewUrl='';
async function preview(lang){
 const status=document.querySelector('#previewStatus'),buttons=document.querySelectorAll('#previewChinese,#previewEnglish,#previewThai');
 buttons.forEach(button=>button.disabled=true);status.textContent='正在生成试听，请先保存需要使用的平台和模型…';
 try{
  if(!csrf)await readStatus();
  const response=await fetch('/api/tts',{method:'POST',headers:{'content-type':'application/json','x-csrf-token':csrf},body:JSON.stringify({lang,text:lang==='th'?'สวัสดีค่ะ คุณต้องการลงทะเบียนช่วยเหลือผู้ประสบอุทกภัย หรือเงินอุดหนุนเด็กแรกเกิดคะ กรุณาตรวจสอบข้อมูลก่อนยืนยันค่ะ':lang==='zh'?'您好，我是您的政务服务助手。您想办理儿童补贴，还是洪灾救助登记？申请资料会由您核对后再确认。':'Hello, I am your government service assistant. Would you like to prepare a child subsidy application or a flood relief registration? You will review the details before confirming.'})});
  if(!response.ok){const error=await response.json();throw Error(error.detail||'语音生成失败')}
  if(previewUrl)URL.revokeObjectURL(previewUrl);
  previewUrl=URL.createObjectURL(await response.blob());const audio=document.querySelector('#previewAudio');audio.src=previewUrl;await audio.play();status.textContent='生成成功，请试听自然度、人名和数字读法。';
 }catch(error){status.textContent='试听失败：'+error.message}
 finally{buttons.forEach(button=>button.disabled=false)}
}
document.querySelector('#previewChinese').onclick=()=>preview('zh');
document.querySelector('#previewEnglish').onclick=()=>preview('en');
document.querySelector('#previewThai').onclick=()=>preview('th');
readStatus().then(status=>message(status.persisted?'✓ 本机配置已自动加载。密码框留空可以直接切换模型。':'尚未保存本机配置。首次保存后，后端重启将自动加载。')).catch(error=>message('无法读取配置：'+error.message,true));
