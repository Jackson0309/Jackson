// A local earcon. Microphone packets are gated by the caller until its tail ends.
export function playListeningCue(context){
 if(!context||context.state!=='running')return Promise.resolve();
 return new Promise(resolve=>{
  const gain=context.createGain(),osc=context.createOscillator(),start=context.currentTime+.01;
  gain.gain.setValueAtTime(0,start);gain.gain.linearRampToValueAtTime(.075,start+.008);gain.gain.exponentialRampToValueAtTime(.001,start+.16);
  osc.type='sine';osc.frequency.setValueAtTime(1046.5,start);osc.connect(gain);gain.connect(context.destination);
  osc.onended=()=>{osc.disconnect();gain.disconnect();setTimeout(resolve,20);};osc.start(start);osc.stop(start+.17);
 });
}
