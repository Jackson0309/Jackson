import {displayFieldValue} from './field-presentation.js?v=20261115-call-3';
// Shared phone/web presentation for the server-owned intent workflow.
export const FLOW='intent-graph-v1';
export const graphCopy={
  zh:{intentSub:'说出您的需求。事项明确后先介绍要求，您同意预填后再采集、校验和推进；您可以随时更正、撤回、取消或改办。',intentIntro:'支持 10 项服务演示。申请准备与查询分开呈现，政府系统尚未接入。',heroText:'洪灾救助、儿童补贴、医保、罚单等 10 项服务。从一句话开始，系统帮助整理资料。',step1Text:'说出需求后，系统识别明确事项，并实时填写您已提供的信息。',intentTitle:'您想办理什么事项？',pairObserver:'连接电脑演示屏',queryConditions:'查询条件与模拟结果',queryBoundary:'本地模拟查询，未连接政府数据库，不代表真实个人记录。'},
  en:{intentSub:'Tell us what you need. The system explains the service first and asks permission before collecting details. You can correct, retract, cancel or switch.',intentIntro:'Ten demonstration services: application preparation and queries. Government systems are not connected.',heroText:'Flood relief, child subsidy, health benefits, fines and more. Start with a conversation across ten demo services.',step1Text:'Describe your request. The service overview opens first. Details are collected after you agree to prefill.',intentTitle:'Which service would you like?',pairObserver:'Connect a presentation screen',queryConditions:'Query conditions and simulated result',queryBoundary:'Local simulated query. No government database or real personal record was accessed.'},
  th:{intentSub:'บอกความต้องการ ระบบอธิบายบริการและขออนุญาตก่อนเริ่มกรอกข้อมูล สามารถแก้ไข ลบ ยกเลิก หรือเปลี่ยนบริการได้ค่ะ',intentIntro:'สาธิต 10 บริการ ทั้งเตรียมใบสมัครและตรวจสอบข้อมูล ยังไม่เชื่อมต่อระบบรัฐบาล',heroText:'เงินช่วยเหลือน้ำท่วม เงินอุดหนุนเด็ก สิทธิสุขภาพ ใบสั่ง และบริการอื่น รวม 10 บริการสาธิต',step1Text:'บอกความต้องการ เมื่อระบุบริการได้ชัดเจน ระบบจะแสดงแบบฟอร์มและกรอกข้อมูลที่แจ้งทันที',intentTitle:'ต้องการใช้บริการใดคะ',pairObserver:'เชื่อมต่อจอการนำเสนอ',queryConditions:'เงื่อนไขและผลการตรวจสอบสาธิต',queryBoundary:'ผลสาธิตในเครื่อง ไม่ได้ตรวจสอบฐานข้อมูลรัฐบาลหรือข้อมูลส่วนบุคคลจริง'}
};

export function renderWorkflowMini(ctx){
  const {draft,lang,state,t,esc,api,toast,go}=ctx;
  const $=s=>document.querySelector(s), intake=draft.service==='intent-intake', meta=state.services[draft.service];
  const intro=['service_intro','government_qa'].includes(draft.workflow.state);
  const fields=draft.schema||[],required=fields.filter(f=>f.required),done=required.length-(draft.missing?.length||0);
  $('#callLayout')?.classList.toggle('intake',intake);
  if($('#callHeading'))$('#callHeading').textContent=intake?t('intentTitle'):meta?.[lang]||t('callTitle');
  if($('#activeServiceTitle'))$('#activeServiceTitle').textContent=meta?.[lang]||t('intentTitle');
  if($('#intentPanel')){
    $('#intentPanel').hidden=!intake&&!intro;
    $('#intentPanel').innerHTML=intro?`<h2>${esc(meta?.[lang]||'')}</h2><p>${esc(draft.questions?.[lang]||'')}</p><div class="actions-row"><button class="primary" id="acceptPrefill">${lang==='zh'?'开始预填':lang==='th'?'เริ่มกรอก':'Start prefilling'}</button><button class="secondary" id="declinePrefill">${lang==='zh'?'暂不预填':lang==='th'?'ยังไม่กรอก':'Not now'}</button></div>`:intake?`<h2>${esc(t('intentTitle'))}</h2><p>${esc(draft.questions?.[lang]||'')}</p><div class="workflow-service-list">${Object.values(state.services).map(s=>`<span>${esc(s[lang])}</span>`).join('')}</div>`:'';
    $('#acceptPrefill')?.addEventListener('click',()=>ctx.sendText({en:'yes please',zh:'好的',th:'ใช่ค่ะ'}[lang]));
    $('#declinePrefill')?.addEventListener('click',()=>ctx.sendText({en:'not now',zh:'暂不',th:'ยังไม่ค่ะ'}[lang]));
  }
  if(!$('#pairObserver')&&$('#intentPanel')){
    const box=document.createElement('div');box.className='observer-pair-hint';
    const button=document.createElement('button');button.className='text-button';button.id='pairObserver';button.type='button';button.textContent=t('pairObserver');
    button.onclick=async()=>{
      button.disabled=true;
      try{
        const r=await api(`/api/drafts/${draft.id}/observe-code`,{method:'POST',body:{}});
        const dialog=document.createElement('dialog');dialog.className='observer-pair-dialog';
        const title=lang==='zh'?'在电脑打开观察台':lang==='th'?'เปิดหน้าสังเกตการณ์บนคอมพิวเตอร์':'Open the observer on your computer';
        const note=lang==='zh'?'配对码 10 分钟内有效，只能使用一次。电脑仅能观察，不能修改或提交。':lang==='th'?'รหัสใช้ได้ครั้งเดียวภายใน 10 นาที จอสามารถดูได้เท่านั้น ไม่แก้ไขหรือส่งข้อมูล':'One-time code, valid for 10 minutes. The screen can observe but cannot edit or submit.';
        dialog.innerHTML=`<h2>${esc(title)}</h2><p class="observer-address">${esc(location.origin+'/observer')}</p><output class="observer-code" aria-label="Pairing code">${esc(r.code.slice(0,4)+' '+r.code.slice(4))}</output><p>${esc(note)}</p><button class="primary" type="button">${lang==='zh'?'关闭':lang==='th'?'ปิด':'Close'}</button>`;
        dialog.querySelector('button').onclick=()=>{dialog.close();dialog.remove()};dialog.addEventListener('cancel',()=>dialog.remove());document.body.append(dialog);dialog.showModal();
      }catch(error){toast(error.message)}finally{button.disabled=false}
    };
    box.append(button);$('#intentPanel').before(box);
  }
  if($('#applicationProgress'))$('#applicationProgress').hidden=intake||intro;
  if($('#sample'))$('#sample').disabled=intro;
  if($('#progressText'))$('#progressText').textContent=`${done} / ${required.length}`;
  if($('#progressBar'))$('#progressBar').style.width=(required.length?done/required.length*100:0)+'%';
  if($('#miniFields'))$('#miniFields').innerHTML=(meta?.mode==='query'?`<div class="workflow-query-note">${esc(t('queryBoundary'))}</div>`:'')+fields.map(f=>`<div class="field-mini"><span>${esc(f[lang])}</span><b>${esc(displayFieldValue(f,draft.fields[f.key],lang)||t('missing'))}</b></div>`).join('')+(draft.workflow.result?`<div class="workflow-result" data-query-result>${esc(lang==='zh'?'模拟查询已完成':lang==='th'?'ตรวจสอบสาธิตเสร็จแล้ว':'Simulated query complete')}<small>${esc(t('queryBoundary'))}</small></div>`:'');
  const reviewButton=document.querySelector('[data-action="review"]');if(reviewButton){reviewButton.textContent=meta?.mode==='query'?t('queryConditions'):t('review');reviewButton.disabled=intake||intro;}
  if($('#transcript')){$('#transcript').innerHTML=(draft.messages.length?draft.messages:[{role:'assistant',content:draft.questions?.[lang]||''}]).map(m=>`<p class="${m.role==='user'?'user':''}"><small>${t(m.role==='user'?'you':'bot')}</small>${esc(m.content)}</p>`).join('');$('#transcript').scrollTop=$('#transcript').scrollHeight;}
}

export function queryForm({draft,lang,state,t,esc}){
  return `<button class="back" data-go="applications">← ${t('back')}</button><div class="page-heading"><h1>${esc(state.services[draft.service]?.[lang]||'')}</h1><p>${esc(t('queryConditions'))}</p></div><section class="panel"><div class="notice amber">${esc(t('queryBoundary'))}</div><div class="form-grid">${(draft.schema||[]).map(f=>`<div class="form-field"><label>${esc(f[lang])}</label><strong>${esc(displayFieldValue(f,draft.fields[f.key],lang)||t('missing'))}</strong></div>`).join('')}</div>${draft.workflow.result?`<div class="workflow-result" data-query-result>${esc(lang==='zh'?'模拟查询已完成':lang==='th'?'ตรวจสอบสาธิตเสร็จแล้ว':'Simulated query complete')}<small>${esc(t('queryBoundary'))}</small></div>`:''}<button class="primary" data-action="voice">${t('continueVoice')}</button></section>`;
}
