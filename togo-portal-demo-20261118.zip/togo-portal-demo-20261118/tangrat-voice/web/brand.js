export const serviceArts={
 duplicate:'documents',nationality:'documents',passport:'documents',criminal:'social',residence:'vehicle',courtfees:'credit',
 'flood-relief-preparation':'flood','child-subsidy-preparation':'child',
 'health-benefits-query':'health','health-entitlement-query':'health',
 'traffic-fines-query':'traffic','vehicle-registration-query':'vehicle',
 'social-security-query':'social','credit-summary-query':'credit',
 'elderly-allowance-query':'elderly','student-loan-query':'student','water-bill-query':'water',
};
export const art=(name,className='service-art')=>`<img class="${className}" src="/assets/brand/${serviceArts[name]||name}.svg" alt="" width="128" height="128" loading="lazy">`;
export const brandCopy={
 zh:{brandDemo:'体验演示',bannerTag:'政务服务，就在您身边',bannerText:'一句话选事项，边聊边填写。',quick:'您的常用服务',bannerLanguages:'English · ไทย · 中文',sectionHint:'选一个事项，或直接说出您的需求',startVoice:'开始语音办事',mainNavigation:'主要导航',openVoice:'语音办事',servicesCount:'10 项服务',receiptBrand:'办理回执',homeSubtitle:'轻松找到服务，随时核对资料。',shortcutSub:'便捷服务，一站办理'},
 en:{brandDemo:'Demo',bannerTag:'Your services, within reach',bannerText:'Name a service. Let the conversation fill the form.',quick:'Your shortcuts',bannerLanguages:'English · ไทย · 中文',sectionHint:'Choose a service or tell us what you need',startVoice:'Start voice services',mainNavigation:'Main navigation',openVoice:'Voice services',servicesCount:'10 services',receiptBrand:'Service receipt',homeSubtitle:'Find a service and keep your details in view.',shortcutSub:'Quick access'},
 th:{brandDemo:'สาธิต',bannerTag:'บริการภาครัฐใกล้คุณ',bannerText:'บอกบริการที่ต้องการ สนทนาเพื่อกรอกข้อมูล',quick:'บริการของคุณ',bannerLanguages:'English · ไทย · 中文',sectionHint:'เลือกบริการหรือบอกความต้องการของคุณ',startVoice:'เริ่มบริการด้วยเสียง',mainNavigation:'เมนูหลัก',openVoice:'บริการด้วยเสียง',servicesCount:'10 บริการ',receiptBrand:'ใบรับบริการ',homeSubtitle:'ค้นหาบริการง่าย ตรวจสอบข้อมูลได้ทุกเมื่อ',shortcutSub:'สะดวกในที่เดียว'},
};
