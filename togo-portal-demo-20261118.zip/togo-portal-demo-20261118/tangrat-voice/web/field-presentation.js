export const uiLocale=lang=>({en:'en-GB',zh:'zh-CN',th:'th-TH-u-ca-gregory'})[lang]||'en-GB';
export function displayFieldValue(field,value,lang){
 if(value===undefined||value===null||value==='')return '';
 const option=field?.options?.find(o=>String(o.value)===String(value));
 if(option)return option[lang]||option.en||String(value);
 if(field?.type==='date'&&/^\d{4}-\d{2}-\d{2}$/.test(value)){
  const date=new Date(value+'T00:00:00Z');
  if(Number.isFinite(date.getTime()))return new Intl.DateTimeFormat(uiLocale(lang),{year:'numeric',month:'long',day:'numeric',timeZone:'UTC'}).format(date);
 }
 return String(value);
}
export function dateInputValue(value,lang){
 const m=String(value||'').match(/^(\d{4})-(\d{2})-(\d{2})$/);if(!m)return value||'';
 return lang==='zh'?`${m[1]}/${m[2]}/${m[3]}`:`${m[3]}/${m[2]}/${m[1]}`;
}
export function dateStorageValue(value,lang){
 const v=String(value||'').trim();if(!v||/^\d{4}-\d{2}-\d{2}$/.test(v))return v;
 const parts=v.match(/^(\d{1,4})[/.](\d{1,2})[/.](\d{1,4})$/);if(!parts)return v;
 const [y,m,d]=lang==='zh'?[parts[1],parts[2],parts[3]]:[parts[3],parts[2],parts[1]];
 if(y.length!==4)return v;return `${y}-${m.padStart(2,'0')}-${d.padStart(2,'0')}`;
}
