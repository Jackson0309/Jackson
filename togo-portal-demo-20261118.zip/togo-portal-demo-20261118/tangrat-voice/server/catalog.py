"""Evidence-backed demo scope, not a volume ranking or official form specification."""
POPULAR = 'https://www.thangrath.go.th/feature/feature-category/popular-service/'
DGA_RANGE = 'https://www.dga.or.th/document-sharing/dga-news/130807/'
SUBJECT = ('query_subject', 'Query subject (demo)', '查询对象（演示）', 'text')
EXTRA_LABELS = {
    'query_subject': 'บุคคลที่ต้องการตรวจสอบ (สาธิต)',
    'vehicle_plate': 'ทะเบียนรถ (ตัวกรองสาธิต)',
    'contribution_period': 'ช่วงเวลาที่ต้องการตรวจสอบ (สาธิต)',
    'customer_number': 'เลขผู้ใช้น้ำตัวอย่าง',
    'water_provider': 'ผู้ให้บริการประปา',
    'academic_year': 'ปีการศึกษา (ตัวกรองสาธิต)',
}
EXTRA_SERVICES = {
    'health-entitlement-query': dict(en='Healthcare entitlement', zh='医疗保障权益查询', th='สิทธิการรักษาพยาบาล', prefix='MED', mode='query',
        fields=[SUBJECT], source=POPULAR, sample={'query_subject':'Demo self'}),
    'traffic-fines-query': dict(en='Traffic fines', zh='交通罚单查询', th='ใบสั่งจราจร', prefix='TRF', mode='query',
        fields=[SUBJECT, ('vehicle_plate','Vehicle plate (optional demo filter)','车牌（可选演示筛选）','text')],
        optional=['vehicle_plate'], source='https://www.thangrath.go.th/feature/check-traffic-fine/', sample={'query_subject':'Demo self','vehicle_plate':'DEMO A1234'}),
    'vehicle-registration-query': dict(en='Vehicle registration', zh='车辆登记查询', th='ทะเบียนรถ', prefix='VEH', mode='query',
        fields=[SUBJECT, ('vehicle_plate','Vehicle plate (optional demo filter)','车牌（可选演示筛选）','text')],
        optional=['vehicle_plate'], source='https://www.thangrath.go.th/feature/vehicle-registration-information/', sample={'query_subject':'Demo self','vehicle_plate':'DEMO B5678'}),
    'social-security-query': dict(en='Social security entitlement', zh='社会保险权益查询', th='สิทธิประกันสังคม', prefix='SOC', mode='query',
        fields=[SUBJECT, ('contribution_period','Period (optional demo filter)','期间（可选演示筛选）','text')],
        optional=['contribution_period'], source=DGA_RANGE, sample={'query_subject':'Demo self'}),
    'credit-summary-query': dict(en='Personal credit summary', zh='个人信用摘要查询', th='สรุปเครดิตบูโร', prefix='CRD', mode='query',
        fields=[SUBJECT], source=POPULAR, sample={'query_subject':'Demo self'}),
    'elderly-allowance-query': dict(en='Elderly allowance entitlement', zh='养老补贴权益查询', th='สิทธิเบี้ยผู้สูงอายุ', prefix='ELD', mode='query',
        fields=[SUBJECT], source='https://www.thangrath.go.th/feature/thangrat-elderly-allowance/', sample={'query_subject':'Demo self'}),
    'student-loan-query': dict(en='Student loan information', zh='学生贷款信息查询', th='ข้อมูลกู้ยืม กยศ.', prefix='STU', mode='query',
        fields=[SUBJECT, ('academic_year','Academic year (optional demo filter)','学年（可选演示筛选）','text')],
        optional=['academic_year'], source=DGA_RANGE, sample={'query_subject':'Demo self'}),
    'water-bill-query': dict(en='Water bill', zh='水费账单查询', th='ค่าน้ำประปา', prefix='WTR', mode='query',
        fields=[('customer_number','Sample customer reference','示例用水客户编号','text'),('water_provider','Water provider (optional demo filter)','供水机构（可选演示筛选）','text')],
        optional=['water_provider'], source='https://www.thangrath.go.th/thangrath-water-bill/', sample={'customer_number':'DEMO-WATER-001','water_provider':'PWA'}),
}
ORDER = ['flood-relief-preparation','child-subsidy-preparation',*EXTRA_SERVICES]
ALIASES = {
    'flood-relief-preparation': r'洪灾|洪水|水灾|受灾|水淹|淹水|flood(?:ing|ed)?|disaster\s+(?:relief|assistance)|เงิน(?:ช่วยเหลือ|เยียวยา)(?:ผู้ประสบภัย)?น้ำท่วม|น้ำท่วม|อุทกภัย',
    'child-subsidy-preparation': r'儿童补贴|育儿补贴|婴儿补贴|child\s+(?:subsidy|benefit|support)|baby\s+(?:subsidy|benefit)|เงินอุดหนุนเด็ก',
    'health-entitlement-query': r'医保|医疗(?:保障|权益|保险)?|health(?:care)?\s+(?:benefit|coverage|entitlement)|medical\s+(?:benefit|coverage|entitlement)|สิทธิ(?:การ)?รักษา|สิทธิบัตรทอง',
    'traffic-fines-query': r'罚单|交通罚款|traffic\s+(?:fine|ticket)|ใบสั่ง(?:จราจร)?',
    'vehicle-registration-query': r'车辆登记|车辆注册|车辆资料|车籍|vehicle\s+(?:registration|details)|ทะเบียนรถ',
    'social-security-query': r'社保|社会保险|社会保障|social\s+(?:security|insurance)|ประกันสังคม',
    'credit-summary-query': r'信用(?:摘要|报告|记录)|征信|credit\s+(?:bureau|summary|report)|เครดิตบูโร',
    'elderly-allowance-query': r'养老补贴|老人补贴|老年津贴|elderly\s+(?:allowance|benefit)|old.age\s+(?:allowance|benefit)|เบี้ย(?:ยังชีพ)?ผู้สูงอายุ',
    'student-loan-query': r'学生贷款|助学贷款|student\s+loan|กยศ|กู้ยืม(?:เงิน)?(?:เพื่อ)?การศึกษา',
    'water-bill-query': r'水费|水务账单|water\s+bill|ค่าน้ำ|ประปา',
}
FIELD_ALIASES = {
    'phone': ['联系电话','手机号码','电话号码','电话','手机号','phone','mobile number','contact number','เบอร์โทร','โทรศัพท์'],
    'applicant_name': ['申请人姓名','申请人','姓名','名字','applicant name','my name','name','ชื่อผู้สมัคร'],
    'guardian_name': ['监护人姓名','监护人','姓名','名字','guardian name','my name','name','ชื่อผู้ปกครอง'],
    'province': ['受灾地区','受灾省份','省份','省','府','province','จังหวัด'],
    'district': ['区县','区','县','district','อำเภอ'],
    'address': ['地址','address','ที่อยู่'],
    'damage_description': ['损失描述','损失','受损情况','damage','ความเสียหาย'],
    'query_subject': ['查询对象','对象','query subject','subject'],
    'vehicle_plate': ['车牌号码','车牌','plate','ทะเบียน'],
    'customer_number': ['客户编号','水费户号','用水编号','customer number','account reference','เลขผู้ใช้น้ำ'],
}

FIELD_ALIASES['flood_duration_days']=['flood duration','duration','受灾时长','ระยะเวลา','กี่วัน']

from . import togo
if togo.ACTIVE:
    ORDER=togo.ORDER
    ALIASES=togo.ALIASES
    FIELD_ALIASES=togo.FIELD_ALIASES
