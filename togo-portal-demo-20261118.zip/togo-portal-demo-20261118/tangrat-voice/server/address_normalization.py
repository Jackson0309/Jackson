"""Bounded spelling correction for the two presenter address scenarios.

Keep house numbers, raw transcripts, and unrelated locations unchanged. An
existing, different province/district in the reference directory is never guessed
away. No network request or second model call is needed.
"""
import re
from difflib import SequenceMatcher
from . import geography

TARGETS=(
    dict(province=('Chiang Mai','เชียงใหม่'),district=('Mueang Chiang Mai','เมืองเชียงใหม่'),
         subdistrict=('Suthep','สุเทพ'),aliases={'suthep','sothep','sothepp','sutep','sudhep','suthepp'}),
    dict(province=('Bangkok','กรุงเทพมหานคร'),district=('Bang Khen','บางเขน'),
         subdistrict=('Anusawari','อนุสาวรีย์'),aliases={'anusawari','anusavari','anusawaree','anusawary','anusawalee'}),
)

def part_norm(value):
    value=re.sub(r'^(?:(?:sub[- ]?district|tambon)\s+|(?:ตำบล|แขวง)\s*)','',str(value),flags=re.I)
    value=re.sub(r'\s+(?:sub[- ]?district|tambon)$','',value,flags=re.I)
    return geography.norm(value)

def similar(value,choices,threshold):
    normalized=part_norm(value)
    return bool(normalized) and max(SequenceMatcher(None,normalized,part_norm(c)).ratio() for c in choices)>=threshold

def full_address(patch):
    """Append only administrative parts not already stated in the address."""
    address=str(patch['address']).strip()
    labels={'subdistrict':('sub[- ]?district|tambon','ตำบล|แขวง'),
            'district':('district|amphoe|khet','อำเภอ|เขต'),
            'province':('province','จังหวัด')}
    for key in ('subdistrict','district','province'):
        value=patch.get(key)
        if not value:continue
        value=str(value).strip();english,thai=labels[key]
        pieces=re.split(r'[,;，]',address)
        present=any(geography.norm(piece)==geography.norm(value) for piece in pieces)
        phrase=re.escape(value).replace(r'\ ',r'\s+')
        present=present or bool(re.search(r'(?<![A-Za-z])'+phrase+r'\s+(?:'+english+r')\b',address,re.I))
        present=present or bool(re.search(r'\b(?:'+english+r')\s+'+phrase+r'(?![A-Za-z])',address,re.I))
        present=present or bool(re.search(r'(?:'+thai+r')\s*'+phrase,address,re.I))
        if not present:address+=', '+value
    return address

def normalize(patch,current):
    result=dict(patch);changes={}
    # Only operate on extracted location facts, never a name or arbitrary speech.
    if not set(result)&{'address','province','district','subdistrict'}:return result,changes
    combined={**current,**result}
    province=combined.get('province','');district=combined.get('district','')
    if not province or not district:return result,changes
    known_province=geography.PROVINCES.get(geography.norm(province))
    known_districts=geography.DISTRICTS.get(geography.norm(district),[])
    for target in TARGETS:
        target_province=geography.PROVINCES[geography.norm(target['province'][0])]
        target_district=geography.DISTRICTS[geography.norm(target['district'][0])][0]
        if known_province:
            if known_province['id']!=target_province['id']:continue
        elif not similar(province,target['province'],.86):continue
        if known_districts:
            if all(row['id']!=target_district['id'] for row in known_districts):continue
        elif not similar(district,target['district'],.84):continue

        def update(key,value):
            if key in result and result[key]!=value:
                changes[key]={'before':result[key],'after':value};result[key]=value

        for key in ('province','district'):
            value=combined.get(key,'')
            update(key,target[key][1 if re.search('[ก-๛]',value) else 0])
        subdistrict=combined.get('subdistrict','')
        subdistrict_match=part_norm(subdistrict) in target['aliases'] or similar(subdistrict,target['subdistrict'],.82)
        if subdistrict_match:
            update('subdistrict',target['subdistrict'][1 if re.search('[ก-๛]',subdistrict) else 0])
        if result.get('address'):
            address=result['address']
            # The stronger province + district anchors above constrain all fixes.
            address=re.sub(r'\b(?:muang|mueang)\s+chiang\s+mai\b',target['district'][0],address,flags=re.I) if target['province'][0]=='Chiang Mai' else re.sub(r'\bbang\s+(?:khaen|ken|khen)\b',target['district'][0],address,flags=re.I)
            if subdistrict_match:
                address=re.sub(r'\b[A-Za-z]+\b',lambda m:target['subdistrict'][0] if m[0].casefold() in target['aliases'] or similar(m[0],(target['subdistrict'][0],),.84) else m[0],address)
            update('address',address)
        return result,changes
    return result,changes
