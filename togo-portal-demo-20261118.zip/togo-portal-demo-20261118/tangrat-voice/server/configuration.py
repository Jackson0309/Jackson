"""Local operator configuration. Windows secrets are protected by user-scoped DPAPI."""
import base64
import ctypes
import json
import os
from pathlib import Path
import tempfile

SECRET_FIELDS = frozenset(('openrouter_key', 'deepseek_key', 'elevenlabs_key', 'iflytek_app_id', 'iflytek_api_key', 'iflytek_api_secret'))
DEFAULTS = {
    'openrouter_key': '', 'deepseek_key':'', 'llm_provider':'openrouter', 'elevenlabs_key': '',
    'llm_model': 'openai/gpt-4.1-mini',
    'asr_model': 'elevenlabs/scribe-v2', 'tts_model': 'elevenlabs/eleven-flash-v2.5',
    'asr_provider': 'elevenlabs', 'tts_provider': 'elevenlabs',
    'voice_id': 'EXAVITQu4vr4xnSDxMaL', 'en_tts_model': 'eleven_flash_v2_5',
    'zh_tts_model': 'eleven_v4_turbo', 'zh_voice_id': 'EXAVITQu4vr4xnSDxMaL',
    'th_asr_provider':'elevenlabs','th_tts_provider':'elevenlabs',
    'th_tts_model':'eleven_v4_turbo','th_voice_id':'EXAVITQu4vr4xnSDxMaL',
    'iflytek_standard_voice_th':'configure-authorized-thai-voice',
    'iflytek_app_id': '', 'iflytek_api_key': '', 'iflytek_api_secret': '',
    'iflytek_asr_model': 'iat', 'iflytek_tts_model': 'super_tts',
    'iflytek_voice_zh': 'x5_lingxiaoxuan_flow', 'iflytek_voice_en': 'x5_lingxiaoxuan_flow',
    'iflytek_standard_voice_zh': 'xiaoyan', 'iflytek_standard_voice_en': 'catherine',
}
CHOICES = {
    'llm_provider':('openrouter','deepseek'),
    'asr_provider': ('elevenlabs', 'iflytek'), 'tts_provider': ('elevenlabs', 'iflytek'),
    'iflytek_asr_model': ('iat', 'spark_asr_v2', 'mul_cn'),
    'iflytek_tts_model': ('tts', 'super_tts'),
    'en_tts_model': ('eleven_flash_v2_5', 'eleven_multilingual_v2', 'eleven_v4_turbo'),
    'zh_tts_model': ('eleven_v4_turbo', 'eleven_multilingual_v2', 'eleven_flash_v2_5'),
    'th_asr_provider':('elevenlabs','iflytek'), 'th_tts_provider':('elevenlabs','iflytek'),
    'th_tts_model':('eleven_v4_turbo',),
}
ENV = {'deepseek_key':'DEEPSEEK_API_KEY','llm_provider':'LLM_PROVIDER','openrouter_key': 'OPENROUTER_API_KEY', 'elevenlabs_key': 'ELEVENLABS_API_KEY',
       'llm_model': 'LLM_MODEL', 'voice_id': 'ELEVENLABS_VOICE_ID',
       'zh_tts_model': 'ZH_TTS_MODEL', 'zh_voice_id': 'ZH_VOICE_ID',
       'iflytek_app_id': 'IFLYTEK_APP_ID', 'iflytek_api_key': 'IFLYTEK_API_KEY',
       'iflytek_api_secret': 'IFLYTEK_API_SECRET'}


class ConfigurationError(Exception):
    pass


def dpapi(data, decrypt=False):
    """No subprocess, shell argument, plaintext temp file or machine-wide scope."""
    from ctypes import wintypes

    class Blob(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_ubyte))]

    buffer = ctypes.create_string_buffer(data)
    source = Blob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    result = Blob()
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    if decrypt:
        method = crypt.CryptUnprotectData
    else:
        method = crypt.CryptProtectData
    method.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p,
                       ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    method.restype = wintypes.BOOL
    if not method(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(result)):
        raise ConfigurationError('Windows could not protect or read the local configuration.')
    try:
        return ctypes.string_at(result.data, result.size)
    finally:
        kernel.LocalFree(result.data)


class LocalConfigStore:
    def __init__(self, path):
        self.path = Path(path)
        self.error = ''

    @property
    def storage(self):
        return 'windows_dpapi_current_user' if os.name == 'nt' else 'owner_only_file'

    def load(self):
        values = dict(DEFAULTS)
        if self.path.exists():
            try:
                envelope = json.loads(self.path.read_text(encoding='utf-8'))
                if envelope['storage'] == 'windows_dpapi_current_user':
                    raw = dpapi(base64.b64decode(envelope['payload']), decrypt=True)
                    saved = json.loads(raw)
                elif os.name != 'nt' and envelope['storage'] == 'owner_only_file':
                    saved = envelope['values']
                else:
                    raise ValueError('Storage belongs to another operating system')
                for key, value in saved.items():
                    if key in DEFAULTS and isinstance(value, str):
                        if key not in CHOICES or value in CHOICES[key]:
                            values[key] = value
            except Exception:
                self.error = '本机配置无法解密或已损坏；原文件已保留，请恢复原 Windows 账户或移开该文件后重新配置。'
        for key, name in ENV.items():
            if name in os.environ:
                values[key] = os.environ[name]
        return values

    def save(self, values):
        if self.error:
            raise ConfigurationError(self.error)
        raw = json.dumps(values, ensure_ascii=False).encode('utf-8')
        envelope = {'version': 1, 'storage': self.storage}
        if os.name == 'nt':
            envelope['payload'] = base64.b64encode(dpapi(raw)).decode('ascii')
        else:
            envelope['values'] = values
        self.path.parent.mkdir(parents=True, exist_ok=True)
        filename = None
        try:
            with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=self.path.parent,
                                             prefix='.operator-', delete=False) as handle:
                filename = handle.name
                if os.name != 'nt':
                    os.chmod(filename, 0o600)
                json.dump(envelope, handle, ensure_ascii=False)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(filename, self.path)
        except Exception:
            if filename:
                Path(filename).unlink(missing_ok=True)
            raise ConfigurationError('配置未能写入本机磁盘；当前运行配置保持原值。') from None


def validate_update(current, body):
    if not isinstance(body, dict) or set(body) - set(DEFAULTS):
        raise ValueError('Unknown configuration field')
    updated = dict(current)
    for key, value in body.items():
        if not isinstance(value, str) or len(value) > 500:
            raise ValueError('Configuration values must be text of at most 500 characters')
        value = value.strip()
        if key in CHOICES and value not in CHOICES[key]:
            raise ValueError('Unsupported option: ' + key)
        if key not in SECRET_FIELDS and not value:
            raise ValueError('Required setting: ' + key)
        if any(ord(character) < 32 for character in value):
            raise ValueError('Control characters are not allowed')
        updated[key] = value
    return updated


def iflytek_ready(config):
    return all(config.get(key) for key in ('iflytek_app_id', 'iflytek_api_key', 'iflytek_api_secret'))


def voice_ready(config):
    if (config.get('_speech_language')=='th' and config.get('tts_provider')=='iflytek'
            and config.get('iflytek_standard_voice_th','configure-authorized-thai-voice')=='configure-authorized-thai-voice'):
        return False
    from .llm import configured
    return configured(config) and all(
        iflytek_ready(config) if config.get(role + '_provider', 'elevenlabs') == 'iflytek'
        else bool(config.get('elevenlabs_key')) for role in ('asr', 'tts'))


def speech_config(config,lang):
    selected=dict(config)
    selected['_speech_language']=lang
    if lang=='th':
        selected['asr_provider']=config.get('th_asr_provider','elevenlabs')
        selected['tts_provider']=config.get('th_tts_provider','elevenlabs')
        if selected['asr_provider']=='iflytek':selected['iflytek_asr_model']='mul_cn'
        if selected['tts_provider']=='iflytek':selected['iflytek_tts_model']='tts'
    return selected
