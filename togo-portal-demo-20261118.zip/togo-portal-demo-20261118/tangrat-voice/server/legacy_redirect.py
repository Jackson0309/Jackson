"""Compatibility entry for old 4190 links; one active Togo runtime owns all sessions."""
from fastapi import FastAPI,Request
from fastapi.responses import RedirectResponse
app=FastAPI(docs_url=None,redoc_url=None,openapi_url=None)
@app.api_route('/{path:path}',methods=['GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS'])
async def redirect(request:Request,path:str):
    host=request.url.hostname or '127.0.0.1'
    if ':' in host:host='['+host+']'
    target=f'{request.url.scheme}://{host}:8080/'+path
    if request.url.query:target+='?'+request.url.query
    return RedirectResponse(target,status_code=307,headers={'Cache-Control':'no-store'})
