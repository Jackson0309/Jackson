"""Conservative service routing; service confirmation always precedes field extraction."""
import re
from .domain import CHILD, FLOOD, INTAKE, SERVICES, next_question

PATTERNS = {
    CHILD: re.compile(r'儿童补贴|育儿补贴|婴儿补贴|child\s+(?:subsidy|benefit|support)|baby\s+(?:subsidy|benefit)|เงินอุดหนุนเด็ก', re.I),
    FLOOD: re.compile(r'洪灾|洪水|水灾|受灾|水淹|淹水|flood(?:ing|ed)?|disaster\s+(?:relief|assistance)|น้ำท่วม|อุทกภัย', re.I)
}
YES = re.compile(r'^(?:是的?|对的?|确认|好的?|没错|就[是办]这[个项]?|继续|yes(?:[\s，,]+(?:confirm|please))?|i\s+confirm|correct|confirm|confirmed|proceed|that.s right|(?:ใช่|ยืนยัน|ถูกต้อง|ตกลง)(?:\s*(?:ค่ะ|ครับ|คะ))?)[\s，,。.!！]*$', re.I)
NO = re.compile(r'^(?:不[是对]?|否|取消|no|cancel|wrong|(?:ไม่ใช่|ยกเลิก)(?:\s*(?:ค่ะ|ครับ|คะ))?)[\s，,。.!！]*$', re.I)

def keyword_intent(text):
    hits = [service for service,pattern in PATTERNS.items() if pattern.search(text)]
    if len(hits)==1:
        # Explicit negation requires clarification instead of routing to a negated service.
        if re.search(r'不(?:是|要|办|想)|不要|not\b|don.t\b|ไม่(?:ต้องการ|อยาก|ใช่|เอา)|ยกเลิก',text,re.I):
            return None, 'ambiguous'
        return hits[0], 'keyword'
    return None, 'ambiguous' if hits else 'unknown'

def intent_question(draft, lang='en'):
    candidate = draft.get('intent',{}).get('candidate')
    if candidate in SERVICES:
        if lang=='th':
            return f'คุณต้องการ{SERVICES[candidate]["th"]} ใช่ไหมคะ กรุณาพูดว่า ยืนยัน หรือบอกบริการที่ต้องการใหม่ค่ะ'
        title = SERVICES[candidate]['zh' if lang=='zh' else 'en']
        return (f'您想办理的是“{title}”，对吗？请说“确认”，或重新说明要办理的事项。' if lang=='zh' else
            f'You would like {title.lower()}, is that correct? Please say yes, or tell me which service you need.')
    return next_question({},lang,INTAKE)
