"""Read-only, explicitly paired observer. SQLite events survive process restart."""
import asyncio
import copy
import hashlib
import json
import secrets
import time

from fastapi import HTTPException, Request
from fastapi.responses import StreamingResponse

from .catalog import ORDER
from .domain import SERVICES, field_schema
from . import workflow

telemetry = {}
attempts = {}


def init_tables(con):
    con.execute('CREATE TABLE IF NOT EXISTS workflow_events(draft_id TEXT NOT NULL, seq INTEGER NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(draft_id,seq))')
    con.execute('CREATE TABLE IF NOT EXISTS observe_codes(code_hash TEXT PRIMARY KEY, draft_id TEXT NOT NULL, owner_hash TEXT NOT NULL, expires REAL NOT NULL)')


def catalog():
    return [dict(id=k, en=SERVICES[k]['en'], zh=SERVICES[k]['zh'], th=SERVICES[k]['th'],
                 mode=SERVICES[k].get('mode','application'), source=SERVICES[k]['source'],
                 field_basis='proposed_demo_schema', schema=field_schema(k)) for k in ORDER]


def snapshot(draft):
    """Whitelist; never expose owner, continuation hash/token, credentials or history."""
    flow=draft.get('workflow',{})
    return {**{k:({**copy.deepcopy(draft.get(k,{})), **({'citizen_id':'•••••••••'+draft['fields']['citizen_id'][-4:]} if draft.get('fields',{}).get('citizen_id') else {})} if k=='fields' else copy.deepcopy(draft.get(k))) for k in ('id','service','status','fields','schema','missing','version','event_seq','updated_at','receipt','language')},
            'state':flow.get('state','intent'), 'checks':copy.deepcopy(flow.get('checks',{})), 'questions':copy.deepcopy(draft.get('questions',{})),
            'messages':conversation_messages(draft,tail=2), 'message_count':len(draft.get('messages',[])), 'errors':copy.deepcopy(flow.get('errors',{})),
            'result':copy.deepcopy(flow.get('result')),
            'archives':[dict(service=k,filled=len([v for v in value.get('fields',{}).values() if v])) for k,value in flow.get('archives',{}).items()]}


def conversation_messages(draft,tail=None):
    messages=draft.get('messages',[])
    start=max(0,len(messages)-tail) if tail is not None else 0
    return [dict(id=i+1,role=message['role'],content=__import__('re').sub(r'(?<!\d)\d{13}(?!\d)',lambda m:'•••••••••'+m[0][-4:],message['content']),at=message.get('at'),lang=message.get('lang'))
            for i,message in enumerate(messages[start:],start=start)]


def capture(con, draft, previous, metadata):
    draft['event_seq']=(previous or {}).get('event_seq',0)+1
    before=(previous or {}).get('fields',{})
    event=dict(seq=draft['event_seq'], draft_id=draft['id'], at=time.time(),
               kind=metadata.get('kind','updated' if previous else 'created'),
               reason=metadata.get('reason','资料已更新 / Details updated' if previous else '会话已创建 / Conversation created'),
               utterance=metadata.get('utterance',''), from_state=(previous or {}).get('workflow',{}).get('state','intent'),
               to_state=draft['workflow']['state'], from_service=(previous or {}).get('service','intent-intake'),
               to_service=draft['service'], changes={k:dict(before=before.get(k),after=draft['fields'].get(k))
                   for k in before.keys()|draft['fields'].keys() if before.get(k)!=draft['fields'].get(k)},
               errors=copy.deepcopy(draft['workflow'].get('errors',{})))
    payload={'event':event,'snapshot':snapshot(draft)}
    con.execute('INSERT INTO workflow_events VALUES(?,?,?)',(draft['id'],event['seq'],json.dumps(payload,ensure_ascii=False)))
    con.execute('DELETE FROM workflow_events WHERE draft_id=? AND seq<?',(draft['id'],event['seq']-499))


def observe_audio(draft_id, message):
    kind=message.get('type')
    if kind not in ('transcript','listening','speech','thinking','ready','disconnected','error'):
        return
    old=telemetry.get(draft_id,{})
    item=dict(revision=old.get('revision',0)+1,at=time.time(),phase=old.get('phase','ready'),text=old.get('text',''),final=old.get('final',False),language=message.get('lang',old.get('language','en')))
    if kind=='transcript':item.update(text=str(message.get('text',''))[:1000],final=bool(message.get('final')))
    else:item['phase']={'speech':'speaking'}.get(kind,kind)
    if kind in ('disconnected','listening'):item.update(text='',final=False)
    telemetry[draft_id]=item
    # This is transient presentation data, not a source of business state.
    if len(telemetry)>1000:
        for key in list(telemetry):
            if time.time()-telemetry[key]['at']>3600:telemetry.pop(key,None)


def install(app, db, sessions, persist_session, read_draft):
    def authorized(sid):
        grant=sessions[sid].get('observer')
        if not grant or grant.get('expires',0)<time.time():raise HTTPException(403,'请先输入手机上的配对码 / Pair with the phone first')
        with db() as con:
            row=con.execute('SELECT owner,payload FROM drafts WHERE id=?',(grant['draft_id'],)).fetchone()
        if not row or not secrets.compare_digest(hashlib.sha256(row[0].encode()).hexdigest(),grant['owner_hash']):
            raise HTTPException(403,'观察授权已失效，请重新配对 / Observer access expired')
        return json.loads(row[1])

    def recent(con,draft_id):
        rows=con.execute('SELECT payload FROM workflow_events WHERE draft_id=? ORDER BY seq DESC LIMIT 20',(draft_id,)).fetchall()
        return [json.loads(row[0])['event'] for row in reversed(rows)]

    @app.post('/api/drafts/{draft_id}/observe-code')
    async def issue(draft_id:str,request:Request):
        draft=read_draft(draft_id,request.state.sid)
        if not workflow.enabled(draft):raise HTTPException(409,'请新建新版语音会话 / Start a new voice session')
        code=f'{secrets.randbelow(100_000_000):08d}'
        owner_hash=hashlib.sha256(request.state.sid.encode()).hexdigest()
        with db() as con:
            con.execute('DELETE FROM observe_codes WHERE expires<? OR draft_id=?',(time.time(),draft_id))
            con.execute('INSERT INTO observe_codes VALUES(?,?,?,?)',(hashlib.sha256(code.encode()).hexdigest(),draft_id,owner_hash,time.time()+600))
        return {'code':code,'expires_in':600,'access':'read_only'}

    @app.post('/api/observer/pair')
    async def pair(request:Request):
        address=request.client.host
        now=time.time()
        attempts[address]=[t for t in attempts.get(address,[]) if now-t<60]
        if len(attempts[address])>=20:raise HTTPException(429,'尝试过于频繁，请稍后重试 / Too many pairing attempts')
        attempts[address].append(now)
        if len(attempts)>2000:
            for key in list(attempts):
                if not attempts[key] or now-attempts[key][-1]>60:attempts.pop(key,None)
        body=await request.json()
        code=str(body.get('code','')).replace('-','').replace(' ','').strip()
        if not code.isascii() or not code.isdigit() or len(code)!=8:raise HTTPException(422,'请输入八位配对码 / Enter the 8-digit code')
        with db() as con:
            con.execute('BEGIN IMMEDIATE')
            hashed=hashlib.sha256(code.encode()).hexdigest()
            row=con.execute('SELECT draft_id,owner_hash,expires FROM observe_codes WHERE code_hash=?',(hashed,)).fetchone()
            if not row or row[2]<now:raise HTTPException(403,'配对码无效、已使用或已过期 / Invalid, used or expired code')
            owner=con.execute('SELECT owner FROM drafts WHERE id=?',(row[0],)).fetchone()
            if not owner or hashlib.sha256(owner[0].encode()).hexdigest()!=row[1]:raise HTTPException(403,'配对码已失效 / Pairing code expired')
            con.execute('DELETE FROM observe_codes WHERE code_hash=?',(hashed,))
        sessions[request.state.sid]['observer']={'draft_id':row[0],'owner_hash':row[1],'expires':now+7200}
        persist_session(request.state.sid)
        return {'snapshot':snapshot(authorized(request.state.sid)),'access':'read_only','expires_in':7200}

    @app.delete('/api/observer/session')
    async def unpair(request:Request):
        sessions[request.state.sid].pop('observer',None);persist_session(request.state.sid)
        return {'ok':True}

    @app.get('/api/observer/bootstrap')
    async def bootstrap(request:Request):
        try:current=snapshot(authorized(request.state.sid))
        except HTTPException:current=None
        return {'csrf':sessions[request.state.sid]['csrf'],'catalog':catalog(),'snapshot':current,'access':'read_only','states':list(workflow.STATES)}

    @app.get('/api/observer/snapshot')
    async def current(request:Request):
        draft=authorized(request.state.sid)
        with db() as con:history=recent(con,draft['id'])
        return {'snapshot':snapshot(draft),'events':history,'telemetry':telemetry.get(draft['id'])}

    @app.get('/api/observer/conversation')
    async def conversation(request:Request):
        draft=authorized(request.state.sid)
        messages=conversation_messages(draft)
        return {'draft_id':draft['id'],'messages':messages,'total':len(messages)}

    @app.get('/api/observer/stream')
    async def stream(request:Request):
        sid=request.state.sid
        initial=authorized(sid)
        async def generate():
            last=initial.get('event_seq',0);revision=0
            with db() as con:history=recent(con,initial['id'])
            yield 'event: snapshot\nid: '+str(last)+'\ndata: '+json.dumps({'snapshot':snapshot(initial),'events':history},ensure_ascii=False)+'\n\n'
            heartbeat=time.monotonic()
            while not await request.is_disconnected():
                await asyncio.sleep(.25)
                try:latest=authorized(sid)
                except HTTPException:
                    yield 'event: revoked\ndata: {}\n\n';return
                with db() as con:
                    rows=con.execute('SELECT seq,payload FROM workflow_events WHERE draft_id=? AND seq>? ORDER BY seq LIMIT 31',(latest['id'],last)).fetchall()
                if len(rows)>30:
                    last=latest['event_seq']
                    with db() as con:history=recent(con,latest['id'])
                    yield 'event: snapshot\nid: '+str(last)+'\ndata: '+json.dumps({'snapshot':snapshot(latest),'events':history},ensure_ascii=False)+'\n\n'
                else:
                    for seq,payload in rows:
                        last=seq
                        yield f'event: update\nid: {seq}\ndata: {payload}\n\n'
                audio=telemetry.get(latest['id'])
                if audio and audio['revision']!=revision:
                    revision=audio['revision']
                    yield 'event: voice\ndata: '+json.dumps(audio,ensure_ascii=False)+'\n\n'
                if time.monotonic()-heartbeat>15:
                    heartbeat=time.monotonic();yield ': keepalive\n\n'
        return StreamingResponse(generate(),media_type='text/event-stream',headers={'Cache-Control':'no-store','X-Accel-Buffering':'no'})
