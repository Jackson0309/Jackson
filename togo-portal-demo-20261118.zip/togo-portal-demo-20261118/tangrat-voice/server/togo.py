"""Togo business profile for the original Tang Rat runtime and UI."""
import os, json, re, datetime as dt
from pathlib import Path
ACTIVE=os.environ.get('TANGRAT_COUNTRY','thai')=='togo'
ROOT=Path(__file__).parent/'profiles'
SCHEMAS=json.loads((ROOT/'togo-schema.json').read_text())
KNOWLEDGE=json.loads((ROOT/'togo-knowledge.json').read_text())
TH_UI=json.loads((ROOT/'togo-ui-th.json').read_text())
ORDER=['duplicate','nationality','passport','criminal','residence','courtfees']
ALIASES={
 'duplicate':r'国籍证明副本(?:申请)?|国籍副本|duplicata(?: de nationalit[ée])?|nationality (?:certificate )?(?:duplicate|copy)',
 'nationality':r'多哥国籍证明|首次(?:申请)?国籍证明|certificat de nationalit[ée](?: togolaise)?|nationality certificate|国籍证明',
 'passport':r'护照(?:申请)?|passport(?: application)?|(?:demande de )?passeport',
 'criminal':r'(?:无)?犯罪记录(?:证明)?(?:摘录)?|无犯罪证明|casier judiciaire|criminal.record(?: extract)?',
 'residence':r'居留证(?:申请)?|carte de s[ée]jour|residence permit',
 'courtfees':r'法院案件登记(?:费用缴纳|缴费)?|法院.*(?:费用|缴费)|frais d.enr[oô]lement|court (?:registration )?fees'}
FIELD_ALIASES={f['key']:list(dict.fromkeys([f['label']['zh'],f['label']['en'],*f.get('aliases',[])])) for s in SCHEMAS.values() for f in s['fields']}
def applies(when,fields):
 return all(fields.get(k) in v['in'] if isinstance(v,dict) else fields.get(k)==v for k,v in (when or {}).items())
def schema(service,fields=None):
 if service not in SCHEMAS:return []
 result=[]
 for f in SCHEMAS[service]['fields']:
  if fields is not None and not applies(f.get('when'),fields):continue
  opts=f.get('options',[])
  if service=='criminal' and f['key']=='documentType' and fields and fields.get('applicantStatus'):
   allowed=['birth','nationality','judgement'] if fields['applicantStatus']=='bornTogo' else ['birth','passport','residence','nationality']
   opts=[o for o in opts if o['value'] in allowed]
  labels={l:re.sub(r'\s*[（(](?:YYYY-MM-DD|yyyy-mm-dd)[）)]','',f['label'][l]) for l in ('en','zh')}
  result.append({**f,'en':labels['en'],'zh':labels['zh'],'th':TH_UI['fields'].get(f['key'],labels['en']),'type':{'phone':'tel','integer':'number','document':'text'}.get(f['type'],f['type']),**({'options':[{'value':o['value'],'en':o['label']['en'],'zh':o['label']['zh'],'th':TH_UI['options'].get(o['label']['en'],o['label']['en'])} for o in opts]} if opts else {})})
 return result
def slots(service,fields):return [{**s,'label':{**s['label'],'th':TH_UI['slots'].get(s['key'],s['label']['en'])}} for s in SCHEMAS.get(service,{}).get('attachments',[]) if applies(s.get('when'),fields)]
def validate(patch,service,current=None,reference_date=None):
 accepted,errors={},{};current=current or {};spec={f['key']:f for f in SCHEMAS.get(service,{}).get('fields',[])}
 for key,raw in patch.items():
  if key not in spec or raw is None or isinstance(raw,(dict,list,bool)):continue
  f=spec[key];value=str(raw).strip();error=''
  if not value:accepted[key]='';continue
  if f['type']=='select':
   opts=f['options'];opt=next((o for o in opts if value==o['value'] or value in o['label'].values()),None)
   if not opt:error='请选择对应选项 / Choose an available option'
   else:value=opt['value']
  elif f['type']=='integer':
   value={'一':'1','二':'2','两':'2','三':'3','四':'4','五':'5'}.get(value.rstrip('份'),value)
   if not value.isdigit() or not f.get('min',0)<=int(value)<=f.get('max',999):error='请输入1–5份 / Enter 1–5 copies'
  elif f['type']=='phone':
   value=re.sub(r'[\s()-]','',value)
   if not re.fullmatch(r'\+?\d{7,15}',value):error='请输入7–15位联系电话 / Enter 7–15 digits'
  elif f['type']=='email' and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',value):error='邮箱格式无效 / Invalid email'
  elif f['type']=='date':
   from . import business_clock
   value=business_clock.relative_date(value,reference_date) or value
   m=re.fullmatch(r'(\d{4})年(\d{1,2})月(\d{1,2})[日号]?',value)
   if m:value=f'{int(m[1]):04}-{int(m[2]):02}-{int(m[3]):02}'
   try:
    born=dt.date.fromisoformat(value)
    if born>(reference_date or business_clock.today()) or born.year<1900:error='日期超出范围 / Date out of range'
   except ValueError:error='请提供具体年月日 / Use YYYY-MM-DD'
  elif f['type']=='document' and not re.fullmatch(r'[\w][\w ./_-]{2,79}',value):error='证明编号格式无效 / Invalid document number'
  elif len(value)<2:error='请提供完整信息 / Provide the full value'
  if len(value)>f.get('maxLength',1000):error='内容过长 / Value too long'
  if error:errors[key]=error
  else:accepted[key]=value
 combined={**current,**accepted}
 for key in combined:
  if key in spec and not applies(spec[key].get('when'),combined):accepted[key]=''
 if service=='criminal' and combined.get('applicantStatus'):
  allowed=['birth','nationality','judgement'] if combined['applicantStatus']=='bornTogo' else ['birth','passport','residence','nationality']
  if combined.get('documentType') and combined['documentType'] not in allowed:
   accepted.pop('documentType',None);errors['documentType']='证明类型与身份不匹配 / Document does not match status'
  if combined.get('birthDate') and combined['applicantStatus']!='foreign':
   try:
    today=reference_date or dt.date.today();b=dt.date.fromisoformat(combined['birthDate']);age=today.year-b.year-((today.month,today.day)<(b.month,b.day))
    if age<14:errors['birthDate']='B3演示分支要求年满14岁，请核实适用路径 / Verify age and applicable route'
   except ValueError:pass
 return accepted,errors
def fee(service,f):
 amount=None
 if service=='duplicate' and f.get('certificateFormat')=='new' and str(f.get('copies','')).isdigit():amount=int(f['copies'])*1000
 if service=='criminal':amount=500
 if service=='nationality' and f.get('basis')=='descent' and f.get('familyProof') in ('yes','no'):amount=15000 if f['familyProof']=='no' else 5000
 if service=='passport' and f.get('passportType')=='ordinary' and f.get('filingZone')=='togo':amount=30000
 if service=='residence':amount={'student1':100000,'student3':250000,'other1':200000,'other3':500000,'other5':800000}.get(f.get('permitType'))
 return {'amount':amount,'currency':'XOF','charged':False,'checked_at':'2026-11-06','postageExcluded':f.get('delivery')=='post'}
def material_missing(draft):
 return [s for s in slots(draft['service'],draft['fields']) if s['required'] and not any(d.get('slot')==s['key'] for d in draft.get('documents',[]))]
def question(fields,lang,service):
 if service not in SCHEMAS:return {'zh':'您好，请说出您要咨询或办理的多哥政务事项。','en':'Which Togo government service would you like help with?'}.get(lang,'Which Togo government service would you like help with?')
 pending=next((f for f in schema(service,fields) if f['required'] and not fields.get(f['key'])),None)
 if not pending:return '资料已准备好。请打开草稿核对，补充适用材料，登录后确认提交。' if lang=='zh' else 'Open your draft, review details, add applicable documents and sign in before confirming submission.'
 if pending['type']=='date':return {'zh':'请问您的出生日期是哪一年、哪一月、哪一天？','en':'What is your date of birth? Please tell me the year, month and day.','th':'คุณเกิดวันที่เท่าไร เดือนอะไร และปีอะไรคะ'}.get(lang,'What is your date of birth? Please tell me the year, month and day.')
 name=pending.get(lang,pending['en']);opts=pending.get('options',[])
 return ('请提供'+name if lang=='zh' else TH_UI['questionPrefix']+name if lang=='th' else 'Please provide '+name)+(('：' if lang=='zh' else ': ')+' / '.join(o.get(lang,o['en']) for o in opts) if opts else '')+('。' if lang=='zh' else '.')
SERVICES={k:{**{lang:KNOWLEDGE['services'][k][lang]['title'] for lang in ('zh','en')},'th':TH_UI['services'][k],'prefix':k[:3].upper(),'mode':'application','field_basis':'togo_demo_schema','fields':[(f['key'],f['en'],f['zh'],f['type']) for f in schema(k)],'source':KNOWLEDGE['services'][k]['sources'][0]['url']} for k in ORDER}
SAMPLES={
 'duplicate':dict(certificateFormat='new',applicantRole='self',applicantName='Demo Applicant',documentType='nationality',documentNumber='DEMO-NAT-001',copies='2',delivery='centre',pickupLocation='Demo collection centre',phone='+22890000000'),
 'nationality':dict(basis='descent',applicantName='Demo Applicant',birthDate='1990-01-01',birthplace='Demo birthplace',familyProof='yes',phone='+22890000000'),
 'passport':dict(applicationType='new',passportType='ordinary',applicantName='Demo Applicant',birthDate='1990-01-01',filingZone='togo',filingLocation='Demo filing office',profession='Demo occupation',phone='+22890000000'),
 'criminal':dict(applicantStatus='bornTogo',applicantName='Demo Applicant',birthDate='1990-01-01',documentType='birth',documentNumber='DEMO-BIRTH-001',delivery='centre',pickupLocation='Demo collection centre',phone='+22890000000'),
 'residence':dict(applicationType='new',permitType='student1',applicantName='Demo Applicant',birthDate='1990-01-01',nationality='Demo nationality',passportNumber='DEMO-PASS-001',residentialAddress='Demo address in Togo',phone='+22890000000'),
 'courtfees':dict(applicantRole='individual',applicantName='Demo Applicant',caseNature='Demo civil case',jurisdiction='Demo court to confirm',caseSummary='Fictional case for demonstration only',phone='+22890000000')}
for key,value in SAMPLES.items():SERVICES[key]['sample']=value
