"""ASR language bounds depend on the conversation UI, never on form extraction."""
import re
import unicodedata

def pending_field(draft):
    if not isinstance(draft,dict):return None
    from .domain import missing
    return next(iter(draft.get('workflow',{}).get('errors',{})),None) or next(iter(missing(draft.get('fields',{}),draft.get('service'))),None)

def answer_pause(draft):
    return 3.0 if pending_field(draft) in ('phone','citizen_id','address','province','district','subdistrict') else 1.5

def incomplete_address(text):
    value=re.sub(r'[\s.,。…:：!！-]+','',text.casefold())
    return value in {'','myaddressis','myaffectedaddressis','theaddressis','address','myaddress','theaffectedaddressis','ilivein',
                     '我的地址是','受灾地址是','我的受灾地址是','地址是','我住在','我的地址','地址',
                     'ที่อยู่คือ','ที่อยู่ของฉันคือ','ที่อยู่ที่ประสบภัยคือ','ที่อยู่','บ้านเลขที่','myaddressisum','myaddressisuh'}

def spoken_digits(text):
    value=text.casefold().strip()
    value=re.sub(r'^(?:my\s+(?:phone\s+number|number|citizen\s+id(?:\s+number)?)\s+is|เบอร์โทรศัพท์(?:ของฉัน)?(?:คือ)?|หมายเลขโทรศัพท์(?:คือ)?|เลขบัตรประชาชน(?:คือ)?|我的(?:电话号码|电话|身份证号码|号码)(?:是)?)\s*','',value)
    value=re.sub(r'(?:ค่ะ|ครับ)$','',value).strip()
    value=re.sub(r'[\s,，.。+()-]','',value.translate(str.maketrans('๐๑๒๓๔๕๖๗๘๙','0123456789')))
    if not value:return ''
    if value.isascii() and value.isdigit():return value
    for mapping in ({**dict(zip(('zero','one','two','three','four','five','six','seven','eight','nine'),'0123456789')),'oh':'0'},
                    dict(zip(('ศูนย์','หนึ่ง','สอง','สาม','สี่','ห้า','หก','เจ็ด','แปด','เก้า'),'0123456789')),
                    dict(zip('零一二三四五六七八九','0123456789'))):
        tokens=re.findall('|'.join(sorted(mapping,key=len,reverse=True)),value)
        if tokens and ''.join(tokens)==value:return ''.join(mapping[t] for t in tokens)
    return None

def unfinished_number(digits,key):
    if key=='citizen_id':return len(digits)<13
    if key=='phone':
        expected=10 if re.match(r'0[689]',digits) else 11 if digits.startswith('66') else 9 if digits.startswith('0') else 8
        return len(digits)<expected
    return False


def languages(ui_language):
    if ui_language=='zh':return ('zh','en','th')
    if ui_language=='th':return ('th','en')
    return ('en','th')


def transcript_allowed(text, ui_language):
    """Script guard, not a semantic language detector. Latin names are legitimate.

    Provider language candidates enforce the language preference; this additional
    check stops out-of-scope scripts from reaching captions, LLMs and forms.
    Punctuation such as the full stop in 'Jason Huang。' is harmless.
    """
    if not isinstance(text,str):return False
    content=False
    for char in text.strip():
        category=unicodedata.category(char);name=unicodedata.name(char,'')
        if category[0]=='L':
            if name.startswith(('LATIN ','THAI ')) or (ui_language=='zh' and name.startswith('CJK ')):
                content=True
            else:return False
        elif category[0]=='N':
            if char.isascii() or name.startswith('THAI ') or (ui_language=='zh' and name.startswith('IDEOGRAPHIC ')):
                content=True
            else:return False
        elif category[0]=='M' and not name.startswith(('COMBINING ','THAI ')):
            return False
    return content


def retry_prompt(ui_language):
    return {'zh':'没听清，请用中文再说一遍。',
            'th':'กรุณาพูดอีกครั้งเป็นภาษาไทยหรือภาษาอังกฤษค่ะ',
            'en':'I couldn’t hear that clearly. Please repeat in English or Thai.'}.get(ui_language,
            'Please repeat in English or Thai.')


def recognition_context(prompt):
    sentences=[part.strip() for part in re.findall(r'[^。.!！？?]+[。.!！？?]?',prompt) if part.strip()]
    return (sentences[-1] if sentences else prompt).strip()[-49:]


def place_hints(draft,ui_language):
    """All districts in the chosen province, never a guessed answer or partial list.

    The provider charges a 20% premium for keyterms; enable only for this field.
    """
    if not isinstance(draft,dict):return []
    from .domain import SERVICES,missing
    from . import geography
    if draft.get('service') not in SERVICES:return []
    fields=draft.get('fields',{});errors=draft.get('workflow',{}).get('errors',{})
    pending=next(iter(errors),None) or next(iter(missing(fields,draft['service'])),None)
    if pending!='district':return []
    province=geography.PROVINCES.get(geography.norm(fields.get('province','')))
    if not province:return []
    names=list(dict.fromkeys(row['th' if ui_language=='th' else 'en']
        for row in geography.DATA['district'] if row['province_id']==province['id']))
    return names if len(names)<=50 else []
