"""Reviewed service summaries; permission is separate from general demo consent."""
import re
from . import togo

DETAILS = {
 'flood-relief-preparation': (
  '洪灾救助登记需要您的姓名、电话、受灾住址、住房类型、受灾日期和损失情况。',
  'For flood relief, I’ll need your name, phone number, affected address, home type, flood dates and damage details.',
  'การลงทะเบียนช่วยเหลือน้ำท่วมต้องใช้ชื่อ เบอร์โทร ที่อยู่ที่ได้รับผลกระทบ ประเภทที่พัก วันที่น้ำท่วม และความเสียหายค่ะ'),
 'child-subsidy-preparation': (
  '新生儿补贴需要监护人和孩子的资料、出生日期、住址、电话、家庭人数及年收入。',
  'For newborn subsidy, I’ll need guardian and child details, birth date, address, phone number, household size and annual income.',
  'การลงทะเบียนเงินอุดหนุนเด็กแรกเกิดต้องใช้ข้อมูลผู้ปกครองและเด็ก วันเกิด ที่อยู่ เบอร์โทร จำนวนสมาชิกและรายได้ครัวเรือนต่อปีค่ะ'),
}

def summary(service, lang):
    if togo.ACTIVE and service in togo.KNOWLEDGE['services']:
        entry=togo.KNOWLEDGE['services'][service].get(lang,togo.KNOWLEDGE['services'][service]['en'])
        fields=togo.schema(service,{})
        names=('、' if lang=='zh' else ', ').join(f.get(lang,f['en']) for f in fields if f['required'])
        return entry['summary']+(' 登记需采集：'+names+'。材料按情形补充；这是本地演示。' if lang=='zh' else ' We collect '+names+'. Applicable documents are checked in the draft. Local demo only.')
    index={'zh':0,'en':1,'th':2}[lang]
    if service in DETAILS:
        summary=DETAILS[service][index]
    elif service=='water-bill-query':
        summary=('查询水费需要客户编号，也可以提供供水机构。',
                 'To prepare a water-bill query, I’ll need the customer reference. You can also give the water provider.',
                 'การตรวจสอบค่าน้ำต้องใช้เลขผู้ใช้น้ำ และแจ้งผู้ให้บริการได้ค่ะ')[index]
    else:
        summary=('我可以帮您整理查询条件，需要先说明查询对象，也可以补充表单中的可选条件。',
                 'I can help prepare the query conditions. Please identify the subject and any optional filters shown on the form.',
                 'ฉันช่วยเตรียมเงื่อนไขการตรวจสอบได้ค่ะ โดยระบุบุคคลและเงื่อนไขเพิ่มเติมตามแบบฟอร์ม')[index]
    return summary

def ask(lang):
    return {'zh':'要现在通过语音预填表单吗？',
            'en':'Would you like to prefill the form by voice now?',
            'th':'ต้องการให้ช่วยกรอกแบบฟอร์มด้วยเสียงตอนนี้ไหมคะ'}[lang]

def overview(service,lang):
    return summary(service,lang)+(' ' if lang=='en' else '')+ask(lang)

def interpreter_prompt(lang):
    """A small state-specific contract avoids competing form-extraction rules."""
    return (
        ('Interpret the latest user reply in a Togo government-service voice conversation. ' if togo.ACTIVE else 'Interpret the latest user reply in a Thai government-service voice conversation. ')+
        'The current state is service_intro: the service has been explained, but permission to start collecting details is still pending. '
        'Understand meaning in Chinese, English and Thai, not fixed phrases. Use history only as context; the latest reply overrides earlier decisions. '
        'Return one JSON object: {"action":"provide|answer|clarify|cancel|undo|resume|clear|clear_all|remove_fields",'
        '"prefill_decision":"accept|decline|unspecified","prefill_evidence":"exact consent or refusal words from latest_utterance, otherwise empty","service":service_id_or_null,"fields":{},"remove_fields":[], '
        '"topic":"identity|capabilities|service_info|explain_field|repeat|privacy|handoff|keep_details|unknown","field":schema_key_or_null}. '
        'Decide in this order: '
        '(1) A request for another service: provide, service:new_service_id, prefill_decision:unspecified, fields:{}. '
        '(2) A request for information or explanation: answer with an appropriate topic, prefill_decision:unspecified, fields:{}. '
        '(3) Declining, postponing, or saying they will answer another day: provide, prefill_decision:decline, fields:{}. '
        'A bare fact is NOT agreement, even if it answers an earlier question or follows repeated permission prompts. '
        'Examples: "My name is Somchai Jaidee", "我的名字是颂猜", "ฉันชื่อสมชาย ใจดี" all mean provide, prefill_decision:unspecified, prefill_evidence:"". '
        'Never use a name, phone number, address or other form fact as evidence of consent. '
        '(4) Clear willingness or instruction to start giving information NOW: provide, prefill_decision:accept. '
        'This includes asking you to begin asking questions. They need not say yes, agree, form, or prefill. '
        'For example, "You can ask me the questions now", "你来问吧，我把资料告诉你", or "ถามข้อมูลฉันได้เลย" mean accept. '
        'A previous refusal does not prevent them from agreeing in the latest reply. '
        '(5) Personal facts without permission to start: provide, prefill_decision:unspecified. '
        '(6) Conditional or uncertain willingness: clarify, prefill_decision:unspecified. '
        'Accept and factual extraction are independent: when permission and personal facts are supplied together, include ALL explicitly supplied facts in fields. '
        'For "You can ask me now. My name is Somchai", prefill_decision is accept, prefill_evidence is "You can ask me now", and fields contains applicant_name. '
        'For "I would rather do this another day", prefill_decision is decline and prefill_evidence quotes the postponement. '
        'Use only active-service schema keys. Never invent facts, reuse facts from another service or treat a question as a name. '
        'For privacy, never collect ID numbers, bank details, passwords or verification codes. '
        'Preserve explicitly spoken province/district names exactly, including inconsistent combinations; the server checks them. '
        'Keep relative dates as spoken for normalization by the server reference_clock. '
        'A polite request can be a question: "Could you start asking now?" accepts; "Could you explain before we start?" asks for information. '
        'Ordinary greetings, a name/phone number alone, or a policy question never imply consent. '
        'A request to cancel, undo or clear uses its corresponding action with prefill_decision:unspecified. '
        'No response authorizes final submission. Output structured data only; the server composes the spoken reply in '
        +{'zh':'Chinese','en':'English','th':'Thai'}[lang]+'.'
    )


def permission(text):
    """Fast path for self-contained consent. Other language goes to the interpreter."""
    value=text.strip().strip('。.!！?？ ').casefold()
    value=re.sub(r'[,，.。!！;；:\s]+',' ',value).strip().strip('"“”')
    value=re.sub(r'\s+(ค่ะ|ครับ)$',r'\1',value)
    value=value.replace('’',"'").replace('‘',"'")
    if re.fullmatch(r"no(?: thanks| thank you)?|not now|no not now|(?:please )?(?:wait|stop|don't start|do not start)|不用|不需要|暂不|暂时不用|先不填|先等等|稍后|ไม่(?:ค่ะ|ครับ)?|ไม่ต้องการ(?:ค่ะ|ครับ)?|ยังไม่(?:ค่ะ|ครับ)?|รอก่อน(?:ค่ะ|ครับ)?",value):
        return 'decline_prefill'
    # A question, qualification or negation needs context, not keyword voting.
    if re.search(r"[?？]|\b(?:no|not|never|don'?t|wait|later|cancel|stop|maybe|but|unless|if)\b|不要|不想|不用|不需要|暂|稍后|等等|先等|取消|但是|不过|先解释|为什么|怎么|吗|ไม่|เดี๋ยว|รอก่อน|ยกเลิก|แต่|ไหม|ทำไม",value):
        return None
    action=r"(?:(?:let'?s|let us|please|we can|you can) )?(?:start|begin|continue|proceed|prefill|fill (?:in|out) the form)(?: (?:now|please|prefilling|the form|by phone|by voice))?|(?:let'?s|let us) (?:do it|get started)|(?:i am|i'm|we are|we're) ready|go ahead(?: please| and (?:start|prefill))?"
    tail=value
    for _ in range(2):
        match=re.match(r'^(?:yes|yeah|yep|ok|okay|sure|alright|all right|sounds good)(?: please| i do)?(?: |$)',tail)
        if not match:break
        tail=tail[match.end():]
        if not tail:return 'accept_prefill'
    if re.fullmatch(action,tail):return 'accept_prefill'
    compact=value.replace(' ','')
    if re.fullmatch(r'(?:好的?|嗯|嗯好|可以|行|没问题)?(?:我们|现在|那就|那)?(?:开始(?:预填|填写|填表)?|帮我预填)(?:吧|好了|了|啦)?|(?:(?:ตกลง|ได้|ได้เลย|โอเค)(?:ค่ะ|ครับ)?)?(?:เริ่ม(?:เลย|ได้เลย)|เริ่มกรอก(?:ข้อมูล)?(?:ได้เลย)?)(?:ค่ะ|ครับ)?|ได้เลย(?:ค่ะ|ครับ)?',compact):
        return 'accept_prefill'
    if re.fullmatch(r'(?:yes(?: please| i do)?|ok(?:ay)?|sure|yes[, ]+(?:prefill(?: it)?(?: by (?:phone|voice))?|please (?:do|start))|please (?:start|prefill)|start prefilling|是的?|好的?|可以|需要|同意|开始预填|帮我预填|ใช่(?:ค่ะ|ครับ)?|ได้(?:ค่ะ|ครับ)?|ต้องการ(?:ค่ะ|ครับ)?|ตกลง(?:ค่ะ|ครับ)?|กรอกเลย(?:ค่ะ|ครับ)?)',value):
        return 'accept_prefill'
    if re.fullmatch(r'(?:no(?: thanks| thank you)?|not now|no[, ]+not now|不用|不需要|暂不|暂时不用|先不填|ไม่(?:ค่ะ|ครับ)?|ไม่ต้องการ(?:ค่ะ|ครับ)?|ยังไม่(?:ค่ะ|ครับ)?)',value):
        return 'decline_prefill'
    return None
