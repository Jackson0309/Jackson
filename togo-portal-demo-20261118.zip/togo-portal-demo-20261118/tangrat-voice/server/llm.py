"""Business LLM routing; speech provider credentials remain independent."""
def provider(config):return config.get('llm_provider','openrouter')
def api_key(config):return config.get('deepseek_key' if provider(config)=='deepseek' else 'openrouter_key','')
def configured(config):return bool(api_key(config))
def endpoint(config):return 'https://api.deepseek.com/chat/completions' if provider(config)=='deepseek' else 'https://openrouter.ai/api/v1/chat/completions'
def headers(config):return {'Authorization':'Bearer '+api_key(config)}
def options(config):return {'thinking':{'type':'disabled'}} if provider(config)=='deepseek' else {}
