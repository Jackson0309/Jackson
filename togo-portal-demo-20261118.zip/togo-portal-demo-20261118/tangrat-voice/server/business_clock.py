"""Request-time dates in Thailand; no daily prompt edits or model date arithmetic."""
import datetime as dt
import re

BANGKOK = dt.timezone(dt.timedelta(hours=7), 'Asia/Bangkok')


def today():
    return dt.datetime.now(BANGKOK).date()


def context(reference=None):
    reference = reference or today()
    return {'timezone': 'Asia/Bangkok', 'today': reference.isoformat(),
            'yesterday': (reference-dt.timedelta(days=1)).isoformat(),
            'tomorrow': (reference+dt.timedelta(days=1)).isoformat(),
            'calendar': 'Gregorian; explicitly stated Buddhist Era years are converted by subtracting 543'}


def relative_date(value, reference=None):
    """Only unambiguous expressions. Unknown/incomplete dates remain unmodified."""
    reference = reference or today()
    value = re.sub(r'[，。,.!！?？\s]+', ' ', str(value)).strip().casefold()
    offsets = {'今天':0, '今日':0, 'today':0, 'วันนี้':0,
               '昨天':-1, '昨日':-1, 'yesterday':-1, 'เมื่อวาน':-1, 'เมื่อวานนี้':-1,
               '前天':-2, 'the day before yesterday':-2, 'day before yesterday':-2, 'เมื่อวานซืน':-2,
               '明天':1, 'tomorrow':1, 'พรุ่งนี้':1}
    if value in offsets:
        return (reference+dt.timedelta(days=offsets[value])).isoformat()
    digits = {'一':1, '两':2, '二':2, '三':3, '四':4, '五':5, '六':6, '七':7, '八':8, '九':9, '十':10,
              'one':1, 'two':2, 'three':3, 'four':4, 'five':5, 'six':6, 'seven':7}
    match = re.fullmatch(r'(\d{1,3}|[一两二三四五六七八九十])天前|(\d{1,3}|one|two|three|four|five|six|seven) days? ago|([๐-๙\d]{1,3}) วันที่แล้ว', value)
    if match:
        number = next(part for part in match.groups() if part is not None)
        count = digits.get(number)
        if count is None:
            count = int(number.translate(str.maketrans('๐๑๒๓๔๕๖๗๘๙', '0123456789')))
        return (reference-dt.timedelta(days=count)).isoformat()
    return None


def date_answer(text, date_keys, reference=None):
    """A short date answer binds only when the pending question asks for a date."""
    if len(date_keys) != 1:
        return {}
    value = str(text).strip()
    value = re.sub(r'^(?:(?:孩子|儿童|宝宝|他|她|小孩)(?:是|在)?|是|在|(?:the baby|the child|she|he|baby|child)\s+(?:was\s+)?(?:born\s+)?|born\s+|เด็ก(?:เกิด)?|เกิด)', '', value, flags=re.I)
    value = re.sub(r'(?:出生(?:的)?|生的|ครับ|ค่ะ|คะ|นะคะ|上午|下午|早上|晚上|\s+morning|\s+afternoon)[。.!！\s]*$', '', value, flags=re.I).strip('。.!！ ')
    resolved = relative_date(value, reference)
    return {date_keys[0]:resolved} if resolved else {}
