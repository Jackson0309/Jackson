"""Thai service labels and prompts. Storage uses Gregorian dates and stable enum values."""
FIELD_LABELS = {
    'guardian_name':'ชื่อและนามสกุลผู้ปกครอง','relationship':'ความสัมพันธ์กับเด็ก',
    'child_name':'ชื่อและนามสกุลเด็ก','child_birth_date':'วันเกิดเด็ก ค.ศ.',
    'province':'จังหวัด','district':'อำเภอหรือเขต','phone':'หมายเลขโทรศัพท์',
    'household_members':'จำนวนสมาชิกในครัวเรือน','annual_household_income':'รายได้ครัวเรือนต่อปี บาท',
    'applicant_name':'ชื่อและนามสกุลผู้สมัคร','subdistrict':'ตำบลหรือแขวง',
    'address':'ที่อยู่ที่พักอาศัยประจำที่ประสบภัย','residence_type':'ประเภทที่พักอาศัย',
    'flood_start_date':'วันที่เริ่มประสบภัย ค.ศ.','flood_end_date':'วันที่สิ้นสุดภัย ค.ศ.',
    'damage_description':'ความเสียหายและผลกระทบต่อชีวิตประจำวัน',
}
OPTIONS = {'mother':'มารดา','father':'บิดา','guardian':'ผู้ปกครองตามกฎหมาย',
           'owned':'บ้านของตนเอง','rented':'บ้านเช่า','other':'ที่พักอาศัยประจำประเภทอื่น'}
QUESTIONS = {
    'guardian_name':'ผู้ปกครองชื่อและนามสกุลอะไรคะ',
    'relationship':'คุณเป็นมารดา บิดา หรือผู้ปกครองตามกฎหมายของเด็กคะ',
    'child_name':'เด็กชื่อและนามสกุลอะไรคะ','child_birth_date':'เด็กเกิดวันที่เท่าไรคะ กรุณาระบุปีด้วย และบอกว่าเป็นปี พ.ศ. หรือ ค.ศ.',
    'province':'คุณอาศัยอยู่จังหวัดใดคะ','district':'คุณอาศัยอยู่อำเภอหรือเขตใดคะ',
    'phone':'ขอหมายเลขโทรศัพท์ที่ติดต่อได้ค่ะ','household_members':'ในครัวเรือนมีสมาชิกทั้งหมดกี่คนคะ',
    'annual_household_income':'ครัวเรือนของคุณมีรายได้รวมต่อปีเท่าไร เป็นเงินบาทคะ',
    'applicant_name':'ผู้สมัครชื่อและนามสกุลอะไรคะ','subdistrict':'ตำบลหรือแขวงที่ประสบภัยคือที่ใดคะ',
    'address':'ขอที่อยู่ที่พักอาศัยประจำที่ประสบอุทกภัยค่ะ',
    'residence_type':'ที่พักนี้เป็นบ้านของตนเอง บ้านเช่า หรือที่พักอาศัยประจำประเภทอื่นคะ',
    'flood_start_date':'เริ่มประสบอุทกภัยวันที่เท่าไรคะ กรุณาระบุปี พ.ศ. หรือ ค.ศ.',
    'flood_end_date':'อุทกภัยสิ้นสุดวันที่เท่าไรคะ หากยังไม่สิ้นสุดให้บอกว่ายังต่อเนื่อง ไม่ต้องคาดเดาวันที่ค่ะ',
    'damage_description':'กรุณาอธิบายความเสียหายและผลกระทบต่อชีวิตประจำวันค่ะ',
}
SERVICE_TITLES = {'child-subsidy-preparation':'เงินอุดหนุนเด็กแรกเกิด',
                  'flood-relief-preparation':'ลงทะเบียนช่วยเหลือผู้ประสบอุทกภัย'}
INTAKE = 'สวัสดีค่ะ คุณต้องการเตรียมคำขอเงินอุดหนุนเด็กแรกเกิด หรือลงทะเบียนช่วยเหลือผู้ประสบอุทกภัยคะ'
READY = 'เตรียมร่างคำขอแล้วค่ะ กรุณาเปิดร่าง ตรวจสอบข้อมูลและเอกสาร แล้วเข้าสู่ระบบเพื่อยืนยันการบันทึกตัวอย่าง ยังไม่ได้ส่งให้หน่วยงานรัฐค่ะ'
THAI_DIGITS = str.maketrans('๐๑๒๓๔๕๖๗๘๙','0123456789')
ERRORS = {
    'Choose mother, father, or guardian / 请选择母亲、父亲或监护人':'กรุณาเลือกมารดา บิดา หรือผู้ปกครองตามกฎหมาย',
    'Choose a residence type / 请选择住房类型':'กรุณาเลือกประเภทที่พักอาศัย',
    'Date cannot be in the future / 日期不能晚于今天':'วันที่ต้องไม่อยู่ในอนาคต',
    'Use YYYY-MM-DD / 请使用 YYYY-MM-DD':'กรุณาระบุวันที่เป็น YYYY-MM-DD',
    'Enter 8–15 digits / 请输入 8–15 位数字':'กรุณาระบุหมายเลขโทรศัพท์ 8 ถึง 15 หลัก',
    'Enter a valid number / 请输入有效数字':'กรุณาระบุตัวเลขที่ถูกต้อง',
    'Please provide the full value / 请填写完整内容':'กรุณากรอกข้อมูลให้ครบถ้วน',
    'End date must not precede start date / 结束日期不能早于开始日期':'วันที่สิ้นสุดต้องไม่ก่อนวันที่เริ่มประสบภัย',
}


def validation_errors(errors,lang):
    geo={
      'en':'Place name or province/district combination was not found. Please check the full English or Thai name.',
      'zh':'地名或府省与区县的组合未匹配，请核对英文或泰语全名。',
      'th':'ไม่พบชื่อพื้นที่หรืออำเภอไม่ตรงกับจังหวัด กรุณาตรวจสอบชื่อเต็มภาษาไทยหรืออังกฤษค่ะ'}
    return {key:geo.get(lang,geo['en']) if str(value).startswith('geo_') else ERRORS.get(value,value) if lang=='th' else value for key,value in errors.items()}

FIELD_LABELS.update(citizen_id='เลขบัตรประชาชน', flood_duration_days='ระยะเวลาที่ได้รับผลกระทบ (วัน)')
