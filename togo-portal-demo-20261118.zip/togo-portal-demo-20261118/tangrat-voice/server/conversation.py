"""Brief, grounded help alongside intake; help never edits a business field."""
import re
from . import togo
from .domain import field_schema, missing, SERVICES, INTAKE
from .catalog import FIELD_ALIASES, ALIASES
from . import service_intro, speech_policy
from .responses import label as spoken_label

TOPICS = ('identity','capabilities','explain_field','repeat','privacy','service_info','handoff','date_context','keep_details','continue_address','unknown')

HELP = {
 'flood_duration_days': ('请说洪水影响您住所正常居住的总天数；如果仍在持续，请说截至今天已持续几天。', 'Please give the total number of days the flooding affected normal life at your home. If it is ongoing, count up to today.', 'กรุณาบอกจำนวนวันที่น้ำท่วมส่งผลกระทบต่อการอยู่อาศัย หากยังท่วมอยู่ ให้นับถึงวันนี้ค่ะ'),
 'guardian_name': ('请说照顾孩子、准备办理申请的家长或监护人的姓名。', 'Please give the name of the parent or guardian preparing the application.', 'กรุณาบอกชื่อพ่อแม่หรือผู้ปกครองที่เตรียมยื่นคำขอค่ะ'),
 'relationship': ('这里是问您和孩子的关系，例如妈妈、爸爸，或其他监护人。', 'This asks whether you are the child’s mother, father or another guardian.', 'ข้อนี้ถามว่าคุณเป็นแม่ พ่อ หรือผู้ปกครองของเด็กค่ะ'),
 'child_name': ('这里填写孩子的姓名，不是家长的姓名。', 'This is the child’s name, rather than the parent’s name.', 'ข้อนี้เป็นชื่อของเด็ก ไม่ใช่ชื่อพ่อแม่ค่ะ'),
 'child_birth_date': ('请按公历说孩子出生的年月日，也可以说今天、昨天或前天。我会换算成具体日期；如用泰国佛历，请说明。', 'Please give the child’s birth date in the Gregorian calendar. You may say today or yesterday; I will work out the date. Please say if a year is Buddhist Era.', 'กรุณาบอกวันเกิดเด็กตามปฏิทินสากล หรือบอกว่าวันนี้ เมื่อวาน หรือเมื่อวานซืนได้ค่ะ หากใช้ปี พ.ศ. โปรดระบุด้วยค่ะ'),
 'phone': ('这个号码用于后续联系或接续办理，不需要提供验证码。', 'This number is for follow-up or continuing the application. No verification code is needed.', 'หมายเลขนี้ใช้ติดต่อหรือดำเนินการต่อ ไม่ต้องบอกรหัสยืนยันค่ะ'),
 'household_members': ('请说家庭共有几位成员，包括孩子。', 'Please tell me how many people are in your household, including the child.', 'กรุณาบอกจำนวนสมาชิกในครัวเรือน รวมเด็กด้วยค่ะ'),
 'annual_household_income': ('请提供家庭一整年的合计收入，单位为泰铢。', 'Please give your household’s total annual income in Thai baht.', 'กรุณาบอกรายได้รวมต่อปีของครัวเรือนเป็นบาทค่ะ'),
 'province': ('请说居住地所在的府；如果在曼谷，可以直接说曼谷。', 'Please give the province where you live; Bangkok is also accepted.', 'กรุณาบอกจังหวัดที่อยู่อาศัย หากอยู่กรุงเทพฯ บอกว่ากรุงเทพมหานครได้ค่ะ'),
 'district': ('请说居住地所在的县或曼谷的区。', 'Please give your district, or khet if you live in Bangkok.', 'กรุณาบอกอำเภอ หรือเขตหากอยู่กรุงเทพมหานครค่ะ'),
 'flood_start_date': ('这里问洪水开始影响您住所的日期，不是退水日期；可以说昨天或前天。', 'This asks when flooding began affecting your home, rather than when it ended. You may say yesterday.', 'ข้อนี้ถามวันที่น้ำเริ่มท่วมที่พัก ไม่ใช่วันที่น้ำลด บอกว่าเมื่อวานได้ค่ะ'),
 'flood_end_date': ('如果洪水还没退，不用填写退水日期。', 'If the flood is ongoing, leave the end date blank.', 'หากน้ำยังไม่ลด ไม่ต้องระบุวันที่สิ้นสุดค่ะ'),
}


def pending_key(draft):
    errors = draft['workflow'].get('errors', {})
    return next(iter(errors), None) or next(iter(missing(draft['fields'],draft['service'])), None)


def field_reference(text, draft, fallback=True):
    candidates = []
    for field in field_schema(draft['service']):
        words = [field[k] for k in ('key','zh','en','th')]+FIELD_ALIASES.get(field['key'], [])
        if any(re.search(re.escape(word),text,re.I) for word in words):
            candidates.append(field['key'])
    return candidates[0] if len(candidates)==1 else pending_key(draft) if fallback else None


def local_question(text, draft):
    if togo.ACTIVE and draft['service'] in togo.SCHEMAS and re.search(r'费用|多少钱|材料|多久|时限|cost|fee|requirements|how long',text,re.I):
        return {'action':'answer','topic':'togo_knowledge','knowledge_key':'requirements' if re.search(r'材料|requirements',text,re.I) else 'time' if re.search(r'多久|时限|how long',text,re.I) else 'fee'}
    if draft.get('service')=='flood-relief-preparation' and speech_policy.incomplete_address(text):
        return {'action':'answer','topic':'continue_address'}
    value = text.strip().strip('。.!！?？ ')
    # Isolated KEEP commands are unambiguous. Mixed corrections need semantics.
    if not re.search(r'\b(?:instead|but|change|update|replace|just|only)\b|改为|改成|换成|更新为|但是|不过|只|แทน|เปลี่ยน|แก้เป็น',value,re.I) and re.fullmatch(
        r"(?:please\s+)?(?:do not|don't|never)\s+(?:clear|delete|remove|erase|reset)\b.+|(?:请)?(?:不要|别)(?:清空|清除|删除|删掉|撤回).+|(?:อย่า|ห้าม)(?:ล้าง|ลบ).+",value,re.I):
        return {'action':'answer','topic':'keep_details'}
    if re.fullmatch(r'(?:请问|那个|你好|hello[, ]*|hi[, ]*)?(?:你是谁|您是谁|你叫什么(?:名字)?|你是真人吗|你是机器人吗|who are you|what are you|what(?: is|’s|\x27s) your name|are you (?:a |an )?(?:human|robot|AI)|คุณคือใคร|คุณเป็นใคร|คุณเป็นคนจริงไหม)', value, re.I):
        return {'action':'answer', 'topic':'identity'}
    if re.search(r'你(?:能|可以|会)(?:帮我)?(?:做|办)什么|能帮我什么|what can you (?:do|help)|ทำอะไรได้',value,re.I):
        return {'action':'answer','topic':'capabilities'}
    if re.search(r'填完(?:后|了)?(?:怎么|怎么办)|填好.{0,5}(?:然后|之后)|after (?:we|i).*fill|after.*form.*(?:done|complete)|กรอก.*เสร็จ.*ทำอย่างไร',value,re.I):
        return {'action':'answer','topic':'handoff'}
    if re.search(r'隐私|安全吗|密码|验证码|privacy|is (?:this|it) safe|password|ความเป็นส่วนตัว|รหัสยืนยัน',value,re.I) and re.search(r'[?？]|吗|么|why|what|safe|privacy|หรือ|ไหม',text,re.I):
        return {'action':'answer','topic':'privacy'}
    if re.fullmatch(r'再说(?:一遍|一次)?|重复(?:一遍|一次)?|刚才(?:问|说)什么|repeat(?: that| the question)?(?: please)?|say that again|พูดอีกครั้ง|ทวนคำถาม',value,re.I):
        return {'action':'answer','topic':'repeat'}
    if re.search(r'解释|什么意思|没听懂|不明白|不懂|怎么填|为什么要|什么是|农历|阳历|公历|我不知道|explain|what.*mean|why.*(?:ask|need)|don.t (?:understand|know)|what is a guardian|อธิบาย|ไม่เข้าใจ|คืออะไร',value,re.I):
        named=[key for key,pattern in ALIASES.items() if re.search(pattern,value,re.I)]
        named_field=field_reference(value,draft,fallback=False)
        if not named_field and draft['workflow']['state']=='service_intro' and not named:
            return {'action':'answer','topic':'service_info'}
        if len(named)==1 and not named_field:
            return {'action':'answer','topic':'service_info','service_topic':named[0]}
        return {'action':'answer','topic':'explain_field','field':field_reference(value,draft)}
    return None


def reply(draft, directive, lang, next_prompt):
    if togo.ACTIVE and directive.get('topic') in ('togo_knowledge','service_info') and draft['service'] in togo.SCHEMAS:
        entry=togo.KNOWLEDGE['services'][draft['service']].get(lang,togo.KNOWLEDGE['services'][draft['service']]['en'])
        value=entry.get(directive.get('knowledge_key','summary'),'')
        if isinstance(value,list):value='；'.join(value)
        return str(value)+('。这是2026-11-06资料快照，仅供参考。' if lang=='zh' else ' Historical reference, checked 2026-11-06. ')+next_prompt
    if directive.get('topic')=='continue_address':
        return {'en':'Please continue with the full address, including house number, subdistrict, district and province.',
                'zh':'请继续说出完整地址，包括门牌号、分区、区县和府省。',
                'th':'กรุณาบอกที่อยู่ต่อให้ครบ รวมบ้านเลขที่ ตำบล อำเภอ และจังหวัดค่ะ'}[lang]
    index={'zh':0,'en':1,'th':2}[lang]
    topic=directive.get('topic','unknown')
    key=directive.get('field')
    allowed={field['key']:field for field in field_schema(draft['service'])}
    if key not in allowed:
        key=pending_key(draft)
    messages={
      'keep_details': ('好的，已填写的信息保持不变。', 'I’ll keep your existing details unchanged. ', 'ได้ค่ะ จะเก็บข้อมูลที่กรอกไว้เหมือนเดิม '),
      'identity': ('我是您的AI助手，可以陪您填写政务申请资料。', 'I’m your AI assistant. I can help you prepare government-service forms.', 'ฉันเป็นผู้ช่วย AI ของคุณ ช่วยเตรียมข้อมูลบริการภาครัฐได้ค่ะ'),
      'capabilities': ('我是您的AI助手。您说出要办的事，我帮您整理资料，也可以解释问题或修改信息。', 'I’m your AI assistant. Tell me what you need; I can collect details, explain questions or correct information.', 'ฉันเป็นผู้ช่วย AI ของคุณ บอกบริการที่ต้องการได้ค่ะ ฉันช่วยรวบรวมข้อมูล อธิบายคำถาม หรือแก้ไขข้อมูลได้ค่ะ'),
      'privacy': ('请不要说密码、验证码、身份证号或银行卡号。语音和文字会由已配置的AI服务处理。', 'Please do not share passwords, verification codes, identity or bank account numbers. Speech and text are processed by the configured AI providers.', 'ไม่ต้องบอกรหัสผ่าน รหัสยืนยัน เลขบัตรประชาชน หรือบัญชีธนาคาร เสียงและข้อความจะประมวลผลโดยบริการ AI ที่ตั้งค่าไว้ค่ะ'),
      'handoff': ('填好后先打开草稿核对。需要换设备继续时，可以生成续办链接，登录后打开。', 'Open the draft and review your details. To continue on another device, create a continuation link and open it after signing in.', 'กรอกแล้วให้เปิดฉบับร่างเพื่อตรวจสอบ หากต้องการดำเนินการต่อบนอุปกรณ์อื่น สามารถสร้างลิงก์แล้วเปิดหลังเข้าสู่ระบบค่ะ'),
      'service_info': ('我可以介绍需要填写的资料，并帮您整理申请。', 'I can explain the information needed and help prepare your application.', 'ฉันอธิบายข้อมูลที่ต้องใช้และช่วยเตรียมคำขอได้ค่ะ'),
      'unknown': ('我是您的AI助手，主要帮您整理政务办理资料，也能解释当前问题。', 'I’m your AI assistant. I help prepare government-service details and can explain the current question.', 'ฉันเป็นผู้ช่วย AI ของคุณ ช่วยเตรียมข้อมูลบริการภาครัฐและอธิบายคำถามปัจจุบันได้ค่ะ'),
    }
    if topic=='repeat':
        return next_prompt
    if topic=='date_context':
        return ('您说的这个日期是指哪一项资料？请告诉我是出生日期，还是其他日期。','Which detail does that date refer to? Please say whether it is a birth date or another date.','วันที่ที่บอกหมายถึงข้อมูลส่วนไหนคะ กรุณาระบุว่าเป็นวันเกิดหรือวันอื่นค่ะ')[index]
    if topic=='service_info':
        service=directive.get('service_topic') or draft['service']
        if service in SERVICES:
            answer=service_intro.summary(service,lang)
            return answer+(' ' if lang=='en' else '')+next_prompt
    if topic=='explain_field' and key:
        if key in HELP:
            answer=HELP[key][index]
        else:
            label=spoken_label(draft,key,lang)
            answer=(f'这里需要填写{label}。可以直接说出来；不确定的话，可以先暂停，核实后再继续。',f'This asks for {label}. You can say it aloud, or pause and check it before continuing.',f'ข้อนี้ต้องการ{label} บอกเป็นเสียงได้ หรือพักเพื่อตรวจสอบข้อมูลก่อนค่ะ')[index]
    else:
        answer=messages.get(topic,messages['unknown'])[index]
    return answer+(' ' if lang=='en' else '')+next_prompt
