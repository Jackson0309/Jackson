"""Concise spoken acknowledgements grounded in accepted, stored values."""
import datetime as dt
import re
from .domain import SERVICES, INTAKE, field_schema
from . import service_intro


def text(lang, zh, en, th):
    return {'zh':zh,'en':en,'th':th}[lang]


def label(draft, key, lang):
    name=next((f[lang] for f in field_schema(draft['service']) if f['key']==key),key)
    return re.sub(r'\([^)]*\)|（[^）]*）','',name).replace('Sample ','').replace('示例','').replace('ตัวอย่าง','').strip()


def display_value(draft, key, value, lang):
    if key=='citizen_id':return text(lang,'尾号'+str(value)[-4:],'ending in '+str(value)[-4:],'ลงท้ายด้วย '+str(value)[-4:])
    field=next((f for f in field_schema(draft['service']) if f['key']==key),{})
    option=next((o for o in field.get('options',[]) if o['value']==value),None)
    if option:return option[lang]
    if key=='query_subject' and str(value).lower() in ('demo self','myself','self','本人','本人 / demo self'):
        return text(lang,'您本人','your profile','ข้อมูลของคุณ')
    if field.get('type')=='date' and value:
        try:
            date=dt.date.fromisoformat(value)
            if lang=='zh':return f'{date.year}年{date.month}月{date.day}日'
            if lang=='en':return date.strftime('%B %d, %Y')
        except (ValueError,TypeError):pass
    value=str(value)
    return value if len(value)<=64 else value[:48]+text(lang,'，完整内容已填入表单','; the full text is in the form',' รายละเอียดทั้งหมดอยู่ในแบบฟอร์ม')


def validation_prompt(draft, lang):
    key=next(iter(draft['workflow'].get('errors',{})),None)
    if not key:return ''
    name=label(draft,key,lang)
    error=str(draft['workflow']['errors'][key])
    if error.startswith('geo_'):
        if key=='province':return text(lang,'这个府或省的名称未匹配到泰国地区名录，请说出英文或泰语全名。','I could not match that province in the Thai place-name directory. Please give its full English or Thai name.','ไม่พบชื่อจังหวัดนี้ในรายการพื้นที่ไทย กรุณาบอกชื่อจังหวัดเต็มเป็นภาษาไทยหรืออังกฤษค่ะ')
        return text(lang,'这个区县未匹配到所选府省，请核对后说出正确的区县名称。','That district does not match the selected province, or its name was not found. Please check the province and district.','ชื่ออำเภอหรือเขตไม่ตรงกับจังหวัดที่เลือก หรือไม่พบชื่อนี้ กรุณาตรวจสอบจังหวัดและอำเภออีกครั้งค่ะ')
    if key=='phone':
        if '10 digits' in error:return text(lang,'泰国手机号码需要10位数字，请完整说出号码。','Please give the full ten-digit Thai mobile number.','กรุณาบอกหมายเลขโทรศัพท์มือถือไทยให้ครบสิบหลักค่ะ')
        return text(lang,'联系电话需要8至15位数字，请完整说出号码。','Please give the full contact number with 8 to 15 digits.','กรุณาบอกหมายเลขโทรศัพท์ให้ครบ 8 ถึง 15 หลักค่ะ')
    if error=='incomplete_address':return text(lang,'请继续说出完整受灾地址。','Please continue with your full affected address.','กรุณาบอกที่อยู่ที่ประสบภัยให้ครบค่ะ')
    if key in ('child_birth_date','flood_start_date','flood_end_date'):
        future='future' in str(draft['workflow']['errors'][key])
        if future:return text(lang,f'{name}不能晚于今天，请核实后再说一次。',f'{name} cannot be later than today. Please check the date and say it again.',f'{name}ต้องไม่เป็นวันในอนาคต กรุณาตรวจสอบแล้วบอกอีกครั้งค่ะ')
        return text(lang,f'请说出{name}的具体年月日，也可以说昨天或前天，我会换算成日期。',f'Please give {name} with the year, month and day. You can also say yesterday.',f'กรุณาบอก{name}เป็นวันเดือนปี หรือบอกว่าเมื่อวานก็ได้ค่ะ')
    return text(lang,f'{name}未通过校验，尚未更新，请再提供一次。',f'{name} was not saved because it did not validate. Please give it again.',f'{name}ยังไม่ถูกบันทึก เนื่องจากรูปแบบไม่ถูกต้อง กรุณาระบุอีกครั้งค่ะ')


def field_acknowledgement(before, draft, keys, lang, action):
    current=draft['fields']
    old=before.get('fields',{}) if before.get('service')==draft['service'] else {}
    allowed={f['key'] for f in field_schema(draft['service'])}
    keys=list(dict.fromkeys(k for k in keys if k in allowed))
    priority={'guardian_name':0,'applicant_name':0,'child_name':1,'phone':2}
    keys.sort(key=lambda k:priority.get(k,3))
    parts=[]
    for key in keys[:3]:
        name=label(draft,key,lang);value=current.get(key)
        if not value:
            if old.get(key):parts.append(text(lang,f'已撤回{name}',f'{name} was removed',f'ลบ{name}แล้วค่ะ'))
            else:parts.append(text(lang,f'{name}尚未填写',f'{name} has not been provided',f'ยังไม่ได้ระบุ{name}ค่ะ'))
            continue
        value=display_value(draft,key,value,lang)
        if action=='undo':parts.append(text(lang,f'已恢复{name}为{value}',f'{name} was restored to {value}',f'คืนค่า{name}เป็น {value} แล้วค่ะ'))
        elif old.get(key)==current.get(key):parts.append(text(lang,f'{name}是{value}',f'{name} is {value}',f'{name}คือ {value} ค่ะ'))
        elif old.get(key):parts.append(text(lang,f'{name}已更新为{value}',f'{name} was updated to {value}',f'แก้ไข{name}เป็น {value} แล้วค่ะ'))
        else:parts.append(text(lang,f'{name}已记录为{value}',f'{name} was recorded as {value}',f'บันทึก{name}เป็น {value} แล้วค่ะ'))
    if len(keys)>3:parts.append(text(lang,f'另有{len(keys)-3}项信息已填入表单',f'{len(keys)-3} other details are in the form',f'บันทึกข้อมูลอื่นอีก {len(keys)-3} รายการในแบบฟอร์มแล้วค่ะ'))
    return text(lang,'，','; ',' ').join(parts)+(text(lang,'。','. ',' ') if parts else '')


def compose_reply(before, draft, action, lang, next_prompt, *, accepted=(), removed=(), restored=False, undone=False, hits=()):
    service=draft['service'];meta=SERVICES.get(service,{})
    title=meta.get(lang,'');previous=SERVICES.get(before.get('service'),{}).get(lang,'')
    ack=''
    if draft['workflow']['state'] in ('service_intro','government_qa'):
        # Explain a newly chosen service once; don't replay its full overview
        # when the user supplies facts without agreeing or asks to clarify.
        prompt=service_intro.ask(lang) if service==before.get('service') and action!='decline_prefill' and not restored else next_prompt
        return prompt,prompt
    if action=='accept_prefill':
        ack=text(lang,'好的，开始填写。','Let’s get started. ','ได้ค่ะ เริ่มกรอกข้อมูล ')
        ack+=field_acknowledgement(before,draft,accepted,lang,action)
    elif action=='cancel':
        ack=text(lang,f'已暂停{previous}，草稿已保留。' if previous else '当前没有正在办理的事项。',f'{previous} was paused and its draft kept. ' if previous else 'There is no active service. ',f'พักบริการ{previous}และเก็บฉบับร่างแล้วค่ะ ' if previous else 'ยังไม่มีบริการที่กำลังดำเนินการค่ะ ')
        next_prompt=text(lang,'接下来想办理什么事项？','Which service would you like next?','ต้องการใช้บริการใดต่อคะ')
    elif action=='clear_all':
        ack=text(lang,'所有事项草稿已清空。','All service drafts have been cleared. ','ล้างฉบับร่างทุกบริการแล้วค่ะ ')
        next_prompt=text(lang,'接下来想办理什么事项？','Which service would you like next?','ต้องการใช้บริการใดต่อคะ')
    elif action=='clear':
        ack=text(lang,f'已清空{title}表单。' if title else '当前没有已选择的表单。',f'The {title} form has been cleared. ' if title else 'No form is selected. ',f'ล้างแบบฟอร์ม{title}แล้วค่ะ ' if title else 'ยังไม่ได้เลือกแบบฟอร์มค่ะ ')
    elif action=='resume' or restored:
        ack=text(lang,f'已恢复{title}草稿。' if restored else f'继续办理{title}。' if title else '没有可恢复的草稿。',f'The {title} draft was restored. ' if restored else f'Continuing {title}. ' if title else 'There is no saved draft. ',f'เรียกคืนฉบับร่าง{title}แล้วค่ะ ' if restored else f'ดำเนินการ{title}ต่อค่ะ ' if title else 'ไม่มีฉบับร่างที่บันทึกไว้ค่ะ ')
        if accepted:ack+=field_acknowledgement(before,draft,accepted,lang,action)
    elif action=='undo':
        if undone:
            keys=[k for k in before.get('fields',{}).keys()|draft['fields'].keys() if before.get('fields',{}).get(k)!=draft['fields'].get(k)] if before.get('service')==service else []
            ack=field_acknowledgement(before,draft,keys,lang,action) or text(lang,'已撤销上一轮修改。','The last change was undone. ','ย้อนกลับการเปลี่ยนแปลงล่าสุดแล้วค่ะ ')
        else:ack=text(lang,'没有可撤销的上一轮修改。','There is no earlier change to undo. ','ไม่มีการเปลี่ยนแปลงก่อนหน้าให้ย้อนกลับค่ะ ')
    elif action=='remove_fields':
        ack=field_acknowledgement(before,draft,removed,lang,action)
    elif action=='provide':
        if service!=before.get('service') and service!=INTAKE:
            ack=text(lang,f'好的，办理{title}。',f'Let’s help with {title.lower()}. ',f'ได้ค่ะ เริ่มบริการ{title} ')
        ack+=field_acknowledgement(before,draft,accepted,lang,action)
    elif action=='confirm':
        if draft['workflow']['state']!='review':ack=text(lang,'还需要补充资料。','A few details are still needed. ','ยังต้องเพิ่มข้อมูลค่ะ ')
    elif len(hits)>1:
        names=[SERVICES[k][lang] for k in hits]
        reply=text(lang,'您想先办理'+'，还是'.join(names)+'？','Which would you like first: '+' or '.join(names)+'?', 'ต้องการเริ่มบริการใดก่อนคะ '+' หรือ '.join(names))
        return reply,reply
    elif service==INTAKE:
        reply=text(lang,'您想办理什么事项？请说出事项名称，例如儿童补贴。','Which service would you like? You can say its name, for example child subsidy.','ต้องการใช้บริการใดคะ บอกชื่อบริการได้เลย เช่น เงินอุดหนุนเด็กค่ะ')
        return reply,reply
    reply=ack+(' ' if ack and lang=='en' and not ack.endswith(' ') else '')+next_prompt
    return reply,ack.strip() or next_prompt
