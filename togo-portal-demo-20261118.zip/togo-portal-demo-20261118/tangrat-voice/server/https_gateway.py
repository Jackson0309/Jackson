"""LAN-only TLS frontend for the existing portal, including voice WS and observer SSE."""
import asyncio,ssl
from pathlib import Path
from aiohttp import web,ClientSession,ClientTimeout,WSMsgType
ROOT=Path(__file__).resolve().parents[1]
UPSTREAM='http://127.0.0.1:4175'
HOP={'host','connection','upgrade','transfer-encoding','content-length','accept-encoding'}
async def forward(request):
    expected='https://'+request.host
    if request.headers.get('Origin') not in (None,expected):
        return web.Response(status=403,text='Origin not allowed')
    headers={k:v for k,v in request.headers.items() if k.lower() not in HOP and not k.lower().startswith('sec-websocket-')}
    headers['Host']='127.0.0.1:4175'
    if 'Origin' in headers:headers['Origin']=UPSTREAM
    session=request.app['client']
    if request.headers.get('Upgrade','').lower()=='websocket':
        async with session.ws_connect(UPSTREAM+str(request.rel_url),headers=headers,autoping=True,max_msg_size=16*1024**2) as upstream:
            downstream=web.WebSocketResponse(autoping=True,max_msg_size=16*1024**2)
            await downstream.prepare(request)
            async def relay(source,target):
                async for msg in source:
                    if msg.type==WSMsgType.TEXT:await target.send_str(msg.data)
                    elif msg.type==WSMsgType.BINARY:await target.send_bytes(msg.data)
                    elif msg.type in (WSMsgType.CLOSE,WSMsgType.CLOSED,WSMsgType.ERROR):break
            tasks=[asyncio.create_task(relay(downstream,upstream)),asyncio.create_task(relay(upstream,downstream))]
            try:await asyncio.wait(tasks,return_when=asyncio.FIRST_COMPLETED)
            finally:
                for task in tasks:task.cancel()
                await asyncio.gather(*tasks,return_exceptions=True)
                await downstream.close()
            return downstream
    async with session.request(request.method,UPSTREAM+str(request.rel_url),headers=headers,data=await request.read(),allow_redirects=False) as result:
        out=web.StreamResponse(status=result.status)
        for k,v in result.headers.items():
            if k.lower() not in HOP|{'content-encoding','set-cookie','location'}:out.headers.add(k,v)
        for value in result.headers.getall('Set-Cookie',[]):
            out.headers.add('Set-Cookie',value if '; secure' in value.lower() else value+'; Secure')
        if 'Location' in result.headers:out.headers['Location']=result.headers['Location'].replace(UPSTREAM,expected)
        out.headers['Permissions-Policy']='microphone=(self)'
        await out.prepare(request)
        async for chunk in result.content.iter_any():await out.write(chunk)
        await out.write_eof()
        return out
async def lifecycle(app):
    app['client']=ClientSession(timeout=ClientTimeout(total=None,sock_connect=15),auto_decompress=True)
    yield
    await app['client'].close()
def main():
    tls=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    tls.minimum_version=ssl.TLSVersion.TLSv1_2
    tls.load_cert_chain(ROOT/'data/tls/server.pem',ROOT/'data/tls/server-key.pem')
    app=web.Application(client_max_size=40*1024**2)
    app.cleanup_ctx.append(lifecycle)
    app.router.add_route('*','/{path:.*}',forward)
    web.run_app(app,host='0.0.0.0',port=8443,ssl_context=tls,access_log=None)
if __name__=='__main__':main()
