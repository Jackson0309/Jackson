"""Scenario fixtures, not government records. Replace adapters before real use."""
import re
from . import geography

SOURCE = 'https://www.thangrath.go.th/thangrath-flood-relief-69-miniapp-guide/'

def words(lang, zh, en, th):
    return {'zh':zh,'en':en,'th':th}[lang]

def materials(lang):
    return words(lang,
        '请准备国民身份证号码、常住地址和受灾情况。当地政府可能在后续核查时要求居住证明。我可以帮您预填并检查信息，现在开始吗？',
        'Please prepare your citizen ID number, usual residential address and flood damage details. Your local office may ask for proof of residence later. I can help prefill and check your information. Shall we start?',
        'กรุณาเตรียมเลขบัตรประชาชน ที่อยู่ที่พักอาศัยประจำ และรายละเอียดความเสียหายค่ะ หน่วยงานท้องถิ่นอาจขอหลักฐานการอยู่อาศัยภายหลัง ฉันช่วยกรอกและตรวจสอบข้อมูลให้ได้ เริ่มเลยไหมคะ')

def is_material_question(text):
    return bool(re.search(r'flood|洪灾|น้ำท่วม',text,re.I) and re.search(r'documents?|materials?|proof|需要.*材料|什么材料|เอกสาร|หลักฐาน',text,re.I))

def direct_patch(text, draft):
    """High-confidence field normalization only; general language still uses LLM."""
    if not draft['workflow'].get('prefill_consent'): return None
    from .domain import missing
    pending=next(iter(missing(draft['fields'],draft['service'])),None)
    value=text.strip().strip('。.! ')
    if pending=='citizen_id':
        digits=re.sub(r'[\s,，.。-]','',value.translate(str.maketrans('๐๑๒๓๔๕๖๗๘๙','0123456789')))
        if digits.isdigit(): return {'citizen_id':digits}
        english={'zero':'0','oh':'0','one':'1','two':'2','three':'3','four':'4','five':'5','six':'6','seven':'7','eight':'8','nine':'9'}
        thai=dict(zip(('ศูนย์','หนึ่ง','สอง','สาม','สี่','ห้า','หก','เจ็ด','แปด','เก้า'),'0123456789'))
        chinese=dict(zip('零一二三四五六七八九','0123456789'))
        for mapping in (english,thai,chinese):
            compact=re.sub(r'[\s,，.。-]','',value.casefold())
            tokens=re.findall('|'.join(sorted(mapping,key=len,reverse=True)),compact)
            if tokens and ''.join(tokens)==compact:
                return {'citizen_id':''.join(mapping[token] for token in tokens)}
    if pending=='flood_duration_days':
        match=re.fullmatch(r'(\d+)\s*(?:days?|天|วัน)?',value,re.I)
        if match:return {'flood_duration_days':match[1]}
    return None

def refresh(draft):
    fields=draft['fields']; checks={}
    if fields.get('citizen_id') and fields.get('applicant_name'):
        # Presentation simulation: basic field formats are validated by domain.py.
        # Any supplied name and accepted 13-digit number pass; no registry lookup.
        checks['identity']={'status':'passed', 'code':'name_match', 'mode':'simulation'}
    if fields.get('address') and fields.get('province') and fields.get('district'):
        _,errors=geography.check({k:fields[k] for k in ('province','district')},{})
        if errors:
            checks['area']={'status':'failed','code':'invalid_address'}
        else:
            province=geography.norm(re.sub(r'[府省]$','',fields['province'])); district=geography.norm(re.sub(r'[区县]$','',fields['district']))
            open_area=province in ('bangkok','กรุงเทพมหานคร','曼谷') and district in ('bangkhen','บางเขน','挽卿','邦肯')
            closed=province in ('chiangmai','เชียงใหม่','清迈') and district in ('mueangchiangmai','เมืองเชียงใหม่','清迈市')
            checks['area']={'status':'passed' if open_area else 'failed' if closed else 'unknown',
                            'code':'open' if open_area else 'not_open' if closed else 'unknown'}
    draft['workflow']['checks']=checks
    return checks

def blocking(draft,lang):
    checks=draft['workflow'].get('checks',{})
    area=checks.get('area',{})
    if area.get('code')=='not_open':
        return words(lang,'该地区目前尚未开放洪灾救助登记，请关注当地政府后续通知。已填信息会保留；如果地址有误，请告诉我正确的完整地址。','Flood relief registration is not open in this area yet. Please follow announcements from your local authority. I have kept your details. If the address is incorrect, please give me the correct full address.','พื้นที่นี้ยังไม่เปิดลงทะเบียนช่วยเหลือน้ำท่วมค่ะ กรุณาติดตามประกาศจากหน่วยงานท้องถิ่น เก็บข้อมูลที่กรอกไว้แล้ว หากที่อยู่ไม่ถูกต้อง กรุณาบอกที่อยู่ที่ถูกต้องทั้งหมดค่ะ')
    if area.get('status') in ('unknown','failed'):
        return words(lang,'暂时无法确认该地址的登记状态，请核对府和区县，或向当地政府咨询。','I cannot confirm registration availability for this address. Please check the province and district, or contact your local authority.','ยังยืนยันสถานะการลงทะเบียนของที่อยู่นี้ไม่ได้ กรุณาตรวจสอบจังหวัดและอำเภอ หรือติดต่อหน่วยงานท้องถิ่นค่ะ')
    return ''

def completed(lang):
    return words(lang,'预填信息已完成并保存在本系统。请打开应用核对后继续提交；如不方便使用应用，可到当地政府服务窗口咨询办理。',
        'Your prefilled information is complete and saved. Please open the application to review your details and continue with submission. If you need help, contact your local government service office.',
        'กรอกข้อมูลล่วงหน้าและบันทึกเรียบร้อยแล้วค่ะ กรุณาเปิดแอปเพื่อตรวจสอบข้อมูลและดำเนินการยื่นคำขอต่อ หากไม่สะดวกใช้แอป สามารถติดต่อหน่วยงานท้องถิ่นเพื่อขอความช่วยเหลือค่ะ')
