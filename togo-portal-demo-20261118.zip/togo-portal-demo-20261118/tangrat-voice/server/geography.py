"""Offline bilingual names and province/district consistency, never geocoding APIs."""
import json
import re
import unicodedata
from pathlib import Path

DATA=json.loads((Path(__file__).parent/'reference'/'thai-admin.json').read_text(encoding='utf-8'))

def norm(value):
    value=unicodedata.normalize('NFC',str(value)).casefold().strip()
    value=re.sub(r'^(?:จังหวัด|จ\.|อำเภอ|อ\.|เขต|province\s+of\s+|amphoe\s+|khet\s+)','',value)
    value=re.sub(r'\s+(?:province|district)$','',value)
    return re.sub(r'[\s\-.,’\x27ฯ]','',value)

PROVINCES={norm(name):row for row in DATA['province'] for name in (row['en'],row['th'])}
for alias in ('กรุงเทพ','กรุงเทพฯ','krung thep','krung thep maha nakhon','bkk'):
    PROVINCES[norm(alias)]=PROVINCES['bangkok']
PROVINCES['songkla']=PROVINCES['songkhla']
DISTRICTS={}
for row in DATA['district']:
    for name in (row['en'],row['th']):DISTRICTS.setdefault(norm(name),[]).append(row)
DISTRICTS[norm('Bang Khaen')]=DISTRICTS[norm('Bang Khen')]

def explicit_patch(text):
    """Preserve explicitly labelled places even if an LLM tries to repair them."""
    result={}
    patterns={
      'province':[r'\bprovince\s*(?:is\b|of\b|[:=])?\s*([a-z][a-z -]*?)(?=\s+(?:and|district)\b|[,;.\n]|$)',
                  r'จังหวัด\s*([ก-๛ ]+?)(?=\s*(?:อำเภอ|เขต|ตำบล|แขวง|เบอร์|ค่ะ|ครับ)|[,;.\n]|$)'],
      'district':[r'\bdistrict\s*(?:is\b|of\b|[:=])?\s*([a-z][a-z -]*?)(?=\s+(?:and|province)\b|[,;.\n]|$)',
                  r'(?:อำเภอ|เขต)\s*([ก-๛ ]+?)(?=\s*(?:จังหวัด|กรุงเทพมหานคร|ตำบล|แขวง|เบอร์|ค่ะ|ครับ)|[,;.\n]|$)']}
    for key,expressions in patterns.items():
        for expression in expressions:
            match=re.search(expression,text,re.I)
            if match:
                result[key]=match.group(1).strip();break
    return result

def check(patch,current):
    accepted=dict(patch);errors={};combined={**current,**patch}
    value=combined.get('province','');province=PROVINCES.get(norm(value))
    # Chinese aliases remain compatible with the Chinese demonstration.
    chinese=lambda s:bool(re.search(r'[\u4e00-\u9fff]',str(s)))
    if value and not chinese(value):
        if province:
            if 'province' in patch:accepted['province']=province['th' if re.search('[ก-๛]',value) else 'en']
        elif 'province' in patch:
            accepted.pop('province',None);errors['province']='geo_unknown_province'
    district=combined.get('district','')
    if district and not chinese(district):
        matches=DISTRICTS.get(norm(district),[])
        if province:matches=[r for r in matches if r['province_id']==province['id']]
        if not matches:
            accepted.pop('district',None)
            if 'district' in patch or 'province' in patch:errors['district']='geo_district_mismatch' if province else 'geo_unknown_district'
        elif 'province' in errors:
            accepted.pop('district',None);errors['district']='geo_check_province_first'
        elif 'district' in patch:
            accepted['district']=matches[0]['th' if re.search('[ก-๛]',district) else 'en']
    return accepted,errors
