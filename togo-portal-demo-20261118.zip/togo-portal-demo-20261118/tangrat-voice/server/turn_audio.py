"""Separate wake/answer ASR sessions and bind every result to its input epoch."""
import asyncio
import base64
import json
import math
from array import array
from dataclasses import dataclass
from urllib.parse import urlencode
from websockets.asyncio.client import connect
from pipecat.frames.frames import InputAudioRawFrame, InterimTranscriptionFrame, TranscriptionFrame, StartFrame, EndFrame, CancelFrame
from pipecat.processors.frame_processor import FrameProcessor
from .speech_policy import languages,recognition_context

@dataclass
class TurnAudioFrame(InputAudioRawFrame):
    input_epoch: int = 0

@dataclass
class TurnTranscript(TranscriptionFrame):
    input_epoch: int = 0
    channel: str = 'answer'

@dataclass
class TurnInterim(InterimTranscriptionFrame):
    input_epoch: int = 0
    channel: str = 'answer'

class NearSpeechGate:
    """Conservative low-energy suppression, retaining pauses and audio timing.

    This rejects very weak input, not other speakers. VAD/background filtering
    remains the provider's responsibility; a headset is better for nearby speech.
    """
    def __init__(self, threshold=0.006, hold_seconds=.35):
        self.threshold=threshold;self.hold_seconds=hold_seconds;self.remaining=0;self.voiced_samples=0

    def filter(self,audio):
        samples=array('h');samples.frombytes(audio)
        rms=math.sqrt(sum(x*x for x in samples)/max(1,len(samples)))/32768
        duration=len(samples)/16000
        if rms>=self.threshold:
            self.remaining=self.hold_seconds;self.voiced_samples+=len(samples)
        else:self.remaining=max(0,self.remaining-duration)
        return audio if self.remaining>0 else bytes(len(audio))

class SeparatedSTT(FrameProcessor):
    """Exactly one active session; a new session is created at every role/turn boundary.

    Wake results never become business answers. Closing the previous session and
    checking its epoch prevent late finals and acoustically mixed segments crossing
    a playback boundary. No key is placed in a URL or exception sent to the client.
    """
    def __init__(self, api_key, lang, notify_error, connector=connect):
        super().__init__()
        self.api_key=api_key
        self.lang=lang
        self.notify_error=notify_error
        self.connector=connector
        self.epoch=-1
        self.channel='closed'
        self.socket=None
        self.reader=None
        self.lock=asyncio.Lock()
        self.closing=False
        self.audio_bytes={'wake':0,'answer':0,'stale':0}
        self.gate=NearSpeechGate()
        self.context=''
        self.keyterms=[]
        self.first_chunk=True
        self.answer_pause=1.5

    def set_context(self,prompt):
        self.context=recognition_context(prompt)

    def set_keyterms(self,terms):
        self.keyterms=list(terms)[:50]

    def set_answer_pause(self,seconds):
        self.answer_pause=max(.3,min(3.0,float(seconds)))

    async def set_channel(self, channel, epoch):
        async with self.lock:
            self.epoch=epoch
            self.channel='switching'
            await self._close_session()
            self.gate=NearSpeechGate()
            self.first_chunk=True
            if self.closing or channel=='closed':
                self.channel='closed'; return
            # Bound detection to the languages appropriate to this UI. Do not
            # return to unbounded auto detection for very short answers.
            candidates=languages(self.lang)
            params=dict(model_id='scribe_v2_realtime',audio_format='pcm_16000',
                language_code=candidates[0],secondary_languages=candidates[1:],
                commit_strategy='vad',vad_silence_threshold_secs=self.answer_pause if channel=='answer' else .6,min_speech_duration_ms=250,
                vad_threshold=0.45,min_silence_duration_ms=150,
                filter_background_audio='true')
            if channel=='answer' and self.keyterms:params['keyterms']=self.keyterms
            socket=None
            try:
                socket=await self.connector('wss://api.elevenlabs.io/v1/speech-to-text/realtime?'+urlencode(params,doseq=True),
                    additional_headers={'xi-api-key':self.api_key},open_timeout=12,max_size=2**20)
                started=json.loads(await asyncio.wait_for(socket.recv(),12))
                if started.get('message_type')!='session_started':
                    await socket.close(); raise ValueError('ASR session not ready')
                self.socket=socket
                self.channel=channel
                self.reader=asyncio.create_task(self._receive(socket,epoch,channel))
            except asyncio.CancelledError:
                if socket: await socket.close()
                raise
            except Exception:
                if socket: await socket.close()
                self.channel='closed'
                await self.notify_error('Speech recognition could not connect. Please reconnect the call. / 语音识别连接失败，请重新开启通话。')
                raise RuntimeError('ASR session could not start') from None

    async def _close_session(self):
        reader,self.reader=self.reader,None
        socket,self.socket=self.socket,None
        if reader and reader is not asyncio.current_task():
            reader.cancel();await asyncio.gather(reader,return_exceptions=True)
        if socket:
            await socket.close()

    async def _receive(self,socket,epoch,channel):
        try:
            async for raw in socket:
                message=json.loads(raw)
                if epoch!=self.epoch or self.channel!=channel: continue
                kind=message.get('message_type','')
                text=message.get('text','').strip()
                if kind in ('partial_transcript','committed_transcript') and text:
                    if kind=='partial_transcript' and self.gate.voiced_samples<1280:continue
                    if kind=='committed_transcript':
                        voiced=self.gate.voiced_samples;self.gate.voiced_samples=0
                        if voiced<1280:continue  # No 80 ms of usable input: ignore silence/noise finals.
                    cls=TurnInterim if kind=='partial_transcript' else TurnTranscript
                    await self.push_frame(cls(text=text,user_id='user',timestamp='',input_epoch=epoch,channel=channel))
                elif 'error' in kind or kind in ('auth_error','rate_limited','quota_exceeded','insufficient_credits','resource_exhausted','session_time_limit_exceeded'):
                    self.channel='closed'
                    await self.notify_error('Speech recognition reported an error. Reconnect and check provider access. / 语音识别异常，请重新连接并检查服务配置。')
                    return
        except asyncio.CancelledError:
            pass
        except Exception:
            if not self.closing and epoch==self.epoch:
                self.channel='closed'
                await self.notify_error('Speech recognition disconnected. Please reconnect the call. / 语音识别已断开，请重新开启通话。')

    async def process_frame(self,frame,direction):
        await super().process_frame(frame,direction)
        if isinstance(frame,TurnAudioFrame):
            if frame.input_epoch!=self.epoch or self.channel not in ('wake','answer') or not self.socket:
                self.audio_bytes['stale']+=len(frame.audio); return
            self.audio_bytes[self.channel]+=len(frame.audio)
            socket=self.socket
            try:
                packet={'message_type':'input_audio_chunk',
                    'audio_base_64':base64.b64encode(self.gate.filter(frame.audio)).decode(),'sample_rate':16000,'commit':False}
                if self.first_chunk:
                    context=self.context if self.channel=='answer' else ''
                    if context:packet['previous_text']=context
                await socket.send(json.dumps(packet))
                self.first_chunk=False
            except Exception:
                if socket is self.socket:
                    self.channel='closed'
                    await self.notify_error('Audio upload stopped. Please reconnect the call. / 音频上传已停止，请重新开启通话。')
            return
        if isinstance(frame,InputAudioRawFrame):
            return  # Unversioned microphone packets must not enter recognition.
        if isinstance(frame,(EndFrame,CancelFrame)):
            self.closing=True;self.epoch+=1;await self._close_session()
        await self.push_frame(frame,direction)

    async def cleanup(self):
        self.closing=True;self.epoch+=1
        await self._close_session()
        await super().cleanup()
