"""Version 2 voice protocol: isolated wake/answer ASR and acknowledged playback."""
import asyncio
import json
import re
from dataclasses import dataclass, field
from loguru import logger
from fastapi import HTTPException
from pipecat.frames.frames import (
    DataFrame, Frame, InputAudioRawFrame, OutputAudioRawFrame, InputTransportMessageFrame,
    OutputTransportMessageFrame, OutputTransportMessageUrgentFrame, InterruptionFrame,
    TTSSpeakFrame, TTSStartedFrame, TTSStoppedFrame, EndFrame, CancelFrame, ErrorFrame,
)
from pipecat.serializers.base_serializer import FrameSerializer
from pipecat.processors.frame_processor import FrameProcessor
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.worker import PipelineWorker, PipelineParams
from pipecat.workers.runner import WorkerRunner
from pipecat.transports.websocket.fastapi import FastAPIWebsocketTransport, FastAPIWebsocketParams
from pipecat.services.elevenlabs.tts import ElevenLabsTTSService
from pipecat.services.elevenlabs.dialogue.tts import ElevenLabsDialogueTTSService
from pipecat.transcriptions.language import Language
from . import speech_policy
from .domain import next_question
from .intent import intent_question
from .turn_audio import SeparatedSTT, TurnAudioFrame, TurnTranscript, TurnInterim

WAKE = re.compile(r'\bhey[，,、\s]+assistant\b|你好[，,、\s]*助手|สวัสดี[\s,，]*ผู้ช่วย', re.I)

@dataclass
class VoiceProtocol:
    output_epoch: int = 0
    input_epoch: int = 0
    speech_id: int = 0
    contexts: dict = field(default_factory=dict)
    completed: set = field(default_factory=set)
    notify_error: object = field(default=None,repr=False)

@dataclass
class InitialPrompt(DataFrame):
    text: str = ''

@dataclass
class VoiceControl(DataFrame):
    message: dict = field(default_factory=dict)

class VoiceSerializer(FrameSerializer):
    def __init__(self, protocol=None):
        super().__init__()
        self.protocol=protocol or VoiceProtocol()
        self.output_tag=None

    async def serialize(self,frame:Frame):
        if isinstance(frame,OutputAudioRawFrame):
            if not self.output_tag or self.output_tag[0]!=self.protocol.output_epoch:
                return None
            epoch,speech_id=self.output_tag
            return epoch.to_bytes(4,'little')+speech_id.to_bytes(4,'little')+frame.audio
        if isinstance(frame,InterruptionFrame):
            return json.dumps({'type':'interrupt','epoch':self.protocol.output_epoch})
        if isinstance(frame,(OutputTransportMessageFrame,OutputTransportMessageUrgentFrame)):
            message=frame.message
            if message.get('type')=='audio_begin':
                self.output_tag=(message['epoch'],message['speech_id'])
            return json.dumps(message,ensure_ascii=False)
        return None

    async def deserialize(self,data):
        if isinstance(data,bytes):
            if len(data)<6 or len(data)%2 or len(data)>65540: return None
            return TurnAudioFrame(audio=data[4:],sample_rate=16000,num_channels=1,input_epoch=int.from_bytes(data[:4],'little'))
        try: message=json.loads(data)
        except (ValueError,TypeError): return None
        if not isinstance(message,dict): return None
        kind=message.get('type')
        if kind in ('interrupt','end'):
            return VoiceControl(message=message)
        if kind=='text' and isinstance(message.get('text'),str) and 1<=len(message['text'].strip())<=3000:
            return VoiceControl(message=message)
        if kind in ('playback_started','playback_ended','playback_stopped') and all(type(message.get(key)) is int and 0<=message[key]<2**32 for key in ('epoch','speech_id')):
            return VoiceControl(message=message)
        return None

class SpeechMarkers(FrameProcessor):
    """Markers use the transport's audio queue, so end cannot overtake PCM."""
    def __init__(self,protocol):
        super().__init__();self.protocol=protocol;self.padded_tag=None
    async def process_frame(self,frame,direction):
        await super().process_frame(frame,direction)
        tag=self.protocol.contexts.get(getattr(frame,'context_id',None))
        if isinstance(frame,TTSStartedFrame) and tag:
            await self.push_frame(frame,direction)
            await self.push_frame(OutputTransportMessageFrame(message={'type':'audio_begin','epoch':tag[0],'speech_id':tag[1]}))
            if tag!=self.padded_tag:
                self.padded_tag=tag
                await self.push_frame(OutputAudioRawFrame(audio=bytes(48000),sample_rate=24000,num_channels=1))
            return
        await self.push_frame(frame,direction)
        if isinstance(frame,TTSStoppedFrame) and tag:
            self.protocol.completed.add(tag)
            await self.push_frame(OutputTransportMessageFrame(message={'type':'audio_end','epoch':tag[0],'speech_id':tag[1]}))

def make_tts(config,lang,protocol):
    if config.get('tts_provider')=='iflytek':
        from .iflytek import IflytekTTS
        return IflytekTTS(config,lang,protocol)
    language={'zh':Language.ZH,'th':Language.TH}.get(lang,Language.EN)
    model=config.get('th_tts_model','eleven_v4_turbo') if lang=='th' else config.get('zh_tts_model','eleven_v4_turbo') if lang=='zh' else config.get('en_tts_model','eleven_flash_v2_5')
    voice=config.get('th_voice_id',config['voice_id']) if lang=='th' else (config.get('zh_voice_id') or config['voice_id']) if lang=='zh' else config['voice_id']
    base=ElevenLabsDialogueTTSService if model.startswith(('eleven_v3','eleven_v4')) else ElevenLabsTTSService
    class BoundTTS(base):
        def create_context_id(self):
            context_id=super().create_context_id()
            protocol.contexts[context_id]=(protocol.output_epoch,protocol.speech_id)
            return context_id
    settings=base.Settings(model=model,voice=voice,language=language,stability=0.5)
    return BoundTTS(api_key=config['elevenlabs_key'],settings=settings)

class FormAssistant(FrameProcessor):
    def __init__(self,websocket,draft_id,sid,lang,read_draft,apply_turn,router=None,protocol=None,**kwargs):
        super().__init__(**kwargs)
        self.ws=websocket;self.draft_id=draft_id;self.sid=sid;self.lang=lang
        self.read_draft=read_draft;self.apply_turn=apply_turn
        self.router=router;self.protocol=protocol or VoiceProtocol()
        self.pending=None;self.phase='starting';self.pending_text=None;self.stop_timeout=None
        self.last_prompt=''
        self.end_after_speech=False
        self.fragment='';self.fragment_key=None;self.fragment_timer=None;self.fragment_wait_seconds=8.0

    def clear_fragment(self):
        if self.fragment_timer and self.fragment_timer is not asyncio.current_task():self.fragment_timer.cancel()
        self.fragment_timer=None;self.fragment='';self.fragment_key=None

    async def hold_fragment(self,text,key):
        self.clear_fragment();self.fragment=text;self.fragment_key=key
        async def remind():
            await asyncio.sleep(self.fragment_wait_seconds)
            if self.phase!='listening':return
            self.clear_fragment()
            prompt=({'en':'Please give your full address when you are ready.','zh':'准备好后，请完整说出地址。','th':'พร้อมแล้วกรุณาบอกที่อยู่ทั้งหมดค่ะ'} if key=='address' else
                    {'en':'Take your time. Please repeat the full number when you are ready.','zh':'不用着急，准备好后请重新完整说出号码。','th':'ไม่ต้องรีบค่ะ พร้อมแล้วกรุณาบอกหมายเลขทั้งหมดอีกครั้งค่ะ'})[self.lang]
            await self.notify({'type':'ready','question':prompt})
            await self.say(prompt)
        self.fragment_timer=asyncio.create_task(remind())

    async def notify(self,payload):
        if getattr(self,'observe',None):self.observe(self.draft_id,{**payload,'lang':self.lang})
        await self.ws.send_json(payload)

    async def switch_input(self,channel):
        self.protocol.input_epoch+=1
        if self.router: await self.router.set_channel(channel,self.protocol.input_epoch)
        await self.notify({'type':'input_state','mode':channel,'turn_id':self.protocol.input_epoch})

    async def ensure_wake(self):
        if not self.router or self.router.channel!='wake': await self.switch_input('wake')

    async def say(self,text):
        self.last_prompt=text
        self.phase='speaking'
        await self.ensure_wake()
        self.protocol.speech_id+=1
        self.protocol.completed.clear()
        await self.notify({'type':'speech','epoch':self.protocol.output_epoch,'speech_id':self.protocol.speech_id})
        await self.push_frame(TTSSpeakFrame(text=text))

    async def arm_answer(self):
        self.phase='opening'
        # Let the actual output device settle; old ASR sessions are never reused.
        await asyncio.sleep(.12)
        if self.router and hasattr(self.router,'set_context'):self.router.set_context(self.last_prompt)
        if self.router and hasattr(self.router,'set_keyterms'):
            draft=self.read_draft(self.draft_id,self.sid)
            self.router.set_keyterms(speech_policy.place_hints(draft,self.lang))
            if hasattr(self.router,'set_answer_pause'):self.router.set_answer_pause(speech_policy.answer_pause(draft))
        await self.switch_input('answer')
        self.phase='listening'
        await self.notify({'type':'listening','turn_id':self.protocol.input_epoch})

    async def interrupt(self,text=None):
        self.clear_fragment()
        self.pending_text=text
        if self.phase=='stopping': return
        if self.pending and self.pending is not asyncio.current_task() and not self.pending.done():
            self.pending.cancel()
            await asyncio.gather(self.pending,return_exceptions=True)
        self.phase='stopping'
        self.protocol.output_epoch+=1
        await self.notify({'type':'stop_required','epoch':self.protocol.output_epoch,'speech_id':self.protocol.speech_id})
        await self.broadcast_interruption()
        await self.switch_input('closed')
        async def timeout():
            await asyncio.sleep(12)
            if self.phase=='stopping':
                await self.notify({'type':'error','message':'Playback did not confirm stopping. Reconnect the call. / 播放停止未确认，请重新开启通话。'})
        if self.stop_timeout: self.stop_timeout.cancel()
        self.stop_timeout=asyncio.create_task(timeout())

    async def retry_recognition(self):
        question=self.last_prompt
        message=speech_policy.retry_prompt(self.lang)
        await self.notify({'type':'transcript','text':'','final':False,'turn_id':self.protocol.input_epoch})
        await self.notify({'type':'ready','question':message})
        await self.say(message)
        self.last_prompt=question

    async def respond(self,text):
        try:
            self.phase='thinking'
            await self.ensure_wake()
            await self.notify({'type':'thinking'})
            result=await self.apply_turn(self.draft_id,self.sid,text,self.lang,'live')
            self.end_after_speech=result['draft'].get('workflow',{}).get('state') in ('review','completed')
            await self.notify({'type':'draft','draft':result['draft'],'reply':result['reply']})
            await self.say(result['reply'])
        except asyncio.CancelledError:
            raise
        except HTTPException as exc:
            await self.notify({'type':'error','message':str(exc.detail)})
            await self.arm_answer()
        except Exception:
            self.phase='error'
            await self.notify({'type':'error','message':'The voice turn could not complete. Reconnect the call. / 本轮语音未完成，请重新开启通话。'})

    async def process_frame(self,frame,direction):
        await super().process_frame(frame,direction)
        if isinstance(frame,InitialPrompt):
            current=self.read_draft(self.draft_id,self.sid) or {}
            self.end_after_speech=current.get('workflow',{}).get('state') in ('review','completed')
            await self.notify({'type':'ready','question':frame.text,'protocol':2})
            await self.say(frame.text)
            return
        if isinstance(frame,(VoiceControl,InputTransportMessageFrame)):
            message=frame.message;kind=message.get('type')
            if kind=='interrupt': await self.interrupt()
            elif kind=='end': await self.push_frame(EndFrame())
            elif kind=='text': await self.interrupt(message['text'])
            elif kind in ('playback_ended','playback_stopped'):
                tag=(message['epoch'],message['speech_id'])
                if tag!=(self.protocol.output_epoch,self.protocol.speech_id): return
                if kind=='playback_ended' and self.phase=='speaking' and tag in self.protocol.completed:
                    if self.end_after_speech:
                        self.phase='ended'
                        await self.switch_input('closed')
                        await self.notify({'type':'call_ended','reason':'draft_ready','question':self.last_prompt})
                        await self.push_frame(EndFrame())
                    else:
                        await self.arm_answer()
                elif kind=='playback_stopped' and self.phase=='stopping':
                    if self.stop_timeout: self.stop_timeout.cancel()
                    text,self.pending_text=self.pending_text,None
                    if text:
                        self.phase='thinking';self.pending=asyncio.create_task(self.respond(text))
                    else: await self.arm_answer()
            return
        if isinstance(frame,(TurnInterim,TurnTranscript)):
            if frame.input_epoch!=self.protocol.input_epoch: return
            if self.router and frame.channel!=self.router.channel: return
            text=frame.text.strip()
            if not text: return
            if not speech_policy.transcript_allowed(text,self.lang):
                if isinstance(frame,TurnTranscript) and frame.channel=='answer' and self.phase=='listening':
                    self.phase='thinking';self.pending=asyncio.create_task(self.retry_recognition())
                return
            if WAKE.search(text):
                if self.phase not in ('stopping','opening','error'): await self.interrupt()
                return
            if frame.channel!='answer' or self.phase!='listening': return
            final=isinstance(frame,TurnTranscript)
            if self.fragment_timer:self.fragment_timer.cancel();self.fragment_timer=None
            draft=self.read_draft(self.draft_id,self.sid)
            key=speech_policy.pending_field(draft)
            digits=speech_policy.spoken_digits(text) if key in ('phone','citizen_id') else None
            if self.fragment_key==key and digits is not None and speech_policy.unfinished_number(digits,key):
                digits=self.fragment+digits
            if final and (digits is not None and speech_policy.unfinished_number(digits,key) or key=='address' and speech_policy.incomplete_address(text)):
                await self.hold_fragment(digits if digits is not None else text,key)
                await self.notify({'type':'transcript','text':digits or text,'final':False,'turn_id':frame.input_epoch})
                return
            if final:
                if digits is not None:text=digits
                self.clear_fragment()
            await self.notify({'type':'transcript','text':text,'final':final,'turn_id':frame.input_epoch})
            if final:
                # Close the acceptance window synchronously: a later final cannot cancel this turn.
                self.phase='thinking';self.pending=asyncio.create_task(self.respond(text))
            return
        if isinstance(frame,ErrorFrame):
            await self.notify({'type':'error','message':'A streaming speech provider reported an error. Check provider access.'})
        if isinstance(frame,(EndFrame,CancelFrame)):
            self.clear_fragment()
            if self.pending and not self.pending.done(): self.pending.cancel()
            if self.stop_timeout: self.stop_timeout.cancel()
        await self.push_frame(frame,direction)

    async def cleanup(self):
        self.clear_fragment()
        for task in (self.pending,self.stop_timeout):
            if task and not task.done(): task.cancel();await asyncio.gather(task,return_exceptions=True)
        await super().cleanup()

async def run_voice(websocket,draft_id,sid,config,read_draft,apply_turn,workers,observe=None):
    if websocket.query_params.get('protocol')!='2':
        await websocket.send_json({'type':'error','message':'Refresh the app to use the updated voice connection. / 请刷新应用以使用新版语音连接。'})
        await websocket.close(); return
    if draft_id in workers:
        await websocket.send_json({'type':'error','message':'This draft already has an active voice connection.'})
        await websocket.close(); return
    lang=websocket.query_params.get('lang','en')
    if lang not in ('en','zh','th'): lang='en'
    protocol=VoiceProtocol()
    transport=FastAPIWebsocketTransport(websocket,FastAPIWebsocketParams(
        audio_in_enabled=True,audio_out_enabled=True,audio_in_sample_rate=16000,
        audio_out_sample_rate=24000,add_wav_header=False,serializer=VoiceSerializer(protocol),
        session_timeout=600,allowed_origins=[websocket.headers.get('origin','')]))
    async def notify_error(message): await websocket.send_json({'type':'error','message':message})
    protocol.notify_error=notify_error
    if config.get('asr_provider')=='iflytek':
        from .iflytek import IflytekSTT
        router=IflytekSTT(config,lang,notify_error)
    else:
        router=SeparatedSTT(config['elevenlabs_key'],lang,notify_error)
    assistant=FormAssistant(websocket,draft_id,sid,lang,read_draft,apply_turn,router,protocol)
    assistant.observe=observe
    tts=make_tts(config,lang,protocol)
    pipeline=Pipeline([transport.input(),router,assistant,tts,SpeechMarkers(protocol),transport.output()])
    worker=PipelineWorker(pipeline,params=PipelineParams(audio_in_sample_rate=16000,audio_out_sample_rate=24000),enable_rtvi=False,idle_timeout_secs=180)
    workers[draft_id]=worker
    @transport.event_handler('on_client_connected')
    async def connected(transport,socket):
        draft=read_draft(draft_id,sid)
        question=draft.get('questions',{}).get(lang) or (intent_question(draft,lang) if draft.get('service')=='intent-intake' else next_question(draft['fields'],lang,draft.get('service','child-subsidy-preparation')))
        await worker.queue_frame(InitialPrompt(text=question))
    @transport.event_handler('on_client_disconnected')
    async def disconnected(transport,socket): await worker.cancel()
    @transport.event_handler('on_session_timeout')
    async def timeout(transport,socket): await worker.cancel()
    logger.disable('pipecat.services.elevenlabs')
    await WorkerRunner(handle_sigint=False).run(worker)
