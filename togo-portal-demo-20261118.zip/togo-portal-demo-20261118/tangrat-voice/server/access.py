"""Optional shared demo access gate for a publicly reachable, paid-API PoC."""
import hashlib
import hmac
import html
import os
from pathlib import Path

from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, FileResponse

COOKIE = 'tr_demo_access'
DESTINATIONS = ('/', '/observer', '/project-overview', '/research/iflytek')
LOGIN_COPY={
    'zh':dict(title='语音政务服务',prompt='请输入访问码',error='访问码不正确，请重试。',placeholder='访问码',button='进入服务',note='说出需求，助手陪您办。'),
    'en':dict(title='Voice government services',prompt='Enter your access code',error='Please check the access code and try again.',placeholder='Access code',button='Continue',note='Tell us what you need. We will help you prepare.'),
    'th':dict(title='บริการภาครัฐด้วยเสียง',prompt='กรอกรหัสเข้าใช้งาน',error='รหัสไม่ถูกต้อง กรุณาลองใหม่',placeholder='รหัสเข้าใช้งาน',button='เข้าสู่บริการ',note='บอกความต้องการ เราพร้อมช่วยคุณ'),
}


def enabled():
    return bool(os.environ.get('DEMO_ACCESS_CODE'))


def expected():
    return hmac.new(os.environ.get('DEMO_ACCESS_CODE','').encode(),
                    b'tangrat-demo-browser-v1', hashlib.sha256).hexdigest()


def allowed(connection):
    return not enabled() or hmac.compare_digest(connection.cookies.get(COOKIE,''), expected())


def landing(destination='/', error=False,lang='en'):
    destination = destination if destination in DESTINATIONS else '/'
    lang=lang if lang in LOGIN_COPY else 'en'
    words=LOGIN_COPY[lang]
    message = words['error'] if error else words['prompt']
    links=''.join('<a href="'+destination+'?ui_lang='+code+'"'+(' aria-current="true"' if code==lang else '')+'>'+name+'</a>' for code,name in [('en','English'),('th','ไทย'),('zh','中文')])
    return HTMLResponse('''<!doctype html><html lang="'''+lang+'''"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Tang Rat Voice</title>
<style>*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 20% 10%,#d5f5e3,transparent 65%),#f5faf7;color:#315741;font:16px "Segoe UI","Microsoft YaHei","Leelawadee UI",Tahoma,sans-serif;display:grid;min-height:100dvh;place-items:center;padding:24px}main{width:min(100%,440px);padding:32px 34px 36px;background:white;border:1px solid #e0eee5;border-radius:24px;box-shadow:0 16px 50px #276f4509}.head{display:flex;align-items:center;justify-content:space-between;margin-bottom:25px}.logo{width:89px;height:63px;object-fit:contain}.languages{display:flex;gap:2px;padding:4px;background:#f1f8f3;border-radius:24px}.languages a{padding:7px 9px;color:#789b85;text-decoration:none;font-size:11px;border-radius:18px}.languages a[aria-current=true]{background:white;color:#009b6b;box-shadow:0 2px 7px #2b6f3b0b}small{color:#7aab8b;letter-spacing:2px;font-size:10px}h1{font-size:27px;margin:14px 0 10px;font-weight:650;color:#166c48}p{line-height:1.8;color:#90a296;font-size:13px}.prompt{color:#62856d;margin-top:24px}input,button{width:100%;font:inherit;border-radius:24px;padding:14px 18px;margin-top:12px}input{border:1px solid #d7e8dd;background:#fbfefc;font-size:14px}button{background:#009b6b;color:white;border:0;cursor:pointer;font-size:14px}input:focus{outline:2px solid #9bdcba;outline-offset:2px}@media(max-width:440px){main{padding:25px}h1{font-size:24px}}</style>
</head><body><main><div class="head"><div class="languages">'''+links+'''</div></div><small>TANG RAT VOICE</small><h1>'''+words['title']+'''</h1><p>'''+words['note']+'''</p><p class="prompt">'''+message+'''</p>
<form method="post" action="/demo-access"><input type="hidden" name="next" value="'''+html.escape(destination,quote=True)+'''">
<input type="hidden" name="ui_lang" value="'''+lang+'''">
<input name="code" type="password" placeholder="'''+words['placeholder']+'''" autocomplete="current-password" required autofocus maxlength="128" aria-label="'''+words['placeholder']+'''">
<button type="submit">'''+words['button']+'''</button></form></main></body></html>''',
        status_code=401 if error else 200, headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})


async def guard(request):
    if not enabled():
        return None
    if request.url.path == '/demo-access' and request.method == 'POST':
        origin = request.headers.get('origin')
        if origin and origin != str(request.base_url).rstrip('/'):
            return JSONResponse({'detail':'Origin not allowed'},status_code=403)
        form = await request.form()
        code = str(form.get('code',''))[:128]
        destination = str(form.get('next','/'))
        destination = destination if destination in DESTINATIONS else '/'
        lang=str(form.get('ui_lang','en'))
        lang=lang if lang in LOGIN_COPY else 'en'
        if not hmac.compare_digest(code.encode(),os.environ['DEMO_ACCESS_CODE'].encode()):
            return landing(destination,error=True,lang=lang)
        target=destination+('?ui_lang='+lang if 'ui_lang' in form else '')
        response = RedirectResponse(target,status_code=303,headers={'Cache-Control':'no-store'})
        response.set_cookie(COOKIE,expected(),httponly=True,secure=request.url.scheme=='https',samesite='strict',max_age=86400)
        return response
    if allowed(request):
        return None
    if request.url.path.startswith('/api/') or request.method != 'GET':
        return JSONResponse({'detail':'Demo access required. Open the home page first.'},status_code=401,headers={'Cache-Control':'no-store'})
    return landing(request.url.path,lang=request.query_params.get('ui_lang','en'))
