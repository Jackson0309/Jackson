"""iFLYTEK streaming protocols. Signed URLs and upstream messages are never logged."""
import asyncio
import base64
from email.utils import formatdate
import hashlib
import hmac
import json
import time
from urllib.parse import urlencode, urlsplit

from websockets.asyncio.client import connect
from pipecat.frames.frames import InputAudioRawFrame, EndFrame, CancelFrame, ErrorFrame, TTSAudioRawFrame
from pipecat.processors.frame_processor import FrameProcessor
from pipecat.services.tts_service import TTSService
from pipecat.services.settings import TTSSettings
from .turn_audio import TurnAudioFrame, TurnTranscript, TurnInterim

IAT = 'wss://iat-api.xfyun.cn/v2/iat'
SPARK_IAT = 'wss://iat.cn-huabei-1.xf-yun.com/v1'
TTS = 'wss://tts-api.xfyun.cn/v2/tts'
SUPER_TTS = 'wss://cbm01.cn-huabei-1.xf-yun.com/v1/private/mcd9m97e6'


class ProviderError(Exception):
    """Only locally constructed messages/codes; never a provider URL or message."""


def signed_url(endpoint, config, date=None):
    date = date or formatdate(usegmt=True)
    parts = urlsplit(endpoint)
    origin = f'host: {parts.netloc}\ndate: {date}\nGET {parts.path} HTTP/1.1'
    signature = base64.b64encode(hmac.new(config['iflytek_api_secret'].encode(), origin.encode(), hashlib.sha256).digest()).decode()
    auth = f'api_key="{config["iflytek_api_key"]}", algorithm="hmac-sha256", headers="host date request-line", signature="{signature}"'
    return endpoint + '?' + urlencode({'host': parts.netloc, 'date': date, 'authorization': base64.b64encode(auth.encode()).decode()})


def asr_packet(config, lang, pcm, seq, status):
    model = config.get('iflytek_asr_model', 'iat')
    audio = base64.b64encode(pcm).decode()
    if model == 'iat':
        packet = {'data': {'status': status, 'format': 'audio/L16;rate=16000', 'encoding': 'raw', 'audio': audio}}
        if status == 0:
            business = {'language': 'zh_cn' if lang == 'zh' else 'en_us', 'domain': 'iat', 'accent': 'mandarin', 'eos': 800}
            if lang == 'zh':
                business['dwa'] = 'wpgs'
            packet.update(common={'app_id': config['iflytek_app_id']}, business=business)
        return packet
    packet = {'header': {'app_id': config['iflytek_app_id'], 'status': status},
              'payload': {'audio': {'encoding': 'raw', 'sample_rate': 16000, 'channels': 1,
                                    'bit_depth': 16, 'seq': seq, 'status': status, 'audio': audio}}}
    if status == 0:
        # V2's language is always zh_cn, including English input, per its specification.
        options = {'domain': 'spark_asr_v2' if model == 'spark_asr_v2' else 'slm',
                   'language': 'zh_cn' if model == 'spark_asr_v2' else 'mul_cn',
                   'accent': 'mandarin', 'eos': 800,
                   'result': {'encoding': 'utf8', 'compress': 'raw', 'format': 'json'}}
        if model == 'spark_asr_v2':
            options.update(dwa='wpgs', bos=60000, svad=1)
        packet['parameter'] = {'iat': options}
    return packet


class TranscriptAccumulator:
    def __init__(self):
        self.parts = {}

    def accept(self, message):
        code = message.get('header', {}).get('code', message.get('code', 0))
        if code:
            raise ProviderError('讯飞 ASR 错误码 ' + str(int(code)))
        data = message.get('data', {})
        wrapper = message.get('payload', {}).get('result', {})
        result = data.get('result', {})
        if wrapper.get('text'):
            result = json.loads(base64.b64decode(wrapper['text']).decode('utf-8'))
        if result.get('ret', 0):
            raise ProviderError('讯飞 ASR 识别错误码 ' + str(int(result['ret'])))
        if result:
            # V2 may place replacement metadata in the outer result envelope.
            replace = result.get('pgs', wrapper.get('pgs')) == 'rpl'
            span = result.get('rg', wrapper.get('rg', []))
            if replace and len(span) == 2:
                for number in list(self.parts):
                    if span[0] <= number <= span[1]:
                        self.parts.pop(number)
            number = result.get('sn', wrapper.get('seq', len(self.parts)))
            self.parts[number] = ''.join(slot.get('cw', [{}])[0].get('w', '') for slot in result.get('ws', []))
        final = data.get('status') == 2 or message.get('header', {}).get('status') == 2 or result.get('ls') is True
        return ''.join(self.parts[number] for number in sorted(self.parts)).strip(), final


class IflytekSTT(FrameProcessor):
    """One independent WS per wake/answer epoch; renew completed short sessions."""
    def __init__(self, config, lang, notify_error, connector=connect):
        super().__init__()
        self.config = dict(config)
        self.lang = lang
        self.notify_error = notify_error
        self.connector = connector
        self.epoch = -1
        self.channel = 'closed'
        self.socket = None
        self.reader = None
        self.sender = None
        self.lock = asyncio.Lock()
        self.closing = False
        self.queue = asyncio.Queue(maxsize=80)
        self.audio_bytes = {'wake': 0, 'answer': 0, 'stale': 0}

    async def _close_session(self):
        tasks = [task for task in (self.reader, self.sender) if task and task is not asyncio.current_task()]
        self.reader = self.sender = None
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        socket, self.socket = self.socket, None
        if socket:
            await socket.close()

    async def _open(self, epoch, channel):
        endpoint = IAT if self.config.get('iflytek_asr_model', 'iat') == 'iat' else SPARK_IAT
        self.socket = await self.connector(signed_url(endpoint, self.config), open_timeout=12, max_size=2**20)
        self.sender = asyncio.create_task(self._send(self.socket))
        self.reader = asyncio.create_task(self._receive(self.socket, epoch, channel))

    async def set_channel(self, channel, epoch):
        async with self.lock:
            self.epoch = epoch
            self.channel = 'switching'
            await self._close_session()
            self.queue = asyncio.Queue(maxsize=80)  # Never carry queued PCM across roles.
            if self.closing or channel == 'closed':
                self.channel = 'closed'
                return
            try:
                await self._open(epoch, channel)
                self.channel = channel
            except asyncio.CancelledError:
                await self._close_session()
                raise
            except Exception:
                await self._close_session()
                self.channel = 'closed'
                await self.notify_error('讯飞 ASR 连接失败，请检查授权与网络后重新通话。')
                raise ProviderError('ASR connection failed') from None

    async def _send(self, socket):
        seq = 0
        pending = bytearray()
        start = time.monotonic()
        deadline = start
        try:
            while socket is self.socket:
                # Real-time pacing, including silence to sustain a wake connection.
                await asyncio.sleep(max(0, deadline-time.monotonic()))
                while not self.queue.empty():
                    pending.extend(self.queue.get_nowait())
                pcm = bytes(pending[:1280])
                del pending[:1280]
                pcm += bytes(1280-len(pcm))
                status = 0 if seq == 0 else 1
                if time.monotonic()-start >= 55:
                    status = 2  # Leave margin below the provider's 60-second cap.
                await socket.send(json.dumps(asr_packet(self.config, self.lang, pcm, seq, status)))
                if status == 2:
                    return
                seq += 1
                deadline = max(deadline+0.04, time.monotonic())
        except asyncio.CancelledError:
            raise
        except Exception:
            if socket is self.socket and not self.closing:
                self.channel = 'closed'
                await self.notify_error('讯飞 ASR 音频上传中断，请重新通话。')

    async def _receive(self, socket, epoch, channel):
        accumulator = TranscriptAccumulator()
        completed = False
        try:
            async with asyncio.timeout(60):
                async for raw in socket:
                    if socket is not self.socket or epoch != self.epoch or channel != self.channel:
                        return
                    text, final = accumulator.accept(json.loads(raw))
                    if text:
                        cls = TurnTranscript if final else TurnInterim
                        await self.push_frame(cls(text=text, user_id='user', timestamp='', input_epoch=epoch, channel=channel))
                    if final:
                        completed = True
                        break
            if not completed:
                raise ProviderError('ASR disconnected')
            # Provider ends on silence; start a fresh short session within the same role.
            async with self.lock:
                if socket is not self.socket or epoch != self.epoch or self.channel != channel or self.closing:
                    return
                if self.sender:
                    self.sender.cancel()
                    await asyncio.gather(self.sender, return_exceptions=True)
                await socket.close()
                await self._open(epoch, channel)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if socket is self.socket and epoch == self.epoch and not self.closing:
                self.channel = 'closed'
                detail = str(error) if isinstance(error, ProviderError) else '讯飞 ASR 连接已断开'
                await self.notify_error(detail + '，请检查服务权限后重新通话。')

    async def process_frame(self, frame, direction):
        await super().process_frame(frame, direction)
        if isinstance(frame, TurnAudioFrame):
            if frame.input_epoch != self.epoch or self.channel not in ('wake', 'answer') or not self.socket:
                self.audio_bytes['stale'] += len(frame.audio)
                return
            self.audio_bytes[self.channel] += len(frame.audio)
            try:
                self.queue.put_nowait(frame.audio)
            except asyncio.QueueFull:
                self.channel = 'closed'
                await self.notify_error('语音上传积压，请重新连接通话。')
            return
        if isinstance(frame, InputAudioRawFrame):
            return
        if isinstance(frame, (EndFrame, CancelFrame)):
            self.closing = True
            self.epoch += 1
            await self._close_session()
        await self.push_frame(frame, direction)

    async def cleanup(self):
        self.closing = True
        self.epoch += 1
        await self._close_session()
        await super().cleanup()


def tts_request(config, text, lang):
    standard = config.get('iflytek_tts_model') == 'tts'
    voice_key = ('iflytek_standard_voice_' if standard else 'iflytek_voice_') + (lang if lang in ('zh','en','th') else 'en')
    voice = config[voice_key]
    if lang=='th' and voice=='configure-authorized-thai-voice':
        raise ProviderError('请在配置页填写讯飞控制台已授权的泰语发音人 vcn；当前不会用中英音色代替泰语。')
    encoded = base64.b64encode(text.encode('utf-8')).decode()
    if standard:
        return TTS, 16000, {'common': {'app_id': config['iflytek_app_id']},
            'business': {'aue': 'raw', 'auf': 'audio/L16;rate=16000', 'vcn': voice, 'tte': 'UTF8', 'speed': 50},
            'data': {'status': 2, 'text': encoded}}
    return SUPER_TTS, 24000, {'header': {'app_id': config['iflytek_app_id'], 'status': 2},
        'parameter': {'oral': {'oral_level': 'low', 'spark_assist': 0, 'remain': 1},
                      'tts': {'vcn': voice, 'speed': 50, 'volume': 50, 'pitch': 50,
                              'audio': {'encoding': 'raw', 'sample_rate': 24000, 'channels': 1, 'bit_depth': 16, 'frame_size': 0}}},
        'payload': {'text': {'encoding': 'utf8', 'compress': 'raw', 'format': 'plain', 'status': 2, 'seq': 0, 'text': encoded}}}


async def synthesize(config, text, lang, connector=connect):
    endpoint, rate, packet = tts_request(config, text, lang)
    socket = None
    try:
        async with asyncio.timeout(50):
            socket = await connector(signed_url(endpoint, config), open_timeout=12, max_size=2**24)
            await socket.send(json.dumps(packet))
            pending = b''
            async for raw in socket:
                message = json.loads(raw)
                header = message.get('header', {})
                code = header.get('code', message.get('code', 0))
                if code:
                    raise ProviderError('讯飞 TTS 错误码 ' + str(int(code)))
                data = message.get('payload', {}).get('audio', message.get('data', {}))
                pending += base64.b64decode(data.get('audio', ''))
                size = len(pending) // 2 * 2
                if size:
                    yield rate, pending[:size]
                    pending = pending[size:]
                if data.get('status') == 2 or header.get('status') == 2:
                    if pending:
                        raise ProviderError('讯飞 TTS 音频格式错误')
                    return
            raise ProviderError('讯飞 TTS 在完成前断开')
    except asyncio.CancelledError:
        raise
    except ProviderError:
        raise
    except Exception:
        raise ProviderError('讯飞 TTS 连接失败，请检查网络、凭据和音色授权') from None
    finally:
        if socket:
            await socket.close()


class IflytekTTS(TTSService):
    def __init__(self, config, lang, protocol):
        super().__init__(sample_rate=24000, push_start_frame=True, push_stop_frames=True,
                         settings=TTSSettings(model=config['iflytek_tts_model'], voice=config['iflytek_voice_zh' if lang == 'zh' else 'iflytek_voice_en'], language=None))
        self.config = dict(config)
        self.lang = lang
        self.protocol = protocol

    def create_context_id(self):
        context = super().create_context_id()
        self.protocol.contexts[context] = (self.protocol.output_epoch, self.protocol.speech_id)
        return context

    async def run_tts(self, text, context_id):
        produced=False
        try:
            async for rate, pcm in synthesize(self.config, text, self.lang):
                produced=True
                yield TTSAudioRawFrame(audio=pcm, sample_rate=rate, num_channels=1, context_id=context_id)
            if not produced:
                raise ProviderError('讯飞未返回音频，请检查音色授权')
        except ProviderError as error:
            if self.protocol.notify_error:
                await self.protocol.notify_error(str(error))
            yield ErrorFrame(error=str(error))
