"""Deterministic application state. AI cannot approve, authenticate, or submit."""
import datetime as dt
import re
from . import togo
from .catalog import EXTRA_SERVICES, EXTRA_LABELS
from . import business_clock, geography, speech_policy
from .thai import FIELD_LABELS as TH_FIELDS, OPTIONS as TH_OPTIONS, QUESTIONS as TH_QUESTIONS, SERVICE_TITLES as TH_SERVICES, INTAKE as TH_INTAKE, READY as TH_READY, THAI_DIGITS

FIELDS = [
    ('guardian_name', 'Guardian full name', '监护人姓名', 'text'),
    ('relationship', 'Relationship to child', '与儿童的关系', 'select'),
    ('child_name', 'Child full name', '儿童姓名', 'text'),
    ('child_birth_date', 'Child date of birth', '儿童出生日期', 'date'),
    ('province', 'Province', '府／省', 'text'),
    ('district', 'District', '区／县', 'text'),
    ('phone', 'Contact number', '联系电话', 'tel'),
    ('household_members', 'Household members', '家庭人数', 'number'),
    ('annual_household_income', 'Annual household income (THB)', '家庭年收入（泰铢）', 'number'),
]
KEYS = {f[0] for f in FIELDS}
SAMPLE = dict(guardian_name='Maya Srisuk', relationship='mother', child_name='Arun Srisuk',
              child_birth_date='2025-09-12', province='Bangkok', district='Bang Khen',
              phone='0812345678', household_members='3', annual_household_income='180000')
QUESTIONS = {
    'en': {
        'guardian_name': 'What is the guardian’s full name?',
        'relationship': 'Are you the child’s mother, father, or legal guardian?',
        'child_name': 'What is the child’s full name?',
        'child_birth_date': 'What is the child’s date of birth? Please include the year.',
        'province': 'Which province do you live in?',
        'district': 'Which district do you live in?',
        'phone': 'What contact phone number should we use?',
        'household_members': 'How many people are in your household?',
        'annual_household_income': 'What is your household’s total annual income in Thai baht?',
    },
    'zh': {
        'guardian_name': '请问监护人的姓名是什么？', 'relationship': '您是孩子的母亲、父亲，还是法定监护人？',
        'child_name': '孩子的姓名是什么？', 'child_birth_date': '孩子的出生日期是什么？请包含年份。',
        'province': '您居住在哪个府或省？', 'district': '您居住在哪个区县？',
        'phone': '请提供联系电话。', 'household_members': '家庭共有几位成员？',
        'annual_household_income': '家庭全年总收入是多少泰铢？',
    }
}

CHILD = 'child-subsidy-preparation'
FLOOD = 'flood-relief-preparation'
INTAKE = 'intent-intake'
FLOOD_FIELDS = [
    ('citizen_id', 'Citizen ID number', '国民身份证号码', 'text'),
    ('applicant_name', 'Applicant full name', '申请人姓名', 'text'),
    ('phone', 'Contact number', '联系电话', 'tel'),
    ('address', 'Affected usual-residence address', '受灾常住地址', 'text'),
    ('province', 'Affected province', '受灾府／省', 'text'),
    ('district', 'Affected district', '受灾区／县', 'text'),
    ('subdistrict', 'Subdistrict', '分区／乡镇', 'text'),
    ('residence_type', 'Residence type', '住房类型', 'select'),
    ('flood_start_date', 'Flood start date', '受灾开始日期', 'date'),
    ('flood_duration_days', 'Flood duration (days)', '受灾时长（天）', 'number'),
    ('damage_description', 'Flood damage and impact', '受灾损失及生活影响', 'textarea'),
]
FLOOD_SAMPLE = dict(citizen_id='0123456789012',applicant_name='Somchai Jaidee', phone='0812345678', province='Bangkok',
    district='Bang Khen', subdistrict='Anusawari', address='88/12 Anusawari, Bang Khen, Bangkok', residence_type='rented',
    flood_start_date='2026-09-26', flood_duration_days='5',
    damage_description='Floodwater damaged furniture and prevented normal daily living.')
FLOOD_QUESTIONS = {
    'en': dict(citizen_id='Please say your thirteen-digit Thai citizen ID number, one digit at a time.', flood_duration_days='How many days did the flooding affect your home?', applicant_name='What is the applicant’s full name?', phone='What contact phone number should we use?',
        province='Which province was your usual residence affected in?', district='Which district was affected?',
        subdistrict='What is the subdistrict?', address='Please give the full affected address, including house number, subdistrict, district and province.',
        residence_type='Is this your own home, a rented home, or another usual residence?',
        flood_start_date='On what date did the flooding start? Please include the year.',
        flood_end_date='On what date did the flooding end? If it is ongoing, say so; do not guess an end date.',
        damage_description='Please describe the flood damage and how it affected your daily living.'),
    'zh': dict(citizen_id='请逐位说出您的13位泰国国民身份证号码。', flood_duration_days='洪灾持续影响您的住所多少天？', applicant_name='请问申请人的姓名是什么？', phone='请提供联系电话。', province='您的常住房屋在哪个府或省受灾？',
        district='受灾地点在哪个区县？', subdistrict='属于哪个分区或乡镇？', address='请一次说出受灾常住地址，包括门牌号、分区、区县和府省。',
        residence_type='这是自有住房、租住房屋，还是其他常住住所？', flood_start_date='洪灾从哪一天开始？请包含年份。',
        flood_end_date='洪灾在哪一天结束？如果仍在受灾，请说明仍在持续，不要估计日期。',
        damage_description='请描述房屋财产损失，以及洪灾对日常生活的影响。')
}
SERVICES = {
    CHILD: {'en':'Child subsidy', 'zh':'儿童补贴', 'prefix':'CSG', 'fields':FIELDS,
        'source':'https://www.thangrath.go.th/feature/feature-category/popular-service/'},
    FLOOD: {'en':'Flood relief registration', 'zh':'洪灾救助登记', 'prefix':'FLD', 'fields':FLOOD_FIELDS,
        'source':'https://www.dga.or.th/document-sharing/dga-news/140690/'}
}
for _key,_value in SERVICES.items():
    _value['th']=TH_SERVICES[_key]
    _value['mode']='application'
    _value['field_basis']='proposed_demo_schema'
SERVICES.update(EXTRA_SERVICES)
QUESTIONS['th']=TH_QUESTIONS
FLOOD_QUESTIONS['th']={**TH_QUESTIONS,
    'citizen_id':'กรุณาบอกเลขบัตรประชาชนสิบสามหลักทีละหลักค่ะ',
    'flood_duration_days':'น้ำท่วมส่งผลกระทบต่อที่พักทั้งหมดกี่วันคะ',
    'address':'กรุณาบอกที่อยู่ที่ประสบภัยทั้งหมด รวมบ้านเลขที่ ตำบล อำเภอ และจังหวัดค่ะ',
    'province':'ที่พักอาศัยประจำที่ประสบภัยอยู่จังหวัดใดคะ','district':'อำเภอหรือเขตที่ประสบภัยคือที่ใดคะ'}

def service_fields(service=CHILD):
    return SERVICES.get(service, {}).get('fields', [])

def field_schema(service=CHILD, current=None):
    if togo.ACTIVE:return togo.schema(service,current)
    return [dict(key=f[0], en=f[1], zh=f[2], th=TH_FIELDS.get(f[0],EXTRA_LABELS.get(f[0],f[1])), type=f[3], required=f[0]!='flood_end_date' and f[0] not in SERVICES.get(service,{}).get('optional',[]), **({'options':
        [{'value':v,'en':en,'zh':zh,'th':TH_OPTIONS[v]} for v,en,zh in (
            [('mother','Mother','母亲'),('father','Father','父亲'),('guardian','Guardian','监护人')]
            if f[0]=='relationship' else [('owned','Owned home','自有住房'),('rented','Rented home','租住房屋'),('other','Other usual residence','其他常住住所')]
        )]} if f[3]=='select' else {})) for f in service_fields(service)]

def validate_patch(patch: dict, service=CHILD, current=None, reference_date=None) -> tuple[dict, dict]:
    if togo.ACTIVE:return togo.validate(patch,service,current,reference_date)
    accepted, errors = {}, {}
    keys = {f[0] for f in service_fields(service)}
    for key, raw in patch.items():
        if key not in keys:
            continue
        if raw is None or isinstance(raw, (dict, list, bool)):
            continue
        value = str(raw).strip()[:600 if key=='damage_description' else 200]
        if key in ('phone','flood_duration_days','household_members','annual_household_income','child_birth_date','flood_start_date','flood_end_date'):
            value=value.translate(THAI_DIGITS)
        if not value:
            accepted[key] = ''
            continue
        error = ''
        if key == 'relationship':
            value = {'母亲':'mother', '妈妈':'mother', '父亲':'father', '爸爸':'father', '监护人':'guardian',
                     'แม่':'mother','มารดา':'mother','พ่อ':'father','บิดา':'father','ผู้ปกครอง':'guardian','ผู้ปกครองตามกฎหมาย':'guardian'}.get(value, value.lower())
            if value not in ('mother', 'father', 'guardian'):
                error = 'Choose mother, father, or guardian / 请选择母亲、父亲或监护人'
        elif key == 'residence_type':
            value = {'自有住房':'owned','自有':'owned','租房':'rented','租住房屋':'rented','其他':'other','其他常住住所':'other',
                     'บ้านของตนเอง':'owned','บ้านตนเอง':'owned','บ้านเช่า':'rented','เช่า':'rented','อื่นๆ':'other','ที่พักอาศัยประจำประเภทอื่น':'other'}.get(value,value.lower())
            if value not in ('owned','rented','other'):
                error = 'Choose a residence type / 请选择住房类型'
        elif key in ('child_birth_date','flood_start_date','flood_end_date'):
            try:
                value = business_clock.relative_date(value,reference_date) or value
                if re.fullmatch(r'2[4-7]\d{2}-\d{2}-\d{2}',value):
                    value=str(int(value[:4])-543)+value[4:]
                born = dt.date.fromisoformat(value)
                if born > (reference_date or business_clock.today()):
                    error = 'Date cannot be in the future / 日期不能晚于今天'
            except ValueError:
                error = 'Use YYYY-MM-DD / 请使用 YYYY-MM-DD'
        elif key == 'citizen_id':
            value=re.sub(r'[\s-]','',value.translate(THAI_DIGITS))
            if not re.fullmatch(r'\d{13}',value):error='Enter 13 digits'
        elif key == 'flood_duration_days':
            if not value.isdigit() or not 1 <= int(value) <= 366:error='Enter a duration from 1 to 366 days'
            else:value=str(int(value))
        elif key == 'phone':
            value = re.sub(r'[\s()-]', '', value)
            if not re.fullmatch(r'\+?\d{8,15}', value):
                error = 'Enter 8–15 digits / 请输入 8–15 位数字'
            elif re.match(r'0[689]',value) and len(value)!=10:
                error='Thai mobile numbers need 10 digits / 泰国手机号码需要10位数字'
            elif re.match(r'\+?66[689]',value) and len(value.lstrip('+'))!=11:
                error='Use +66 followed by 9 digits / +66后应为9位数字'
        elif key=='address' and speech_policy.incomplete_address(value):
            error='incomplete_address'
        elif key in ('household_members', 'annual_household_income'):
            try:
                number = float(value.replace(',', ''))
                if key == 'household_members':
                    if not number.is_integer() or not 1 <= number <= 100:
                        raise ValueError()
                    value = str(int(number))
                else:
                    if not 0 <= number <= 1_000_000_000:
                        raise ValueError()
                    value = str(int(number)) if number.is_integer() else str(number)
            except ValueError:
                error = 'Enter a valid number / 请输入有效数字'
        elif len(value) < 2:
            error = 'Please provide the full value / 请填写完整内容'
        if error:
            errors[key] = error
        else:
            accepted[key] = value
    accepted,geo_errors=geography.check(accepted,current or {})
    errors.update(geo_errors)
    combined = {**(current or {}), **accepted}
    if service == FLOOD and combined.get('flood_start_date') and combined.get('flood_end_date'):
        if combined['flood_end_date'] < combined['flood_start_date']:
            for key in ('flood_start_date','flood_end_date'):
                if key in accepted:
                    accepted.pop(key)
                    errors[key] = 'End date must not precede start date / 结束日期不能早于开始日期'
    return accepted, errors

def missing(fields: dict, service=CHILD) -> list[str]:
    return [f['key'] for f in field_schema(service,fields) if f['required'] and not fields.get(f['key'])]

def next_question(fields: dict, lang='en', service=CHILD) -> str:
    if togo.ACTIVE:return togo.question(fields,lang,service)
    if service == INTAKE:
        if lang=='th':return TH_INTAKE
        return ('您好，请问您想办理儿童补贴，还是洪灾救助登记？' if lang=='zh' else
            'Hello. Would you like help with child subsidy or flood relief registration?')
    todo = missing(fields,service)
    if service==FLOOD and not todo:
        from .flood_checks import completed
        return completed(lang)
    if todo:
        if service in EXTRA_SERVICES:
            key=todo[0]
            if key=='query_subject':
                return {'zh':'要为您本人还是其他人整理查询条件？请提供姓名或昵称，不需要证件号码。','en':'Are the query conditions for you or someone else? Please give a name or nickname; no identity number is needed.','th':'ต้องการเตรียมเงื่อนไขสำหรับตนเองหรือผู้อื่นคะ บอกชื่อหรือชื่อเล่นได้ ไม่ต้องบอกเลขบัตรประชาชนค่ะ'}.get(lang,'Whom are the query conditions for?')
            return {'zh':'请提供用水客户编号。','en':'Please provide the water customer reference.','th':'กรุณาระบุเลขผู้ใช้น้ำค่ะ'}.get(lang,'Please provide the customer reference.')
        questions = FLOOD_QUESTIONS if service==FLOOD else QUESTIONS
        return questions.get(lang, questions['en'])[todo[0]]
    if lang=='th':return TH_READY
    return ('资料已准备好。请打开申请草稿，核对并补充材料，登录后确认提交。' if lang == 'zh'
            else 'Your draft is ready. Open it to check the details, add documents, and sign in before confirming submission.')

def demo_extract(text: str, fields: dict, service=CHILD) -> dict:
    """Explicitly labelled offline rehearsal; never presented as model output."""
    result = {}
    for key in (f[0] for f in service_fields(service)):
        match = re.search(r'\b' + key + r'\s*[:=]\s*([^;\n]+)', text, re.I)
        if match:
            result[key] = match[1].strip()
    if result:
        return result
    todo = missing(fields,service)
    if todo:
        result[todo[0]] = text.strip()
    return result

if togo.ACTIVE:
    SERVICES.clear()
    SERVICES.update(togo.SERVICES)
