/**
 * Integration boundary. This adapter never sends a government request or payment.
 * A future official adapter must implement the same submit(application) contract
 * and obtain its own authorised field mapping, authentication and upload APIs.
 */
export const localDemoAdapter={
 mode:'local-demo',
 async submit(application){
  return {reference:application.id,acceptedBy:'local-demo-server',externalSubmission:false,paymentCollected:false};
 }
};
