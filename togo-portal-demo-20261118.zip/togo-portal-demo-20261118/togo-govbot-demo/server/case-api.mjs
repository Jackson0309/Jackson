import {mkdir,readFile,writeFile,rename,readdir,unlink} from 'node:fs/promises';
import path from 'node:path';
import {randomBytes,createHash,randomUUID} from 'node:crypto';
import {workAbroadCandidates,validJourneyAnswers} from './journey-rules.mjs';
import {localDemoAdapter} from './submission-adapter.mjs';
import {CASE_SCHEMAS,activeFields,activeSlots,fieldError,validateCase,feeEstimate} from './case-schema.mjs';
const digest=s=>createHash('sha256').update(s).digest('hex');
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const locks=new Map();
async function serial(key,fn){const prior=locks.get(key)||Promise.resolve();const next=prior.catch(()=>{}).then(fn);locks.set(key,next);try{return await next;}finally{if(locks.get(key)===next)locks.delete(key);}}
const bad=(status,code,extra={})=>Object.assign(new Error(code),{status,code,...extra});
const now=()=>new Date().toISOString();
const localDate=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()).replaceAll('-','');
export function createCaseApi({dataDir,adapter=localDemoAdapter}){
 const records=path.join(dataDir,'cases'),uploads=path.join(dataDir,'uploads'),journeys=path.join(dataDir,'journeys'),reminders=path.join(dataDir,'reminders');
 const ready=Promise.all([mkdir(records,{recursive:true,mode:0o700}),mkdir(uploads,{recursive:true,mode:0o700}),mkdir(journeys,{recursive:true,mode:0o700}),mkdir(reminders,{recursive:true,mode:0o700})]);
 async function save(record){
  const filename=path.join(records,record.id+'.json'),tmp=filename+'.'+randomUUID()+'.tmp';
  try{await writeFile(tmp,JSON.stringify(record,null,2),{mode:0o600});await rename(tmp,filename);}catch(e){await unlink(tmp).catch(()=>{});throw e;}
 }
 async function load(id,owner){
  if(!/^DEMO-\d{8}-[A-F0-9]{12}$/.test(id))throw bad(404,'case_not_found');
  let record;try{record=JSON.parse(await readFile(path.join(records,id+'.json'),'utf8'));}catch{throw bad(404,'case_not_found');}
  if(record.owner!==owner)throw bad(404,'case_not_found');return record;
 }
 function publicRecord(record){const {owner,clientKey,...visible}=record;return {...visible,attachments:visible.attachments.map(({storageName,...a})=>({...a,downloadUrl:`/api/demo/cases/${record.id}/attachments/${a.id}`})),validation:validateCase(record),feeEstimate:feeEstimate(record.service,record.fields),receiptUrl:record.status==='submitted'?`/api/demo/cases/${record.id}/receipt`:null};}
 function headers(res){res.setHeader('cache-control','no-store');res.setHeader('x-content-type-options','nosniff');}
 function json(res,status,data){headers(res);res.writeHead(status,{'content-type':'application/json; charset=utf-8'});res.end(JSON.stringify(data));}
 async function readBody(req,limit){
  const chunks=[];let size=0,tooLarge=false;
  for await(const chunk of req){size+=chunk.length;if(size>limit){tooLarge=true;chunks.length=0;}else if(!tooLarge)chunks.push(chunk);}
  if(tooLarge)throw bad(413,'body_too_large');
  return Buffer.concat(chunks);
 }
 async function bodyJson(req){const bytes=await readBody(req,64*1024);try{const v=JSON.parse(bytes.toString());if(!v||typeof v!=='object'||Array.isArray(v))throw 0;return v;}catch{throw bad(400,'invalid_json');}}
 function editable(record,body){if(record.status!=='draft')throw bad(409,'case_already_submitted');if(body.version!==record.version)throw bad(409,'version_conflict',{currentVersion:record.version});}
 function touch(record,type,details={}){record.version++;record.updatedAt=now();record.events.push({type,at:record.updatedAt,...details});}
 function identify(req,res){
  const cookie=String(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('govbot_demo='))?.slice('govbot_demo='.length);
  const session=/^[a-f0-9]{64}$/.test(cookie||'')?cookie:randomBytes(32).toString('hex');
  if(session!==cookie)res.setHeader('set-cookie',`govbot_demo=${session}; HttpOnly; SameSite=Strict; Path=/api/demo; Max-Age=15552000`);
  return digest(session);
 }
 async function ownerCases(owner){
  const result=[];for(const name of (await readdir(records)).filter(n=>/^DEMO-\d{8}-[A-F0-9]{12}\.json$/.test(n))){try{const r=JSON.parse(await readFile(path.join(records,name),'utf8'));if(r.owner===owner)result.push(r);}catch{}}
  return result.sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));
 }
 async function savePlan(plan){const file=path.join(journeys,plan.id+'.json'),tmp=file+'.'+randomUUID()+'.tmp';try{await writeFile(tmp,JSON.stringify(plan,null,2),{mode:0o600});await rename(tmp,file);}catch(e){await unlink(tmp).catch(()=>{});throw e;}}
 async function loadPlan(id,owner){if(!/^PLAN-\d{8}-[A-F0-9]{12}$/.test(id))throw bad(404,'journey_not_found');let plan;try{plan=JSON.parse(await readFile(path.join(journeys,id+'.json'),'utf8'));}catch{throw bad(404,'journey_not_found');}if(plan.owner!==owner)throw bad(404,'journey_not_found');return plan;}
 async function publicPlan(plan){const {owner,clientKey,...out}=plan;const tasks=[];for(const task of plan.tasks){let linked=null;if(task.caseId){try{const c=await load(task.caseId,owner);linked={id:c.id,status:c.status,version:c.version};}catch{}}tasks.push({...task,case:linked});}return {...out,tasks};}
 async function ownerPlans(owner){const result=[];for(const name of (await readdir(journeys)).filter(n=>/^PLAN-\d{8}-[A-F0-9]{12}\.json$/.test(n))){try{const p=await loadPlan(name.slice(0,-5),owner);result.push(await publicPlan(p));}catch{}}return result.sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));}
 async function reminderList(owner){
  const items=[];const cases=await ownerCases(owner);
  for(const c of cases.filter(c=>c.status==='draft')){const errors=validateCase(c);items.push({id:'draft:'+c.id,kind:errors.some(e=>e.slot)?'missing_attachments':'unfinished_draft',caseId:c.id,service:c.service,updatedAt:c.updatedAt,revision:String(c.version),missingFields:errors.filter(e=>e.field).length,missingAttachments:errors.filter(e=>e.slot).length,provenance:'local-record'});}
  for(const p of await ownerPlans(owner)){const next=p.tasks.find(t=>t.case?.status!=='submitted');if(next&&!next.case)items.push({id:'next:'+p.id+':'+next.service,kind:'next_task',journeyId:p.id,service:next.service,caseId:next.case?.id||null,updatedAt:p.updatedAt,revision:String(p.version),provenance:'local-task-plan'});}
  let dismissed={};try{dismissed=JSON.parse(await readFile(path.join(reminders,owner+'.json'),'utf8'));}catch{}
  return items.filter(item=>!dismissed[item.id]||(typeof dismissed[item.id]==='string'?item.updatedAt>dismissed[item.id]:item.revision!==dismissed[item.id].revision));
 }
 async function handler(req,res){
  if(!(req.url==='/api/demo'||req.url.startsWith('/api/demo/')))return false;
  headers(res);
  try{
   await ready;
   if(req.headers.origin&&req.headers.origin!==`http://${req.headers.host}`&&req.headers.origin!==`https://${req.headers.host}`)throw bad(403,'origin_not_allowed');
   if(req.headers['sec-fetch-site']==='cross-site')throw bad(403,'origin_not_allowed');
   const owner=identify(req,res),url=new URL(req.url,'http://localhost'),parts=url.pathname.split('/').filter(Boolean).slice(2);
   if(req.method==='GET'&&parts[0]==='schema'){
    json(res,200,{version:1,mode:'local-demo',services:CASE_SCHEMAS,limits:{maxFileBytes:10*1024*1024,maxCaseBytes:30*1024*1024,maxAttachments:20},officialSubmission:false});return true;
   }
   if(parts[0]==='journeys'){
    if(req.method==='POST'&&parts.length===2&&parts[1]==='preview'){const body=await bodyJson(req);if(!validJourneyAnswers(body.answers))throw bad(400,'invalid_journey');json(res,200,{candidates:workAbroadCandidates(body.answers),mode:'local-advisory',createsCases:false});return true;}
    if(req.method==='GET'&&parts.length===1){json(res,200,{journeys:await ownerPlans(owner),mode:'local-advisory'});return true;}
    if(req.method==='POST'&&parts.length===1){
     const body=await bodyJson(req);if(body.confirmed!==true||!validJourneyAnswers(body.answers)||!Array.isArray(body.services)||!body.services.length||!/^[-a-f0-9]{20,64}$/i.test(body.clientRequestId||''))throw bad(400,'invalid_journey');
     const candidates=workAbroadCandidates(body.answers),keys=[...new Set(body.services)];if(keys.some(key=>!candidates.some(t=>t.service===key)))throw bad(400,'task_not_in_candidates');
     const id='PLAN-'+localDate()+'-'+digest(owner+':'+body.clientRequestId).slice(0,12).toUpperCase();
     await serial(id,async()=>{let existing;try{existing=await loadPlan(id,owner);}catch{}if(existing)return json(res,200,await publicPlan(existing));const stamp=now(),plan={id,owner,event:'work-abroad',mode:'local-advisory',version:1,answers:{destination:body.answers.destination.trim(),passportStatus:body.answers.passportStatus,employerRequirement:body.answers.employerRequirement,nationalityStatus:body.answers.nationalityStatus},tasks:keys.map(service=>({service,caseId:null})),createdAt:stamp,updatedAt:stamp,confirmedAt:stamp};await savePlan(plan);json(res,201,await publicPlan(plan));});return true;
    }
    if(req.method==='POST'&&parts.length===3&&parts[2]==='link'){
     const body=await bodyJson(req);await serial(parts[1],async()=>{const plan=await loadPlan(parts[1],owner),record=await load(body.caseId,owner),task=plan.tasks.find(t=>t.service===body.service);if(!task||record.service!==body.service)throw bad(400,'case_service_mismatch');if(task.caseId===record.id)return json(res,200,await publicPlan(plan));if(body.version!==plan.version)throw bad(409,'version_conflict');task.caseId=record.id;plan.version++;plan.updatedAt=now();await savePlan(plan);json(res,200,await publicPlan(plan));});return true;
    }
    throw bad(404,'route_not_found');
   }
   if(parts[0]==='reminders'){
    if(req.method==='GET'&&parts.length===1){json(res,200,{reminders:await reminderList(owner),autoSubmit:false});return true;}
    if(req.method==='POST'&&parts.length===2&&parts[1]==='dismiss'){
     const body=await bodyJson(req);if(typeof body.id!=='string'||body.id.length>160)throw bad(400,'invalid_reminder');const items=await reminderList(owner);if(!items.some(i=>i.id===body.id))throw bad(404,'reminder_not_found');await serial('reminders:'+owner,async()=>{const file=path.join(reminders,owner+'.json');let data={};try{data=JSON.parse(await readFile(file,'utf8'));}catch{}data[body.id]={at:now(),revision:items.find(item=>item.id===body.id).revision};const tmp=file+'.'+randomUUID()+'.tmp';await writeFile(tmp,JSON.stringify(data),{mode:0o600});await rename(tmp,file);});json(res,200,{dismissed:true});return true;
    }throw bad(404,'route_not_found');
   }
   if(parts[0]!=='cases')throw bad(404,'route_not_found');
   if(parts.length===1&&req.method==='GET'){
    const names=await readdir(records),list=[];
    for(const name of names.filter(n=>/^DEMO-\d{8}-[A-F0-9]{12}\.json$/.test(n))){try{const record=JSON.parse(await readFile(path.join(records,name),'utf8'));if(record.owner===owner)list.push(publicRecord(record));}catch{}}
    list.sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));json(res,200,{mode:'local-demo',cases:list});return true;
   }
   if(parts.length===1&&req.method==='POST'){
    const body=await bodyJson(req);
    if(!Object.hasOwn(CASE_SCHEMAS,body.service))throw bad(400,'unknown_service');
    if(!/^[a-f0-9-]{20,64}$/i.test(body.clientRequestId||''))throw bad(400,'request_key_required');
    const id='DEMO-'+localDate()+'-'+digest(owner+':'+body.clientRequestId).slice(0,12).toUpperCase();
    await serial(id,async()=>{
     let existing;try{existing=await load(id,owner);}catch{}
     if(existing){if(existing.service!==body.service)throw bad(409,'request_key_reused');return json(res,200,publicRecord(existing));}
     const stamp=now(),record={id,owner,clientKey:body.clientRequestId,service:body.service,mode:'local-demo',status:'draft',version:1,createdAt:stamp,updatedAt:stamp,fields:{},skippedFields:[],attachments:[],events:[{type:'draft_created',at:stamp}],adapterMode:adapter.mode};
     await save(record);json(res,201,publicRecord(record));
    });return true;
   }
   const id=parts[1];
   if(!id)throw bad(404,'route_not_found');
   if(parts.length===2&&req.method==='GET'){json(res,200,publicRecord(await load(id,owner)));return true;}
   if(parts.length===2&&req.method==='PATCH'){
    const body=await bodyJson(req);
    await serial(id,async()=>{
     const record=await load(id,owner);editable(record,body);
     if(!body.fields||typeof body.fields!=='object'||Array.isArray(body.fields))throw bad(400,'fields_required');
     const fields=CASE_SCHEMAS[record.service].fields,allowed=new Map(fields.map(f=>[f.key,f])),errors=[];
     for(const [key,value] of Object.entries(body.fields)){
      if(!allowed.has(key)){errors.push({field:key,code:'unknown_field'});continue;}
      const code=fieldError(allowed.get(key),value);if(code)errors.push({field:key,code});
     }
     if(errors.length)throw bad(422,'invalid_fields',{errors});
     for(const [key,value] of Object.entries(body.fields)){if(value===null||value==='')delete record.fields[key];else record.fields[key]=value;}
     record.skippedFields=(record.skippedFields||[]).filter(key=>!Object.hasOwn(body.fields,key));
     if(body.skipFields!==undefined){
      if(!Array.isArray(body.skipFields)||body.skipFields.some(key=>!allowed.has(key)||allowed.get(key).required))throw bad(400,'invalid_skipped_fields');
      for(const key of body.skipFields){delete record.fields[key];if(!record.skippedFields.includes(key))record.skippedFields.push(key);}
     }
     // Remove dormant branch values so they cannot leak into a different submission.
     const visible=new Set(activeFields(record.service,record.fields).map(f=>f.key));
     for(const key of Object.keys(record.fields))if(!visible.has(key))delete record.fields[key];
     touch(record,'fields_updated',{keys:Object.keys(body.fields)});await save(record);json(res,200,publicRecord(record));
    });return true;
   }
   if(parts[2]==='validate'&&parts.length===3&&req.method==='POST'){
    const record=await load(id,owner);const errors=validateCase(record);json(res,200,{valid:errors.length===0,errors,feeEstimate:feeEstimate(record.service,record.fields),version:record.version,checks:['required_fields','field_formats','branch_consistency','required_attachment_presence','attachment_file_format'],notChecked:['identity_authenticity','document_authenticity','official_eligibility']});return true;
   }
   if(parts[2]==='attachments'&&parts.length===3&&req.method==='POST'){
    const slot=url.searchParams.get('slot'),filename=path.basename(url.searchParams.get('name')||'').replace(/[\u0000-\u001F\u007F]/g,'').slice(0,160),version=Number(url.searchParams.get('version'));
    if(!filename)throw bad(400,'filename_required');
    const bytes=await readBody(req,10*1024*1024);
    let type;
    if(bytes.subarray(0,5).toString()==='%PDF-'&&/\.pdf$/i.test(filename))type='application/pdf';
    else if(bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))&&/\.png$/i.test(filename))type='image/png';
    else if(bytes.length>3&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255&&/\.jpe?g$/i.test(filename))type='image/jpeg';
    else throw bad(415,'unsupported_file');
    if(bytes.length<12)throw bad(415,'unsupported_file');
    await serial(id,async()=>{
     const record=await load(id,owner);editable(record,{version});
     if(!activeSlots(record.service,record.fields).some(s=>s.key===slot))throw bad(400,'unknown_attachment_slot');
     if(record.attachments.length>=20||record.attachments.reduce((n,a)=>n+a.size,0)+bytes.length>30*1024*1024)throw bad(413,'case_attachment_limit');
     const attachmentId=randomUUID(),storageName=randomUUID(),stored=path.join(uploads,storageName);
     await writeFile(stored,bytes,{mode:0o600,flag:'wx'});
     record.attachments.push({id:attachmentId,slot,filename,type,size:bytes.length,sha256:digest(bytes),storageName,uploadedAt:now()});
     touch(record,'attachment_uploaded',{attachmentId,slot});
     try{await save(record);}catch(e){await unlink(stored).catch(()=>{});throw e;}
     json(res,201,publicRecord(record));
    });return true;
   }
   if(parts[2]==='attachments'&&parts.length===4&&req.method==='GET'){
    const record=await load(id,owner),item=record.attachments.find(a=>a.id===parts[3]);if(!item)throw bad(404,'attachment_not_found');
    const bytes=await readFile(path.join(uploads,item.storageName));res.writeHead(200,{'content-type':item.type,'content-disposition':`attachment; filename="document${path.extname(item.filename).toLowerCase()}"; filename*=UTF-8''${encodeURIComponent(item.filename)}`,'content-length':bytes.length});res.end(bytes);return true;
   }
   if(parts[2]==='attachments'&&parts.length===4&&req.method==='DELETE'){
    const body=await bodyJson(req);
    await serial(id,async()=>{
     const record=await load(id,owner);editable(record,body);const item=record.attachments.find(a=>a.id===parts[3]);if(!item)throw bad(404,'attachment_not_found');
     record.attachments=record.attachments.filter(a=>a.id!==item.id);touch(record,'attachment_removed',{attachmentId:item.id});await save(record);await unlink(path.join(uploads,item.storageName)).catch(()=>{});json(res,200,publicRecord(record));
    });return true;
   }
   if(parts[2]==='submit'&&parts.length===3&&req.method==='POST'){
    const body=await bodyJson(req);
    if(body.confirmed!==true)throw bad(400,'explicit_confirmation_required');
    await serial(id,async()=>{
     const record=await load(id,owner);
     // Retrying a successful submit returns the existing receipt, never another case.
     if(record.status==='submitted')return json(res,200,publicRecord(record));
     editable(record,body);
     const errors=validateCase(record);if(errors.length)throw bad(422,'case_incomplete',{errors});
     const activeKeys=new Set(activeSlots(record.service,record.fields).map(s=>s.key));
     record.attachments=record.attachments.filter(a=>activeKeys.has(a.slot));
     record.feeAtSubmission=feeEstimate(record.service,record.fields);
     record.adapterResult=await adapter.submit({schemaVersion:1,id:record.id,service:record.service,mode:'local-demo',fields:structuredClone(record.fields),attachments:record.attachments.map(({storageName,...item})=>({...item})),feeEstimate:record.feeAtSubmission});
     record.status='submitted';record.submittedAt=now();touch(record,'local_submission_received');
     record.events.push({type:'awaiting_local_review',at:record.updatedAt});await save(record);json(res,200,publicRecord(record));
    });return true;
   }
   if(parts[2]==='receipt'&&parts.length===3&&req.method==='GET'){
    const record=await load(id,owner);if(record.status!=='submitted')throw bad(409,'receipt_not_ready');
    if(url.searchParams.get('format')==='json'){json(res,200,publicRecord(record));return true;}
    const lang=['fr','en','zh'].includes(url.searchParams.get('lang'))?url.searchParams.get('lang'):'zh',schema=CASE_SCHEMAS[record.service],label=obj=>obj[lang]||obj.en;
    const title={zh:'演示办件提交回执',en:'Demo case submission receipt',fr:'Récépissé de dossier de démonstration'}[lang];
    const rows=activeFields(record.service,record.fields).filter(f=>record.fields[f.key]!==undefined).map(f=>{let v=record.fields[f.key];if(f.type==='select')v=label(f.options.find(o=>o.value===v).label);return `<tr><th>${escape(label(f.label))}</th><td>${escape(v)}</td></tr>`;}).join('');
    const submittedLocal=new Intl.DateTimeFormat(({zh:'zh-CN',en:'en-GB',fr:'fr-FR'})[lang],{timeZone:'Asia/Shanghai',dateStyle:'medium',timeStyle:'medium'}).format(new Date(record.submittedAt))+' (UTC+8)';
    const html=`<!doctype html><html lang="${lang}"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${title} ${id}</title><style>body{font-family:Arial,'Microsoft YaHei',sans-serif;color:#1f2937;margin:40px auto;padding:24px;max-width:900px;line-height:1.6}h1{color:#1f5fae}.notice{background:#edf4ff;padding:18px;border:1px solid #b8c7d9}table{border-collapse:collapse;width:100%;margin:24px 0}th,td{border:1px solid #d8e0ea;padding:10px;text-align:left;overflow-wrap:anywhere}th{width:35%}small{color:#526174}@media print{body{margin:0}}</style><h1>${title}</h1><div class="notice">DEMO / 演示办件 / Démonstration<br>仅已提交到本机演示后台，未提交至多哥政府系统；未实际缴费，无官方受理或审批效力。<br>Stored locally only; no government filing, payment or official decision.</div><h2>${escape(label(schema.title))}</h2><p><strong>${escape(id)}</strong><br>${escape(submittedLocal)}<br>演示状态：已提交，待本地审核 / Submitted, awaiting local review</p><table>${rows}</table><h3>附件 / Attachments</h3><ul>${record.attachments.map(a=>`<li>${escape(a.filename)} — ${a.size} bytes — SHA-256 ${a.sha256}</li>`).join('')||'<li>无 / None</li>'}</ul><p>参考费用：${record.feeAtSubmission.amount===null?'待官方表单确认':escape(record.feeAtSubmission.amount)+' XOF'}${record.feeAtSubmission.postageExcluded?'（不含邮费 / excluding postage）':''}；实际收款：0。Reference only; no payment collected.</p><small>本回执由本地演示服务生成。Official-form completeness and document authenticity are not certified.</small></html>`;
    res.writeHead(200,{'content-type':'text/html; charset=utf-8','content-disposition':`inline; filename="${id}-receipt.html"`,'content-security-policy':"default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'self'"});res.end(html);return true;
   }
   throw bad(404,'route_not_found');
  }catch(error){if(!res.headersSent)json(res,error.status||500,{error:error.code||'local_storage_error',...(error.errors?{errors:error.errors}:{}),...(error.currentVersion?{currentVersion:error.currentVersion}:{})});else res.end();}
  return true;
 }
 return handler;
}
