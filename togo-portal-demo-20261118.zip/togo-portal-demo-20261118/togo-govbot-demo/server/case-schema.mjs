// Demo data contracts, not a certified replica of every official form.
const tr=(fr,en,zh)=>({fr,en,zh});
const option=(value,fr,en,zh)=>({value,label:tr(fr,en,zh)});
const field=(key,type,label,extra={})=>({key,type,label,required:true,...extra});
const name=()=>field('applicantName','text',tr('Nom complet du demandeur','Applicant full name','申请人姓名'),{aliases:['申请人姓名','申请人','姓名','我的名字是','我叫','my name is',"je m'appelle",'applicant name','full name','nom complet','nom'],maxLength:100});
const phone=()=>field('phone','phone',tr('Téléphone de contact','Contact phone','联系电话'),{aliases:['联系电话','手机号','手机','电话','phone','telephone','téléphone','tel'],hint:tr('Ex. +228 90 00 00 00','E.g. +228 90 00 00 00','例如 +228 90 00 00 00'),maxLength:25});
const email=()=>field('email','email',tr('Email (facultatif)','Email (optional)','电子邮箱（可选）'),{required:false,aliases:['电子邮箱','邮箱','email','e-mail','courriel'],maxLength:150});
const birth=()=>field('birthDate','date',tr('Date de naissance (AAAA-MM-JJ)','Birth date (YYYY-MM-DD)','出生日期（YYYY-MM-DD）'),{aliases:['出生日期','生日','birth date','date of birth','date de naissance']});
const docnum=()=>field('documentNumber','document',tr('Numéro du document','Document number','证明文件编号'),{aliases:['证明文件编号','证件编号','证明编号','文件编号','编号','document number','certificate number','numero','numéro'],maxLength:80});
const delivery=()=>field('delivery','select',tr('Mode de retrait','Collection method','领取方式'),{aliases:['领取方式','领取','取件','delivery','collection','retrait'],options:[option('centre','Centre de retrait','Collection centre','中心领取'),option('post','Envoi postal','By post','邮寄')]});
const pickup=()=>field('pickupLocation','text',tr('Centre/lieu de retrait souhaité','Requested collection location','拟领取中心/地点'),{when:{delivery:'centre'},aliases:['领取中心','领取地点','中心','collection centre','pickup location','centre'],maxLength:150,hint:tr('Lieu souhaité, à confirmer avec le service officiel','Requested location; official availability is not checked','填写拟选地点，演示不核实其官方可预约性')});
const address=()=>field('postalAddress','text',tr('Adresse postale complète','Full postal address','完整邮寄地址'),{when:{delivery:'post'},aliases:['完整邮寄地址','邮寄地址','地址','postal address','address','adresse'],maxLength:400});
const slot=(key,fr,en,zh,required=true,when)=>({key,label:tr(fr,en,zh),required,...(when?{when}: {})});
const first=()=>field('applicationType','select',tr('Type de demande','Application type','申请类型'),{aliases:['申请类型','类型','application type','type de demande'],options:[option('new','Première demande','First application','首次申请'),option('renew','Renouvellement','Renewal','续期/换发')]});
export const CASE_SCHEMAS={
 duplicate:{title:tr('Duplicata de nationalité','Nationality certificate duplicate','国籍证明副本'),fields:[
  field('certificateFormat','select',tr('Format du certificat','Certificate format','国籍证明格式'),{aliases:['证明格式','证书格式','格式','format'],options:[option('new','Nouveau format','New format','新版'),option('old','Ancien format','Old format','旧版')]}),
  field('applicantRole','select',tr('Pour qui faites-vous la demande ?','Who is the application for?','为谁申请？'),{aliases:['申请关系','关系','为谁','relationship','pour qui'],options:[option('self','Moi-même','Myself','本人'),option('relative','Un parent/proche','A relative','亲属')]}),name(),
  field('holderName','text',tr('Nom du titulaire','Certificate holder name','持证人姓名'),{when:{applicantRole:'relative'},aliases:['持证人姓名','持证人','holder name','titulaire'],maxLength:100}),
  field('documentType','select',tr('Type de document de référence','Reference document type','编号来源文件'),{aliases:['编号来源','文件类型','document type','type de document'],options:[option('nationality','Certificat de nationalité','Nationality certificate','国籍证明'),option('birth','Acte de naissance','Birth record','出生登记文件')]}),docnum(),
  field('copies','integer',tr('Nombre de copies (1–5)','Copies (1–5)','副本份数（1–5）'),{aliases:['副本份数','份数','申请几份','copies','nombre de copies'],min:1,max:5}),delivery(),pickup(),address(),phone(),email()],
  attachments:[slot('reference','Justificatif du numéro (facultatif)','Number reference evidence (optional)','编号来源证明（演示可选附件）',false)]},
 nationality:{title:tr('Certificat de nationalité','Nationality certificate','国籍证明'),fields:[
  field('basis','select',tr('Fondement de la demande','Application basis','申请依据'),{aliases:['申请依据','依据','basis','fondement'],options:[option('descent','Filiation','Descent','血缘'),option('marriage','Mariage','Marriage','婚姻'),option('naturalisation','Naturalisation','Naturalisation','入籍'),option('status','Possession d’état / autre','Possession of status / other','身份占有/其他')]}),name(),birth(),
  field('birthplace','text',tr('Lieu de naissance','Birthplace','出生地'),{aliases:['出生地','birthplace','lieu de naissance'],maxLength:150}),
  field('familyProof','select',tr('Justificatif familial de nationalité disponible ?','Accepted family nationality proof available?','是否有官方认可的亲属国籍证明？'),{when:{basis:'descent'},aliases:['亲属国籍证明','父母证明','family proof'],options:[option('yes','Oui','Yes','有'),option('no','Non, voie certificat d’origine','No, certificate-of-origin route','无，来源证明途径')]}),
  field('basisDetails','text',tr('Précisez votre situation','Describe your application basis','说明具体申请情形'),{when:{basis:{in:['marriage','naturalisation','status']}},aliases:['具体情形','情形说明','situation','details'],maxLength:1000}),phone(),email()],
  attachments:[slot('birth','Acte de naissance','Birth record','出生登记材料'),slot('photo','Photo','Photo','照片'),slot('family','Justificatif familial de nationalité','Family nationality evidence','亲属国籍证明',true,{basis:'descent',familyProof:'yes'}),slot('origin','Certificat d’origine','Certificate of origin','来源证明',true,{basis:'descent',familyProof:'no'}),slot('basis','Pièce liée au fondement (démo)','Basis evidence (demo)','申请依据证明（演示材料）',true,{basis:{in:['marriage','naturalisation','status']}})]},
 passport:{title:tr('Passeport','Passport application','护照申请'),fields:[first(),
  field('passportType','select',tr('Type de passeport','Passport type','护照类型'),{aliases:['护照类型','passport type','type de passeport'],options:[option('ordinary','Ordinaire','Ordinary','普通'),option('service','Service','Service','公务'),option('diplomatic','Diplomatique','Diplomatic','外交')]}),name(),birth(),
  field('filingZone','select',tr('Zone de dépôt','Filing area','递交区域'),{aliases:['递交区域','递交地区','zone','filing area'],options:[option('togo','Au Togo','In Togo','多哥境内'),option('abroad','Hors du Togo','Outside Togo','多哥境外')]}),
  field('filingLocation','text',tr('Lieu de dépôt souhaité','Requested filing location','拟递交地点'),{aliases:['递交地点','filing location','lieu de depot','site'],maxLength:150}),
  field('profession','text',tr('Profession / situation','Profession / occupation','职业/身份'),{aliases:['职业','profession','occupation'],maxLength:150}),
  field('oldPassportNumber','document',tr('Ancien numéro de passeport','Previous passport number','旧护照编号'),{when:{applicationType:'renew'},aliases:['旧护照编号','旧护照号码','previous passport','ancien passeport'],maxLength:80}),phone(),email()],
  attachments:[slot('nationality','Preuve de nationalité','Nationality proof','国籍证明'),slot('birth','Acte de naissance','Birth record','出生登记材料'),slot('photo','Photo','Photo','照片'),slot('oldPassport','Ancien passeport','Previous passport','旧护照',true,{applicationType:'renew'}),slot('additional','Pièces complémentaires (facultatif)','Additional evidence (optional)','其他适用证明（可选）',false)]},
 criminal:{title:tr('Casier judiciaire','Criminal-record extract','犯罪记录证明'),fields:[
  field('applicantStatus','select',tr('Statut du demandeur','Applicant status','申请人身份'),{aliases:['申请人身份','身份','applicant status','statut'],options:[option('bornTogo','Togolais né au Togo','Togolese born in Togo','多哥公民，境内出生'),option('bornAbroad','Togolais né à l’étranger','Togolese born abroad','多哥公民，境外出生'),option('foreign','Étranger résidant au Togo','Foreign resident in Togo','多哥外国居民')]}),name(),birth(),
  field('documentType','select',tr('Document justificatif','Supporting document type','所用证明文件类型'),{aliases:['证明类型','文件类型','document type','document justificatif'],options:[option('birth','Acte de naissance','Birth record','出生登记文件'),option('nationality','Nationalité','Nationality certificate','国籍证明'),option('passport','Passeport','Passport','护照'),option('residence','Carte de séjour','Residence permit','居留证'),option('judgement','Jugement','Judgement','判决文件')]}),docnum(),delivery(),pickup(),address(),phone(),email()],
  attachments:[slot('identity','Une pièce acceptée selon le statut','One accepted status-specific document','与身份匹配的一份证明文件')]},
 residence:{title:tr('Carte de séjour','Residence permit','居留证申请'),fields:[first(),
  field('permitType','select',tr('Catégorie / durée','Category / duration','居留证类别/期限'),{aliases:['居留证类别','居留类别','类别','permit type','categorie','catégorie'],options:[option('student1','Étudiant, 1 an','Student, 1 year','学生1年'),option('student3','Étudiant, 3 ans','Student, 3 years','学生3年'),option('other1','Autre, 1 an','Other, 1 year','其他类别1年'),option('other3','Autre, 3 ans','Other, 3 years','其他类别3年'),option('other5','Privilégiée, 5 ans','Privileged, 5 years','特许类别5年')]}),name(),birth(),
  field('nationality','text',tr('Nationalité actuelle','Current nationality','现国籍'),{aliases:['现国籍','国籍','nationality','nationalité'],maxLength:100}),
  field('passportNumber','document',tr('Numéro du passeport','Passport number','护照编号'),{aliases:['护照编号','护照号码','passport number','numero passeport'],maxLength:80}),
  field('residentialAddress','text',tr('Adresse au Togo','Address in Togo','多哥居住地址'),{aliases:['居住地址','多哥地址','residential address','adresse au togo'],maxLength:400}),phone(),email()],
  attachments:[slot('passport','Passeport','Passport','护照'),slot('photo','Photo','Photo','照片'),slot('medical','Certificat médical','Medical certificate','体检证明'),slot('resources','Justificatif de ressources','Resources evidence','经济来源证明'),slot('student','Inscription / stage','Enrolment / internship','在读/实习证明',true,{permitType:{in:['student1','student3']}}),slot('oldPermit','Ancienne carte','Previous permit','原居留证',true,{applicationType:'renew'}),slot('additional','Pièces de catégorie (facultatif)','Category-specific evidence (optional)','其他类别证明（可选）',false)]},
 courtfees:{title:tr('Frais d’enrôlement au tribunal','Court registration fees','法院案件登记缴费'),fields:[
  field('applicantRole','select',tr('Qualité du demandeur','Applicant capacity','申请主体'),{aliases:['申请主体','主体','capacity'],options:[option('individual','Particulier','Individual','个人'),option('entity','Personne morale','Legal entity','法人/组织'),option('representative','Représentant','Representative','代表')]}),name(),
  field('entityName','text',tr('Nom de la personne morale','Legal entity name','法人/组织名称'),{when:{applicantRole:'entity'},aliases:['组织名称','法人名称','公司名称','entity name'],maxLength:200}),
  field('caseNature','text',tr('Nature de l’affaire','Case type','案件性质'),{aliases:['案件性质','案件类型','case type','nature de l affaire'],maxLength:250}),
  field('jurisdiction','text',tr('Juridiction sélectionnée','Selected court','所选法院'),{aliases:['所选法院','法院','jurisdiction','court','juridiction'],maxLength:200}),
  field('caseSummary','text',tr('Résumé de la demande','Application summary','案件/申请简述'),{aliases:['案件简述','申请简述','简述','summary','resume','résumé'],maxLength:2000}),phone(),email()],
  attachments:[slot('caseFile','Pièce relative à l’affaire (démo)','Case-related document (demo)','案件相关材料（演示附件）')]}
};
export function matches(when,values){return !when||Object.entries(when).every(([key,rule])=>rule&&typeof rule==='object'?rule.in?.includes(values[key]):values[key]===rule);}
export function activeFields(service,values){return CASE_SCHEMAS[service].fields.filter(f=>matches(f.when,values));}
export function activeSlots(service,values){return CASE_SCHEMAS[service].attachments.filter(f=>matches(f.when,values));}
export function fieldError(field,value){
 if(value===undefined||value===null||value==='')return null;
 if(field.type==='integer')return typeof value==='number'&&Number.isInteger(value)&&value>=field.min&&value<=field.max?null:'range';
 if(typeof value!=='string')return 'type';
 if(value!==value.trim()||/[\u0000-\u001F\u007F]/.test(value))return 'format';
 if(value.length>(field.maxLength||400))return 'length';
 if(field.type==='select')return field.options.some(o=>o.value===value)?null:'option';
 if(field.type==='phone'&&!/^\+?[\d ()-]{7,25}$/.test(value))return 'phone';
 if(field.type==='phone'&&value.replace(/\D/g,'').length<7)return 'phone';
 if(field.type==='email'&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value))return 'email';
 if(field.type==='document'&&!/^[\p{L}\p{N}][\p{L}\p{N} ./_-]{2,79}$/u.test(value))return 'document';
 if(field.type==='date'){
  const dt=new Date(value+'T00:00:00Z');
  if(!/^\d{4}-\d{2}-\d{2}$/.test(value)||!Number.isFinite(dt.getTime())||dt.toISOString().slice(0,10)!==value||dt>Date.now()||dt.getUTCFullYear()<1900)return 'date';
 }
 if(field.type==='text'&&value.length<2)return 'short';
 return null;
}
export function validateCase(record){
 const errors=[];
 for(const field of activeFields(record.service,record.fields)){
  const v=record.fields[field.key];
  if(field.required&&(v===undefined||v===null||v===''))errors.push({field:field.key,code:'required'});
  else{const code=fieldError(field,v);if(code)errors.push({field:field.key,code});}
 }
 for(const slot of activeSlots(record.service,record.fields))if(slot.required&&!record.attachments.some(a=>a.slot===slot.key))errors.push({slot:slot.key,code:'attachment_required'});
 // These checks express demo consistency, not an official eligibility decision.
 if(record.service==='criminal'&&record.fields.applicantStatus){
  const today=new Date(),b=new Date(record.fields.birthDate+'T00:00:00Z');
  let age=today.getUTCFullYear()-b.getUTCFullYear();if(today.toISOString().slice(5,10)<b.toISOString().slice(5,10))age--;
  if(record.fields.applicantStatus!=='foreign'&&age<14)errors.push({field:'birthDate',code:'b3_age'});
  const allowed=record.fields.applicantStatus==='bornTogo'?['birth','nationality','judgement']:['birth','passport','residence','nationality'];
  if(record.fields.documentType&&!allowed.includes(record.fields.documentType))errors.push({field:'documentType',code:'document_status'});
 }
 return errors;
}
export function feeEstimate(service,values){
 if(service==='duplicate'&&values.certificateFormat==='old')return {currency:'XOF',amount:null,basis:'physical_official_route_required',charged:false};
 if(service==='duplicate')return {currency:'XOF',amount:1000*Number(values.copies||0),basis:'published_reference',charged:false,postageExcluded:values.delivery==='post'};
 if(service==='criminal')return {currency:'XOF',amount:500,basis:'published_reference',charged:false};
 if(service==='nationality'&&values.basis==='descent')return {currency:'XOF',amount:values.familyProof==='no'?15000:5000,basis:'published_reference',charged:false};
 if(service==='residence')return {currency:'XOF',amount:{student1:100000,student3:250000,other1:200000,other3:500000,other5:800000}[values.permitType]||null,basis:'published_reference',charged:false};
 if(service==='passport'&&values.passportType==='ordinary'&&values.filingZone==='togo')return {currency:'XOF',amount:30000,basis:'published_reference_confirm_in_official_form',charged:false};
 return {currency:'XOF',amount:null,basis:'official_form_required',charged:false};
}
