import http from 'node:http';
import net from 'node:net';
import {readFile} from 'node:fs/promises';
import {Readable} from 'node:stream';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createCaseApi} from './case-api.mjs';
const port=Number(process.env.PORT||4175);
const tangrat=new URL(process.env.TANGRAT_UPSTREAM||'http://host.docker.internal:8080');
const caseApi=createCaseApi({dataDir:process.env.CASE_DATA_DIR||fileURLToPath(new URL('../runtime/',import.meta.url))});
const web=path.resolve(fileURLToPath(new URL('../web/',import.meta.url))); 
const portal='https://new.service-public.gouv.tg';
const gateway='https://api-gateway.service-public.gouv.tg';
const allowed=new Set([new URL(portal).origin,new URL(gateway).origin]);
async function upstream(url,options={},depth=0){
  if(!allowed.has(url.origin)||depth>4) throw new Error('Invalid upstream redirect');
  const response=await fetch(url,{...options,redirect:'manual',signal:AbortSignal.timeout(45000)});
  if([301,302,303,307,308].includes(response.status)&&response.headers.has('location')){
    return upstream(new URL(response.headers.get('location'),url),options,depth+1);
  }
  return response;
}
const mime={'.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.html':'text/html; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.woff2':'font/woff2','.woff':'font/woff','.ttf':'font/ttf'};
const server=http.createServer(async(req,res)=>{
 try{
  if(req.url==='/tangrat'||req.url.startsWith('/tangrat/')){
    if(req.headers.origin&&!['http://'+req.headers.host,'https://'+req.headers.host].includes(req.headers.origin)){res.writeHead(403);res.end('Origin not allowed');return;}
    const target=tangrat.origin+(req.url.slice('/tangrat'.length)||'/');
    const headers={...req.headers,host:tangrat.host};delete headers['accept-encoding'];headers['x-tangrat-prefix']='/tangrat';
    if(headers.origin)headers.origin=tangrat.origin;
    const response=await fetch(target,{method:req.method,headers,body:['GET','HEAD'].includes(req.method)?undefined:Readable.toWeb(req),duplex:'half',redirect:'manual'});
    const out={};for(const [k,v] of response.headers)if(!['content-length','content-encoding','transfer-encoding','connection','set-cookie'].includes(k))out[k]=v;
    const cookies=response.headers.getSetCookie();if(cookies.length)out['set-cookie']=cookies;
    out['cache-control']='no-store';
    if(out.location?.startsWith('/'))out.location='/tangrat'+out.location;
    res.writeHead(response.status,out);
    const type=response.headers.get('content-type')||'';
    if(/javascript|text\/html|text\/css/.test(type)){
      let body=await response.text();
      body=body.replace(/(?<=["'`(])\/assets\//g,'/tangrat/assets/').replaceAll('/api/','/tangrat/api/').replaceAll('href="/operator"','href="/tangrat/operator"').replaceAll("location.origin+'/observer'","location.origin+'/tangrat/observer'");
      res.end(body);
    }else if(response.body)Readable.fromWeb(response.body).pipe(res);else res.end();
    return;
  }
  if(await caseApi(req,res))return;
  const incoming=new URL(req.url,'http://localhost');
  const pathname=incoming.pathname;
  if(pathname==='/health'){
    res.writeHead(200,{'content-type':'application/json'});return res.end(JSON.stringify({status:'ok',port,assistant:'Togo official-service guide',upstream:portal}));
  }
  if(pathname.startsWith('/govbot/')){
    if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);return res.end();}
    const relative=decodeURIComponent(pathname.slice('/govbot/'.length));
    const file=path.resolve(web,relative||'demo/index.html');
    if(!file.startsWith(web+path.sep)){res.writeHead(403);return res.end();}
    let bytes;
    try{bytes=await readFile(file);}catch{res.writeHead(404);return res.end('Not found');}
    if(relative==='demo/index.html'||relative==='demo/assistant.html'){
      // Keep the original Demo source untouched; isolate and display its existing dialog.
      bytes=Buffer.from(bytes.toString().replace('</body>','<script src="/govbot/embed.js"></script></body>'));
    }
    res.writeHead(200,{'content-type':mime[path.extname(file)]||'application/octet-stream','cache-control':'no-store'});
    return res.end(req.method==='HEAD'?undefined:bytes);
  }
  // The old injected entry scripts are deliberately absent from this version.
  if(['/assistant.js','/assistant-fixes.js','/assistant-position.js','/flood-entry.js'].includes(pathname)){
    res.writeHead(404);return res.end();
  }
  if(pathname==='/assets/env.js'){
    res.writeHead(200,{'content-type':'application/javascript','cache-control':'no-store'});
    return res.end(`window.__env={API_URL:'/api-gateway/api/v1',Legacy_API_URL:'${portal}',PAYMENT_SOCKET_URL:'',TASK_SOCKET_URL:'',NOTIFICATION_SOCKET_URL:'',CHATBOT_URL:'/api-gateway/api/v1'};`);
  }
  const isApi=pathname.startsWith('/api-gateway/');
  const target=new URL((isApi?pathname.slice('/api-gateway'.length):pathname)+incoming.search,isApi?gateway:portal);
  const headers={'user-agent':'Mozilla/5.0'};
  let body;
  if(!['GET','HEAD'].includes(req.method)){
    const chunks=[];for await(const chunk of req)chunks.push(chunk);body=Buffer.concat(chunks);
    headers['content-type']=req.headers['content-type']||'application/json';
  }
  const source=await upstream(target,{method:req.method,headers,body});
  const type=source.headers.get('content-type')||'application/octet-stream';
  res.writeHead(source.status,{'content-type':type,'cache-control':'no-store'});
  if(req.method==='HEAD')return res.end();
  if(type.includes('text/html')){
    let html=await source.text();
    html=html.replace(/<base\b[^>]*>/i,'<base href="/">');
    html=html.replace(/<script\b[^>]*src=["']\/(?:assistant(?:-fixes|-position)?|flood-entry)\.js["'][^>]*><\/script>/gi,'');
    return res.end(html.replace('</body>','<script src="/govbot/launcher.js"></script></body>'));
  }
  if(type.includes('javascript')){
    const code=(await source.text()).replaceAll('https://api-gateway.service-public.gouv.tg/api/v1','/api-gateway/api/v1');
    return res.end(code);
  }
  if(!source.body)return res.end();
  Readable.fromWeb(source.body).pipe(res);
 }catch(error){
  if(!res.headersSent)res.writeHead(502,{'content-type':'text/plain; charset=utf-8'});
  res.end('多哥门户暂时无法加载，请稍后刷新。 / Portail temporairement indisponible.');
 }
 });
server.on('upgrade',(req,socket,head)=>{
 if(req.headers.origin&&!['http://'+req.headers.host,'https://'+req.headers.host].includes(req.headers.origin)){socket.destroy();return;}
 if(!req.url.startsWith('/tangrat/api/voice/')){socket.destroy();return;}
 const remote=net.connect(Number(tangrat.port||80),tangrat.hostname,()=>{
  let request=`${req.method} ${req.url.slice('/tangrat'.length)} HTTP/1.1\r\n`;
  for(const [key,value] of Object.entries(req.headers))request+=`${key}: ${key==='host'?tangrat.host:key==='origin'?tangrat.origin:value}\r\n`;
  remote.write(request+'\r\n');if(head.length)remote.write(head);socket.pipe(remote);remote.pipe(socket);
 });remote.on('error',()=>socket.destroy());socket.on('error',()=>remote.destroy());socket.on('close',()=>remote.destroy());
});
server.listen(port,'0.0.0.0' ,()=>console.log(`Togo + GovBot: http://localhost:${port}`));
