// Advisory local task packages, not a legal list of requirements for working abroad.
export function workAbroadCandidates(answers){
 const tasks=[];
 if(['missing','expired','unknown'].includes(answers.passportStatus))tasks.push({service:'passport',reason:answers.passportStatus==='expired'?'passport_renewal':'passport_check',defaultSelected:answers.passportStatus!=='unknown'});
 if(answers.nationalityStatus==='needsFirst')tasks.push({service:'nationality',reason:'nationality_not_available',defaultSelected:true});
 if(answers.nationalityStatus==='needsCopy')tasks.push({service:'duplicate',reason:'existing_certificate_copy',defaultSelected:true});
 if(['criminal','both','unknown'].includes(answers.employerRequirement))tasks.push({service:'criminal',reason:answers.employerRequirement==='unknown'?'employer_requirement_unconfirmed':'employer_requests_record',defaultSelected:answers.employerRequirement!=='unknown'});
 if(['nationality','both'].includes(answers.employerRequirement)&&answers.nationalityStatus==='unknown')tasks.push({service:'nationality',reason:'nationality_to_verify',defaultSelected:false});
 return tasks;
}
export function validJourneyAnswers(a){return a&&typeof a.destination==='string'&&a.destination.trim().length>=2&&a.destination.length<=100&&['valid','missing','expired','unknown'].includes(a.passportStatus)&&['criminal','nationality','both','none','unknown'].includes(a.employerRequirement)&&['hasProof','needsCopy','needsFirst','unknown'].includes(a.nationalityStatus);}
