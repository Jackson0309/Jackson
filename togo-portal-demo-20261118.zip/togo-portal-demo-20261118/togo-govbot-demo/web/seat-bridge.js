// Same-origin protocol used only by the independently opened AI seat.
(() => {
 if(new URLSearchParams(location.search).get('seat')!=='1')return;
 document.querySelector('.chatbot-close').style.display='none';
 document.getElementById('gbot-language').style.display='none';
 document.querySelector('.gbot-input-bar').style.display='none';
 let sequence=0,lastUtterance='',lastSpokenRow=null,scheduled=false;
 function publish(){
  scheduled=false;
  const r=GBOT_FLOW.draft?.service===GBOT_FLOW.service?GBOT_FLOW.draft:null;
  const fields=r?demoFields(r):[],slots=r?demoSlots(r):[];
  const validation=r?.validation||[];
  const state={type:'govbot:state',sequence:++sequence,at:new Date().toISOString(),language:GBOT_ENGINE.lang,stage:GBOT_FLOW.stage,service:GBOT_FLOW.service||GBOT_ENGINE.lastIntent,caseId:r?.id||null,status:r?.status||null,version:r?.version||0,active:GBOT_FLOW.active,busy:GBOT_FLOW.busy,fieldsTotal:fields.length,fieldsFilled:fields.filter(f=>r.fields[f.key]!==undefined||(r.skippedFields||[]).includes(f.key)).length,missingFields:validation.filter(e=>e.field).length,missingAttachments:validation.filter(e=>e.slot).length,attachmentCount:r?.attachments.length||0,events:(r?.events||[]).map(e=>({type:e.type,at:e.at})),provenance:'local-api'};
  parent.postMessage(state,location.origin);
  const area=document.getElementById('gbot-chat-messages');
  const latestRow=area.querySelector('.gbot-msg-row.bot:last-child');
  if(!latestRow||latestRow.querySelector('.gbot-typing'))return;
  let utterance=latestRow.querySelector('.gbot-bubble')?.textContent||'';
  if(GBOT_FLOW.stage==='collect'&&GBOT_FLOW.currentField){const f=fields.find(f=>f.key===GBOT_FLOW.currentField);if(f)utterance=TL(f.label)+(f.options?'。'+f.options.map(o=>TL(o.label)).join('；'):'');}
  if(GBOT_FLOW.stage==='review')utterance=validation.length?FL('Des informations ou pièces restent à compléter.','Some information or attachments are still missing.','还有信息或材料需要补充，请查看校验提示。'):FL('Le contrôle est terminé. Vérifiez les informations. Dites « confirmer le dépôt » pour soumettre uniquement au serveur local.','Validation is complete. Review the information. Say confirm submission to submit only to the local server.','校验已完成，请核对信息。可以说“确认提交演示办件”，仅提交到本地后台。');
  if(r?.status==='submitted'&&GBOT_FLOW.stage==='submitted')utterance=FL('Votre dossier de démonstration est soumis. Vous pouvez consulter le récépissé et son état.','Your demo case has been submitted. You can view its receipt and status.','演示办件已提交，可以查看回执和查询状态。');
  if(latestRow.querySelector('.demo-history'))utterance=FL('Dossier démo soumis, en attente de traitement local.','Demo case submitted, awaiting local review.','演示办件已提交，待本地审核；可以展开页面上的处理记录。');
  const notice=area.querySelector('.gbot-msg-row.bot:last-child .gbot-notice-box');if(notice)utterance=notice.textContent||utterance;
  utterance=utterance.replace(/\s+/g,' ').trim().slice(0,500);
  if(utterance&&(utterance!==lastUtterance||latestRow!==lastSpokenRow)){lastUtterance=utterance;lastSpokenRow=latestRow;parent.postMessage({type:'govbot:utterance',text:utterance,language:GBOT_ENGINE.lang},location.origin);}
 }
 function schedule(){if(!scheduled){scheduled=true;queueMicrotask(publish);}}
 const append=gbotAppendMsg;
 gbotAppendMsg=function(...args){const result=append(...args);schedule();return result;};
 const observer=new MutationObserver(schedule);observer.observe(document.getElementById('gbot-chat-messages'),{childList:true,subtree:true,characterData:true});
 addEventListener('message',event=>{
  if(event.source!==parent||event.origin!==location.origin)return;
  const data=event.data;
  if(data?.type==='govbot:input'&&typeof data.text==='string'&&data.text.length<=2000){gbotHandleInput(data.text.replace(/[。！？!?]+$/,'').trim());schedule();}
  if(data?.type==='govbot:seat-command'){
   if(data.action==='start-case'&&GBOT_KB[data.service])gbotStartFlow(data.service);
   if(data.action==='resume-case'&&/^DEMO-\d{8}-[A-F0-9]{12}$/.test(data.caseId||''))demoResume(data.caseId);
   if(data.action==='show-cases')demoShowCases();
   if(data.action==='set-language'&&['zh','en','fr'].includes(data.language)){sessionStorage.setItem('togo-govbot-language',data.language);gbotSyncLang(data.language);}
   if(data.action==='pause'&&GBOT_FLOW.active)gbotRestart();
   if(data.action==='assistant-message'&&typeof data.text==='string'&&data.text.length<=1500)gbotAppendMsg('bot',E(data.text));
   if(data.action==='state')schedule();
  }
 });
 let previousBusy=GBOT_FLOW.busy;setInterval(()=>{if(previousBusy!==GBOT_FLOW.busy){previousBusy=GBOT_FLOW.busy;schedule();}},300);
 schedule();parent.postMessage({type:'govbot:seat-ready'},location.origin);
})();
