(() => {
 window.toggleChatbot=function(show){document.getElementById('chatbotPopup').classList.toggle('hidden',!show);};
 const style=document.createElement('style');
 style.textContent=`html,body{width:100%;height:100%;margin:0;overflow:hidden;background:#fff}body>*:not(#chatbotPopup):not(script):not(style){display:none!important}#chatbotPopup{position:fixed!important;inset:0!important;width:100%!important;max-width:none!important;height:100%!important;max-height:none!important;border:0;border-radius:0;box-shadow:none}#chatbotPopup.hidden{display:none!important}.gbot-sidebar-item{width:100%;background:transparent;text-align:start}.gbot-action-row{display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin-top:10px}.gbot-portal-jump{background:#fff;border:1px solid var(--primary);color:var(--primary)}.gbot-flow-options{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}button:disabled{cursor:default;opacity:.55}.gbot-flow-footer{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}.gbot-flow-checklist{display:flex;flex-direction:column;gap:10px;margin-top:12px}.gbot-flow-checklist label{display:flex;align-items:flex-start;gap:10px;font-size:.875rem;line-height:1.5}.gbot-flow-checklist input{flex-shrink:0;margin-top:4px;accent-color:var(--primary)}.gbot-source-note{padding-top:10px;margin-top:10px;border-top:1px solid var(--border);font-size:.72rem;color:var(--gbot-text-dim);line-height:1.5}.gbot-source-note a{color:var(--primary)}.gbot-language{background:#f8fbff;color:#1f2937;border:1px solid #d8e0ea;border-radius:7px;font:inherit;font-size:.75rem;padding:4px 6px;max-width:105px}.gbot-topbar-left{min-width:0}.gbot-topbar-tag{display:none}.gbot-rag-conf{font-size:.65rem}.gbot-apply-btn{text-decoration:none}.gbot-source-note a{overflow-wrap:anywhere}@media(max-width:420px){.gbot-status-chip{display:none}.gbot-topbar-right{gap:3px}.gbot-topbar-left{gap:5px}.gbot-language{max-width:88px}.gbot-agent-btn{padding:4px 6px}}`;
 document.head.append(style);
 const casesCss=document.createElement('link');casesCss.rel='stylesheet';casesCss.href='/govbot/demo/css/cases.css';document.head.append(casesCss);
 const selector=document.createElement('select');selector.id='gbot-language';selector.className='gbot-language';selector.setAttribute('aria-label','Language / 语言');
 selector.innerHTML='<option value="fr">Français</option><option value="en">English</option><option value="zh">中文</option>';
 document.querySelector('.gbot-topbar-left').append(selector);
 const casesButton=document.createElement('button');casesButton.className='demo-cases-button';casesButton.id='demo-cases-button';casesButton.type='button';casesButton.textContent='Mes dossiers';casesButton.onclick=()=>demoShowCases();document.querySelector('.gbot-topbar-right').prepend(casesButton);
 const updateCaseLabel=()=>{casesButton.textContent=({fr:'Mes dossiers',en:'My cases',zh:'我的办件'})[GBOT_ENGINE.lang]||'Mes dossiers';};
 selector.addEventListener('change',()=>setTimeout(updateCaseLabel,0));
 selector.value=new URLSearchParams(location.search).get('ui_lang')||sessionStorage.getItem('togo-govbot-language')||'en';
 sessionStorage.setItem('togo-govbot-language',selector.value);
 gbotSyncLang(selector.value);
 selector.addEventListener('change',()=>{sessionStorage.setItem('togo-govbot-language',selector.value);gbotSyncLang(selector.value);});
 function open(){toggleChatbot(true);gbotInit();gbotSetConversationLanguage(GBOT_ENGINE.lang);updateCaseLabel();document.getElementById('gbot-chat-input')?.focus();}
 document.querySelector('.chatbot-close').addEventListener('click',()=>parent.postMessage({type:'govbot:close'},location.origin));
 document.addEventListener('keydown',event=>{if(event.key==='Escape')parent.postMessage({type:'govbot:close'},location.origin);});
 addEventListener('message',event=>{if(event.source===parent&&event.origin===location.origin&&event.data?.type==='govbot:open')open();});
 open();
 if(new URLSearchParams(location.search).get('seat')==='1'){const bridge=document.createElement('script');bridge.src='/govbot/seat-bridge.js';document.body.append(bridge);}
})();
