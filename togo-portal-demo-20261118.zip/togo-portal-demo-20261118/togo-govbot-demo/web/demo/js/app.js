
const translations = window.APP_TRANSLATIONS;
const services = window.APP_SERVICES;

let currentLang = 'en';
let currentService = 'hygiene';
let currentOfficerService = 'hygiene';
let currentOfficerTab = 'pre';
let currentAdminService = 'hygiene';

const caseData = [
  {id:'CASE-2026-00128', serviceId:'hygiene', applicant:'Sara Trading Co.', submittedAt:'2026-03-27 09:25', aiScore:98, issues:1},
  {id:'CASE-2026-00111', serviceId:'birth', applicant:'Layla Hassan', submittedAt:'2026-03-25 14:10', aiScore:97, issues:0},
  {id:'CASE-2026-00097', serviceId:'idcard', applicant:'Daniel Pereira', submittedAt:'2026-03-24 11:00', aiScore:95, issues:0},
  {id:'CASE-2026-00083', serviceId:'company', applicant:'NovaLink Trading Limited', submittedAt:'2026-03-22 16:45', aiScore:96, issues:0},
  {id:'CASE-2026-00066', serviceId:'grant', applicant:'Maria João', submittedAt:'2026-03-21 08:30', aiScore:92, issues:1},
  {id:'CASE-2026-00040', serviceId:'school', applicant:'Ana Fernandes', submittedAt:'2026-03-19 10:05', aiScore:99, issues:0}
];

function tt(k){ return (translations[currentLang] && translations[currentLang][k]) || (translations.en && translations.en[k]) || k; }
function mapText(map){ return (map && (map[currentLang] || map.en)) || ''; }
function serviceTitle(key){ return mapText(services[key].title); }
function serviceDesc(key){ return mapText(services[key].desc); }
function serviceAgency(key){ return mapText(services[key].agency); }
function serviceOutput(key){ return mapText(services[key].output); }
function mats(key){ return services[key].materials || []; }
function selectedCase(){ return caseData.find(c => c.serviceId === currentOfficerService) || caseData[0]; }

function translateServiceTime(raw){
  const map = {
    '2 Working Days':'time_2_days',
    '3 Working Days':'time_3_days',
    '4 Working Days':'time_4_days',
    '5 Working Days':'time_5_days',
    '7 Working Days':'time_7_days',
    '10 Working Days':'time_10_days'
  };
  return tt(map[raw] || raw);
}
function translateServiceFee(raw){
  if(raw === 'No Fee') return tt('fee_none');
  return raw;
}


function applyTranslations(){
  document.querySelectorAll('[data-i18n]').forEach(el => el.textContent = tt(el.dataset.i18n));
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => el.placeholder = tt(el.dataset.i18nPlaceholder));
  const rs = document.getElementById('roleSelect');
  rs.options[0].text = tt('business'); rs.options[1].text = tt('citizen'); rs.options[2].text = tt('officer'); rs.options[3].text = tt('admin');
  document.title = tt('portal_name');
}
function setLanguage(lang){
  currentLang = lang;
  if(typeof gbotSyncLang==="function") gbotSyncLang(lang);
  document.documentElement.lang = lang;
  document.body.dir = lang === 'ar' ? 'rtl' : 'ltr';
  applyTranslations();
  renderServiceCards(); renderDashboard(); renderCitizenService(); renderOfficer(); renderAdmin(); renderOfficerDecisionPanel(); initChatbot();
}
function hideAllPages(){ document.querySelectorAll('.page').forEach(p => p.classList.add('hidden')); }
function openPage(id){ hideAllPages(); document.getElementById(id).classList.remove('hidden'); window.scrollTo({top:0, behavior:'smooth'}); }
function goHome(){ openPage('homePage'); }
function openLogin(){
  const role = (document.getElementById('roleSelect')||{}).value || 'citizen';
  if(role==='business'){
    setBizLoginTab('company');
    openPage('bizLoginPage');
  } else {
    openPage('loginPage');
  }
}

function setBizLoginTab(tab){
  const panelIds = {company:'bizCompanyPanel', etoken:'bizEtokenPanel', mobile:'bizMobilePanel'};
  const btnIds   = {company:'bizTabCompany', etoken:'bizTabEtoken', mobile:'bizTabMobile'};
  Object.keys(panelIds).forEach(t=>{
    const panel = document.getElementById(panelIds[t]);
    const btn   = document.getElementById(btnIds[t]);
    if(panel) panel.classList.toggle('hidden', tab!==t);
    if(btn)   btn.classList.toggle('active-tab', tab===t);
  });
}
function simulateBizEtoken(){
  const el=document.getElementById('bizEtokenStatus');
  if(el) el.textContent = tt('biz_etoken_scanning')||'Authenticating…';
  setTimeout(()=>{
    if(el) el.textContent = '✅ ' + (tt('face_auth_success')||'Authenticated successfully');
    setTimeout(()=>openPage('mfaPage'), 600);
  }, 1400);
}

function setLoginTab(tab){
  const panelIds = {mobile:'mobileLoginPanel', nid:'nidLoginPanel', face:'faceLoginPanel'};
  const btnIds   = {mobile:'tabMobile', nid:'tabNid', face:'tabFace'};
  Object.keys(panelIds).forEach(t=>{
    const panel = document.getElementById(panelIds[t]);
    const btn   = document.getElementById(btnIds[t]);
    if(panel) panel.classList.toggle('hidden', tab!==t);
    if(btn)   btn.classList.toggle('active-tab', tab===t);
  });
  window._loginTab = tab;
}
function sendOTP(){}
function verifyOTP(){ openDashboard(); }
function proceedToMFA(){ openPage('mfaPage'); }
function verifyMFA(){
  const v=(document.getElementById('mfaInput').value||'').trim();
  if(!v || v==='246810'){ openDashboard(); } else { alert(tt('invalid_otp')); }
}
function simulateFaceAuth(){
  const el=document.getElementById('faceStatus');
  el.textContent='Scanning…';
  setTimeout(()=>{ el.textContent='✅ '+tt('face_auth_success'); setTimeout(()=>openPage('mfaPage'),600); },1400);
}
function openRegister(){ openPage('registerPage'); goRegStep(1); }
function goRegStep(n){
  [1,2,3,4].forEach(i=>{
    document.getElementById('regStep'+i).classList.toggle('hidden', i!==n);
    const ind=document.getElementById('regStep'+i+'ind');
    if(ind){ ind.style.background = i===n?'var(--primary)':'var(--surface)'; ind.style.color=i===n?'#fff':'var(--muted)'; }
  });
}
function completeRegistration(){ openPage('registerSuccessPage'); }
function openDashboard(){
  document.getElementById('dashStatus').textContent = tt('dashboard_auth');
  renderDashboard(); openPage('dashboardPage');
  // Switch header from sign-in to user chip
  const signInBtn = document.getElementById('headerSignInBtn');
  const userChip  = document.getElementById('headerUserChip');
  const roleLabel = document.getElementById('headerUserRole');
  if(signInBtn) signInBtn.classList.add('hidden');
  if(userChip)  { userChip.classList.remove('hidden'); userChip.style.display='flex'; }
  const role = (document.getElementById('roleSelect')||{}).value||'citizen';
  const roleNames={citizen:tt('citizen')||'Citizen',business:tt('business')||'Business',officer:tt('officer')||'Officer',admin:tt('admin')||'Admin'};
  if(roleLabel) roleLabel.textContent = roleNames[role]||role;
  window._loggedIn = true;
}
function signOut(){
  window._loggedIn = false;
  const signInBtn = document.getElementById('headerSignInBtn');
  const userChip  = document.getElementById('headerUserChip');
  if(signInBtn) signInBtn.classList.remove('hidden');
  if(userChip)  { userChip.classList.add('hidden'); userChip.style.display='none'; }
  goHome();
}

function renderDashboard(){
  document.getElementById('dashItem1').textContent = serviceTitle('hygiene');
  document.getElementById('dashItem2').textContent = serviceTitle('idcard');
  document.getElementById('dashItem3').textContent = serviceTitle('birth');
  const actionEl = document.getElementById('dashItem1Action');
  if(actionEl) actionEl.textContent = serviceTitle('hygiene') + ' · HYGIENE-2026-004182';
  const issuedEl = document.getElementById('dashIssuedTitle');
  if(issuedEl) issuedEl.textContent = serviceTitle('birth');
}
function quickSearch(q){ document.getElementById('homeSearch').value = q; renderServiceCards(); }
function renderServiceCards(){
  const q=(document.getElementById('homeSearch').value||'').toLowerCase(); const grid=document.getElementById('serviceGrid'); grid.innerHTML='';
  const role=(document.getElementById('roleSelect')||{}).value||'citizen';
  const BIZ_CATS=['business_cat','health'];
  const _allKeys=Object.keys(services);
  const _filtered=_allKeys.filter(key=>{
    const title=serviceTitle(key),desc=serviceDesc(key);
    const catMatch = role==='business' ? BIZ_CATS.includes(services[key].category_key) : true;
    return catMatch && (!q||(title.toLowerCase().includes(q)||desc.toLowerCase().includes(q)));
  });
  const _showAll = q || (role==='business' && _filtered.length<=4);
  (_filtered.length>6&&!_showAll?_filtered.slice(0,6):_filtered).forEach(key=>{
    const s=services[key], title=serviceTitle(key), desc=serviceDesc(key);
    if(false) return;
    const el=document.createElement('button'); el.className='service-card';
    el.onclick=()=>{ currentService=key; renderCitizenService(); openPage('servicePage'); };
    el.innerHTML=`<div class="card-icon">${s.icon}</div><div class="service-top"><div><div class="service-title">${title}</div><div class="small muted">${tt(s.category_key)}</div></div><span class="fee-pill">${s.fee}</span></div><div class="small muted">⏱ ${translateServiceTime(s.time)}</div><p>${desc}</p>`;
    grid.appendChild(el);
  });
  if(_filtered.length>6&&!q){ const more=document.createElement('div'); more.style.cssText='grid-column:1/-1;text-align:center;padding:4px 0'; more.innerHTML=`<button class="ghost" onclick="document.getElementById('homeSearch').value=' ';renderServiceCards()" style="font-size:13px">${tt('see_all_services')||'See all services'} (${_filtered.length})</button>`; grid.appendChild(more); }
}
function showStep(id){
  ['serviceInfoStep','guidanceStep','formStep','aiStep','paymentStep','pendingApprovalStep','successStep'].forEach(x=>document.getElementById(x).classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
  const stepOrder={'serviceInfoStep':-1,'guidanceStep':0,'formStep':1,'aiStep':2,'paymentStep':3,'pendingApprovalStep':3,'successStep':3};
  const activeIdx = stepOrder[id] ?? -1;
  const stepEls = document.querySelectorAll('#servicePage .step');
  stepEls.forEach((el,i)=>{ el.classList.toggle('active-step', i===activeIdx); el.classList.toggle('done-step', i<activeIdx); });
  const nextLabels={guidanceStep:tt('guidance'),formStep:tt('application_form'),aiStep:tt('ai_inspection'),paymentStep:tt('online_payment'),successStep:tt('submission_success')};
  const nextBtn = document.querySelector('#servicePage .actions button.primary');
}
function renderCitizenService(){
  const s=services[currentService];
  document.getElementById('svcBadge').textContent=tt('citizen');
  document.getElementById('svcTitle').textContent=serviceTitle(currentService);
  document.getElementById('svcDesc').textContent=serviceDesc(currentService);
  document.getElementById('svcTime').textContent=translateServiceTime(s.time); document.getElementById('svcFee').textContent=translateServiceFee(s.fee); document.getElementById('svcAgency').textContent=serviceAgency(currentService); document.getElementById('svcOutput').textContent=serviceOutput(currentService);
  document.getElementById('sumAgency').textContent=serviceAgency(currentService); document.getElementById('sumTime').textContent=translateServiceTime(s.time); document.getElementById('sumFee').textContent=translateServiceFee(s.fee); document.getElementById('sumOutput').textContent=serviceOutput(currentService);
  document.getElementById('svcFinalStep').textContent=s.paid?tt('online_payment'):tt('submit_application');
  document.getElementById('recommendationText').textContent=serviceTitle(currentService);
  document.getElementById('payFee').textContent=translateServiceFee(s.fee); document.getElementById('payTotal').textContent=translateServiceFee(s.fee);
  document.getElementById('paymentFields').innerHTML=getPaymentFields(currentService, 'card');
  renderMaterials(); renderGuidance(); renderForm();
  showStep('serviceInfoStep');
}

function materialUiMeta(serviceKey){
  const map = {
    hygiene: {
      mat_business_cert:{mode:'hybrid', source:'source_business_registry', status:'retrieved', updated:'2026-03-18', multi:false},
      mat_kitchen_plan:{mode:'manual', source:'', status:'pending', updated:'', multi:false},
      mat_food_safety:{mode:'manual', source:'', status:'pending', updated:'', multi:false},
      mat_staff_health:{mode:'manual', source:'', status:'pending', updated:'', multi:true},
      mat_waste_agreement:{mode:'manual', source:'', status:'pending', updated:'', multi:false}
    },
    birth: {
      mat_birth_notice:{mode:'manual', source:'', status:'pending', updated:'', multi:false},
      mat_parent_id:{mode:'hybrid', source:'source_identity_registry', status:'retrieved', updated:'2026-03-09', multi:false},
      mat_marriage_cert:{mode:'auto', source:'source_civil_registry', status:'retrieved', updated:'2025-12-02', multi:false},
      mat_birth_place_proof:{mode:'auto', source:'source_civil_registry', status:'retrieved', updated:'2026-03-21', multi:false}
    },
    idcard: {
      mat_prev_id:{mode:'auto', source:'source_identity_registry', status:'retrieved', updated:'2025-08-11', multi:false},
      mat_address_proof:{mode:'manual', source:'', status:'pending', updated:'', multi:false},
      mat_citizenship:{mode:'auto', source:'source_civil_registry', status:'retrieved', updated:'2026-02-03', multi:false},
      mat_portrait:{mode:'manual', source:'', status:'pending', updated:'', multi:false}
    },
    company: {
      mat_company_name:{mode:'manual', source:'', status:'pending', updated:'', multi:false},
      mat_shareholder:{mode:'manual', source:'', status:'pending', updated:'', multi:true},
      mat_registered_address:{mode:'manual', source:'', status:'pending', updated:'', multi:false},
      mat_articles:{mode:'manual', source:'', status:'pending', updated:'', multi:false}
    },
    grant: {
      mat_applicant_id:{mode:'auto', source:'source_identity_registry', status:'retrieved', updated:'2026-01-13', multi:false},
      mat_household_record:{mode:'auto', source:'source_social_registry', status:'retrieved', updated:'2026-03-07', multi:false},
      mat_income:{mode:'manual', source:'', status:'pending', updated:'', multi:true},
      mat_vulnerability:{mode:'manual', source:'', status:'pending', updated:'', multi:false}
    },
    school: {
      mat_learner_birth:{mode:'auto', source:'source_civil_registry', status:'retrieved', updated:'2026-01-25', multi:false},
      mat_guardian_id:{mode:'auto', source:'source_identity_registry', status:'retrieved', updated:'2026-02-14', multi:false},
      mat_residence:{mode:'manual', source:'', status:'pending', updated:'', multi:false},
      mat_school_record:{mode:'hybrid', source:'source_education_registry', status:'retrieved', updated:'2025-12-19', multi:false}
    }
  };
  return (map[serviceKey] || {});
}
function renderMaterialCard(key, name, desc, idx, serviceKey, isPreview=false){
  const meta = materialUiMeta(serviceKey)[key] || {mode:'manual', source:'', status:'pending', updated:'', multi:false};
  const icon=['📄','🆔','🏢','📷','🧾'][idx%5];
  const req = idx < 2;
  const reqTag = req ? tt('required') : tt('optional');
  const sourceText = meta.source ? tt(meta.source) : '';
  const statusClass = meta.status === 'retrieved' ? 'retrieved' : (meta.status === 'uploaded' ? 'uploaded' : 'pending');
  const statusText = meta.status === 'retrieved' ? tt('status_retrieved') : (meta.status === 'uploaded' ? tt('status_uploaded') : tt('status_pending'));
  const sourceMode = meta.mode === 'auto' ? tt('source_auto') : (meta.mode === 'hybrid' ? tt('source_hybrid') : tt('source_manual'));

  if(isPreview){
    return `<div class="material-card preview-only">
      <div class="material-top">
        <div style="display:flex;gap:12px;align-items:flex-start">
          <div class="doc-icon">${icon}</div>
          <div>
            <div><strong>${name}</strong></div>
            <div class="small muted">${desc}</div>
          </div>
        </div>
      </div>
      <div class="material-actions">
        <button class="ghost" onclick="openDoc('${key}')">${tt('view_document')}</button>
      </div>
    </div>`;
  }

  let actions = `<button class="ghost" onclick="openDoc('${key}')">${tt('view_document')}</button>`;
  if(meta.mode === 'manual'){
    actions = `<button class="ghost" onclick="simulateUpload('${key}')">${tt('upload_document')}</button>` + actions;
  } else if(meta.mode === 'hybrid'){
    actions = actions + `<button class="secondary" onclick="simulateUpload('${key}')">${tt('replace_document')}</button>`;
  }
  const helper = meta.mode === 'auto' ? tt('prefilled_from_records') : (meta.mode === 'hybrid' ? tt('replace_with_new') : (req ? tt('upload_required') : tt('upload_optional')));
  const extraMeta = [];
  extraMeta.push(`<span class="meta-chip secondary">${reqTag}</span>`);
  extraMeta.push(`<span class="meta-chip">${sourceMode}</span>`);
  if(meta.multi) extraMeta.push(`<span class="meta-chip secondary">${tt('multi_file_allowed')}</span>`);
  if(sourceText) extraMeta.push(`<span class="meta-chip secondary">${tt('source_label')}: ${sourceText}</span>`);
  if(meta.updated) extraMeta.push(`<span class="meta-chip secondary">${tt('last_updated_label')}: ${meta.updated}</span>`);
  return `<div class="material-card">
    <div class="material-top">
      <div style="display:flex;gap:12px;align-items:flex-start">
        <div class="doc-icon">${icon}</div>
        <div>
          <div><strong>${name}</strong></div>
          <div class="small muted">${desc}</div>
        </div>
      </div>
      <div class="material-status ${statusClass}">${statusText}</div>
    </div>
    <div class="material-meta">${extraMeta.join('')}</div>
    <div class="material-note">${helper}${(meta.mode !== 'manual') ? ` <span class="tooltip-wrap"><span class="tooltip-icon">i</span><span class="tooltip-bubble">${tt('registry_tooltip')}</span></span>` : ''}</div>
    <div class="material-actions">${actions}</div>
  </div>`;
}
function simulateUpload(key){
  // Show a styled upload modal instead of browser alert
  const backdrop = document.getElementById('uploadModalBackdrop');
  const titleEl  = document.getElementById('uploadModalTitle');
  const nameEl2  = document.getElementById('uploadModalName');
  const hintEl   = document.getElementById('uploadModalHint');
  if(!backdrop) return;
  // get the material name from the DOM card
  const card = document.querySelector(`[data-material-row="${key}"]`);
  const matName = card ? (card.querySelector('strong') || {}).textContent || key : key;
  const isRequired = card ? card.querySelector('.req-tag.required') !== null : true;
  titleEl.textContent = tt('upload_modal_title') || 'Upload Document';
  nameEl2.textContent = matName;
  hintEl.textContent = isRequired
    ? (tt('upload_required_hint') || 'This document is required. Only PDF or JPG files under 10 MB are accepted.')
    : (tt('upload_optional_hint') || 'This document is optional but may strengthen your application.');
  document.getElementById('uploadModalKey').value = key;
  document.getElementById('uploadModalFileRow').innerHTML = '';
  backdrop.style.display = 'flex';
}
function confirmUpload(){
  const key = document.getElementById('uploadModalKey').value;
  const fileInput = document.getElementById('uploadModalFileInput');
  const fileName = fileInput.files && fileInput.files[0]
    ? fileInput.files[0].name
    : (tt('upload_demo_filename') || 'document_scan_2026.pdf');
  // Update the material card status
  const card = document.querySelector(`[data-material-row="${key}"]`);
  if(card){
    const statusEl = card.querySelector('.material-status');
    if(statusEl){ statusEl.className='material-status uploaded'; statusEl.textContent=tt('status_uploaded'); }
    // show filename
    let fnEl = card.querySelector('.upload-filename');
    if(!fnEl){ fnEl=document.createElement('div'); fnEl.className='upload-filename small muted'; card.querySelector('.material-actions').before(fnEl); }
    fnEl.innerHTML = '📎 '+fileName;
  }
  closeUploadModal();
}
function closeUploadModal(){
  const backdrop = document.getElementById('uploadModalBackdrop');
  if(backdrop) backdrop.style.display='none';
}

function renderMaterials(){
  const mw = document.getElementById('materialsWrap');
  const uw = document.getElementById('uploadsWrap');
  if(mw) mw.innerHTML = '';
  if(uw) uw.innerHTML = '';

  const keyMap = {
    hygiene:[['mat_business_cert','mat_business_cert_desc'],['mat_kitchen_plan','mat_kitchen_plan_desc'],['mat_food_safety','mat_food_safety_desc'],['mat_staff_health','mat_staff_health_desc'],['mat_waste_agreement','mat_waste_agreement_desc']],
    birth:[['mat_birth_notice','mat_birth_notice_desc'],['mat_parent_id','mat_parent_id_desc'],['mat_marriage_cert','mat_marriage_cert_desc'],['mat_birth_place_proof','mat_birth_place_proof_desc']],
    idcard:[['mat_prev_id','mat_prev_id_desc'],['mat_address_proof','mat_address_proof_desc'],['mat_citizenship','mat_citizenship_desc'],['mat_portrait','mat_portrait_desc']],
    company:[['mat_company_name','mat_company_name_desc'],['mat_shareholder','mat_shareholder_desc'],['mat_registered_address','mat_registered_address_desc'],['mat_articles','mat_articles_desc']],
    grant:[['mat_applicant_id','mat_applicant_id_desc'],['mat_household_record','mat_household_record_desc'],['mat_income','mat_income_desc'],['mat_vulnerability','mat_vulnerability_desc']],
    school:[['mat_learner_birth','mat_learner_birth_desc'],['mat_guardian_id','mat_guardian_id_desc'],['mat_residence','mat_residence_desc'],['mat_school_record','mat_school_record_desc']]
  };

  if(mw){
    mw.insertAdjacentHTML('beforeend',
      `<div class="requirement-preview-head">
        <div><strong>${tt('pre_application_requirement')}</strong><div class="small muted">${tt('pre_application_note')}</div></div>
        <span class="status-tag">${tt('preview_only')}</span>
      </div>`
    );
  }

  (keyMap[currentService] || []).forEach((pair, idx) => {
    const key = pair[0], name = tt(pair[0]), desc = tt(pair[1]);
    if(mw){
      mw.insertAdjacentHTML('beforeend', `<div data-material-row="preview-${key}">${renderMaterialCard(key, name, desc, idx, currentService, true)}</div>`);
    }
    if(uw){
      uw.insertAdjacentHTML('beforeend', `<div data-material-row="${key}">${renderMaterialCard(key, name, desc, idx, currentService, false)}</div>`);
    }
  });
}
function renderGuidance(){
  const k=currentService; const t=translatedGuidanceLabelMap(); let left='', right='';
  if(k==='hygiene'){
    left=`<label>${t.typeEst||'Type of establishment'}</label><select class="select"><option>${tt('option_restaurant')}</option><option>${tt('option_cafe')}</option><option>${tt('option_stall')}</option><option>${tt('option_catering')}</option></select><label>${t.onsite||'Will food be prepared on-site?'} <span style="color:#b91c1c;font-size:11px">*</span></label><div class="option-row"><label class="option-pill"><input type="radio" name="g-onsite" checked> ${tt('yes')}</label><label class="option-pill"><input type="radio" name="g-onsite"> ${tt('no')}</label></div><label>${t.dailyVol||'Expected daily customer volume'}</label><select class="select"><option>${tt('option_below_50')}</option><option>${tt('option_50_150')}</option><option>${tt('option_151_300')}</option><option>${tt('option_above_300')}</option></select>`;
    right=`<label>${t.foodCat||'Primary food category'}</label><select class="select"><option>${tt('option_cooked_meals')}</option><option>${tt('option_beverages')}</option><option>${tt('option_bakery')}</option><option>${tt('option_mixed_fnb')}</option></select><label>${t.waste||'Waste oil / food waste management arrangement'}</label><select class="select"><option>${tt('option_licensed_collector')}</option><option>${tt('option_municipal_collection')}</option><option>${tt('option_pending_arrangement')}</option></select><label>${t.collect||'Result collection preference'}</label><select class="select"><option>${tt('option_download_cert')}</option><option>${tt('option_collect_center')}</option></select>`;
  } else if(k==='birth'){
    left=`<label>${t.appType||tt('key_application_type')}</label><select class="select"><option>${formMock('first_reg')}</option><option>${formMock('cert_copy')}</option></select><label>${t.placeBirth||'Place of birth'}</label><select class="select"><option>${tt('option_public_hospital')}</option><option>${tt('option_private_clinic')}</option><option>${tt('option_home_birth')}</option></select>`;
    right=`<label>${t.relationship||'Applicant relationship'}</label><select class="select"><option>${tt('option_mother')}</option><option>${tt('option_father')}</option><option>${tt('option_guardian')}</option></select><label>${t.certFormat||'Preferred certificate format'}</label><select class="select"><option>${tt('option_digital_cert')}</option><option>${tt('option_printed_cert')}</option></select>`;
  } else if(k==='idcard'){
    left=`<label>${t.purpose||'Application purpose'}</label><select class="select"><option>${tt('option_first_time')}</option><option>${tt('option_renewal')}</option><option>${tt('option_replacement')}</option></select><label>${t.ageBand||'Age band'}</label><select class="select"><option>${formMock('under_16')}</option><option>16–17</option><option>${formMock('over_18')}</option></select>`;
    right=`<label>${t.delivery||tt('key_delivery_preference')}</label><select class="select"><option>${tt('option_collect_center')}</option><option>${tt('option_postal')}</option></select><label>${t.urgency||'Urgency level'}</label><select class="select"><option>${tt('option_standard')}</option><option>${tt('option_priority')}</option></select>`;
  } else if(k==='company'){
    left=`<label>${t.entity||'Entity type'}</label><select class="select"><option>${tt('option_private_company')}</option><option>${tt('option_public_company')}</option><option>${tt('option_partnership')}</option></select><label>${t.reserve||'Need name reservation?'} <span style="color:#b91c1c;font-size:11px">*</span></label><div class="option-row"><label class="option-pill"><input type="radio" name="g-reserve" checked> ${tt('yes')}</label><label class="option-pill"><input type="radio" name="g-reserve"> ${tt('no')}</label></div>`;
    right=`<label>${t.directors||'Number of directors'}</label><select class="select"><option>1</option><option>2</option><option>3 or more</option></select><label>${t.certDelivery||'Certificate delivery'}</label><select class="select"><option>${tt('option_digital_cert')}</option><option>${formMock('printed_cert')}</option></select>`;
  } else if(k==='grant'){
    left=`<label>${t.basis||'Primary basis of application'}</label><select class="select"><option>${tt('option_low_income')}</option><option>${tt('option_disability')}</option><option>${tt('option_older_person')}</option></select><label>${t.employment||'Current employment status'}</label><select class="select"><option>${tt('option_employed')}</option><option>${tt('option_informal')}</option><option>${tt('option_unemployed')}</option></select>`;
    right=`<label>${t.dependants||'Household dependants'}</label><select class="select"><option>${tt('option_none')}</option><option>${tt('option_1_2')}</option><option>${tt('option_3_4')}</option></select><label>${t.channel||'Preferred payment channel'}</label><select class="select"><option>${tt('option_bank_account')}</option><option>${tt('option_mobile_wallet')}</option><option>${tt('option_cash_collection')}</option></select>`;
  } else {
    left=`<label>${t.appType||tt('key_application_type')}</label><select class="select"><option>${tt('option_new_admission')}</option><option>${tt('option_transfer_request')}</option></select><label>${t.eduLevel||'Education level'}</label><select class="select"><option>${tt('option_preprimary')}</option><option>${tt('option_primary')}</option><option>${tt('option_lower_secondary')}</option></select>`;
    right=`<label>${t.intake||'Preferred intake period'}</label><select class="select"><option>${tt('option_current_term')}</option><option>${tt('option_next_term')}</option><option>${tt('option_next_year')}</option></select><label>${t.collect||'Result collection preference'}</label><select class="select"><option>${formMock('digital_enrol')}</option><option>${tt('option_collect_office')}</option></select>`;
  }
  document.getElementById('guideLeft').innerHTML=left; document.getElementById('guideRight').innerHTML=right;
}
function formMock(key){
  const MOCK_DATA = {
    // Hygiene permit
    'biz_name':    {en:'Green Garden Restaurant Ltd.',zh:'绿园餐厅有限公司',fr:'Green Garden Restaurant SARL',ar:'شركة Green Garden للمطاعم ذ.م.م',pt:'Green Garden Restaurant Lda.'},
    'biz_address': {en:'12 Central Market Avenue, Capital City',zh:'中央市场大道12号，首都',fr:'12 avenue du Marché Central, Capitale',ar:'12 شارع السوق المركزي، العاصمة',pt:'12 Avenida do Mercado Central, Capital'},
    'kitchen_desc':{en:'Dedicated receiving area, cold storage, hot kitchen, hand-washing station, dishwashing area, and separate waste holding point.',zh:'专设收货区、冷藏区、热厨区、洗手台、洗碗区和独立废弃物存放点。',fr:'Zone de réception dédiée, stockage froid, cuisine chaude, station lavage mains, plonge, et point de déchets séparé.',ar:'منطقة استقبال مخصصة، تخزين بارد، مطبخ ساخن، محطة غسيل يدين، منطقة جلي، ونقطة تخزين نفايات منفصلة.',pt:'Área de receção dedicada, armazenamento frio, cozinha quente, estação de lavagem de mãos, zona de lavagem e ponto de resíduos separado.'},
    // Birth
    'child_name':  {en:'Nadia Amina Yusuf',zh:'娜迪娅·阿米娜·优素福',fr:'Nadia Amina Yusuf',ar:'ناديا أمينة يوسف',pt:'Nadia Amina Yusuf'},
    'hospital':    {en:'Capital City General Hospital',zh:'首都综合医院',fr:'Hôpital général de la Capitale',ar:'مستشفى العاصمة العام',pt:'Hospital Geral da Capital'},
    'mother_name': {en:'Amina Yusuf',zh:'阿米娜·优素福',fr:'Amina Yusuf',ar:'أمينة يوسف',pt:'Amina Yusuf'},
    'father_name': {en:'Karim Yusuf',zh:'卡里姆·优素福',fr:'Karim Yusuf',ar:'كريم يوسف',pt:'Karim Yusuf'},
    // ID card / general
    'person_name': {en:'Karim Yusuf',zh:'卡里姆·优素福',fr:'Karim Yusuf',ar:'كريم يوسف',pt:'Karim Yusuf'},
    // Company
    'co_name':     {en:'Green Garden Hospitality Ltd.',zh:'绿园酒店管理有限公司',fr:'Green Garden Hospitality SARL',ar:'Green Garden للضيافة ذ.م.م',pt:'Green Garden Hospitality Lda.'},
    'co_activity': {en:'Restaurant and café operations',zh:'餐厅及咖啡馆运营',fr:'Exploitation de restaurant et café',ar:'تشغيل مطاعم ومقاهٍ',pt:'Operação de restaurante e café'},
    'shareholders':{en:'Karim Yusuf - 60%; Amina Yusuf - 40%',zh:'卡里姆·优素福 - 60%；阿米娜·优素福 - 40%',fr:'Karim Yusuf - 60% ; Amina Yusuf - 40%',ar:'كريم يوسف - 60%؛ أمينة يوسف - 40%',pt:'Karim Yusuf - 60%; Amina Yusuf - 40%'},
    // Grant
    'grant_name':  {en:'Fatima Ndaye',zh:'法蒂玛·恩达伊',fr:'Fatima Ndaye',ar:'فاطمة نداي',pt:'Fatima Ndaye'},
    'grant_addr':  {en:'55 Hill View Settlement, North District',zh:'北区山景定居点55号',fr:'55 quartier Hill View, District Nord',ar:'55 تجمع هيل فيو، المنطقة الشمالية',pt:'55 Bairro Hill View, Distrito Norte'},
    'grant_income':{en:'USD 85',zh:'85美元',fr:'85 USD',ar:'85 دولاراً',pt:'USD 85'},
    'grant_note':  {en:'Applicant is primary caregiver for three dependants and currently has no formal income.',zh:'申请人是三名受抚养人的主要照料者，目前无正式收入。',fr:'Le demandeur est le principal aidant de trois personnes à charge et n\'a actuellement aucun revenu formel.',ar:'مقدم الطلب هو المعيل الرئيسي لثلاثة معالين وليس لديه دخل رسمي حالياً.',pt:'O requerente é o cuidador principal de três dependentes e não tem rendimento formal atualmente.'},
    // School
    'learner_name':{en:'Nadia Karim Yusuf',zh:'娜迪娅·卡里姆·优素福',fr:'Nadia Karim Yusuf',ar:'ناديا كريم يوسف',pt:'Nadia Karim Yusuf'},
    'school_note': {en:'Learner is applying for Primary Year 1 and prefers a school within the home catchment area.',zh:'学生申请小学一年级，优先选择住家招生范围内的学校。',fr:'L\'élève postule pour la Primaire Année 1 et préfère une école dans sa zone de recrutement.',ar:'يتقدم الطالب للصف الأول الابتدائي ويفضل مدرسة ضمن نطاق السكن.',pt:'O aluno candidata-se ao 1.º ano do ensino primário e prefere uma escola na área de captação da residência.'},
    // Guidance dropdowns
    'first_reg':   {en:'First-time registration',zh:'首次登记',fr:'Première inscription',ar:'التسجيل الأول',pt:'Primeiro registo'},
    'cert_copy':   {en:'Certified copy / re-issue',zh:'认证副本/补发',fr:'Copie certifiée / réémission',ar:'نسخة مصدقة / إعادة إصدار',pt:'Cópia certificada / reemissão'},
    'under_16':    {en:'Under 16',zh:'16岁以下',fr:'Moins de 16 ans',ar:'دون 16 سنة',pt:'Menos de 16'},
    'over_18':     {en:'18 and above',zh:'18岁及以上',fr:'18 ans et plus',ar:'18 سنة فأكثر',pt:'18 e acima'},
    'printed_cert':{en:'Printed Certificate',zh:'纸质证书',fr:'Certificat imprimé',ar:'شهادة مطبوعة',pt:'Certificado impresso'},
    'digital_enrol':{en:'Digital Enrollment Notice',zh:'电子入学通知书',fr:'Avis d\'inscription numérique',ar:'إشعار التسجيل الرقمي',pt:'Aviso de matrícula digital'},
  };
  const row = MOCK_DATA[key];
  if(!row) return key;
  return row[currentLang] || row.en;
}
function renderForm(){
  const k=currentService; const t=translatedFormLabelMap(); let left='', right='';
  const reqStar = '<span style="color:#b91c1c;font-size:11px;margin-left:3px">*</span>';
  const optTag = `<span style="font-size:11px;color:#667085;font-weight:400;margin-left:6px">(${tt('optional')||'Optional'})</span>`;
  const grpHead = (label,color='#1f5fae') => `<div style="font-size:12px;font-weight:700;color:${color};background:#f0f5ff;border-radius:8px;padding:6px 10px;margin-bottom:4px">${label}</div>`;
  if(k==='hygiene'){
    left=`<div class="panel">${grpHead(tt('form_group_business')||'Business Details')}<label>${t.businessName||tt('key_business_name')}${reqStar}</label><input class="input" value="${formMock('biz_name')}"><label>${t.businessNo||tt('key_business_registration_number')}</label><input class="input" value="BR-2026-44182"><label>${(translatedGuidanceLabelMap().typeEst)||'Type of Establishment'}</label><select class="select"><option>${tt('option_restaurant')}</option><option>${tt('option_cafe')}</option><option>${tt('option_stall')}</option><option>${tt('option_catering')}</option></select><label>${t.operatingAddress||'Operating Address'}</label><input class="input" value="${formMock('biz_address')}"></div>`;
    right=`<div class="panel">${grpHead(tt('form_group_operations')||'Operating Details')}<label>${(translatedGuidanceLabelMap().foodCat)||'Primary food category'}${reqStar}</label><select class="select"><option>${tt('option_mixed_fnb')}</option><option>${tt('option_cooked_meals')}</option><option>${tt('option_beverages')}</option></select><label>${t.foodHandlers||'Number of food handlers'}</label><input class="input" value="12"><label>${t.kitchenDesc||'Kitchen layout description'}</label><textarea class="textarea">${formMock('kitchen_desc')}</textarea></div>`;
  } else if(k==='birth'){
    left=`<div class="panel"><label>${t.childName||tt('key_child_full_name')}</label><input class="input" value="${formMock('child_name')}"><label>${t.dob||tt('key_date_of_birth')}</label><input class="input" value="2026-02-14"><label>${t.birthPlace||tt('key_place_of_birth')}</label><input class="input" value="${formMock('hospital')}"></div>`;
    right=`<div class="panel"><label>${t.mother||"Mother's Full Name"}</label><input class="input" value="${formMock('mother_name')}"><label>${t.father||"Father's Full Name"}</label><input class="input" value="${formMock('person_name')}"><label>${t.district||'Registry District'}</label><select class="select"><option>${tt('option_capital_district')}</option><option>${tt('option_north_district')}</option></select></div>`;
  } else if(k==='idcard'){
    left=`<div class="panel"><label>${t.fullName||'Full Name'}</label><input class="input" value="${formMock('person_name')}"><label>${t.dob||tt('key_date_of_birth')}</label><input class="input" value="1992-08-21"><label>${t.address||'Current Residential Address'}</label><input class="input" value="${formMock('biz_address')}"></div>`;
    right=`<div class="panel"><label>${(translatedGuidanceLabelMap().purpose)||'Application purpose'}</label><select class="select"><option>${tt('option_renewal')}</option><option>${tt('option_first_time')}</option><option>${tt('option_replacement')}</option></select><label>${t.prevId||'Previous ID Number'}</label><input class="input" value="NID-88211990"><label>${t.deliveryMethod||'Preferred delivery method'}</label><select class="select"><option>${tt('option_collect_center')}</option><option>${tt('option_postal')}</option></select></div>`;
  } else if(k==='company'){
    left=`<div class="panel"><label>${t.proposedName||'Proposed Company Name'}</label><input class="input" value="${formMock('co_name')}"><label>${(translatedGuidanceLabelMap().entity)||'Entity Type'}</label><select class="select"><option>${tt('option_private_company')}</option><option>${tt('option_public_company')}</option></select><label>${t.activity||'Primary Business Activity'}</label><input class="input" value="${formMock('co_activity')}"></div>`;
    right=`<div class="panel"><label>${t.officeAddress||'Registered Office Address'}</label><input class="input" value="${formMock('biz_address')}"><label>${t.director||'Primary Director Name'}</label><input class="input" value="${formMock('person_name')}"><label>${t.shareholding||'Shareholder Structure'}</label><textarea class="textarea">${formMock('shareholders')}</textarea></div>`;
  } else if(k==='grant'){
    left=`<div class="panel"><label>${t.fullName||'Full Name'}</label><input class="input" value="${formMock('grant_name')}"><label>${t.nationalId||'National ID Number'}</label><input class="input" value="ID-99442210"><label>${t.residential||'Residential Address'}</label><input class="input" value="${formMock('grant_addr')}"></div>`;
    right=`<div class="panel"><label>${t.household||'Household Size'}</label><input class="input" value="5"><label>${t.income||'Monthly Household Income'}</label><input class="input" value="${formMock('grant_income')}"><label>${t.support||'Additional supporting explanation'}</label><textarea class="textarea">${formMock('grant_note')}</textarea></div>`;
  } else {
    left=`<div class="panel"><label>${t.learner||'Learner Full Name'}</label><input class="input" value="${formMock('learner_name')}"><label>${t.dob||tt('key_date_of_birth')}</label><input class="input" value="2018-05-11"><label>${t.grade||'Current Grade / Level'}</label><select class="select"><option>${tt('option_primary_year_1')}</option><option>${tt('option_primary_year_2')}</option></select></div>`;
    right=`<div class="panel"><label>${t.guardian||'Parent / Guardian Name'}</label><input class="input" value="${formMock('mother_name')}"><label>${t.school||'Preferred School'}</label><select class="select"><option>${tt('option_school_1')}</option><option>${tt('option_school_2')}</option></select><label>${t.notes||'Additional notes'}</label><textarea class="textarea">${formMock('school_note')}</textarea></div>`;
  }
  document.getElementById('formWrap').innerHTML=left+right;
}
function startAI(){
  renderAIResults(); showStep('aiStep'); document.getElementById('aiResults').classList.add('hidden'); document.getElementById('aiActions').classList.add('hidden');
  const bar=document.getElementById('aiBar'), status=document.getElementById('aiStatus'); bar.style.width='0%';
  const seq=[[22,tt('ai_step1')],[48,tt('ai_step2')],[72,tt('ai_step3')],[100,tt('ai_step4')]];
  let i=0; function tick(){ if(i<seq.length){ bar.style.width=seq[i][0]+'%'; status.textContent=seq[i][1]; i+=1; setTimeout(tick,550);} else { document.getElementById('aiResults').classList.remove('hidden'); document.getElementById('aiActions').classList.remove('hidden'); const btn=document.getElementById('aiNextBtn'); if(services[currentService].paid){ btn.textContent=tt('continue_payment'); btn.onclick=()=>showStep('paymentStep'); } else { btn.textContent=tt('submit_application'); btn.onclick=openSuccess; } } } tick();
}
function choosePayment(method){
  document.querySelectorAll('.pay-choice').forEach(el=>el.classList.remove('selected'));
  document.getElementById('pay-'+method).classList.add('selected');
  const fields = document.getElementById('paymentFields');
  if(fields){ fields.innerHTML = getPaymentFields(currentService, method); }
}
function renderCertificate(ref,title){
  const authority = serviceAgency(currentService || currentOfficerService);
  const holder = selectedCase && !document.getElementById('servicePage').classList.contains('hidden') ? 
    (currentLang==='zh' ? '申请人' : currentLang==='fr' ? 'Demandeur' : currentLang==='ar' ? 'مقدم الطلب' : currentLang==='pt' ? 'Requerente' : 'Applicant')
    : selectedCase().applicant;
  return `<div class="certificate-a4-wrap"><div class="certificate">
    <div class="certificate-head">
      <div>
        <div class="certificate-sub">${tt('certificate_title')}</div>
        <h3 class="certificate-title">${title}</h3>
      </div>
      <div class="qr">
        <svg width="92" height="92" viewBox="0 0 92 92" xmlns="http://www.w3.org/2000/svg" aria-label="${tt('qr_verify')}">
          <rect width="92" height="92" fill="white"/>
          <g fill="#111827">
            <rect x="4" y="4" width="24" height="24"/><rect x="8" y="8" width="16" height="16" fill="white"/><rect x="12" y="12" width="8" height="8"/>
            <rect x="64" y="4" width="24" height="24"/><rect x="68" y="8" width="16" height="16" fill="white"/><rect x="72" y="12" width="8" height="8"/>
            <rect x="4" y="64" width="24" height="24"/><rect x="8" y="68" width="16" height="16" fill="white"/><rect x="12" y="72" width="8" height="8"/>
            <rect x="34" y="8" width="6" height="6"/><rect x="44" y="8" width="6" height="6"/><rect x="54" y="8" width="6" height="6"/>
            <rect x="34" y="18" width="6" height="6"/><rect x="44" y="18" width="16" height="6"/>
            <rect x="34" y="30" width="6" height="6"/><rect x="44" y="30" width="6" height="6"/><rect x="54" y="30" width="6" height="6"/>
            <rect x="32" y="42" width="8" height="8"/><rect x="44" y="42" width="6" height="6"/><rect x="54" y="42" width="12" height="6"/>
            <rect x="34" y="54" width="6" height="6"/><rect x="44" y="54" width="6" height="6"/><rect x="54" y="54" width="6" height="6"/><rect x="64" y="54" width="6" height="6"/>
            <rect x="34" y="66" width="6" height="6"/><rect x="44" y="66" width="16" height="6"/><rect x="64" y="66" width="18" height="6"/>
            <rect x="34" y="78" width="6" height="6"/><rect x="44" y="78" width="6" height="6"/><rect x="56" y="78" width="6" height="6"/><rect x="68" y="78" width="6" height="6"/>
          </g>
        </svg>
      </div>
    </div>
    <div class="certificate-meta">
      <div><span>${tt('certificate_reference')}</span><strong>${ref}</strong></div>
      <div><span>${tt('issue_date')}</span><strong>2026-03-30</strong></div>
      <div><span>${tt('issuing_authority')}</span><strong>${authority}</strong></div>
      <div><span>${tt('certificate_status')}</span><strong>${tt('complete')}</strong></div>
      <div><span>${tt('certificate_holder')}</span><strong>${holder}</strong></div>
      <div><span>${tt('output')}</span><strong>${title}</strong></div>
    </div>
    <div class="certificate-body">
      ${tt('cert_statement_prefix')} <strong>${title}</strong> ${tt('cert_statement_suffix')}
    </div>
    <div class="certificate-body">${tt('verification_note')}</div>
    <div class="certificate-footer">
      <div class="sig-block">
        <svg width="170" height="70" viewBox="0 0 170 70" xmlns="http://www.w3.org/2000/svg" aria-label="${tt('cert_seal')}">
          <circle cx="55" cy="35" r="28" fill="none" stroke="#b91c1c" stroke-width="3"/>
          <circle cx="55" cy="35" r="20" fill="none" stroke="#b91c1c" stroke-width="1.5"/>
          <path d="M45 35l6 6 14-14" fill="none" stroke="#b91c1c" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
          <text x="92" y="30" font-size="10" fill="#b91c1c" font-weight="700">${tt('cert_seal')}</text>
          <text x="92" y="44" font-size="9" fill="#b91c1c">National Service Platform</text>
        </svg>
        <div class="sig-line">${tt('authorized_signature')}</div>
      </div>
      <div class="certificate-verify"><div class="small muted">${tt('qr_verify')}</div></div>
    </div>
  </div></div>`;
}
function openPendingApproval(){
  showStep('pendingApprovalStep');
  const ref=currentService.toUpperCase()+'-2026-004182';
  const el=document.getElementById('pendingRef');
  if(el) el.textContent=ref;
}
function simulateOfficerApproval(){
  const btn=document.querySelector('#pendingApprovalStep .actions .primary');
  if(btn){ btn.textContent=(tt('approving')||'Approving…'); btn.disabled=true; }
  setTimeout(()=>{ openSuccess(); }, 1400);
}

function renderAIResults(){
  const svc = currentService;
  // Services that involve business registration docs — show the name mismatch warning
  const bizServices = ['hygiene','construction','trading'];
  const hasBizMismatch = bizServices.includes(svc);
  // Services with no fee — no payment step, so consistency check always passes
  const isPaid = services[svc] && services[svc].paid;
  const el = document.getElementById('aiResults');
  if(!el) return;

  const passBlock = `<div class="ok">${tt('ai_passed')}</div>`;
  const docCount = (services[svc] && services[svc].materials) ? services[svc].materials.length : 4;

  const consistencyBlock = hasBizMismatch
    ? `<div class="warn">${tt('ai_manual')}</div>
       <div class="small" style="margin-top:8px;padding:8px;background:#fffaeb;border-radius:8px;border:1px solid #fde68a">
         <strong>${tt('ai_issue_doc')}</strong>
         <div class="small muted">${tt('ai_issue_desc')}</div>
       </div>`
    : `${passBlock}<div class="small muted" style="margin-top:6px">${tt('ai_consistency_ok')||'All key data fields are consistent across submitted documents.'}</div>`;

  el.innerHTML = `
    <div class="panel soft">
      <h4>${tt('ai_check_complete')}</h4>
      ${passBlock}
      <div class="small muted" style="margin-top:6px">${tt('ai_complete_detail')}</div>
    </div>
    <div class="panel soft">
      <h4>${tt('ai_check_quality')}</h4>
      ${passBlock}
      <div class="small muted" style="margin-top:6px">${tt('ai_quality_detail')}</div>
    </div>
    <div class="panel soft">
      <h4>${tt('ai_check_consistency')}</h4>
      ${consistencyBlock}
    </div>`;
}

function openSuccess(){
  showStep('successStep');
  const certWrap = document.getElementById('successCertificate');
  certWrap.innerHTML=`<div style="text-align:center;padding:40px 0"><div style="font-size:40px;margin-bottom:12px">🖨️</div><div style="font-weight:600" data-i18n="cert_generating">${tt('cert_generating')||'Generating certificate…'}</div><div class="progress" style="margin:14px 0"><div id="certGenBar" class="bar" style="width:0%"></div></div><div class="small muted" data-i18n="cert_gen_hint">${tt('cert_gen_hint')||'Applying digital seal and issuing authority signature'}</div></div>`;
  let p=0; const barEl=document.getElementById('certGenBar');
  const t=setInterval(()=>{ p+=12; if(barEl) barEl.style.width=Math.min(p,100)+'%'; if(p>=100){ clearInterval(t); _renderSuccessContent(); } }, 180);
}
function _renderSuccessContent(){
  const paid=services[currentService].paid;
  document.getElementById('successTitle').textContent=paid?tt('payment_success'):tt('submission_success');
  document.getElementById('successSummary').textContent=paid?tt('payment_success'):tt('submission_success');
  const ref=currentService.toUpperCase()+'-2026-004182';
  document.getElementById('successRef').textContent=tt('reference')+': '+ref;
  document.getElementById('successStatusText').textContent=tt('status_submitted');
  document.getElementById('successCertificate').innerHTML=renderCertificate(ref, serviceOutput(currentService));
}

function switchRole(role){
  document.getElementById('roleSelect').value=role;
  renderServiceCards();
  // Update header user chip role label if logged in
  if(window._loggedIn){
    const roleLabel=document.getElementById('headerUserRole');
    const roleNames={citizen:tt('citizen')||'Citizen',business:tt('business')||'Business',officer:tt('officer')||'Officer',admin:tt('admin')||'Admin'};
    if(roleLabel) roleLabel.textContent=roleNames[role]||role;
  }
  // Show/hide business hero banner
  const bizBanner=document.getElementById('bizHeroBanner');
  if(bizBanner) bizBanner.classList.toggle('hidden', role!=='business');
  // Update homepage heading
  const heading=document.querySelector('[data-i18n="search_heading"]');
  if(heading) heading.textContent = role==='business' ? (tt('biz_search_heading')||'Business Services Portal') : tt('search_heading');
  const subtext=document.querySelector('[data-i18n="search_text"]');
  if(subtext) subtext.textContent = role==='business' ? (tt('biz_search_text')||'Access licensing, registration, compliance and regulatory services for your business.') : tt('search_text');
  // Update service section title
  const svcHead=document.querySelector('#serviceGrid').previousElementSibling?.querySelector('h2');
  if(svcHead) svcHead.textContent = role==='business' ? (tt('biz_services_heading')||'Business Services') : tt('popular_services');
  document.body.className=document.body.className.replace(/role-\S+/g,'').trim();
  const banner=document.getElementById('roleBanner');
  const icons={citizen:'👤',officer:'🏛️',admin:'⚙️',business:'🏢'};
  const labels={citizen:tt('citizen'),officer:tt('officer'),admin:tt('admin'),business:tt('business')};
  const descs={citizen:tt('role_desc_citizen')||'Citizen Portal',officer:tt('role_desc_officer')||'Officer Review Console',admin:tt('role_desc_admin')||'Administration Console',business:tt('role_desc_business')||'Business Services'};
  if(role==='officer'||role==='admin'){
    document.body.classList.add('role-'+role);
    if(banner){ banner.classList.add('visible'); document.getElementById('roleBannerIcon').textContent=icons[role]; document.getElementById('roleBannerText').textContent=descs[role]; document.getElementById('roleBannerLabel').textContent=labels[role]; }
  } else {
    if(banner) banner.classList.remove('visible');
  }
  if(role==='officer'){ renderOfficer(); openPage('officerPage'); }
  else if(role==='admin'){ renderAdmin(); openPage('adminPage'); }
  else { goHome(); }
}
function renderDocThumb(kind='pdf'){ return `<div class="doc-thumb ${kind}"><div class="doc-top">${kind==='pdf'?'PDF':kind==='img'?'IMG':'FILE'}</div><div class="doc-lines"><div class="doc-line"></div><div class="doc-line short"></div><div class="doc-line"></div></div></div>`; }
function backToOfficerQueue(){ document.getElementById('officerQueueView').classList.remove('hidden'); document.getElementById('officerWorkView').classList.add('hidden'); }
function renderOfficer(){
  const list=document.getElementById('officerCaseList'); list.innerHTML='';
  caseData.forEach(item=>{
    const row=document.createElement('div'); row.className='queue-row';
    row.innerHTML=`<div class="queue-cell-title"><strong>${serviceTitle(item.serviceId)}</strong><div class="small muted">${tt('applicant')}: ${item.applicant}</div><div class="small muted">${item.submittedAt}</div></div><div><span class="status-tag">${item.id}</span></div><div><span class="status-tag">${tt('ai_score')}: ${item.aiScore}</span></div><div><span class="status-tag">${tt('issues')}: ${item.issues}</span></div><div><button class="primary">${tt('open_case')}</button></div>`;
    row.querySelector('button').onclick=()=>{ currentOfficerService=item.serviceId; document.getElementById('officerQueueView').classList.add('hidden'); document.getElementById('officerWorkView').classList.remove('hidden'); setOfficerTab('pre'); };
    list.appendChild(row);
  });
  backToOfficerQueue();
}
function setOfficerTab(stage){
  currentOfficerTab = stage;
  officerDossierTab = officerDossierTab || 'form'; document.querySelectorAll('.officer-tab').forEach(el=>el.classList.remove('active')); document.getElementById('officerTab-'+stage).classList.add('active'); openOfficerStage(stage); }
function openOfficerStage(stage){
  const item=selectedCase();
  const titleMap={pre:tt('pre_approval'),accept:tt('acceptance'),approve:tt('approval'),complete:tt('completion')};
  document.getElementById('officerStageBadge').textContent=tt('officer');
  document.getElementById('officerStageTitle').textContent=titleMap[stage];
  document.getElementById('officerStageDesc').textContent=serviceTitle(currentOfficerService);
  document.getElementById('officerRef').textContent=item.id;
  document.getElementById('officerAgency').textContent=serviceAgency(currentOfficerService);
  document.getElementById('officerCurrentStage').textContent=titleMap[stage];
  document.getElementById('officerCaseName').textContent=serviceTitle(currentOfficerService);
  document.getElementById('officerRefPill').textContent=`${tt('reference')}: ${item.id}`;
  document.getElementById('officerApplicantPill').textContent=`${tt('applicant')}: ${item.applicant}`;
  document.getElementById('officerServicePill').textContent=`${tt('service')}: ${serviceTitle(currentOfficerService)}`;

  const c=document.getElementById('officerStageContent');
  let stageHtml = '';

  if(stage==='pre'){
    stageHtml = `
      <div class="officer-stage-shell">
        ${officerHeaderStrip()}
        ${officerSnapshotCard()}
        <div class="officer-stage-card">
          <h3>${tt('submission_readiness')}</h3>
          <div class="officer-note">${tt('readiness_note')}</div>
          <h3>${tt('materials_overview')}</h3>
          ${officerMaterialsOverview()}
          <label>${tt('officer_opinion')}</label>
          <textarea class="textarea">The application package has been reviewed for completeness and may proceed to formal acceptance.</textarea>
          <div class="actions"><button class="secondary">${tt('return_correction')}</button><button class="primary" onclick="setOfficerTab('accept')">${tt('advance_acceptance')}</button></div>
        </div>
      </div>`;
  } else if(stage==='accept'){
    stageHtml = `
      <div class="officer-stage-shell">
        ${officerHeaderStrip()}
        ${officerSnapshotCard()}
        <div class="officer-stage-card">
          <h3>${tt('acceptance_ai_checks')}</h3>
          <div id="officerAiInspectionWrap"></div>
          <h3>${tt('materials_overview')}</h3>
          ${officerMaterialsOverview()}
          <label>${tt('receiving_officer')}</label>
          <select class="select"><option>${tt('senior_reviewing_officer')}</option></select>
          <div class="actions"><button class="secondary" onclick="setOfficerTab('pre')">${tt('back')}</button><button class="primary" onclick="setOfficerTab('approve')">${tt('advance_approval')}</button></div>
        </div>
      </div>`;
  } else if(stage==='approve'){
    stageHtml = `
      <div class="officer-stage-shell">
        ${officerHeaderStrip()}
        ${officerSnapshotCard()}
        <div class="officer-stage-card">
          <h3>${tt('decision_panel')}</h3>
          <div class="officer-note">${tt('review_note')}</div>
          <div id="officerDecisionWrap"></div>
          <div class="actions"><button class="secondary" onclick="setOfficerTab('accept')">${tt('back')}</button></div>
        </div>
      </div>`;
  } else {
    stageHtml = `
      <div class="officer-stage-shell">
        ${officerHeaderStrip()}
        <div class="officer-stage-card">
          <h3>${tt('final_result')}</h3>
          ${renderCertificate(item.id, serviceOutput(currentOfficerService))}
          <div class="actions"><button class="secondary" onclick="setOfficerTab('approve')">${tt('back')}</button><button class="primary">${tt('close_case')}</button></div>
        </div>
      </div>`;
  }

  c.innerHTML = stageHtml;
  const ai = document.getElementById('officerAiInspectionWrap'); if(ai) renderOfficerAiInspection();
  const dec = document.getElementById('officerDecisionWrap'); if(dec) renderOfficerDecisionPanel();
}

function backToAdminServices(){
  document.getElementById('adminServiceView').classList.remove('hidden');
  document.getElementById('adminWorkView').classList.add('hidden');
  populateAdminContext();
  const sel = document.getElementById('adminContextSelect');
  if(sel) sel.value = currentAdminService;
  renderAdminContext();
}



function adminBusinessConfigData(serviceKey){
  const base = {
    serviceCode: services[serviceKey].id || serviceKey.toUpperCase(),
    serviceType: serviceKey === 'grant' ? 'Benefit Service' : (serviceKey === 'school' ? 'Enrollment Service' : 'Licensing Service'),
    level: tt('national_level'),
    supportingAgency: serviceKey === 'hygiene' ? 'Public Health Inspectorate' : serviceAgency(serviceKey),
    targetUsers: serviceKey === 'company' ? tt('businesses_only') : (serviceKey === 'birth' ? tt('citizens_only') : tt('citizen_businesses')),
    deliveryChannel: tt('online_and_counter'),
    legalTitle: tt('legal_basis_sample'),
    regulationRef: serviceKey === 'hygiene' ? 'PH-REG-2024/17' : (serviceKey === 'birth' ? 'CR-REG-2023/08' : (serviceKey === 'idcard' ? 'ID-ACT-2022/05' : (serviceKey === 'company' ? 'CORP-ACT-2021/11' : (serviceKey === 'grant' ? 'SP-POL-2024/03' : 'EDU-DIR-2024/02')))),
    issuingAuthority: serviceAgency(serviceKey),
    effectiveDate: '2026-01-01',
    complianceNotes: tt('inspection_after_submission'),
    mandatoryService: serviceKey !== 'company',
    expedited: serviceKey === 'idcard',
    approvalModel: tt('manual_review_model'),
    inspectionRequired: serviceKey === 'hygiene',
    aiEnabled: true,
    outputType: serviceKey === 'school' ? tt('downloadable_result') : tt('digital_pdf_output'),
    paymentRequired: parseFloat((services[serviceKey].fee||'').replace(/[^0-9.]/g,'')) > 0,
    currency: 'USD',
    paymentModes: ['Card','Mobile Money','Bank Transfer'],
    feeWaiver: serviceKey === 'grant' || serviceKey === 'birth',
    refundRule: tt('refund_rule_text'),
    receiptGeneration: true,
    whoCanApply: serviceKey === 'company' ? tt('businesses_only') : tt('citizen_businesses'),
    eligibility: tt('eligibility_hint'),
    prerequisite: serviceKey === 'hygiene' ? 'Valid Business Registration' : 'None',
    proxyAllowed: serviceKey !== 'company',
    resubmission: true,
    digitalCert: serviceKey !== 'school',
    physicalCollection: serviceKey === 'idcard',
    postalDelivery: serviceKey === 'idcard',
    deliveryAfterApproval: serviceKey === 'idcard' ? '3 Working Days' : 'Immediate',
    verificationEnabled: true,
    publicVisibility: true,
    publicationStatus: tt('published_status'),
    publishDate: '2026-03-30',
    lastUpdatedBy: 'System Administrator',
    version: 'v2.3'
  };
  return base;
}

function adminContextData(){
  return {
    hygiene:{
      materials:5, fields:8, rules:4, publication:tt('context_ready'),
      summary: `${serviceTitle('hygiene')} — ${tt('service_context_summary')}`,
      changes:[
        tt('admin_change_hygiene'),
        tt('ctx_change_kitchen'),
        tt('ctx_change_waste')
      ],
      notifications:[
        tt('ctx_notif_hygiene_pub'),
        tt('ctx_notif_hygiene_ai'),
        tt('ctx_notif_hygiene_route')
      ],
      drafts:[
        tt('ctx_draft_food_safety'),
        tt('ctx_draft_staff_health'),
        tt('ctx_draft_hygiene_checklist')
      ]
    },
    birth:{
      materials:4, fields:6, rules:3, publication:tt('context_ready'),
      summary: `${serviceTitle('birth')} — ${tt('service_context_summary')}`,
      changes:[
        tt('ctx_change_birth_mapping'),
        tt('ctx_change_parent_id'),
        tt('ctx_change_registry_order')
      ],
      notifications:[
        tt('ctx_notif_certified_copy'),
        tt('ctx_notif_civil_registry'),
        tt('ctx_notif_birth_place')
      ],
      drafts:[
        tt('ctx_draft_marriage_branch'),
        tt('admin_draft_birth'),
        tt('ctx_draft_registry_wording')
      ]
    },
    idcard:{
      materials:4, fields:6, rules:4, publication:tt('context_draft'),
      summary: `${serviceTitle('idcard')} — ${tt('service_context_summary')}`,
      changes:[
        tt('admin_change_id'),
        tt('ctx_change_portrait'),
        tt('ctx_change_address_review')
      ],
      notifications:[
        tt('ctx_notif_unpublished_rule'),
        tt('ctx_notif_identity_review'),
        tt('ctx_notif_postal')
      ],
      drafts:[
        tt('ctx_draft_priority'),
        tt('ctx_draft_photo'),
        tt('ctx_draft_replacement')
      ]
    },
    company:{
      materials:4, fields:6, rules:5, publication:tt('context_ready'),
      summary: `${serviceTitle('company')} — ${tt('service_context_summary')}`,
      changes:[
        tt('ctx_change_name_reservation'),
        tt('ctx_change_shareholder'),
        tt('ctx_change_articles')
      ],
      notifications:[
        tt('ctx_notif_legal_route'),
        tt('ctx_notif_name_unique'),
        tt('ctx_notif_company_ready')
      ],
      drafts:[
        tt('ctx_draft_office_verification'),
        tt('admin_draft_company'),
        tt('ctx_draft_company_publish')
      ]
    },
    grant:{
      materials:4, fields:6, rules:5, publication:tt('context_draft'),
      summary: `${serviceTitle('grant')} — ${tt('service_context_summary')}`,
      changes:[
        tt('ctx_change_income'),
        tt('ctx_change_vulnerability'),
        tt('ctx_change_household')
      ],
      notifications:[
        tt('ctx_notif_eligibility_draft'),
        tt('ctx_notif_manual_review'),
        tt('ctx_notif_grant_wording')
      ],
      drafts:[
        tt('admin_draft_grant'),
        tt('ctx_draft_means'),
        tt('ctx_draft_grant_checklist')
      ]
    },
    school:{
      materials:4, fields:6, rules:4, publication:tt('context_ready'),
      summary: `${serviceTitle('school')} — ${tt('service_context_summary')}`,
      changes:[
        tt('admin_change_school'),
        tt('ctx_change_school_record'),
        tt('ctx_change_catchment')
      ],
      notifications:[
        tt('ctx_notif_enrollment_route'),
        tt('ctx_notif_education_review'),
        tt('ctx_notif_school_template')
      ],
      drafts:[
        tt('ctx_draft_transfer'),
        tt('ctx_draft_intake'),
        tt('ctx_draft_school_checklist')
      ]
    }
  };
}
function renderAdminContext(){
  const ctx = adminContextData()[currentAdminService] || adminContextData().hygiene;
  const setText = (id, value) => { const el = document.getElementById(id); if(el) el.textContent = value; };
  setText('adminContextMaterials', String(ctx.materials));
  setText('adminContextFields', String(ctx.fields));
  setText('adminContextRules', String(ctx.rules));
  setText('adminContextPublication', ctx.publication);
  setText('adminContextSummary', ctx.summary);

  const changes = document.getElementById('adminContextChanges');
  const notifications = document.getElementById('adminContextNotifications');
  const drafts = document.getElementById('adminContextDrafts');

  if(changes) changes.innerHTML = ctx.changes.map(item => `<div class="admin-list-item">${item}</div>`).join('');
  if(notifications) notifications.innerHTML = ctx.notifications.map(item => `<div class="admin-list-item">${item}</div>`).join('');
  if(drafts) drafts.innerHTML = ctx.drafts.map(item => `<div class="admin-list-item">${item}</div>`).join('');

  const hintConfig = document.getElementById('adminModuleHintConfig');
  const hintWorkflow = document.getElementById('adminModuleHintWorkflow');
  const hintForms = document.getElementById('adminModuleHintForms');
  const hintRules = document.getElementById('adminModuleHintRules');

  if(hintConfig) hintConfig.textContent = `${serviceTitle(currentAdminService)} — ${tt('context_module_hint_config')}`;
  if(hintWorkflow) hintWorkflow.textContent = `${serviceTitle(currentAdminService)} — ${tt('context_module_hint_workflow')}`;
  if(hintForms) hintForms.textContent = `${serviceTitle(currentAdminService)} — ${tt('context_module_hint_forms')}`;
  if(hintRules) hintRules.textContent = `${serviceTitle(currentAdminService)} — ${tt('context_module_hint_rules')}`;
}

function populateAdminContext(){
  const sel = document.getElementById('adminContextSelect');
  if(!sel) return;
  sel.innerHTML = '';
  Object.keys(services).forEach(key => {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = serviceTitle(key);
    if(key === currentAdminService) opt.selected = true;
    sel.appendChild(opt);
  });
}
function selectAdminContext(key){
  currentAdminService = key;
  renderAdminContext();
  const sel = document.getElementById('adminContextSelect');
  if(sel) sel.value = key;
}
function openAdminFromHome(section){
  const sel = document.getElementById('adminContextSelect');
  if(sel && sel.value) currentAdminService = sel.value;
  document.getElementById('adminServiceView').classList.add('hidden');
  document.getElementById('adminWorkView').classList.remove('hidden');
  openAdminModule();
  setAdminTab(section);
}

function renderAdmin(){
  populateAdminContext();
  backToAdminServices();
  renderAdminContext();
}
function setAdminTab(section){
  document.querySelectorAll('.admin-tab').forEach(el=>el.classList.remove('active'));
  document.getElementById('adminTab-'+section).classList.add('active');
  const adminOrder=['business','materials','form','review','scenario','publish'];
  const aIdx=adminOrder.indexOf(section);
  document.querySelectorAll('.admin-tab').forEach((el,i)=>{
    el.style.opacity = i<aIdx ? '.6' : '1';
    el.style.borderColor = i===aIdx ? 'var(--primary)' : '';
    el.style.color = i===aIdx ? 'var(--primary)' : (i<aIdx ? '#667085' : '');
  });
  const actionBar=document.querySelector('#adminWorkView .actions');
  if(actionBar){ const nextLabels=['materials','form','review','scenario','publish','done']; const nextLabel=nextLabels[aIdx]; actionBar.dataset.step=section; }
  openAdminSection(section);
}
function openAdminModule(){
  document.getElementById('adminModuleBadge').textContent=tt('admin'); document.getElementById('adminModuleTitle').textContent=serviceTitle(currentAdminService); document.getElementById('adminModuleDesc').textContent=serviceDesc(currentAdminService);
  document.getElementById('adminCat').textContent=tt(services[currentAdminService].category_key); document.getElementById('adminFee').textContent=services[currentAdminService].fee; document.getElementById('adminTime').textContent=translateServiceTime(services[currentAdminService].time); document.getElementById('adminAgency').textContent=serviceAgency(currentAdminService);
  setAdminTab('business');
}
function openAdminSection(section){
  const c=document.getElementById('adminModuleContent');
  const materialsHtml=mats(currentAdminService).map((item,idx)=>{ const [name,desc]=item.split('|'); const tag=idx<2?`<span class="req-tag required">${tt('required')}</span>`:`<span class="req-tag optional">${tt('optional')}</span>`; return `<div class="audit-item"><div style="display:flex;justify-content:space-between;gap:10px;align-items:center"><strong>${name}</strong>${tag}</div><div class="small muted">${desc}</div><div class="small muted">${tt('accepted_formats')}: PDF / JPG · ${tt('max_size')}: 10 MB</div></div>`; }).join('');
  if(section==='business'){
    const d = adminBusinessConfigData(currentAdminService);
    c.innerHTML=`<div class="notice">${tt('select_service_context')}: <strong>${serviceTitle(currentAdminService)}</strong></div>
    <div class="config-form-grid">
      <div class="form-panel">
        <div class="form-section-title">${tt('service_basic_info')}</div>
        <label>${tt('service_name')}</label><input class="input" value="${serviceTitle(currentAdminService)}">
        <label>${tt('service_code')}</label><input class="input" value="${d.serviceCode}">
        <label>${tt('service_type')}</label><input class="input" value="${d.serviceType}">
        <label>${tt('service_category')}</label><input class="input" value="${tt(services[currentAdminService].category_key)}">
        <label>${tt('administrative_level')}</label><select class="select"><option>${d.level}</option><option>${tt('provincial_level')}</option><option>${tt('district_level')}</option></select>
        <label>${tt('responsible_department')}</label><input class="input" value="${serviceAgency(currentAdminService)}">
        <label>${tt('supporting_agency')}</label><input class="input" value="${d.supportingAgency}">
        <label>${tt('target_users')}</label><select class="select"><option>${d.targetUsers}</option><option>${tt('citizen_businesses')}</option><option>${tt('businesses_only')}</option><option>${tt('citizens_only')}</option></select>
        <label>${tt('delivery_channel')}</label><select class="select"><option>${d.deliveryChannel}</option><option>${tt('online_only')}</option></select>
        <label>${tt('service_desc')}</label><textarea class="textarea">${serviceDesc(currentAdminService)}</textarea>
      </div>

      <div class="form-panel">
        <div class="form-section-title">${tt('service_policy_basis')}</div>
        <label>${tt('legal_basis_title')}</label><input class="input" value="${d.legalTitle}">
        <label>${tt('regulation_ref')}</label><input class="input" value="${d.regulationRef}">
        <label>${tt('issuing_authority')}</label><input class="input" value="${d.issuingAuthority}">
        <label>${tt('effective_date')}</label><input class="input" value="${d.effectiveDate}">
        <label>${tt('mandatory_service')}</label>
        <div class="inline-toggle"><button class="tab-btn active">${d.mandatoryService ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.mandatoryService ? tt('no') : tt('yes')}</button></div>
        <label>${tt('compliance_notes')}</label><textarea class="textarea">${d.complianceNotes}</textarea>
      </div>

      <div class="form-panel">
        <div class="form-section-title">${tt('service_processing_config')}</div>
        <label>${tt('processing_time')}</label><input class="input" value="${translateServiceTime(services[currentAdminService].time)}">
        <label>${tt('sla_unit')}</label><select class="select"><option>${tt('working_days_unit')}</option><option>${tt('calendar_days_unit')}</option></select>
        <label>${tt('expedited_option')}</label><div class="inline-toggle"><button class="tab-btn active">${d.expedited ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.expedited ? tt('no') : tt('yes')}</button></div>
        <label>${tt('approval_model')}</label><select class="select"><option>${d.approvalModel}</option><option>${tt('fully_manual_model')}</option></select>
        <label>${tt('site_inspection_required')}</label><div class="inline-toggle"><button class="tab-btn active">${d.inspectionRequired ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.inspectionRequired ? tt('no') : tt('yes')}</button></div>
        <label>${tt('ai_preinspection_enabled')}</label><div class="inline-toggle"><button class="tab-btn active">${d.aiEnabled ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.aiEnabled ? tt('no') : tt('yes')}</button></div>
        <label>${tt('output_type')}</label><input class="input" value="${d.outputType}">
      </div>

      <div class="form-panel">
        <div class="form-section-title">${tt('service_payment_config')}</div>
        <label>${tt('payment_required')}</label><div class="inline-toggle"><button class="tab-btn active">${d.paymentRequired ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.paymentRequired ? tt('no') : tt('yes')}</button></div>
        <label>${tt('payment_amount')}</label><input class="input" value="${d.paymentRequired ? services[currentAdminService].fee : tt('no_fee_required')}">
        <label>${tt('currency')}</label><input class="input" value="${d.currency}">
        <label>${tt('payment_modes_accepted')}</label>
        <div class="checkbox-group">${d.paymentModes.map(m => `<label class="checkbox-pill"><input type="checkbox" checked> <span>${m}</span></label>`).join('')}</div>
        <label>${tt('fee_waiver_option')}</label><div class="inline-toggle"><button class="tab-btn active">${d.feeWaiver ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.feeWaiver ? tt('no') : tt('yes')}</button></div>
        <label>${tt('refund_rule')}</label><textarea class="textarea">${d.refundRule}</textarea>
        <label>${tt('receipt_generation')}</label><div class="inline-toggle"><button class="tab-btn active">${d.receiptGeneration ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.receiptGeneration ? tt('no') : tt('yes')}</button></div>
      </div>

      <div class="form-panel">
        <div class="form-section-title">${tt('service_submission_eligibility')}</div>
        <label>${tt('who_can_apply')}</label><input class="input" value="${d.whoCanApply}">
        <label>${tt('eligibility_conditions')}</label><textarea class="textarea">${d.eligibility}</textarea>
        <label>${tt('prerequisite_services')}</label><input class="input" value="${d.prerequisite}">
        <label>${tt('proxy_submission')}</label><div class="inline-toggle"><button class="tab-btn active">${d.proxyAllowed ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.proxyAllowed ? tt('no') : tt('yes')}</button></div>
        <label>${tt('resubmission_allowed')}</label><div class="inline-toggle"><button class="tab-btn active">${d.resubmission ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.resubmission ? tt('no') : tt('yes')}</button></div>
      </div>

      <div class="form-panel">
        <div class="form-section-title">${tt('service_result_delivery')}</div>
        <label>${tt('digital_certificate_option')}</label><div class="inline-toggle"><button class="tab-btn active">${d.digitalCert ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.digitalCert ? tt('no') : tt('yes')}</button></div>
        <label>${tt('physical_collection')}</label><div class="inline-toggle"><button class="tab-btn active">${d.physicalCollection ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.physicalCollection ? tt('no') : tt('yes')}</button></div>
        <label>${tt('postal_delivery')}</label><div class="inline-toggle"><button class="tab-btn active">${d.postalDelivery ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.postalDelivery ? tt('no') : tt('yes')}</button></div>
        <label>${tt('delivery_time_after_approval')}</label><input class="input" value="${d.deliveryAfterApproval}">
        <label>${tt('verification_enabled')}</label><div class="inline-toggle"><button class="tab-btn active">${d.verificationEnabled ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.verificationEnabled ? tt('no') : tt('yes')}</button></div>
      </div>

      <div class="form-panel full">
        <div class="form-section-title">${tt('service_publication_control')}</div>
        <div class="config-form-grid">
          <div>
            <label>${tt('public_visibility')}</label>
            <div class="inline-toggle"><button class="tab-btn active">${d.publicVisibility ? tt('yes') : tt('no')}</button><button class="tab-btn">${d.publicVisibility ? tt('no') : tt('yes')}</button></div>
          </div>
          <div>
            <label>${tt('publication_status')}</label>
            <select class="select"><option>${d.publicationStatus}</option><option>${tt('draft_status')}</option><option>${tt('published_status')}</option><option>${tt('suspended_status')}</option></select>
          </div>
          <div>
            <label>${tt('publish_date')}</label><input class="input" value="${d.publishDate}">
          </div>
          <div>
            <label>${tt('last_updated_by')}</label><input class="input" value="${d.lastUpdatedBy}">
          </div>
          <div>
            <label>${tt('version_number')}</label><input class="input" value="${d.version}">
          </div>
        </div>
        <div class="actions">
          <button class="secondary">${tt('save_changes')}</button>
          <button class="secondary">${tt('validate_configuration')}</button>
          <button class="primary">${tt('publish_service')}</button>
        </div>
      </div>
    </div>`;
  } else if(section==='materials'){
    const materialKeyMap = {
      hygiene:[['mat_business_cert','mat_business_cert_desc'],['mat_kitchen_plan','mat_kitchen_plan_desc'],['mat_food_safety','mat_food_safety_desc'],['mat_staff_health','mat_staff_health_desc'],['mat_waste_agreement','mat_waste_agreement_desc']],
      birth:[['mat_birth_notice','mat_birth_notice_desc'],['mat_parent_id','mat_parent_id_desc'],['mat_marriage_cert','mat_marriage_cert_desc'],['mat_birth_place_proof','mat_birth_place_proof_desc']],
      idcard:[['mat_prev_id','mat_prev_id_desc'],['mat_address_proof','mat_address_proof_desc'],['mat_citizenship','mat_citizenship_desc'],['mat_portrait','mat_portrait_desc']],
      company:[['mat_company_name','mat_company_name_desc'],['mat_shareholder','mat_shareholder_desc'],['mat_registered_address','mat_registered_address_desc'],['mat_articles','mat_articles_desc']],
      grant:[['mat_applicant_id','mat_applicant_id_desc'],['mat_household_record','mat_household_record_desc'],['mat_income','mat_income_desc'],['mat_vulnerability','mat_vulnerability_desc']],
      school:[['mat_learner_birth','mat_learner_birth_desc'],['mat_guardian_id','mat_guardian_id_desc'],['mat_residence','mat_residence_desc'],['mat_school_record','mat_school_record_desc']]
    };
    const baseRows = materialConfigRows(currentAdminService);
    const rows = baseRows.map((row, idx) => {
      const pair = (materialKeyMap[currentAdminService] || [])[idx];
      const tName = pair ? tt(pair[0]) : row.name;
      const tDesc = pair ? tt(pair[1]) : row.desc;
      const sourceMeta = materialUiMeta(currentAdminService)[pair ? pair[0] : ''] || {mode:'manual'};
      const sourceText = sourceMeta.mode === 'auto' ? tt('source_auto') : (sourceMeta.mode === 'hybrid' ? tt('source_hybrid') : tt('source_manual'));
      return `
      <div class="admin-row v21">
        <div><strong>${tName}</strong><div class="small muted">${tDesc}</div></div>
        <div>
          <div class="toggle">
            <button class="${row.required ? 'active' : ''}">${tt('required')}</button>
            <button class="${!row.required ? 'active' : ''}">${tt('optional')}</button>
          </div>
        </div>
        <div><span class="status-tag">${sourceText}</span></div>
        <div><div class="format-group">${row.formats.map(f => `<span class="format-pill">${f}</span>`).join('')}</div></div>
        <div><span class="status-tag">${row.size}</span></div>
        <div><button class="ghost">${tt('edit_label')}</button></div>
      </div>`}).join('');
    c.innerHTML=`<div class="notice">${tt('select_service_context')}: <strong>${serviceTitle(currentAdminService)}</strong></div><div class="module-panel">
      <h3>${tt('materials_config')}</h3>
      <div class="admin-table">
        <div class="admin-row header v21">
          <div>${tt('material_name')}</div>
          <div>${tt('requirement')}</div>
          <div>${tt('source_mode')}</div>
          <div>${tt('format')}</div>
          <div>${tt('max_size_col')}</div>
          <div>${tt('actions_col')}</div>
        </div>
        ${rows}
      </div>
      <div class="module-actions">
        <div class="notice">${tt('validation_notes')}: ${tt('validation_upload_note')}</div>
        <button class="primary">${tt('add_new')}</button>
      </div>
    </div>`;
  } else if(section==='form'){
    const rows = citizenFieldRows(currentAdminService).map((row, idx) => `
      <div class="field-row">
        <div><input class="inline-edit" value="${row[0]}"></div>
        <div><select class="select"><option>${row[1]}</option><option>${tt('text_type')}</option><option>${tt('dropdown_type')}</option><option>${tt('date_type')}</option><option>${tt('upload_type')}</option></select></div>
        <div><select class="select"><option>${row[2]}</option><option>${tt('yes')}</option><option>${tt('no')}</option></select></div>
        <div><select class="select"><option>${row[3]}</option><option>${tt('mandatory')}</option><option>${tt('controlled_list')}</option><option>${tt('logical_date')}</option><option>${tt('format_size')}</option></select></div>
        <div><button class="ghost">${tt('delete_label')}</button></div>
      </div>`).join('');
    c.innerHTML=`<div class="notice">${tt('select_service_context')}: <strong>${serviceTitle(currentAdminService)}</strong></div><div class="module-panel">
      <h3>${tt('form_assoc')}</h3>
      <label>${tt('active_form_template')}</label>
      <select class="select"><option>${serviceTitle(currentAdminService)} Form</option></select>
      <div class="field-builder" style="margin-top:14px">
        <div class="field-row header">
          <div>${tt('field_label')}</div>
          <div>${tt('field_type_col')}</div>
          <div>${tt('field_required')}</div>
          <div>${tt('field_validation')}</div>
          <div>${tt('actions_col')}</div>
        </div>
        ${rows}
      </div>
      <div class="module-actions">
        <button class="secondary">${tt('add_field')}</button>
        <button class="primary">${tt('save_changes')}</button>
      </div>
    </div>
    <div class="module-panel" style="margin-top:14px">
      <h3>${tt('autofill_rules_title')||'Auto-Fill Rules'}</h3>
      <div class="small muted" style="margin-bottom:12px">${tt('autofill_rules_desc')||'Configure which fields are pre-populated from national registries and data sources.'}</div>
      <div class="admin-table">
        <div class="admin-row header" style="grid-template-columns:1.2fr 1fr 1fr 1fr auto">
          <div>${tt('form_field')}</div>
          <div>${tt('data_source')}</div>
          <div>${tt('source_field')}</div>
          <div>${tt('autofill_mode')}</div>
          <div>${tt('actions_col')}</div>
        </div>
        ${[['key_business_name','source_business_registry','registered_name','auto'],['key_date_of_birth','source_identity_registry','dob','auto'],['key_address','source_civil_registry','residential_address','hybrid']].map(r=>`
        <div class="admin-row" style="grid-template-columns:1.2fr 1fr 1fr 1fr auto">
          <div><strong>${tt(r[0])||r[0]}</strong></div>
          <div><select class="select"><option>${tt(r[1])||r[1]}</option></select></div>
          <div><input class="inline-edit" value="${r[2]}"></div>
          <div><select class="select"><option>${r[3]==='auto'?(tt('source_auto')||'Auto-filled'):(tt('source_hybrid')||'Editable')}</option><option>${tt('source_manual')||'Manual'}</option></select></div>
          <div><button class="ghost">${tt('delete_label')}</button></div>
        </div>`).join('')}
      </div>
      <div class="module-actions"><button class="secondary">${tt('add_rule')||'Add Rule'}</button><button class="primary">${tt('save_changes')}</button></div>
    </div>
    <div class="module-panel" style="margin-top:14px">
      <h3>${tt('validation_rules_title')||'Business Validation Rules'}</h3>
      <div class="small muted" style="margin-bottom:12px">${tt('validation_rules_desc')||'Define field-level validation logic applied before submission.'}</div>
      <div class="admin-table">
        <div class="admin-row header" style="grid-template-columns:1.2fr 1fr 1.5fr auto">
          <div>${tt('form_field')}</div>
          <div>${tt('rule_type')}</div>
          <div>${tt('rule_description')}</div>
          <div>${tt('actions_col')}</div>
        </div>
        ${[['key_business_name','rule_not_empty','Business name must not be blank'],['key_date_of_birth','rule_logical_date','Date must be in the past'],['key_business_name','rule_registry_match','Must match registered name in Business Registry']].map(r=>`
        <div class="admin-row" style="grid-template-columns:1.2fr 1fr 1.5fr auto">
          <div><strong>${tt(r[0])||r[0]}</strong></div>
          <div><select class="select"><option>${tt(r[1])||r[1]}</option></select></div>
          <div><input class="inline-edit" value="${r[2]}"></div>
          <div><button class="ghost">${tt('delete_label')}</button></div>
        </div>`).join('')}
      </div>
      <div class="module-actions"><button class="secondary">${tt('add_rule')||'Add Rule'}</button><button class="primary">${tt('save_changes')}</button></div>
    </div>`;
  } else if(section==='review'){
    const checklists = [
      [tt('compliance_check'), tt('stage_pre'), tt('review_outcome_pass'), tt('stage_accept'), tt('low_risk')],
      [tt('identity_match'), tt('stage_accept'), tt('review_outcome_verified'), tt('stage_approve'), tt('low_risk')],
      [tt('material_validity'), tt('stage_pre'), tt('return_if_missing'), tt('stage_pre'), tt('medium_risk')],
      [tt('fee_settlement'), tt('stage_accept'), tt('review_outcome_confirmed'), tt('stage_approve'), tt('low_risk')],
      [tt('inspection_alignment'), tt('stage_approve'), tt('approve_if_all'), tt('stage_complete'), tt('medium_risk')]
    ].map(row => `
      <div class="check-item">
        <div><strong>${row[0]}</strong></div>
        <div><span class="flow-chip">${row[1]}</span></div>
        <div>${row[2]}</div>
        <div><span class="flow-chip">${row[3]}</span></div>
        <div><span class="status-tag">${row[4]}</span></div>
      </div>`).join('');
    c.innerHTML=`<div class="notice">${tt('select_service_context')}: <strong>${serviceTitle(currentAdminService)}</strong></div>
    <div class="module-panel" style="margin-bottom:14px">
      <h3 style="margin:0 0 14px">${tt('workflow_diagram')||'Workflow Flow Diagram'}</h3>
      <div style="display:flex;align-items:center;gap:0;flex-wrap:wrap;padding:8px 0;overflow-x:auto">
        ${['pre_approval','acceptance','approval','completion'].map((s,i)=>`
          <div style="display:flex;align-items:center;gap:0">
            <div style="background:#eef4fb;border:1.5px solid #a6c4f0;border-radius:12px;padding:12px 18px;text-align:center;min-width:110px">
              <div style="font-size:20px">${['📥','✅','⚖️','🏆'][i]}</div>
              <div style="font-size:12px;font-weight:700;margin-top:4px;color:#1f5fae">${tt(['pre_approval','acceptance','approval','completion'][i])}</div>
              <div style="font-size:11px;color:#667085;margin-top:2px">${['Receive & check','Validate docs','Officer decides','Issue result'][i]}</div>
            </div>
            ${i<3?'<div style="padding:0 6px;color:#667085;font-size:18px">→</div>':''}
          </div>`).join('')}
      </div>
    </div>
    <div class="mapping-grid">
      <div class="mapping-card">
        <div class="mapping-head">
          <h3 style="margin:0">${tt('review_mapping')}</h3>
          <button class="secondary">${tt('add_checklist')}</button>
        </div>
        <div style="display:grid;grid-template-columns:1.8fr 1fr 1.4fr 1fr .9fr;gap:10px;padding:10px 12px;background:#f8fbff;border-radius:10px;font-weight:700;font-size:12px;color:#667085;border:1px solid var(--border)">
          <div>${tt('checklist_name')}</div>
          <div>${tt('review_stage')}</div>
          <div>${tt('review_outcome')}</div>
          <div>${tt('route_to')}</div>
          <div>${tt('risk_level')}</div>
        </div>
        <div class="checklist-list" style="margin-top:8px">${checklists.replace(/class="check-item"/g,'class="check-item" style="display:grid;grid-template-columns:1.8fr 1fr 1.4fr 1fr .9fr;gap:10px;align-items:center"')}</div>
      </div>
      <div class="mapping-card">
        <h3 style="margin:0">${tt('decision_criteria')}</h3>
        <div class="audit-list">
          <div class="audit-item">${tt('approve_if_all')}</div>
          <div class="audit-item">${tt('return_if_missing')}</div>
          <div class="audit-item">${tt('send_manual_review')}</div>
        </div>
      </div>
    </div>`;
  } else if(section==='scenario'){
    const rules = [
      [tt('scenario_business_type'), `=`, tt('option_restaurant'), tt('require_additional_doc')],
      [tt('scenario_application_type'), `=`, tt('option_renewal'), tt('bypass_payment')],
      [tt('scenario_customer_volume'), `>`, `300`, tt('send_manual_review')],
      [tt('scenario_delivery_preference'), `=`, tt('option_download_cert'), tt('route_fast_track')]
    ].map(r => `
      <div class="logic-line">
        <input class="inline-edit" value="${r[0]}">
        <select class="select"><option>${r[1]}</option><option>=</option><option>></option><option><</option><option>contains</option></select>
        <input class="inline-edit" value="${r[2]}">
        <select class="select"><option>${r[3]}</option><option>${tt('require_additional_doc')}</option><option>${tt('send_manual_review')}</option><option>${tt('bypass_payment')}</option><option>${tt('route_fast_track')}</option></select>
      </div>`).join('');
    c.innerHTML=`<div class="notice">${tt('select_service_context')}: <strong>${serviceTitle(currentAdminService)}</strong></div><div class="rule-canvas">
      <div class="rule-block">
        <div class="mapping-head">
          <h3 style="margin:0">${tt('scenario_builder')}</h3>
          <button class="secondary">${tt('add_rule')}</button>
        </div>
        <div class="field-row header">
          <div>${tt('condition')}</div>
          <div>${tt('operator')}</div>
          <div>${tt('value')}</div>
          <div>${tt('system_action')}</div>
          <div></div>
        </div>
        ${rules}
      </div>
      <div class="rule-block">
        <h3 style="margin:0">${tt('rule_logic')}</h3>
        <div class="notice">${serviceTitle(currentAdminService)} — ${tt('key_rule_logic_suffix')}</div>
        <div class="module-actions">
          <button class="secondary">${tt('save_changes')}</button>
          <button class="primary">${tt('publish_logic')}</button>
        </div>
      </div>
    </div>`;
  } else {
    c.innerHTML=`<div class="notice">${tt('select_service_context')}: <strong>${serviceTitle(currentAdminService)}</strong></div><div class="config-grid"><div class="module-panel"><h3>${tt('publish_checklist')}</h3><div class="summary-list"><div><span>${tt('business_config')}</span><strong>${tt('complete')}</strong></div><div><span>${tt('materials_config')}</span><strong>${tt('complete')}</strong></div><div><span>${tt('form_assoc')}</span><strong>${tt('complete')}</strong></div><div><span>${tt('review_mapping')}</span><strong>${tt('complete')}</strong></div><div><span>${tt('scenario_builder')}</span><strong>${tt('complete')}</strong></div></div></div><div class="module-panel"><h3>${tt('publish_ready')}</h3><div class="notice">${serviceTitle(currentAdminService)} ${tt('publish_ready_desc')}</div><div class="actions"><button class="primary">${tt('publish_service')}</button></div></div></div>`;
  }
}



function getPaymentFields(serviceKey, method='card'){
  const paid = services[serviceKey].paid;
  if(!paid){
    return `<div class="notice payment-note">${tt('payment_details')}: ${tt('not_applicable')}</div>`;
  }
  const common = `
    <div class="payment-form-grid">
      <div>
        <label>${tt('payment_reference')}</label>
        <input class="input" value="PAY-2026-004182">
      </div>
      <div>
        <label>${tt('payer_name')}</label>
        <input class="input" value="${currentLang==='zh' ? '申请人账户' : currentLang==='fr' ? 'Compte du demandeur' : currentLang==='ar' ? 'حساب مقدم الطلب' : currentLang==='pt' ? 'Conta do requerente' : 'Applicant Account'}">
      </div>
      <div>
        <label>${tt('billing_email')}</label>
        <input class="input" value="applicant@example.gov.demo">
      </div>
      <div>
        <label>${tt('amount_due')}</label>
        <input class="input" value="${services[serviceKey].fee}">
      </div>
    </div>`;
  if(method==='card'){
    return common + `
      <div class="payment-form-grid payment-details">
        <div><label>${tt('card_number')}</label><input class="input" value="4111 1111 1111 1111"></div>
        <div><label>${tt('card_holder')}</label><input class="input" value="KARIM YUSUF"></div>
        <div><label>${tt('expiry_date')}</label><input class="input" value="12/28"></div>
        <div><label>${tt('security_code')}</label><input class="input" value="123"></div>
      </div>`;
  }
  if(method==='mobile'){
    return common + `
      <div class="payment-form-grid payment-details">
        <div><label>${tt('mobile_wallet')}</label><input class="input" value="+250 788 555 010"></div>
        <div><label>${tt('wallet_provider')}</label><select class="select"><option>${tt('option_mobile_money')}</option><option>${tt('option_airtel_money')}</option><option>${tt('option_mpesa')}</option></select></div>
      </div>`;
  }
  return common + `
    <div class="payment-form-grid payment-details">
      <div><label>${tt('bank_name')}</label><input class="input" value="National Commercial Bank"></div>
      <div><label>${tt('account_name')}</label><input class="input" value="${currentLang==='zh' ? '申请人结算账户' : currentLang==='fr' ? 'Compte de règlement du demandeur' : currentLang==='ar' ? 'حساب تسوية مقدم الطلب' : currentLang==='pt' ? 'Conta de liquidação do requerente' : 'Applicant Settlement Account'}"></div>
      <div><label>${tt('transaction_reference')}</label><input class="input" value="TRX-889122"></div>
    </div>`;
}

function translatedGuidanceLabelMap(){
  return {
    en:{
      typeEst:"Type of establishment",onsite:"Will food be prepared on-site?",dailyVol:"Expected daily customer volume",foodCat:"Primary food category",waste:"Waste oil / food waste management arrangement",collect:"Result collection preference",appType:"Application type",placeBirth:"Place of birth",relationship:"Applicant relationship",certFormat:"Preferred certificate format",purpose:"Application purpose",ageBand:"Age band",delivery:"Delivery preference",urgency:"Urgency level",entity:"Entity type",reserve:"Need name reservation?",directors:"Number of directors",certDelivery:"Certificate delivery",basis:"Primary basis of application",employment:"Current employment status",dependants:"Household dependants",channel:"Preferred payment channel",eduLevel:"Education level",intake:"Preferred intake period"
    },
    zh:{
      typeEst:"经营场所类型",onsite:"是否现场制作食品？",dailyVol:"预计日接待量",foodCat:"主要食品类别",waste:"废油/食物垃圾处理安排",collect:"结果领取方式",appType:"申请类型",placeBirth:"出生地点",relationship:"申请人与儿童关系",certFormat:"证明形式偏好",purpose:"申请用途",ageBand:"年龄段",delivery:"领取方式",urgency:"紧急程度",entity:"实体类型",reserve:"是否需要名称预留？",directors:"董事人数",certDelivery:"证书交付方式",basis:"申请主要依据",employment:"当前就业状态",dependants:"家庭赡养人数",channel:"首选发放渠道",eduLevel:"教育阶段",intake:"首选入学时间"
    },
    fr:{
      typeEst:"Type d’établissement",onsite:"Les aliments seront-ils préparés sur place ?",dailyVol:"Volume quotidien estimé",foodCat:"Catégorie alimentaire principale",waste:"Gestion des huiles / déchets alimentaires",collect:"Préférence de remise du résultat",appType:"Type de demande",placeBirth:"Lieu de naissance",relationship:"Lien avec le demandeur",certFormat:"Format de certificat préféré",purpose:"Objet de la demande",ageBand:"Tranche d’âge",delivery:"Préférence de remise",urgency:"Niveau d’urgence",entity:"Type d’entité",reserve:"Réserver le nom ?",directors:"Nombre de directeurs",certDelivery:"Mode de remise du certificat",basis:"Fondement principal de la demande",employment:"Situation d’emploi actuelle",dependants:"Personnes à charge du ménage",channel:"Canal de paiement préféré",eduLevel:"Niveau d’enseignement",intake:"Période d’admission souhaitée"
    },
    ar:{
      typeEst:"نوع المنشأة",onsite:"هل سيتم إعداد الطعام في الموقع؟",dailyVol:"الحجم اليومي المتوقع للعملاء",foodCat:"الفئة الغذائية الرئيسية",waste:"ترتيبات التخلص من الزيوت / نفايات الطعام",collect:"تفضيل استلام النتيجة",appType:"نوع الطلب",placeBirth:"مكان الميلاد",relationship:"صلة مقدم الطلب",certFormat:"صيغة الشهادة المفضلة",purpose:"غرض الطلب",ageBand:"الفئة العمرية",delivery:"تفضيل التسليم",urgency:"مستوى الاستعجال",entity:"نوع الكيان",reserve:"هل يلزم حجز الاسم؟",directors:"عدد المديرين",certDelivery:"طريقة تسليم الشهادة",basis:"الأساس الرئيسي للطلب",employment:"وضع العمل الحالي",dependants:"المعالون في الأسرة",channel:"قناة الصرف المفضلة",eduLevel:"المرحلة التعليمية",intake:"فترة الالتحاق المفضلة"
    },
    pt:{
      typeEst:"Tipo de estabelecimento",onsite:"Os alimentos serão preparados no local?",dailyVol:"Volume diário estimado de clientes",foodCat:"Categoria alimentar principal",waste:"Gestão de óleo / resíduos alimentares",collect:"Preferência de entrega do resultado",appType:"Tipo de pedido",placeBirth:"Local de nascimento",relationship:"Relação do requerente",certFormat:"Formato preferido do certificado",purpose:"Finalidade do pedido",ageBand:"Faixa etária",delivery:"Preferência de entrega",urgency:"Nível de urgência",entity:"Tipo de entidade",reserve:"Necessita de reserva de nome?",directors:"Número de diretores",certDelivery:"Entrega do certificado",basis:"Base principal do pedido",employment:"Situação laboral atual",dependants:"Dependentes do agregado",channel:"Canal de pagamento preferido",eduLevel:"Nível de ensino",intake:"Período de ingresso preferido"
    }
  }[currentLang] || {};
}

function translatedFormLabelMap(){
  return {
    en:{businessName:"Business Name",businessNo:"Business Registration Number",operatingAddress:"Operating Address",foodHandlers:"Number of food handlers",kitchenDesc:"Kitchen layout description",childName:"Child Full Name",dob:"Date of Birth",birthPlace:"Place of Birth",mother:"Mother's Full Name",father:"Father's Full Name",district:"Registry District",fullName:"Full Name",address:"Current Residential Address",prevId:"Previous ID Number",deliveryMethod:"Preferred delivery method",proposedName:"Proposed Company Name",activity:"Primary Business Activity",officeAddress:"Registered Office Address",director:"Primary Director Name",shareholding:"Shareholder Structure",nationalId:"National ID Number",residential:"Residential Address",household:"Household Size",income:"Monthly Household Income",support:"Additional supporting explanation",learner:"Learner Full Name",grade:"Current Grade / Level",guardian:"Parent / Guardian Name",school:"Preferred School",notes:"Additional notes"},
    zh:{businessName:"企业名称",businessNo:"营业登记号码",operatingAddress:"经营地址",foodHandlers:"食品从业人数",kitchenDesc:"厨房布局说明",childName:"儿童姓名",dob:"出生日期",birthPlace:"出生地点",mother:"母亲姓名",father:"父亲姓名",district:"登记区域",fullName:"姓名",address:"现居住地址",prevId:"原身份证号",deliveryMethod:"首选领取方式",proposedName:"拟注册公司名称",activity:"主要经营活动",officeAddress:"注册地址",director:"主要董事姓名",shareholding:"股权结构",nationalId:"身份证号码",residential:"居住地址",household:"家庭人数",income:"家庭月收入",support:"补充说明",learner:"学生姓名",grade:"当前年级/阶段",guardian:"家长/监护人姓名",school:"意向学校",notes:"补充说明"},
    fr:{businessName:"Nom de l’entreprise",businessNo:"Numéro d’enregistrement",operatingAddress:"Adresse d’exploitation",foodHandlers:"Nombre de manipulateurs d’aliments",kitchenDesc:"Description du plan de cuisine",childName:"Nom complet de l’enfant",dob:"Date de naissance",birthPlace:"Lieu de naissance",mother:"Nom complet de la mère",father:"Nom complet du père",district:"District d’enregistrement",fullName:"Nom complet",address:"Adresse actuelle",prevId:"Numéro d’identité précédent",deliveryMethod:"Mode de remise préféré",proposedName:"Nom proposé de l’entreprise",activity:"Activité principale",officeAddress:"Adresse du siège",director:"Nom du directeur principal",shareholding:"Structure de l’actionnariat",nationalId:"Numéro d’identité nationale",residential:"Adresse de résidence",household:"Taille du ménage",income:"Revenu mensuel du ménage",support:"Informations complémentaires",learner:"Nom complet de l’élève",grade:"Niveau / classe actuel",guardian:"Nom du parent / tuteur",school:"École préférée",notes:"Notes complémentaires"},
    ar:{businessName:"اسم المنشأة",businessNo:"رقم تسجيل المنشأة",operatingAddress:"عنوان التشغيل",foodHandlers:"عدد العاملين في تداول الأغذية",kitchenDesc:"وصف مخطط المطبخ",childName:"الاسم الكامل للطفل",dob:"تاريخ الميلاد",birthPlace:"مكان الميلاد",mother:"الاسم الكامل للأم",father:"الاسم الكامل للأب",district:"منطقة التسجيل",fullName:"الاسم الكامل",address:"عنوان السكن الحالي",prevId:"رقم الهوية السابق",deliveryMethod:"طريقة التسليم المفضلة",proposedName:"الاسم المقترح للشركة",activity:"النشاط التجاري الرئيسي",officeAddress:"عنوان المكتب المسجل",director:"اسم المدير الرئيسي",shareholding:"هيكل المساهمين",nationalId:"رقم الهوية الوطنية",residential:"عنوان السكن",household:"حجم الأسرة",income:"دخل الأسرة الشهري",support:"بيان داعم إضافي",learner:"الاسم الكامل للطالب",grade:"الصف / المستوى الحالي",guardian:"اسم ولي الأمر / الوصي",school:"المدرسة المفضلة",notes:"ملاحظات إضافية"},
    pt:{businessName:"Nome da empresa",businessNo:"Número de registo empresarial",operatingAddress:"Endereço de funcionamento",foodHandlers:"Número de manipuladores de alimentos",kitchenDesc:"Descrição do layout da cozinha",childName:"Nome completo da criança",dob:"Data de nascimento",birthPlace:"Local de nascimento",mother:"Nome completo da mãe",father:"Nome completo do pai",district:"Distrito de registo",fullName:"Nome completo",address:"Endereço residencial atual",prevId:"Número de ID anterior",deliveryMethod:"Método de entrega preferido",proposedName:"Nome proposto da empresa",activity:"Atividade principal",officeAddress:"Endereço da sede",director:"Nome do diretor principal",shareholding:"Estrutura acionista",nationalId:"Número de identificação nacional",residential:"Endereço residencial",household:"Dimensão do agregado",income:"Rendimento mensal do agregado",support:"Explicação de apoio adicional",learner:"Nome completo do aluno",grade:"Ano / nível atual",guardian:"Nome do encarregado / tutor",school:"Escola preferida",notes:"Notas adicionais"}
  }[currentLang] || {};
}


function toggleChatbot(show){
  const el = document.getElementById('chatbotPopup');
  if(!el) return;
  if(typeof show === 'boolean'){
    el.classList.toggle('hidden', !show);
  } else {
    el.classList.toggle('hidden');
  }
}
function chatMessagesMap(){
  return {
    how_apply: {
      en: "To apply, open the Food & Beverage Establishment Hygiene Permit service, complete the guidance questions, fill in the application form, upload the required documents, pass AI inspection, and complete the online payment.",
      zh: "请先打开餐饮经营卫生许可证服务，完成情形引导问题，填写申请表，上传所需材料，通过AI审查后完成在线支付。",
      fr: "Pour déposer la demande, ouvrez le service de permis d’hygiène pour établissement de restauration, répondez aux questions de guidage, remplissez le formulaire, téléversez les documents requis, passez le contrôle IA, puis effectuez le paiement en ligne.",
      ar: "لتقديم الطلب، افتح خدمة تصريح نظافة منشآت الأغذية والمشروبات، وأجب عن أسئلة التوجيه، واملأ نموذج الطلب، وارفع المستندات المطلوبة، واجتز فحص الذكاء الاصطناعي، ثم أكمل الدفع الإلكتروني.",
      pt: "Para apresentar o pedido, abra o serviço de licença sanitária para estabelecimento de alimentos e bebidas, responda às perguntas de orientação, preencha o formulário, carregue os documentos exigidos, conclua a inspeção IA e efetue o pagamento online."
    },
    documents: {
      en: "The main required documents are the business registration certificate, kitchen layout plan, food safety management plan, staff health certificates, and waste disposal agreement.",
      zh: "主要材料包括营业登记证书、厨房布局图、食品安全管理方案、从业人员健康证明以及废弃物处理协议。",
      fr: "Les principaux documents requis sont le certificat d’enregistrement de l’entreprise, le plan d’aménagement de la cuisine, le plan de gestion de la sécurité alimentaire, les certificats de santé du personnel et l’accord d’élimination des déchets.",
      ar: "تشمل المستندات الرئيسية المطلوبة شهادة تسجيل النشاط، ومخطط المطبخ، وخطة إدارة سلامة الغذاء، وشهادات صحة العاملين، واتفاقية التخلص من النفايات.",
      pt: "Os principais documentos exigidos são o certificado de registo empresarial, o plano de layout da cozinha, o plano de gestão de segurança alimentar, os certificados de saúde dos funcionários e o acordo de eliminação de resíduos."
    },
    time_fee: {
      en: "The service standard processing time is 5 working days and the current demonstration fee is USD 40.",
      zh: "该服务的标准办理时限为5个工作日，当前演示费用为40美元。",
      fr: "Le délai standard de traitement est de 5 jours ouvrables et les frais de démonstration actuels sont de 40 USD.",
      ar: "مدة المعالجة القياسية لهذه الخدمة هي 5 أيام عمل والرسوم الحالية في العرض هي 40 دولاراً أمريكياً.",
      pt: "O prazo normal de tratamento deste serviço é de 5 dias úteis e a taxa demonstrativa atual é de 40 USD."
    }
  };
}
function addChatMessage(role, text){
  const wrap = document.getElementById('chatbotConversation');
  if(!wrap) return;
  const msg = document.createElement('div');
  msg.className = 'chat-msg ' + role;
  const roleLabel = role === 'user' ? tt('chat_user_label') : tt('chat_ai_label');
  msg.innerHTML = `<div class="small muted">${roleLabel}</div><div class="chat-bubble">${text}</div>`;
  wrap.appendChild(msg);
  wrap.scrollTop = wrap.scrollHeight;
}
function initChatbot(){
  const icon = document.getElementById('chatbotIcon');
  if(icon){ icon.onclick = () => { toggleChatbot(); if(typeof gbotInit==='function') gbotInit(); }; }
  const wrap = document.getElementById('chatbotConversation');
  if(wrap && !wrap.dataset.seeded){
    wrap.dataset.seeded = '1';
    const welcome = {
      en: "How may I assist you with government services today?",
      zh: "今天我可以如何协助您办理政府服务？",
      fr: "Comment puis-je vous aider aujourd’hui pour les services publics ?",
      ar: "كيف يمكنني مساعدتك اليوم في الخدمات الحكومية؟",
      pt: "Como posso ajudar hoje com os serviços governamentais?"
    };
    addChatMessage('ai', welcome[currentLang] || welcome.en);
  }
}
function chatAsk(key){
  const qs = { how_apply: tt('chat_q1'), documents: tt('chat_q2'), time_fee: tt('chat_q3') };
  addChatMessage('user', qs[key]);
  const map = chatMessagesMap();
  addChatMessage('ai', (map[key] && (map[key][currentLang] || map[key].en)) || '');
}
function materialConfigRows(serviceKey){
  const base = mats(serviceKey);
  const defaults = [
    {required:true, formats:['PDF','JPG'], size:'10 MB'},
    {required:true, formats:['PDF','JPG'], size:'10 MB'},
    {required:false, formats:['PDF'], size:'10 MB'},
    {required:false, formats:['PDF','JPG','PNG'], size:'5 MB'},
    {required:false, formats:['PDF'], size:'10 MB'}
  ];
  return base.map((item, idx) => {
    const parts = item.split('|');
    return {name: parts[0], desc: parts[1], required: defaults[idx]?.required ?? false, formats: defaults[idx]?.formats ?? ['PDF'], size: defaults[idx]?.size ?? '10 MB'};
  });
}
function citizenFieldRows(serviceKey){
  const common = {
    hygiene: [
      [translatedFormLabelMap().businessName || tt('key_business_name'), tt('text_type'), tt('yes'), tt('mandatory')],
      [translatedFormLabelMap().businessNo || tt('key_business_registration_number') || tt('key_business_registration_number'), tt('text_type'), tt('yes'), tt('mandatory')],
      [translatedGuidanceLabelMap().typeEst || 'Type of Establishment', tt('dropdown_type'), tt('yes'), tt('controlled_list')],
      [translatedFormLabelMap().operatingAddress || 'Operating Address', tt('text_type'), tt('yes'), tt('mandatory')],
      [translatedGuidanceLabelMap().foodCat || 'Primary food category', tt('dropdown_type'), tt('yes'), tt('controlled_list')],
      [translatedFormLabelMap().foodHandlers || 'Number of food handlers', tt('text_type'), tt('yes'), tt('mandatory')],
      [translatedFormLabelMap().kitchenDesc || 'Kitchen layout description', tt('text_type'), tt('yes'), tt('mandatory')],
      [tt('key_supporting_upload'), tt('upload_type'), tt('yes'), tt('format_size')]
    ],
    birth: [
      [translatedFormLabelMap().childName || tt('key_child_full_name'), tt('text_type'), tt('yes'), tt('mandatory')],
      [translatedFormLabelMap().dob || tt('key_date_of_birth'), tt('date_type'), tt('yes'), tt('logical_date')],
      [translatedFormLabelMap().birthPlace || tt('key_place_of_birth'), tt('text_type'), tt('yes'), tt('mandatory')],
      [tt('field_mother_name'), tt('text_type'), tt('yes'), tt('mandatory')],
      [tt('field_father_name'), tt('text_type'), tt('no'), tt('mandatory')],
      [tt('key_supporting_upload'), tt('upload_type'), tt('yes'), tt('format_size')]
    ]
  };
  return common[serviceKey] || common.hygiene;
}



function docForMaterialKey(materialKey){
  const docs = {
    mat_business_cert: {
      title: () => tt('mat_business_cert'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">BUSINESS</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_business_cert')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_registry')}</div></div>
          <div class="pdf-meta">
            <div class="pdf-meta-item"><span>${tt('pdf_ref')}</span><strong>BUS-2026-44182</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_authority')}</span><strong>${tt('pdf_auth_business_registry')}</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_classification')}</span><strong>${tt('pdf_related_service_file')}</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_review_status')}</span><strong>${tt('pdf_prechecked')}</strong></div>
          </div>
          <div class="pdf-section-title">${tt('pdf_section_registration')}</div>
          <div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line"></div><div class="pdf-line short"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_filed_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_kitchen_plan: {
      title: () => tt('mat_kitchen_plan'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">HYGIENE</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_kitchen_plan')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_fnb')}</div></div>
          <div class="pdf-meta">
            <div class="pdf-meta-item"><span>${tt('pdf_ref')}</span><strong>HYG-PLAN-2026-118</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_authority')}</span><strong>${tt('pdf_auth_public_health')}</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_classification')}</span><strong>${tt('pdf_related_service_file')}</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_review_status')}</span><strong>${tt('pdf_prechecked')}</strong></div>
          </div>
          <div class="pdf-grid2">
            <div class="pdf-box"><strong>${tt('pdf_zone_prep')}</strong><div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div></div></div>
            <div class="pdf-box"><strong>${tt('pdf_zone_wash')}</strong><div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div></div></div>
            <div class="pdf-box"><strong>${tt('pdf_zone_cold')}</strong><div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div></div></div>
            <div class="pdf-box"><strong>${tt('pdf_zone_waste')}</strong><div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div></div></div>
          </div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_approved_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_food_safety: {
      title: () => tt('mat_food_safety'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">SAFETY</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_food_safety')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_plan')}</div></div>
          <div class="pdf-meta">
            <div class="pdf-meta-item"><span>${tt('pdf_ref')}</span><strong>FSP-2026-022</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_authority')}</span><strong>${tt('pdf_auth_public_health')}</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_classification')}</span><strong>${tt('pdf_related_service_file')}</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_review_status')}</span><strong>${tt('pdf_prechecked')}</strong></div>
          </div>
          <div class="pdf-section-title">${tt('pdf_section_control_measures')}</div>
          <div class="pdf-lines"><div class="pdf-line"></div><div class="pdf-line"></div><div class="pdf-line med"></div><div class="pdf-line"></div><div class="pdf-line short"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_verified_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_staff_health: {
      title: () => tt('mat_staff_health'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">HEALTH</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_staff_health')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_medical')}</div></div>
          <div class="pdf-meta">
            <div class="pdf-meta-item"><span>${tt('pdf_ref')}</span><strong>MED-2026-763</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_authority')}</span><strong>${tt('pdf_auth_public_health')}</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_classification')}</span><strong>${tt('pdf_related_service_file')}</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_review_status')}</span><strong>${tt('pdf_prechecked')}</strong></div>
          </div>
          <div class="pdf-grid2">
            <div class="pdf-box"><div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div><div class="pdf-line med"></div></div></div>
            <div class="pdf-box"><div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div><div class="pdf-line med"></div></div></div>
          </div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_verified_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_waste_agreement: {
      title: () => tt('mat_waste_agreement'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">WASTE</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_waste_agreement')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_service')}</div></div>
          <div class="pdf-meta">
            <div class="pdf-meta-item"><span>${tt('pdf_ref')}</span><strong>WST-2026-091</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_authority')}</span><strong>${tt('pdf_auth_public_health')}</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_classification')}</span><strong>${tt('pdf_related_service_file')}</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_review_status')}</span><strong>${tt('pdf_prechecked')}</strong></div>
          </div>
          <div class="pdf-lines"><div class="pdf-line"></div><div class="pdf-line med"></div><div class="pdf-line"></div><div class="pdf-line short"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_filed_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },

    mat_birth_notice: {
      title: () => tt('mat_birth_notice'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">BIRTH</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_birth_notice')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_registry')}</div></div>
          <div class="pdf-meta">
            <div class="pdf-meta-item"><span>${tt('pdf_ref')}</span><strong>BRT-2026-204</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_authority')}</span><strong>${tt('pdf_auth_civil_registry')}</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_classification')}</span><strong>${tt('pdf_related_service_file')}</strong></div>
            <div class="pdf-meta-item"><span>${tt('pdf_review_status')}</span><strong>${tt('pdf_prechecked')}</strong></div>
          </div>
          <div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div><div class="pdf-line med"></div><div class="pdf-line short"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_issued_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_parent_id: {
      title: () => tt('mat_parent_id'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">PARENT ID</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_parent_id')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_id')}</div></div>
          <div class="pdf-grid2"><div class="pdf-photo">👤</div><div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div><div class="pdf-line med"></div></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_verified_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_marriage_cert: {
      title: () => tt('mat_marriage_cert'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">MARRIAGE</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_marriage_cert')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_civil')}</div></div>
          <div class="pdf-lines"><div class="pdf-line"></div><div class="pdf-line med"></div><div class="pdf-line short"></div><div class="pdf-line"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_filed_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_birth_place_proof: {
      title: () => tt('mat_birth_place_proof'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">FACILITY</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_birth_place_proof')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_attestation')}</div></div>
          <div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line"></div><div class="pdf-line short"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_issued_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },

    mat_prev_id: {
      title: () => tt('mat_prev_id'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">IDENTITY</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_prev_id')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_card')}</div></div>
          <div class="pdf-grid2"><div class="pdf-photo">🪪</div><div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div><div class="pdf-line med"></div></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_verified_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_address_proof: {
      title: () => tt('mat_address_proof'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">ADDRESS</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_address_proof')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">UTILITY</div></div>
          <div class="pdf-lines"><div class="pdf-line"></div><div class="pdf-line med"></div><div class="pdf-line short"></div><div class="pdf-line"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_verified_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_citizenship: {
      title: () => tt('mat_citizenship'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">CITIZENSHIP</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_citizenship')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_status')}</div></div>
          <div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line"></div><div class="pdf-line short"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_verified_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_portrait: {
      title: () => tt('mat_portrait'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">PHOTO</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_portrait')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">IMG</div></div>
          <div class="pdf-grid2"><div class="pdf-photo">👤</div><div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div><div class="pdf-line med"></div></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_verified_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },

    mat_company_name: {
      title: () => tt('mat_company_name'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">NAME</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_company_name')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_reservation')}</div></div>
          <div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div><div class="pdf-line med"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_filed_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_shareholder: {
      title: () => tt('mat_shareholder'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">SHAREHOLDERS</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_shareholder')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_register')}</div></div>
          <div class="pdf-lines"><div class="pdf-line"></div><div class="pdf-line"></div><div class="pdf-line med"></div><div class="pdf-line short"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_filed_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_registered_address: {
      title: () => tt('mat_registered_address'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">ADDRESS</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_registered_address')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_office')}</div></div>
          <div class="pdf-lines"><div class="pdf-line"></div><div class="pdf-line med"></div><div class="pdf-line short"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_filed_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_articles: {
      title: () => tt('mat_articles'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">${tt('pdf_chip_legal')}</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_articles')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_legal')}</div></div>
          <div class="pdf-lines"><div class="pdf-line"></div><div class="pdf-line"></div><div class="pdf-line med"></div><div class="pdf-line"></div><div class="pdf-line"></div><div class="pdf-line short"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_filed_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },

    mat_applicant_id: {
      title: () => tt('mat_applicant_id'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">IDENTITY</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_applicant_id')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_id')}</div></div>
          <div class="pdf-grid2"><div class="pdf-photo">👤</div><div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_verified_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_household_record: {
      title: () => tt('mat_household_record'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">HOUSEHOLD</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_household_record')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_social')}</div></div>
          <div class="pdf-lines"><div class="pdf-line"></div><div class="pdf-line med"></div><div class="pdf-line short"></div><div class="pdf-line"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_accepted_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_income: {
      title: () => tt('mat_income'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">INCOME</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_income')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_social')}</div></div>
          <div class="pdf-lines"><div class="pdf-line short"></div><div class="pdf-line short"></div><div class="pdf-line med"></div><div class="pdf-line"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_approved_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_vulnerability: {
      title: () => tt('mat_vulnerability'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">SUPPORT</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_vulnerability')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_evidence')}</div></div>
          <div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div><div class="pdf-line"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_verified_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },

    mat_learner_birth: {
      title: () => tt('mat_learner_birth'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">LEARNER</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_learner_birth')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_education')}</div></div>
          <div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div><div class="pdf-line med"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_accepted_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_guardian_id: {
      title: () => tt('mat_guardian_id'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">GUARDIAN</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_guardian_id')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_id')}</div></div>
          <div class="pdf-grid2"><div class="pdf-photo">👤</div><div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_verified_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_residence: {
      title: () => tt('mat_residence'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">RESIDENCE</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_residence')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">ADDRESS</div></div>
          <div class="pdf-lines"><div class="pdf-line"></div><div class="pdf-line med"></div><div class="pdf-line short"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_verified_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    },
    mat_school_record: {
      title: () => tt('mat_school_record'),
      page: () => `
        <div class="pdf-page">
          <div class="pdf-watermark">SCHOOL</div>
          <div class="pdf-head"><div><div class="pdf-sub">${tt('pdf_generated_by')}</div><div class="pdf-title">${tt('mat_school_record')}</div><div class="pdf-sub">${tt('pdf_official_copy')}</div></div><div class="pdf-chip">${tt('pdf_chip_record')}</div></div>
          <div class="pdf-lines"><div class="pdf-line med"></div><div class="pdf-line short"></div><div class="pdf-line med"></div><div class="pdf-line"></div></div>
          <div class="pdf-footer"><div class="pdf-sign"><div class="pdf-sign-line">${tt('pdf_authorized_signatory')}</div></div><div class="pdf-seal">${tt('pdf_accepted_stamp')}</div></div>
        </div>`,
      notes: () => [tt('pdf_verified_readable'), tt('pdf_fields_match'), tt('pdf_clarify_may_be_required')]
    }
  };
  return docs[materialKey] || docs.mat_kitchen_plan;
}
function openDoc(materialKey){
  const body = document.getElementById('docModalBody');
  const title = document.getElementById('docModalTitle');
  if(!body || !title) return;
  const doc = docForMaterialKey(materialKey);
  title.textContent = doc.title();
  body.innerHTML = `
    ${doc.page()}
    <div class="pdf-side">
      <div class="panel">
        <h3>${tt('pdf_doc_summary')}</h3>
        <div class="audit-list">
          ${doc.notes().map(n => `<div class="audit-item">${n}</div>`).join('')}
        </div>
      </div>
    </div>`;
  document.getElementById('docBackdrop').style.display = 'flex';
}
function closeDoc(){
  const el = document.getElementById('docBackdrop');
  if(el) el.style.display = 'none';
}


let officerDecisionMode = 'approve';
function decisionReasonsByMode(mode){
  if(mode === 'correction'){
    return ['reason_missing_material','reason_unreadable_doc','reason_data_inconsistent','reason_wrong_branch','reason_payment_incomplete'];
  }
  if(mode === 'reject'){
    return ['reason_not_eligible','reason_legal_requirement','reason_invalid_evidence','reason_duplicate_application','reason_expired_record'];
  }
  if(mode === 'escalate'){
    return ['reason_high_risk','reason_cross_agency','reason_policy_review'];
  }
  return [];
}
function officerDecisionStatus(mode){
  if(mode === 'correction') return tt('correction_required_status');
  if(mode === 'reject') return tt('rejected_status');
  if(mode === 'escalate') return tt('escalated_status');
  return tt('approved_status');
}
function renderOfficerDecisionPanel(){
  const root = document.getElementById('officerDecisionWrap');
  if(!root) return;
  const modes = [
    ['approve', tt('approve_action')],
    ['correction', tt('return_correction')],
    ['reject', tt('reject_application')],
    ['escalate', tt('escalate_review')]
  ];
  const reasons = decisionReasonsByMode(officerDecisionMode);
  const reasonHtml = reasons.length ? `
    <div>
      <label>${tt('select_reasons')}</label>
      <div class="reason-grid">
        ${reasons.map(r => `<label class="reason-item"><input type="checkbox"> <span>${tt(r)}</span></label>`).join('')}
      </div>
    </div>` : '';
  root.innerHTML = `
    <div class="decision-shell">
      <div>
        <label>${tt('decision_type')}</label>
        <div class="decision-types">
          ${modes.map(([id,label]) => `<div class="decision-type ${officerDecisionMode===id?'active':''}" onclick="setOfficerDecisionMode('${id}')"><strong>${label}</strong><div class="small muted">${officerDecisionStatus(id)}</div></div>`).join('')}
        </div>
      </div>
      ${reasonHtml}
      <div>
        <label>${tt('officer_comments')}</label>
        <textarea class="textarea"></textarea>
      </div>
      <div>
        <label>${tt('citizen_explanation')}</label>
        <textarea class="textarea"></textarea>
      </div>
      <div>
        <label>${tt('internal_note')}</label>
        <textarea class="textarea"></textarea>
      </div>
      <div class="toggle-row"><input type="checkbox" checked> <span>${tt('notify_applicant')}</span></div>
      <div class="summary-box">
        <h3>${tt('decision_summary')}</h3>
        <div class="summary-list">
          <div><span>${tt('outcome_status')}</span><strong>${officerDecisionStatus(officerDecisionMode)}</strong></div>
          <div><span>${tt('reasons_selected')}</span><strong>${reasons.length ? reasons.map(r=>tt(r)).join(', ') : '—'}</strong></div>
        </div>
        <div class="actions">
          <button class="secondary">${tt('save_draft')}</button>
          <button class="primary">${tt('submit_decision')}</button>
        </div>
      </div>
    </div>`;
}
function setOfficerDecisionMode(mode){
  officerDecisionMode = mode;
  renderOfficerDecisionPanel();
}


function officerAiInspectionData(serviceKey){
  if(serviceKey === 'hygiene'){
    return {
      score:87, risk:'medium', confidence:tt('ai_confidence_medium'),
      bars:[[tt('ai_completeness'),80],[tt('ai_consistency'),90],[tt('ai_clarity'),70]],
      checks:[
        ['pass',tt('ai_pass_required_docs')],
        ['pass',tt('ai_pass_file_format')],
        ['warn',tt('ai_warn_address')],
        ['warn',tt('ai_warn_clarity')],
        ['pass',tt('ai_pass_payment')]
      ],
      docs:[
        [tt('mat_business_cert'),tt('ai_doc_verified'),'pass'],
        [tt('mat_kitchen_plan'),tt('ai_doc_needs_review'),'warn'],
        [tt('mat_food_safety'),tt('ai_doc_verified'),'pass']
      ],
      suggestions:[tt('ai_suggestion_clearer_layout'),tt('ai_suggestion_confirm_address')]
    };
  }
  return {
    score:91, risk:'low', confidence:tt('ai_confidence_good'),
    bars:[[tt('ai_completeness'),92],[tt('ai_consistency'),90],[tt('ai_clarity'),91]],
    checks:[
      ['pass',tt('ai_pass_required_docs')],
      ['pass',tt('ai_pass_file_format')],
      ['pass',tt('ai_pass_identity')]
    ],
    docs:[[tt('mat_parent_id') || 'ID',tt('ai_doc_verified'),'pass']],
    suggestions:[tt('ai_officer_hint')]
  };
}
function renderOfficerAiInspection(){
  const root = document.getElementById('officerAiInspectionWrap');
  if(!root) return;
  const d = officerAiInspectionData(currentOfficerService || 'hygiene');
  const riskLabel = d.risk === 'low' ? tt('ai_low_risk') : (d.risk === 'high' ? tt('ai_high_risk') : tt('ai_medium_risk'));
  root.innerHTML = `
    <div class="ai-audit-shell">
      <div class="ai-topbar">
        <div class="ai-score-card">
          <div class="ai-score-head">
            <div>
              <div class="small muted">${tt('ai_score_label')}</div>
              <div class="ai-score-number">${d.score}<span style="font-size:16px;font-weight:700"> / 100</span></div>
            </div>
            <span class="ai-risk ${d.risk}">${riskLabel}</span>
          </div>
          <div class="ai-score-sub">${d.confidence}</div>
          <div class="ai-hint-box">${tt('ai_officer_hint')}</div>
        </div>
        <div class="ai-breakdown-card">
          <h3>${tt('ai_inspection_overview')}</h3>
          ${d.bars.map(([label,val]) => `<div class="ai-break-row"><span>${label}</span><div class="ai-bar"><span style="width:${val}%"></span></div><strong>${val}%</strong></div>`).join('')}
        </div>
      </div>

      <div class="ai-findings-card">
        <h3>${tt('ai_check_results')}</h3>
        <div class="ai-checklist">
          ${d.checks.map(([state,text]) => `<div class="ai-check-item"><strong class="${state==='pass'?'ai-icon-pass':state==='warn'?'ai-icon-warn':'ai-icon-fail'}">${state==='pass'?'✔':state==='warn'?'⚠':'✖'}</strong><span>${text}</span><span class="status-tag">${state==='pass'?tt('ai_doc_verified'):state==='warn'?tt('ai_doc_needs_review'):tt('ai_doc_invalid')}</span></div>`).join('')}
        </div>
      </div>

      <div class="ai-doc-card">
        <h3>${tt('ai_doc_breakdown')}</h3>
        <div class="ai-doc-list">
          ${d.docs.map(([name,status,state]) => `<div class="ai-doc-item"><div class="ai-mini-thumb"></div><div><strong>${name}</strong></div><span class="status-tag">${status}</span><strong class="${state==='pass'?'ai-icon-pass':state==='warn'?'ai-icon-warn':'ai-icon-fail'}">${state==='pass'?'✔':state==='warn'?'⚠':'✖'}</strong></div>`).join('')}
        </div>
      </div>

      <div class="ai-suggest-card">
        <h3>${tt('ai_suggestions')}</h3>
        <div class="ai-suggest-list">
          ${d.suggestions.map(s => `<div class="ai-suggest-item"><strong class="ai-icon-warn">⚠</strong><span>${s}</span><span></span></div>`).join('')}
        </div>
      </div>
    </div>`;
}


let officerDossierTab = 'form';
function officerSubmissionData(serviceKey){
  const stageLabelMap = {pre: tt('pre_approval'), accept: tt('acceptance'), approve: tt('approval'), complete: tt('completion')};
  if(serviceKey === 'hygiene'){
    return {
      appNo:'HYGIENE-2026-004182',
      applicant:'Evergreen Bistro Ltd.',
      contact:'Amelia Tan',
      submitted:'2026-03-30 10:24',
      service:serviceTitle('hygiene'),
      status: stageLabelMap[currentOfficerTab || 'pre'] || 'Acceptance',
      fields:[
        ['key_business_name', 'Evergreen Bistro Ltd.', 'citizen'],
        ['owner_contact', 'Amelia Tan / +65 8123 4567', 'citizen'],
        ['field_address', '25 Market Street, Central District', 'citizen', 'mismatch'],
        ['establishment_type', 'Restaurant', 'citizen'],
        ['food_category', 'Hot meals and beverages', 'citizen'],
        ['food_handlers', '12', 'citizen'],
        ['delivery_preference', 'Digital Certificate', 'citizen'],
        ['onsite_prep', 'Yes', 'citizen']
      ],
      docs:[
        [tt('mat_business_cert'), tt('auto_fetched'), tt('source_business_registry')],
        [tt('mat_kitchen_plan'), tt('citizen_entered'), tt('linked_document')],
        [tt('mat_food_safety'), tt('citizen_entered'), tt('linked_document')],
        [tt('mat_staff_health'), tt('citizen_entered'), tt('linked_document')]
      ],
      ai:[
        'Address in application differs slightly from business registry record.',
        'Kitchen layout image requires closer officer review.',
        'Required document set is otherwise complete.'
      ],
      history:[tt('history_submitted'), tt('history_ai_checked'), tt('history_accepted'), tt('history_reviewing')]
    };
  }
  return {
    appNo:`${serviceKey.toUpperCase()}-2026-001001`,
    applicant:'Sample Applicant',
    contact:'Citizen Record',
    submitted:'2026-03-29 09:00',
    service:serviceTitle(serviceKey),
    status: stageLabelMap[currentOfficerTab || 'pre'] || 'Review',
    fields:[
      ['applicant_name', 'Sample Applicant', 'citizen'],
      ['submitted_on', '2026-03-29 09:00', 'auto']
    ],
    docs:[[tt('mat_parent_id') || 'Document', tt('auto_fetched'), tt('linked_document')]],
    ai:['No significant discrepancies identified.'],
    history:[tt('history_submitted'), tt('history_ai_checked')]
  };
}



function officerHeaderStrip(){
  const d = officerSubmissionData(currentOfficerService || 'hygiene');
  const score = (currentOfficerService || 'hygiene') === 'hygiene' ? '87 / 100' : '91 / 100';
  return `<div class="officer-header-strip">
    <div class="officer-head-card"><span>${tt('application_no')}</span><strong>${d.appNo}</strong></div>
    <div class="officer-head-card"><span>${tt('applicant_name')}</span><strong>${d.applicant}</strong></div>
    <div class="officer-head-card"><span>${tt('service_reference')}</span><strong>${d.service}</strong></div>
    <div class="officer-head-card"><span>${tt('submitted_on')}</span><strong>${d.submitted}</strong></div>
    <div class="officer-head-card"><span>${tt('current_stage')}</span><strong>${d.status}</strong></div>
    <div class="officer-head-card"><span>${tt('ai_score')}</span><strong>${score}</strong></div>
  </div>`;
}
function officerSnapshotCard(){
  const d = officerSubmissionData(currentOfficerService || 'hygiene');
  return `<div class="officer-snapshot">
    <h3>${tt('application_snapshot')}</h3>
    <div class="officer-snapshot-grid">
      ${d.fields.map(row => `<div class="officer-field"><span>${tt(row[0]) || row[0]}</span><strong>${row[1]}</strong><div class="tags"><span class="officer-source-tag">${row[2]==='auto'?tt('auto_fetched'):tt('citizen_entered')}</span>${row[3]==='mismatch'?`<span class="officer-mismatch">${tt('mismatch_flag')}</span>`:''}</div></div>`).join('')}
    </div>
  </div>`;
}
function officerMaterialsOverview(){
  const d = officerSubmissionData(currentOfficerService || 'hygiene');
  const map = {
    hygiene:['mat_business_cert','mat_kitchen_plan','mat_food_safety','mat_staff_health'],
    birth:['mat_birth_notice','mat_parent_id','mat_birth_place_proof'],
    idcard:['mat_prev_id','mat_address_proof','mat_portrait'],
    company:['mat_company_name','mat_shareholder','mat_articles'],
    grant:['mat_applicant_id','mat_income','mat_vulnerability'],
    school:['mat_learner_birth','mat_guardian_id','mat_school_record']
  };
  const keys = map[currentOfficerService] || map.hygiene;
  return `<div class="officer-doc-grid">
    ${d.docs.map((row, idx) => `<div class="officer-doc-card"><strong>${row[0]}</strong><div class="small muted">${row[2]}</div><div class="officer-source-tag">${row[1]}</div><div class="actions"><button class="ghost" onclick="openDoc('${keys[idx] || keys[0]}')">${tt('view_document')}</button></div></div>`).join('')}
  </div>`;
}

window.addEventListener('DOMContentLoaded', ()=>{
  document.getElementById('langSelect').value='en';
  applyTranslations(); renderServiceCards(); renderDashboard(); renderCitizenService(); renderOfficer(); renderAdmin(); renderOfficerDecisionPanel(); choosePayment('card'); setLoginTab('mobile'); goHome(); initChatbot(); populateAdminContext(); renderAdminContext();
});

