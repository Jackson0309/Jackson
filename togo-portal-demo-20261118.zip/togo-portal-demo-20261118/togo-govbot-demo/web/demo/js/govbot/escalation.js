// Public help routes, without the old fictional officers/account-access claims.
const GBOT_ESCALATION={active:false};
const GBOT_ESC_i18n={fr:{triggerBtn:'Consulter l’assistance officielle'},en:{triggerBtn:'Official assistance'},zh:{triggerBtn:'查看官方帮助'}};
function gbotStartEscalation(key){
 GBOT_FLOW.active=false;GBOT_FLOW.generation++;
 const service=GBOT_KB[key||GBOT_ENGINE.lastIntent];
 const url=service?'https://new.service-public.gouv.tg/faqs/service/'+service.service_id:'https://new.service-public.gouv.tg/faqs';
 const {bubble}=gbotAppendMsg('bot','',true);
 setTimeout(()=>{bubble.innerHTML=`<strong>${FL('Assistance officielle','Official assistance','官方办事帮助')}</strong><p>${FL('Consultez les questions fréquentes propres à la démarche et les coordonnées de son fournisseur. Aucun agent humain n’est connecté à cette démonstration.','Use the service-specific FAQs and provider contact details. No live human agent is connected to this demonstration.','可查看该事项常见问题及主管机构联系方式。本演示未连接真实人工客服。')}</p><a class="gbot-apply-btn" href="${url}" target="_blank" rel="noopener noreferrer">${FL('Centre d’assistance ↗','Help centre ↗','打开官方帮助中心 ↗')}</a>`;},700);
}
function gbotInterceptEscalation(){}
