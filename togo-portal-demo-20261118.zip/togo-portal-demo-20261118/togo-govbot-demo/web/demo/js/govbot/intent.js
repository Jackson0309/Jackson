// Normalise accents/apostrophes and match the six real homepage service intents.
const GBOT_INTENT_KW = {
 nationality:['国籍证明','国籍证','nationality certificate','nationalité','nationalite','filiation','naturalisation','citizenship'],
 passport:['护照','passport','passeport'],
 courtfees:['法院','案件登记','立案','缴费','enrôlement','enrolement','tribunal','juridiction','court','case registration'],
 criminal:['犯罪记录','无犯罪','无定罪','casier','judiciaire','criminal record','non-conviction','non condamnation','non-condamnation','b3','cje'],
 duplicate:['国籍证明副本','副本','国籍补发','duplicata','duplicate','copie de nationalite'],
 residence:['居留','residence','résidence','sejour','séjour','residence permit']
};
const GBOT_ASPECT_KW = {
 requirements:['材料','文件','清单','documents','pieces','requirements','checklist','bring','besoin'],
 fees:['费用','多少钱','收费','价格','付款','frais','cout','prix','payer','combien','tarif','fee','cost','price','pay'],
 time:['时限','多久','时间','délai','delai','jours','semaines','duration','timeline','how long','processing time'],
 steps:['怎么','流程','如何','步骤','办理','申请','comment','étape','etape','procedure','apply','process','how to'],
 eligibility:['资格','条件','谁可以','eligible','eligibilite','qui peut','critere','qualify','who can'],
 hours:['办公','开放','几点','营业','horaire','ouvert','office hours','opening'],
 faq:['常见','faq','question','问题']
};
function gbotNormalise(text){return String(text).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[’']/g,' ').replace(/\s+/g,' ').trim();}
function gbotDetectIntent(text){
 const value=gbotNormalise(text);
 // Duplicate certificates contain “nationalité” too: handle the narrower intent first.
 if(GBOT_INTENT_KW.duplicate.some(k=>value.includes(gbotNormalise(k)))) return {intent:'duplicate',score:1};
 let intent=null,score=0;
 for(const [key,keywords] of Object.entries(GBOT_INTENT_KW)){
  const n=keywords.reduce((sum,k)=>sum+(value.includes(gbotNormalise(k))?k.length:0),0);
  if(n>score){intent=key;score=n;}
 }
 return {intent,score};
}
function gbotDetectAspect(text){
 const value=gbotNormalise(text);
 for(const aspect of ['requirements','hours','fees','time','eligibility','steps','faq'])if(GBOT_ASPECT_KW[aspect].some(w=>value.includes(gbotNormalise(w))))return aspect;
 return 'overview';
}
