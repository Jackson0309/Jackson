// Togo homepage services — official sources checked 2026-11-06.
const GBOT_KB = {
  "nationality": {
    "icon": "📜",
    "service_id": "01KJNT5BN004M0AZCF7PW283VQ",
    "route": "/service/01KJNT5BN004M0AZCF7PW283VQ",
    "sources": [
      {
        "url": "https://new.service-public.gouv.tg/service/01KJNT5BN004M0AZCF7PW283VQ",
        "publisher": "Service Public de l’administration togolaise",
        "scope": "Current service entry and situation selector",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      },
      {
        "url": "https://service-public.gouv.tg/mjl-certificat-nationalite",
        "publisher": "Service Public de l’administration togolaise",
        "scope": "Published service guidance",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      }
    ],
    "fr": {
      "title": "Certificat de nationalité togolaise",
      "summary": "Prouver la nationalité togolaise. Le formulaire distingue filiation, mariage, possession d’état, naturalisation et changement de format.",
      "eligibility": [
        "Choisir le fondement de la demande et le lieu de naissance.",
        "La branche filiation concerne les enfants d’un parent togolais. Les autres branches ont leurs propres conditions."
      ],
      "requirements": [
        "Filiation : acte de naissance légalisé ou acte équivalent.",
        "Nationalité du parent togolais ou d’un frère/d’une sœur de même père ou de même mère selon le formulaire ; ancien original/copie ou duplicata nouveau format.",
        "Photo passeport. À défaut de justificatif familial accepté, vérifier la voie du certificat d’origine.",
        "Pour mariage ou autres fondements, consulter la liste propre à la situation."
      ],
      "steps": [
        "Sélectionner le fondement et le lieu de naissance.",
        "Préparer les pièces et remplir le formulaire officiel.",
        "Régler les frais affichés ; la DNSC vérifie le dossier et peut demander des compléments.",
        "Après avis favorable, effectuer le dépôt physique au lieu choisi puis attendre la notification de retrait."
      ],
      "fee": "5 000 F CFA — filiation",
      "time": "2 mois — délai publié, indicatif",
      "notice": "Sans justificatif de nationalité familial accepté, la procédure liée au certificat d’origine est annoncée à 15 000 F CFA. Les autres branches doivent être vérifiées dans le formulaire.",
      "faq": [
        {
          "q": "Est-ce un acte de naissance ?",
          "a": "Non. Il prouve la nationalité ; l’acte de naissance atteste une naissance."
        },
        {
          "q": "Le parcours est-il entièrement en ligne ?",
          "a": "Non. La branche filiation prévoit un dépôt physique après avis favorable."
        },
        {
          "q": "Quelle durée de validité ?",
          "a": "Le formulaire indique une validité permanente pour la branche filiation."
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KJNT5BN004M0AZCF7PW283VQ"
    },
    "en": {
      "title": "Togolese nationality certificate",
      "summary": "Evidence of Togolese nationality. Select descent, marriage, possession of status, naturalisation or format change in the official form.",
      "eligibility": [
        "Select the legal basis and birthplace.",
        "The descent branch concerns children of a Togolese parent; other branches require separate checks."
      ],
      "requirements": [
        "Descent: legalised birth record or equivalent.",
        "Nationality certificate of the Togolese parent or a sibling sharing the relevant father/mother as allowed by the form; old original/copy or new-format duplicate.",
        "Passport photo; if accepted family-nationality evidence is unavailable, check the certificate-of-origin route.",
        "Other branches: use their own official checklist."
      ],
      "steps": [
        "Choose basis and birthplace.",
        "Prepare documents and complete the official form.",
        "Pay the displayed fee; DNSC checks completeness and requests corrections if needed.",
        "After a favourable notice, lodge the physical dossier at the selected centre and await collection instructions."
      ],
      "fee": "5,000 F CFA — descent",
      "time": "2 months — published indication",
      "notice": "The certificate-of-origin route when accepted family-nationality evidence is unavailable is published at 15,000 F CFA. Other branches require confirmation.",
      "faq": [
        {
          "q": "Is this a birth certificate?",
          "a": "No. It establishes nationality, rather than recording a birth."
        },
        {
          "q": "Is it fully online?",
          "a": "No. The observed descent procedure includes a physical dossier after a favourable notice."
        },
        {
          "q": "Does it expire?",
          "a": "The descent form displays permanent validity."
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KJNT5BN004M0AZCF7PW283VQ"
    },
    "zh": {
      "title": "多哥国籍证明",
      "summary": "证明持有人具有多哥国籍。官方表单区分血缘、婚姻、身份占有、入籍及证书格式变更。",
      "eligibility": [
        "先确定申请依据和出生地。",
        "血缘分支面向多哥籍父母的子女；其他分支须单独核对条件。"
      ],
      "requirements": [
        "血缘分支：经认证的出生登记文件或等效文件。",
        "多哥籍父母，或按官方表单认可的同父/同母兄弟姐妹的国籍证明；旧版原件及复印件，或新版副本。",
        "证件照片；缺少被认可的亲属国籍证明时，核对来源证明（certificat d’origine）途径。",
        "婚姻、入籍等情形使用各自清单，不能套用血缘材料。"
      ],
      "steps": [
        "在官方表单选择申请依据和出生地。",
        "备齐材料并填写官方申请。",
        "按页面金额缴费；DNSC 核验并通知补充或纠正材料。",
        "收到有利审查通知后，到所选地点递交纸质材料，再按通知领取。"
      ],
      "fee": "5,000 西非法郎（F CFA）—血缘分支",
      "time": "公布参考：2 个月",
      "notice": "缺少被认可的亲属国籍证明、改走来源证明相关途径时，页面公布为 15,000 F CFA。其他分支须在官方表单确认。",
      "faq": [
        {
          "q": "国籍证明就是出生证明吗？",
          "a": "不是。国籍证明证明国籍，出生登记文件证明出生事实。"
        },
        {
          "q": "可以全程线上完成吗？",
          "a": "本次核查的血缘分支包含审查通过后的线下递交环节。"
        },
        {
          "q": "有效期多久？",
          "a": "血缘分支页面显示永久有效。"
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KJNT5BN004M0AZCF7PW283VQ"
    }
  },
  "passport": {
    "icon": "🛂",
    "service_id": "01KFKEHS3KVS1VDVCFWVVBEQWM",
    "route": "/service/01KFKEHS3KVS1VDVCFWVVBEQWM",
    "sources": [
      {
        "url": "https://new.service-public.gouv.tg/service/01KFKEHS3KVS1VDVCFWVVBEQWM",
        "publisher": "Service Public de l’administration togolaise",
        "scope": "Current service entry and situation selector",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      },
      {
        "url": "https://service-public.gouv.tg/service/62a3c668c07b617d9d1be12b/papiers-citoyennete/demande-de-passeport",
        "publisher": "Service Public de l’administration togolaise",
        "scope": "Published service guidance",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      }
    ],
    "fr": {
      "title": "Demande de passeport",
      "summary": "Préparer une première demande ou un renouvellement auprès de la DGDN. Le nouveau formulaire distingue type de passeport, zone et site de dépôt.",
      "eligibility": [
        "Passeport ordinaire : citoyen togolais.",
        "Passeport de service et diplomatique : circuits spécifiques, à vérifier sur la fiche officielle."
      ],
      "requirements": [
        "Première demande : nationalité et acte de naissance avec justificatifs légalisés.",
        "Attestation de personne à prévenir pour un adulte ou autorisation parentale pour un mineur.",
        "Pièce d’identité, justificatif de profession, photos et acte de mariage si applicable.",
        "Renouvellement : ajouter l’ancien passeport ; vérifier la liste du site choisi."
      ],
      "steps": [
        "Choisir le type, première demande/renouvellement, zone et site.",
        "Remplir la demande ; corriger les informations demandées par la DGDN.",
        "Payer après notification, imprimer formulaire et reçu.",
        "Présenter le dossier à la DGDN selon les consignes puis retirer après notification."
      ],
      "fee": "30 000 F CFA — tarif publié",
      "time": "Au moins 2 semaines — indication publiée",
      "notice": "Le tarif et les pièces publiés concernent le parcours décrit sur la fiche. Un dépôt hors du Togo ou un autre type doit être confirmé dans le formulaire actuel.",
      "faq": [
        {
          "q": "Renouvellement : que faut-il ajouter ?",
          "a": "L’ancien passeport ; conserver les autres justificatifs exigés pour votre situation."
        },
        {
          "q": "Peut-on éviter le dépôt physique ?",
          "a": "La fiche prévoit de présenter le dossier à la DGDN après la phase en ligne."
        },
        {
          "q": "Quelle validité ?",
          "a": "La fiche officielle publiée indique 5 ans."
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KFKEHS3KVS1VDVCFWVVBEQWM"
    },
    "en": {
      "title": "Passport application",
      "summary": "Prepare a first passport or renewal with DGDN. The current form separates passport type, filing area and filing location.",
      "eligibility": [
        "Ordinary passport: Togolese citizen.",
        "Service/diplomatic passports use specific procedures."
      ],
      "requirements": [
        "First application: nationality and birth evidence with required legalised copies.",
        "Emergency-contact attestation for adults or parental permission for minors.",
        "Identity, profession evidence, photos and marriage record where applicable.",
        "Renewal: include the old passport; confirm the chosen location’s checklist."
      ],
      "steps": [
        "Select passport type, first/renewal, area and filing site.",
        "Complete the official form and resolve DGDN corrections.",
        "Pay when notified; print the form and receipt.",
        "Attend the required physical filing and collect after notification."
      ],
      "fee": "30,000 F CFA — published tariff",
      "time": "At least 2 weeks — published indication",
      "notice": "The published tariff/checklist applies to the described procedure. Overseas filing or other passport types require confirmation in the current form.",
      "faq": [
        {
          "q": "What changes for renewal?",
          "a": "Include the previous passport alongside the applicable documents."
        },
        {
          "q": "Is an in-person visit required?",
          "a": "The published procedure includes physical filing at DGDN."
        },
        {
          "q": "How long is it valid?",
          "a": "The published official sheet states five years."
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KFKEHS3KVS1VDVCFWVVBEQWM"
    },
    "zh": {
      "title": "护照申请",
      "summary": "向 DGDN 办理首次护照或换发。新版表单按护照种类、申请类型、境内外和递交地点区分。",
      "eligibility": [
        "普通护照面向多哥公民。",
        "公务、外交护照有专门流程，须查对应分支。"
      ],
      "requirements": [
        "首次申请：国籍证明、出生登记文件及要求的认证副本。",
        "成年人紧急联系人证明，或未成年人的父母授权。",
        "身份证明、职业证明、照片；适用时提交婚姻文件。",
        "换发须增加旧护照，具体材料以递交地点分支为准。"
      ],
      "steps": [
        "选择护照类型、首次或换发、境内外及递交点。",
        "填写官方表单，按 DGDN 通知纠正信息。",
        "收到缴费通知后付款，打印表单和收据。",
        "按通知到指定地点递交材料，并在办妥后领取。"
      ],
      "fee": "官方事项页公布：30,000 F CFA",
      "time": "官方事项页参考：至少 2 周",
      "notice": "该金额和材料对应已发布事项说明；境外递交或其他护照类型须以新版表单确认。",
      "faq": [
        {
          "q": "换发需要增加什么？",
          "a": "旧护照，并保留对应情形要求的其他证明材料。"
        },
        {
          "q": "是否需要线下递交？",
          "a": "官方公布流程包含完成线上步骤后向 DGDN 递交材料。"
        },
        {
          "q": "有效期多久？",
          "a": "已发布的官方事项说明为 5 年。"
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KFKEHS3KVS1VDVCFWVVBEQWM"
    }
  },
  "courtfees": {
    "icon": "⚖️",
    "service_id": "01KPTAYWV1ZAYE012PKN63Q1MM",
    "route": "/service/01KPTAYWV1ZAYE012PKN63Q1MM",
    "sources": [
      {
        "url": "https://new.service-public.gouv.tg/service/01KPTAYWV1ZAYE012PKN63Q1MM",
        "publisher": "Service Public de l’administration togolaise",
        "scope": "Current service entry and situation selector",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      },
      {
        "url": "https://service-public.gouv.tg/service/6a4586a30e3d624b614dd11c/papiers-citoyennete/procedure-de-paiement-de-frais-d-enrolement-de-dossier-dans",
        "publisher": "Service Public de l’administration togolaise",
        "scope": "Published service guidance",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      }
    ],
    "fr": {
      "title": "Frais d’enrôlement au tribunal",
      "summary": "Déposer un dossier judiciaire ou administratif et régler les frais adaptés à la nature de l’affaire et à la juridiction.",
      "eligibility": [
        "Particulier, personne morale ou représentant ayant un dossier à déposer.",
        "Sélectionner la nature de l’affaire et la juridiction compétente."
      ],
      "requirements": [
        "Les pièces dépendent de l’affaire : aucun dossier universel n’est annoncé.",
        "Préparer les informations et justificatifs demandés par le formulaire de l’affaire choisie."
      ],
      "steps": [
        "Choisir l’affaire et la juridiction ; vérifier pièces et montant.",
        "Soumettre sur le portail et régler les frais affichés.",
        "Se présenter au tribunal choisi ; l’administration vérifie et enrôle le dossier conforme.",
        "En cas de requalification, suivre la notification et régler le complément demandé."
      ],
      "fee": "Variable selon l’affaire",
      "time": "Variable selon l’affaire",
      "notice": "Un paiement ne vaut ni enrôlement automatique, ni décision de justice. Aucun tarif fixe ni délai garanti ne peut être déduit de cette fiche.",
      "faq": [
        {
          "q": "Quel montant dois-je payer ?",
          "a": "Il apparaît après le choix de l’affaire et de la juridiction dans le formulaire officiel."
        },
        {
          "q": "Pourquoi un complément ?",
          "a": "L’administration peut requalifier l’affaire et notifier les frais complémentaires."
        },
        {
          "q": "Cette démarche délivre-t-elle un casier judiciaire ?",
          "a": "Non. L’extrait de casier dispose d’un service séparé."
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KPTAYWV1ZAYE012PKN63Q1MM"
    },
    "en": {
      "title": "Court case registration fees",
      "summary": "File a judicial or administrative dossier and pay the fee for the selected case type and court.",
      "eligibility": [
        "Individuals, legal entities or representatives with a dossier to lodge.",
        "Select the case type and competent court."
      ],
      "requirements": [
        "Documents vary by case: the official sheet gives no universal checklist.",
        "Use the documents requested by the selected case form."
      ],
      "steps": [
        "Select case type/court and inspect documents and amount.",
        "Submit on the official portal and pay its displayed fee.",
        "Attend the chosen court; the authority checks and registers a compliant dossier.",
        "Follow any reclassification and additional-fee notice."
      ],
      "fee": "Depends on case type",
      "time": "Depends on case type",
      "notice": "Payment does not guarantee registration or a court decision; no fixed tariff or guaranteed time is published.",
      "faq": [
        {
          "q": "How much will it cost?",
          "a": "The official form calculates it after case and court selection."
        },
        {
          "q": "Why an additional payment?",
          "a": "The authority may reclassify the case and notify a fee difference."
        },
        {
          "q": "Is this a criminal-record certificate?",
          "a": "No. That is a separate service."
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KPTAYWV1ZAYE012PKN63Q1MM"
    },
    "zh": {
      "title": "法院案件登记费用缴纳",
      "summary": "提交司法或行政案件材料，并按案件性质和法院支付相应登记费用。",
      "eligibility": [
        "有案件需提交的个人、法人或合法代表。",
        "必须选择案件性质与有管辖权的法院。"
      ],
      "requirements": [
        "材料按案件类型变化，官方未公布一份通用清单。",
        "按所选案件表单准备案件信息及页面明确要求的证明文件。"
      ],
      "steps": [
        "选择案件类型和法院，核对页面材料及费用。",
        "在官方门户提交并支付页面显示的金额。",
        "按指引前往所选法院；主管机关核验后为合规案件登记。",
        "若案件被重新分类，按通知补缴差额并完成要求。"
      ],
      "fee": "按案件类型确定",
      "time": "按案件类型确定",
      "notice": "缴费不等于自动立案或获得法院裁决；本事项没有统一固定金额或保证时限。",
      "faq": [
        {
          "q": "为什么不能直接给固定费用？",
          "a": "官方表单在选择案件性质与法院后显示对应金额。"
        },
        {
          "q": "为什么可能要求补缴？",
          "a": "主管机关可能重新认定案件类型，并通知补缴对应差额。"
        },
        {
          "q": "这就是犯罪记录证明申请吗？",
          "a": "不是。犯罪记录证明有独立事项入口。"
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KPTAYWV1ZAYE012PKN63Q1MM"
    }
  },
  "criminal": {
    "icon": "📄",
    "service_id": "01KJNQA87SE30X0ATQKSQEEVEA",
    "route": "/service/01KJNQA87SE30X0ATQKSQEEVEA",
    "sources": [
      {
        "url": "https://new.service-public.gouv.tg/service/01KJNQA87SE30X0ATQKSQEEVEA",
        "publisher": "Service Public de l’administration togolaise",
        "scope": "Current service entry and situation selector",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      },
      {
        "url": "https://service-public.gouv.tg/service/66ad0d1a77147a240f6d7547/justice/demande-d-extrait-de-casier-judiciaire",
        "publisher": "Service Public de l’administration togolaise",
        "scope": "Published service guidance",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      },
      {
        "url": "https://justice.gouv.tg/modernisation-de-la-justice-la-plateforme-du-casier-judiciaire-automatise-operationnelle/",
        "publisher": "Ministère de la Justice",
        "scope": "500 F CFA fee and B3/CJE distinction cross-check",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      }
    ],
    "fr": {
      "title": "Extrait de casier judiciaire",
      "summary": "Obtenir un bulletin B3 pour un Togolais ou une attestation de non-condamnation CJE pour un étranger résidant au Togo.",
      "eligibility": [
        "B3 : Togolais âgé d’au moins 14 ans ; demande par l’intéressé ou son représentant.",
        "CJE : étranger résidant au Togo."
      ],
      "requirements": [
        "Togolais né au Togo : une pièce parmi acte de naissance/déclaration, nationalité, jugement rectificatif/supplétif/reconstitution.",
        "Né à l’étranger ou étranger résident : une pièce parmi naissance, passeport, séjour ou nationalité selon le formulaire."
      ],
      "steps": [
        "Choisir statut et pièce justificative ; compléter le formulaire officiel.",
        "Choisir le retrait et payer par les moyens proposés.",
        "Suivre les notifications et corriger si nécessaire.",
        "Retirer au centre choisi ou par la poste selon la demande."
      ],
      "fee": "500 F CFA",
      "time": "2 jours ouvrés — indication publiée",
      "notice": "B3 et CJE ne sont pas les bulletins B1/B2. Le délai publié est indicatif ; ne pas le confondre avec une statistique de traitement.",
      "faq": [
        {
          "q": "Étranger : B3 ou CJE ?",
          "a": "La fiche oriente les étrangers résidents vers le CJE."
        },
        {
          "q": "Faut-il toutes les pièces listées ?",
          "a": "La fiche demande une pièce parmi les options adaptées à votre statut, pas toutes."
        },
        {
          "q": "Le document est-il toujours valable 3 mois ?",
          "a": "La fiche évoque 3 mois en pratique, sans durée légale fixée ; vérifier l’exigence de l’organisme destinataire."
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KJNQA87SE30X0ATQKSQEEVEA"
    },
    "en": {
      "title": "Criminal-record extract",
      "summary": "Obtain B3 for a Togolese applicant, or CJE non-conviction attestation for a foreign resident.",
      "eligibility": [
        "B3: Togolese citizen aged at least 14; applicant or representative.",
        "CJE: foreign national residing in Togo."
      ],
      "requirements": [
        "Born in Togo: one accepted birth, nationality or corrective/supplementary/reconstituted judgement document.",
        "Born abroad/foreign resident: one accepted birth, passport, residence or nationality document appropriate to status."
      ],
      "steps": [
        "Select status and supporting-document type; complete the official form.",
        "Choose delivery/collection and pay using the offered methods.",
        "Follow notifications and correct any issue.",
        "Collect at the selected centre or receive by post."
      ],
      "fee": "500 F CFA",
      "time": "2 working days — published indication",
      "notice": "B3/CJE differ from B1/B2. The published time is indicative, not a guarantee or a live processing statistic.",
      "faq": [
        {
          "q": "Which certificate for a foreign resident?",
          "a": "The official service describes CJE for foreign residents."
        },
        {
          "q": "Do I need every listed identity document?",
          "a": "No. Select one accepted option for the applicant’s status."
        },
        {
          "q": "Does it expire after three months?",
          "a": "The sheet describes three months in practice without a fixed statutory period; check the receiving body’s requirements."
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KJNQA87SE30X0ATQKSQEEVEA"
    },
    "zh": {
      "title": "犯罪记录证明摘录",
      "summary": "多哥公民申请 B3 犯罪记录摘录，外国居民申请 CJE 无定罪证明。",
      "eligibility": [
        "B3：年满 14 岁的多哥公民，可本人或由代表申请。",
        "CJE：在多哥居住的外国人。"
      ],
      "requirements": [
        "多哥境内出生：出生登记、国籍证明或更正/补充/重建判决等受理选项中选一。",
        "境外出生或外国居民：按身份从出生证明、护照、居留证、国籍证明等受理选项中选一。"
      ],
      "steps": [
        "选择申请人身份和证明材料种类，填写官方表单。",
        "选择领取方式，按页面提供的方式缴费。",
        "按短信、邮件或账户通知补正和跟踪。",
        "在所选中心领取，或按申请使用邮寄。"
      ],
      "fee": "500 F CFA",
      "time": "公布参考：2 个工作日",
      "notice": "B3/CJE 与 B1/B2 不同。公布参考时限不是保证，也不等于页面实时处理统计。",
      "faq": [
        {
          "q": "外国居民申请哪一种？",
          "a": "官方事项说明将外国居民对应至 CJE 无定罪证明。"
        },
        {
          "q": "列出的身份证明必须全部提供吗？",
          "a": "不需要。按身份从对应的受理文件选项中选择一种。"
        },
        {
          "q": "有效期一定是三个月吗？",
          "a": "官方说明提到实践中常用三个月，但未给法定固定有效期；应核对接收机构要求。"
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KJNQA87SE30X0ATQKSQEEVEA"
    }
  },
  "duplicate": {
    "icon": "📑",
    "service_id": "01KSJSR8X21AM1WRC1JWMQE337",
    "route": "/service/01KSJSR8X21AM1WRC1JWMQE337",
    "sources": [
      {
        "url": "https://new.service-public.gouv.tg/service/01KSJSR8X21AM1WRC1JWMQE337",
        "publisher": "Service Public de l’administration togolaise",
        "scope": "Current service entry and situation selector",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      },
      {
        "url": "https://service-public.gouv.tg/service/63c8495032efd6f2a20662f2/papiers-citoyennete/obtenir-un-duplicata-d-un-certificat-de-nationalite",
        "publisher": "Service Public de l’administration togolaise",
        "scope": "Published service guidance",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      }
    ],
    "fr": {
      "title": "Duplicata de nationalité",
      "summary": "Obtenir une copie du certificat de nationalité qui tient lieu de copie légalisée ; ce n’est pas une première attribution.",
      "eligibility": [
        "L’intéressé ou un parent.",
        "Service en ligne réservé au certificat de nouveau format. Ancien format : guichet physique compétent."
      ],
      "requirements": [
        "Numéro de l’acte de naissance ou du certificat de nationalité.",
        "Choix du demandeur, du nombre de copies et du mode de retrait."
      ],
      "steps": [
        "Vérifier le nouveau format et préparer le numéro requis.",
        "Compléter la demande officielle et le nombre de copies.",
        "Payer puis suivre les notifications/corrections.",
        "Retirer au centre ou choisir la poste avec frais éventuels."
      ],
      "fee": "1 000 F CFA par copie",
      "time": "24 heures — délai publié, indicatif",
      "notice": "Ancien format : s’adresser au service du Sceau/de la Nationalité. Le délai publié peut différer du délai réel observé ; aucun retrait sous 24 h n’est garanti.",
      "faq": [
        {
          "q": "Ancien format : puis-je commander en ligne ?",
          "a": "La fiche exige le nouveau format ; utiliser le guichet compétent pour l’ancien."
        },
        {
          "q": "Est-ce une nouvelle nationalité ?",
          "a": "Non. Le duplicata reproduit un certificat existant."
        },
        {
          "q": "La poste est-elle comprise ?",
          "a": "Des frais postaux peuvent s’ajouter au prix des copies."
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KSJSR8X21AM1WRC1JWMQE337"
    },
    "en": {
      "title": "Nationality certificate duplicate",
      "summary": "Request an authenticated-equivalent copy of an existing nationality certificate, rather than a first grant.",
      "eligibility": [
        "The holder or a parent.",
        "Online route requires the new certificate format; old format goes to the competent counter."
      ],
      "requirements": [
        "Birth-record or nationality-certificate number.",
        "Applicant relationship, copy quantity and delivery/collection choice."
      ],
      "steps": [
        "Check the format and prepare the document number.",
        "Complete the official request and quantity.",
        "Pay and follow processing/correction notices.",
        "Collect at the centre or use post with possible extra charges."
      ],
      "fee": "1,000 F CFA per copy",
      "time": "24 hours — published indication",
      "notice": "Old-format certificates require the competent nationality/seal counter. Published and observed times can differ; collection within 24 hours is not guaranteed.",
      "faq": [
        {
          "q": "Can an old certificate use this online route?",
          "a": "The official sheet limits it to the new format."
        },
        {
          "q": "Is this a first nationality application?",
          "a": "No. It is a copy of an existing certificate."
        },
        {
          "q": "Is postage included?",
          "a": "Postal charges may be added to the copy fee."
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KSJSR8X21AM1WRC1JWMQE337"
    },
    "zh": {
      "title": "国籍证明副本申请",
      "summary": "申请已有国籍证明的副本，可替代认证复印件；不是首次取得国籍。",
      "eligibility": [
        "本人或亲属。",
        "线上申请限新版国籍证明；旧版须向主管线下窗口办理。"
      ],
      "requirements": [
        "出生登记文件编号或国籍证明编号。",
        "确定为谁申请、副本份数及领取方式。"
      ],
      "steps": [
        "核对证书是否新版，准备对应编号。",
        "在官方表单填写申请人关系和份数。",
        "缴费后按通知跟踪，必要时补正。",
        "在所选中心领取；选择邮寄时可能另有费用。"
      ],
      "fee": "每份 1,000 F CFA",
      "time": "公布参考：24 小时",
      "notice": "旧版须联系国籍/印玺主管窗口。公布时限可能与实际处理统计不同，不承诺 24 小时领证。",
      "faq": [
        {
          "q": "旧版证书可以线上申请吗？",
          "a": "官方说明要求新版，旧版需走主管线下窗口。"
        },
        {
          "q": "这等于首次申请国籍吗？",
          "a": "不是，这是对已存在证明申请副本。"
        },
        {
          "q": "价格包含邮寄吗？",
          "a": "邮寄费用可能在副本费用之外另计。"
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KSJSR8X21AM1WRC1JWMQE337"
    }
  },
  "residence": {
    "icon": "🪪",
    "service_id": "01KSV1K2HDKKYSS92R4V861B17",
    "route": "/service/01KSV1K2HDKKYSS92R4V861B17",
    "sources": [
      {
        "url": "https://new.service-public.gouv.tg/service/01KSV1K2HDKKYSS92R4V861B17",
        "publisher": "Service Public de l’administration togolaise",
        "scope": "Current service entry and situation selector",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      },
      {
        "url": "https://service-public.gouv.tg/service/62a3b6e4c07b617d9d1b9bd9/papiers-citoyennete/demande-de-carte-de-sejour",
        "publisher": "Service Public de l’administration togolaise",
        "scope": "Published service guidance",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      },
      {
        "url": "https://www.dgdn.gouv.tg/fr/titre-et-documents/carte-de-sejour",
        "publisher": "DGDN",
        "scope": "Fee table cross-check; document-detail conflict",
        "checked_at": "2026-11-06",
        "published_or_updated_at": null
      }
    ],
    "fr": {
      "title": "Carte de séjour",
      "summary": "Titre destiné aux étrangers souhaitant résider au Togo. Choisir catégorie, durée et première demande/renouvellement.",
      "eligibility": [
        "Étranger souhaitant séjourner ou résider au Togo.",
        "Étudiant, salarié, indépendant et autres situations ont des pièces complémentaires distinctes."
      ],
      "requirements": [
        "Formulaire, passeport, photo, justificatifs de ressources et certificat médical.",
        "Première demande : casier du pays d’origine ; attestation de non-condamnation selon le parcours.",
        "Étudiant : inscription/stage ; salarié : emploi/contrat ; indépendant : entreprise et justificatifs fiscaux/sociaux requis.",
        "Renouvellement : ancienne carte. Vérifier la liste DGDN adaptée avant dépôt."
      ],
      "steps": [
        "Choisir le type et première demande/renouvellement.",
        "Compléter le dossier officiel et répondre aux corrections DGDN.",
        "Payer après la notification, imprimer puis déposer le dossier selon les consignes.",
        "Suivre les notifications et retirer la carte prête."
      ],
      "fee": "100 000 à 800 000 F CFA selon type",
      "time": "30 à 45 jours — indication publiée",
      "notice": "Étudiant : 1 an 100 000 / 3 ans 250 000 ; autres : 1 an 200 000 / 3 ans 500 000 / 5 ans 800 000 F CFA. Des listes officielles de pièces diffèrent : confirmer les exigences de votre catégorie auprès de la DGDN.",
      "faq": [
        {
          "q": "Est-ce une carte d’identité togolaise ?",
          "a": "Non. C’est un titre de séjour pour étrangers."
        },
        {
          "q": "Un étudiant paie-t-il le même tarif ?",
          "a": "Non. Les tarifs étudiants et autres catégories diffèrent selon la durée."
        },
        {
          "q": "Pourquoi vérifier les pièces ?",
          "a": "La fiche portail et le site DGDN ne donnent pas exactement les mêmes détails de photos/passeport ; ne pas fusionner ces listes en une obligation universelle."
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KSV1K2HDKKYSS92R4V861B17"
    },
    "en": {
      "title": "Residence permit",
      "summary": "Residence document for foreign nationals. Choose permit category, duration and first application/renewal.",
      "eligibility": [
        "Foreign nationals wishing to stay or reside in Togo.",
        "Students, employees and self-employed applicants have distinct supporting documents."
      ],
      "requirements": [
        "Official form, passport, photo, resources evidence and medical certificate.",
        "First application: home-country criminal record; non-conviction attestation as applicable.",
        "Student: enrolment/internship; employee: work/contract; self-employed: business and required tax/social evidence.",
        "Renewal: old permit. Verify the category-specific DGDN checklist."
      ],
      "steps": [
        "Choose category and first/renewal.",
        "Complete official documents and resolve DGDN corrections.",
        "Pay when notified, print and attend filing as instructed.",
        "Track the request and collect after notification."
      ],
      "fee": "100,000–800,000 F CFA by type",
      "time": "30–45 days — published indication",
      "notice": "Students: 1 year 100,000 / 3 years 250,000; others: 1 year 200,000 / 3 years 500,000 / 5 years 800,000 F CFA. Official checklists differ in detail; confirm your category with DGDN.",
      "faq": [
        {
          "q": "Is this a national ID card?",
          "a": "No. It is a residence permit for foreign nationals."
        },
        {
          "q": "Are student fees different?",
          "a": "Yes. The published fees depend on student status and duration."
        },
        {
          "q": "Why confirm the checklist?",
          "a": "The portal and DGDN list different photo/passport details; they must not be merged into one universal requirement."
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KSV1K2HDKKYSS92R4V861B17"
    },
    "zh": {
      "title": "居留证申请",
      "summary": "面向希望在多哥居住的外国人。按身份、期限、首次或续期选择对应类别。",
      "eligibility": [
        "希望在多哥停留或定居的外国人。",
        "学生、雇员、自雇等身份有不同补充材料。"
      ],
      "requirements": [
        "官方表单、护照、照片、经济来源证明和体检证明等基础材料。",
        "首次申请需原籍国犯罪记录证明；按路径提供无定罪证明。",
        "学生提供在读/实习材料；雇员提供工作/合同材料；自雇者提供企业及适用税务、社保材料。",
        "续期增加原居留证；递交前核对对应 DGDN 清单。"
      ],
      "steps": [
        "选择居留证类别及首次/续期。",
        "填写官方申请，按 DGDN 通知补正。",
        "收到缴费通知后支付，打印并按指引递交材料。",
        "跟踪通知，并在办妥后领取。"
      ],
      "fee": "按类别：100,000–800,000 F CFA",
      "time": "官方公布参考：30–45 天",
      "notice": "学生：1 年 100,000、3 年 250,000；其他类别：1 年 200,000、3 年 500,000、5 年 800,000 F CFA。官方材料清单细节存在差异，须向 DGDN 确认适用类别。",
      "faq": [
        {
          "q": "这是多哥公民身份证吗？",
          "a": "不是，这是面向外国人的居留证件。"
        },
        {
          "q": "学生与其他人收费一样吗？",
          "a": "不同；公布费用按学生身份和期限区分。"
        },
        {
          "q": "为什么材料还要确认？",
          "a": "门户与 DGDN 对照片数量、护照要求等细节不完全一致，不能合并成人人适用的强制清单。"
        }
      ],
      "portal": "https://new.service-public.gouv.tg/service/01KSV1K2HDKKYSS92R4V861B17"
    }
  }
};
