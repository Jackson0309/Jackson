// Local demo case workflow. Fields and files are persisted by /api/demo; no official submission.
const GBOT_FLOW={active:false,awaitingInput:false,service:null,generation:0,stage:'idle',draft:null,currentField:null,busy:false,reviewVersion:null};
let DEMO_SCHEMA=null;
function FL(fr,en,zh){return ({fr,en,zh})[GBOT_ENGINE.lang]||fr;}
function TL(v){return typeof v==='string'?v:(v?.[GBOT_ENGINE.lang]||v?.fr||'');}
function E(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function FD(){const k=GBOT_KB[GBOT_FLOW.service];return k?.[GBOT_ENGINE.lang]||k?.fr;}
function FB(text,handler,extra=''){return `<button type="button" class="gbot-qr-btn" onclick="${handler}" ${extra}>${E(text)}</button>`;}
function gbotPortalAction(key,primary=false){if(!GBOT_KB[key])return '';return `<button type="button" class="gbot-apply-btn${primary?'':' gbot-portal-jump'}" onclick="gbotNavigatePortal('${key}')">${FL('Ouvrir cette démarche ici →','Continue on this portal →','在主页办理此事项 →')}</button>`;}
function officialButton(){return `<div class="gbot-action-row">${gbotPortalAction(GBOT_FLOW.service)}<a class="gbot-portal-url" href="${FD()?.portal}" target="_blank" rel="noopener noreferrer">${FL('Site officiel ↗','Official website ↗','官方网站 ↗')}</a></div>`;}
function gbotNavigatePortal(key){if(!GBOT_KB[key])return;if(parent!==window)parent.postMessage({type:'govbot:navigate',service:key},location.origin);else location.assign(GBOT_KB[key].route);}
function gbotOpenPortalService(key){gbotNavigatePortal(key);}
function flowDeactivateControls(){document.querySelectorAll('.demo-current button,.demo-current input').forEach(el=>el.disabled=true);document.querySelectorAll('.demo-current').forEach(el=>el.classList.remove('demo-current'));}
function demoMatches(when,values){return !when||Object.entries(when).every(([k,v])=>typeof v==='object'?v.in.includes(values[k]):values[k]===v);}
function demoFields(record=GBOT_FLOW.draft){return (DEMO_SCHEMA?.services[record?.service]?.fields||[]).filter(f=>demoMatches(f.when,record.fields));}
function demoSlots(record=GBOT_FLOW.draft){return (DEMO_SCHEMA?.services[record?.service]?.attachments||[]).filter(s=>demoMatches(s.when,record.fields));}
function demoTitle(record){return TL(DEMO_SCHEMA?.services[record.service]?.title)||record.service;}
function demoStatus(record){return record.status==='submitted'?FL('Soumis — en attente de traitement local','Submitted — awaiting local review','已提交 — 待本地审核'):FL('Brouillon enregistré','Draft saved','草稿已保存');}
function demoDate(value){return new Intl.DateTimeFormat(({zh:'zh-CN',en:'en-GB',fr:'fr-FR'})[GBOT_ENGINE.lang]||'fr-FR',{dateStyle:'short',timeStyle:'short',timeZone:'Asia/Shanghai'}).format(new Date(value))+' (UTC+8)';}
function demoBadge(){return `<span class="gbot-rag-pill">${FL('DOSSIER DÉMO · local','DEMO CASE · local','演示办件 · 本地')}</span>`;}
function demoControls(){return `<div class="gbot-flow-footer">${GBOT_FLOW.stage==='collect'?FB(FL('Utiliser des informations fictives','Use fictional example information','填充虚构示例信息'),'demoFillExample()'):''}${FB(FL('Enregistrer et quitter','Save and leave','暂存并退出'),'gbotRestart()')}${FB(FL('Mes dossiers démo','My demo cases','我的演示办件'),'demoShowCases()')}</div>`;}
function demoFee(record=GBOT_FLOW.draft){const f=record.feeEstimate;return f?.amount===null||f?.amount===undefined?FL('À confirmer dans le formulaire officiel','Confirm in the official form','以官方表单确认'):new Intl.NumberFormat('en-US').format(f.amount)+' XOF'+(f.postageExcluded?FL(' (hors poste)',' (postage excluded)','（不含邮费）'):'');}
async function demoApi(route,options={}){
 const response=await fetch('/api/demo'+route,{credentials:'same-origin',...options,headers:{...(typeof options.body==='string'?{'content-type':'application/json'}:{}),...options.headers}});
 let data;try{data=await response.json();}catch{throw new Error('local_storage_unavailable');}
 if(!response.ok){const error=new Error(data.error||'request_failed');Object.assign(error,data);throw error;}return data;
}
async function demoInit(){if(!DEMO_SCHEMA)DEMO_SCHEMA=await demoApi('/schema');return DEMO_SCHEMA;}
function demoError(error){
 const messages={version_conflict:FL('Le brouillon a changé. Rouvrez-le pour continuer.','The draft changed. Reopen it to continue.','草稿版本已变化，请恢复草稿后继续。'),unsupported_file:FL('Formats acceptés : PDF, PNG, JPG. Le contenu doit correspondre au format.','Use PDF, PNG or JPG with matching file content.','仅支持 PDF、PNG、JPG，文件内容须与扩展名一致。'),body_too_large:FL('Fichier trop volumineux : 10 Mo maximum.','File too large: maximum 10 MB.','文件过大，单个附件最多 10 MB。'),case_attachment_limit:FL('Limite des pièces dépassée.','Attachment limit exceeded.','附件数量或总大小超过限制。'),case_not_found:FL('Dossier introuvable dans ce navigateur.','No matching case in this browser.','未找到属于当前浏览器的办件。'),case_already_submitted:FL('Dossier déjà soumis : les données sont figées.','Already submitted: case data is frozen.','办件已经提交，提交信息已冻结。')};
 gbotAppendMsg('bot',`<div class="gbot-notice-box">${E(messages[error.message]||FL('Opération non aboutie. Les données déjà enregistrées sont conservées ; réessayez ou rouvrez le brouillon.','The operation did not complete. Saved data is retained; retry or reopen the draft.','操作未完成，已保存内容仍保留。请重试或从“我的演示办件”恢复草稿。'))}</div>`);
}
function demoMissing(record=GBOT_FLOW.draft){return demoFields(record).find(f=>(record.fields[f.key]===undefined||record.fields[f.key]==='')&&!(record.skippedFields||[]).includes(f.key));}
function demoValue(field,value){return field.type==='select'?TL(field.options.find(o=>o.value===value)?.label)||value:String(value??'');}
function demoQuestion(field){
 if(!field)return demoRenderUploads();
 flowDeactivateControls();GBOT_FLOW.stage='collect';GBOT_FLOW.currentField=field.key;GBOT_FLOW.awaitingInput=true;
 GBOT_ENGINE.lastIntent=GBOT_FLOW.draft.service;gbotUpdateSidebarActive(GBOT_FLOW.draft.service);
 const gen=GBOT_FLOW.generation,filled=demoFields().filter(f=>GBOT_FLOW.draft.fields[f.key]!==undefined||(GBOT_FLOW.draft.skippedFields||[]).includes(f.key)).length,total=demoFields().length;
 gbotAppendMsg('bot',`<div class="demo-current">${demoBadge()}<div class="demo-progress">${FL('Informations','Information','信息采集')} ${filled}/${total} · ${FL('Enregistré sur ce serveur','Saved on this server','已保存到本地后台')}</div><strong>${E(TL(field.label))}</strong>${field.hint?`<p class="gbot-summary">${E(TL(field.hint))}</p>`:''}<p class="gbot-summary">${FL('Répondez dans le champ de dialogue. Vous pouvez aussi préciser plusieurs champs avec leurs noms.','Reply in the chat input. You can also provide several labelled fields at once.','请直接在下方对话框回复，也可以一次说明多个带名称的字段。')}</p>${field.options?`<div class="gbot-flow-options">${field.options.map((o,i)=>FB(TL(o.label),`demoChoose('${field.key}',${i},${gen})`)).join('')}</div>`:''}${!field.required?FB(FL('Passer ce champ','Skip this field','跳过此项'),`demoSkip('${field.key}',${gen})`):''}${demoControls()}</div>`);
}
async function gbotStartFlow(key,forceNew=false){
 if(!GBOT_KB[key]||GBOT_FLOW.busy)return;
 flowDeactivateControls();GBOT_FLOW.active=true;GBOT_FLOW.awaitingInput=false;GBOT_FLOW.service=key;GBOT_FLOW.generation++;const gen=GBOT_FLOW.generation;GBOT_FLOW.busy=true;gbotSetQR([]);
 try{
  await demoInit();const list=await demoApi('/cases');if(gen!==GBOT_FLOW.generation)return;
  const existing=list.cases.find(c=>c.service===key&&c.status==='draft');
  if(existing&&!forceNew){GBOT_FLOW.draft=existing;GBOT_FLOW.stage='resume';GBOT_FLOW.awaitingInput=true;gbotAppendMsg('bot',`<div class="demo-current">${demoBadge()}<p>${FL('Un brouillon existe pour cette démarche.','There is a saved draft for this service.','此事项已有保存的草稿。')}</p><strong>${E(existing.id)}</strong><div class="gbot-flow-options">${FB(FL('Reprendre le brouillon','Resume draft','继续已有草稿'),`demoResume('${existing.id}')`)}${FB(FL('Créer un autre dossier démo','Create another demo case','新建另一份演示办件'),`gbotStartFlow('${key}',true)`)}</div></div>`);return;}
  const record=await demoApi('/cases',{method:'POST',body:JSON.stringify({service:key,clientRequestId:crypto.randomUUID()})});if(gen!==GBOT_FLOW.generation)return;
  GBOT_FLOW.draft=record;
  gbotAppendMsg('bot',`<div class="demo-current">${demoBadge()}<strong class="demo-title">${E(demoTitle(record))}</strong><p>${FL('Le dossier est réellement enregistré dans le serveur local. Nous collectons les informations, recevons les pièces et créons un récépissé après votre confirmation. Ce n’est pas un dépôt gouvernemental.','This case is saved in the local server. We collect answers and files, validate them and issue a local receipt after confirmation. This is not a government submission.','草稿已实际保存到本地后台。接下来通过对话采集信息、上传材料、校验并确认提交，再生成本地回执；不向多哥政府系统提交。')}</p><small>${E(record.id)}</small><p class="gbot-summary">${FL('Ces champs constituent un formulaire de démonstration, pas une copie certifiée du formulaire officiel. Utilisez des données fictives pour la démonstration.','These are demo fields, not a certified official-form replica. Fictional information can be used for the demo.','这些字段属于演示表单，并非经认证的官方完整申报表。演示时可使用虚构资料。')}</p></div>`);
  demoQuestion(demoMissing());
 }catch(error){demoError(error);}finally{GBOT_FLOW.busy=false;}
}
async function demoResume(id){
 if(GBOT_FLOW.busy)return;GBOT_FLOW.busy=true;
 try{await demoInit();const record=await demoApi('/cases/'+encodeURIComponent(id));flowDeactivateControls();GBOT_FLOW.generation++;GBOT_FLOW.draft=record;GBOT_FLOW.service=record.service;GBOT_ENGINE.lastIntent=record.service;gbotUpdateSidebarActive(record.service);
  if(record.status==='submitted'){GBOT_FLOW.active=false;demoRenderSubmitted(record);return;}
  GBOT_FLOW.active=true;GBOT_FLOW.awaitingInput=true;gbotAppendMsg('bot',`<p>${demoBadge()} ${FL('Brouillon restauré, données et pièces conservées.','Draft restored; saved answers and files retained.','已恢复草稿，填报信息和附件均已保留。')} <strong>${E(record.id)}</strong></p>`);demoQuestion(demoMissing());
 }catch(error){demoError(error);}finally{GBOT_FLOW.busy=false;}
}
async function demoPatch(patch,skipFields=[]){
 GBOT_FLOW.draft=await demoApi('/cases/'+GBOT_FLOW.draft.id,{method:'PATCH',body:JSON.stringify({version:GBOT_FLOW.draft.version,fields:patch,...(skipFields.length?{skipFields}:{})})});
}
function demoFieldError(code,field){
 const label=field?TL(field.label):'';
 const text={phone:FL('Téléphone invalide : utilisez au moins 7 chiffres.','Invalid phone: use at least seven digits.','电话格式不正确，请填写至少7位数字，可含国际区号。'),email:FL('Email invalide.','Invalid email address.','邮箱格式不正确。'),date:FL('Date invalide : AAAA-MM-JJ, non future.','Invalid date: YYYY-MM-DD, not in the future.','日期须为有效的 YYYY-MM-DD，不能为未来日期。'),range:FL('Nombre hors de la plage proposée.','Number outside the allowed range.','数值不在允许范围内。'),document:FL('Numéro invalide : 3 à 80 caractères, lettres/chiffres.','Invalid document number: 3–80 letters/digits and separators.','编号须为3–80位字母、数字及允许的分隔符。'),b3_age:FL('La fiche B3 vise les citoyens de 14 ans ou plus. Vérifiez la date ou la situation.','The B3 sheet covers citizens aged 14+. Check the birth date or status.','B3事项针对年满14岁的多哥公民，请核对出生日期及申请人身份。'),document_status:FL('Cette pièce ne correspond pas au statut choisi.','This document does not match the selected status.','所选证明文件与申请人身份不匹配。')};
 return label+'：'+(text[code]||FL('Valeur non valide ou manquante.','Invalid or missing value.','内容格式不符或尚未填写。'));
}
function demoConvert(field,value){
 let v=String(value).trim().replace(/^[：:=\s]+/,'').replace(/[。！？!?]+$/,'');
 if(field.type==='phone'){const digits={'零':'0','〇':'0','一':'1','幺':'1','二':'2','两':'2','三':'3','四':'4','五':'5','六':'6','七':'7','八':'8','九':'9'};v=v.replace(/加号|加|plus /gi,'+').replace(/[零〇一幺二两三四五六七八九]/g,c=>digits[c]);}
 if(['applicantName','holderName'].includes(field.key))v=v.replace(/^(?:我的名字[叫是]|我叫|姓名[是为]?|my name is |je m'appelle )/i,'');
 if(field.type==='integer'){const chinese={一:1,二:2,两:2,三:3,四:4,五:5};const m=v.match(/\d+/);return m?Number(m[0]):chinese[v.replace(/[份个]/g,'')]??v;}
 if(field.type==='select'){
  const n=gbotNormalise(v);
  for(const o of field.options){if(n===o.value||Object.values(o.label).some(label=>n===gbotNormalise(label)))return o.value;}
  const synonyms={new:['首次','新申请','first','premiere'],renew:['续期','换发','更新','renew','renouvel'],self:['本人','自己','myself','moi'],relative:['亲属','家人','relative','proche'],centre:['中心','自取','现场','centre','center'],post:['邮寄','寄到','post','courrier'],yes:['有','是','yes','oui'],no:['没有','无','no','non']};
  if(field.key==='certificateFormat'){if(/新版|新版本|新的|新格式|nouveau|new/i.test(v))return 'new';if(/旧版|老版|旧的|旧格式|ancien|old/i.test(v))return 'old';}
  for(const o of field.options)if((synonyms[o.value]||[]).some(w=>n.includes(w)))return o.value;
  for(const o of field.options)if(Object.values(o.label).some(label=>gbotNormalise(label).length>2&&n.includes(gbotNormalise(label))))return o.value;
  return v;
 }
 if(field.type==='date')v=v.replace(/年|\//g,'-').replace(/月/g,'-').replace(/日/g,'').replace(/^(\d{4})-(\d{1,2})-(\d{1,2})$/,(m,y,mo,d)=>`${y}-${mo.padStart(2,'0')}-${d.padStart(2,'0')}`);
 return v;
}
function demoParse(text,current){
 const fields=DEMO_SCHEMA.services[GBOT_FLOW.service].fields,patch={};
 const aliases=fields.flatMap(f=>(f.aliases||[]).map(a=>({field:f,alias:a}))).sort((a,b)=>b.alias.length-a.alias.length);
 const clean=text.replace(/[。！？!?]+$/,'').replace(/^(请|帮我|把|将|修改|更改|change|set|modifier|changer)\s*/i,'');
 for(const part of clean.split(/[，,；;\n]+/).map(s=>s.trim()).filter(Boolean)){
  let found=false;
  for(const {field,alias} of aliases){
   if(part.toLowerCase().startsWith(alias.toLowerCase())){
    let value=part.slice(alias.length).replace(/^\s*(?:改成|改为|修改为|更改为|为|是|叫|[:：=]|is\b|to\b|est\b|en\b)\s*/i,'').trim();
    if(value){patch[field.key]=demoConvert(field,value);found=true;break;}
   }
  }
  if(!found&&GBOT_FLOW.service==='duplicate'){
   const copies=part.match(/(?:申请|需要|要)?\s*([1-5一二两三四五])\s*份/);
   if(copies){patch.copies=demoConvert(fields.find(f=>f.key==='copies'),copies[1]);found=true;}
   if(/^(邮寄|寄到|post)/i.test(part)){
    patch.delivery='post';const address=part.replace(/^(邮寄到|寄到|邮寄|post to)\s*[:：]?\s*/i,'').trim();if(address)patch.postalAddress=address;found=true;
   }
  }
  if(!found&&Object.keys(patch).length===0&&current)patch[current.key]=demoConvert(current,text);
 }
 return patch;
}
async function demoAccept(patch){
 try{await demoPatch(patch);flowDeactivateControls();gbotAppendMsg('bot',`<p class="demo-saved">✓ ${FL('Informations enregistrées','Information saved','信息已保存')} · ${FL('Vous pouvez demander une modification à tout moment.','You can request changes at any time.','可随时说“修改手机号为……”等指令。')}</p>`);demoQuestion(demoMissing());}
 catch(error){if(error.errors){gbotAppendMsg('bot',`<div class="gbot-notice-box">${error.errors.map(e=>E(demoFieldError(e.code,DEMO_SCHEMA.services[GBOT_FLOW.service].fields.find(f=>f.key===e.field)))).join('<br>')}</div>`);}else demoError(error);}
}
async function demoChoose(key,index,gen){
 if(GBOT_FLOW.busy||gen!==GBOT_FLOW.generation||!GBOT_FLOW.active)return;
 const f=DEMO_SCHEMA.services[GBOT_FLOW.service].fields.find(f=>f.key===key),o=f?.options?.[index];if(!o)return;
 gbotAppendMsg('user',E(TL(o.label)));GBOT_FLOW.busy=true;try{await demoAccept({[key]:o.value});}finally{GBOT_FLOW.busy=false;}
}
async function demoSkip(key,gen){if(GBOT_FLOW.busy||gen!==GBOT_FLOW.generation)return;GBOT_FLOW.busy=true;try{await demoPatch({},[key]);demoQuestion(demoMissing());}catch(e){demoError(e);}finally{GBOT_FLOW.busy=false;}}
async function gbotInterceptFlow(text){
 if(GBOT_FLOW.busy){gbotAppendMsg('bot',FL('Enregistrement en cours, veuillez patienter.','Saving, please wait.','正在保存，请稍候。'));return;}
 gbotAppendMsg('user',E(text));
 if(/(?:样例|示例|演示材料|sample attachment|exemple fictif)/i.test(text)&&GBOT_FLOW.stage==='attachments')return demoUploadAllSamples();
 if(/^(校验|校验材料|开始校验|核对提交信息|validate|verifier|vérifier)$/i.test(text.trim()))return demoReview();
 if(/^(暂存|退出|取消填报|save|pause|quitter)/i.test(text))return gbotRestart();
 if(GBOT_FLOW.stage==='resume'){if(/继续|恢复|resume|reprendre/i.test(text))return demoResume(GBOT_FLOW.draft.id);if(/新建|另建|new|nouveau/i.test(text))return gbotStartFlow(GBOT_FLOW.service,true);gbotAppendMsg('bot',FL('Dites reprendre ou nouveau dossier.','Say resume or new case.','请说“继续已有草稿”或“新建另一份”。'));return;}
 if(/^(我的办件|我的演示办件|查询状态|my cases|mes dossiers)/i.test(text))return demoShowCases();
 if(/^(确认提交|我确认提交|确定提交|确认提交演示办件|提交演示办件|confirm submission|confirm and submit|confirmer le depot|confirmer le dépôt|je confirme)$/i.test(text.trim())){
  if(GBOT_FLOW.stage==='review')return demoSubmit();
  gbotAppendMsg('bot',FL('Terminez les champs et pièces, puis vérifiez le récapitulatif.','Complete fields and attachments, then review the summary.','请先完成信息与材料，并核对提交摘要。'));return;
 }
 const current=demoFields().find(f=>f.key===GBOT_FLOW.currentField);
 if(/^(跳过|略过|skip|passer)$/i.test(text.trim())&&current&&!current.required)return demoSkip(current.key,GBOT_FLOW.generation);
 if(/^(返回上一步|上一题|back|previous|retour)$/i.test(text.trim())){
  const completed=demoFields().filter(f=>GBOT_FLOW.draft.fields[f.key]!==undefined);return demoQuestion(completed.at(-1)||demoMissing());
 }
 // Continue consulting verified material without discarding the application.
 if(/材料|费用|收费|时限|多久|documents|requirements|fees|frais|delai|délai/i.test(text)&&!/(改为|修改|[:：=])/.test(text)){
  const d=FD(),aspect=gbotDetectAspect(text),answer=aspect==='requirements'?d.requirements.join('<br>'):aspect==='fees'?d.fee+'<br>'+d.notice:aspect==='time'?d.time:d.summary;
  gbotAppendMsg('bot',`<p>${answer}</p><small>${FL('Votre brouillon reste enregistré.','Your draft remains saved.','草稿仍已保存，可继续填报。')}</small>`);return;
 }
 const patch=demoParse(text,current);
 if(!Object.keys(patch).length){gbotAppendMsg('bot',FL('Indiquez le nom du champ à modifier, ou utilisez les boutons.','Name the field to change, or use the buttons.','请说明要修改的字段名称，或使用当前步骤的按钮。'));return;}
 GBOT_FLOW.busy=true;try{await demoAccept(patch);}finally{GBOT_FLOW.busy=false;}
}
async function demoEdit(key){if(GBOT_FLOW.busy)return;const field=demoFields().find(f=>f.key===key);if(field){GBOT_FLOW.active=true;demoQuestion(field);}}
function demoRenderUploads(){
 flowDeactivateControls();GBOT_FLOW.stage='attachments';GBOT_FLOW.currentField=null;GBOT_FLOW.awaitingInput=true;
 const r=GBOT_FLOW.draft,gen=GBOT_FLOW.generation;
 gbotAppendMsg('bot',`<div class="demo-current demo-upload-card">${demoBadge()}<strong class="demo-title">${FL('Pièces du dossier','Case attachments','办件材料上传')}</strong><p class="gbot-summary">${FL('Fichiers conservés dans ce serveur local : PDF, PNG, JPG ; 10 Mo par fichier. Les exemples sont des pièces fictives.','Files are stored on this local server: PDF, PNG, JPG; 10 MB per file. Sample files are fictional.','附件实际保存到本地后台。支持 PDF、PNG、JPG，单个不超过10 MB；也可使用明确标识的演示样例。')}</p>${demoSlots().map(slot=>{const files=r.attachments.filter(a=>a.slot===slot.key);return `<div class="demo-upload-slot"><strong>${E(TL(slot.label))} ${slot.required?'*':FL('(facultatif)','(optional)','（可选）')}</strong>${files.map(a=>`<div class="demo-file"><a href="${a.downloadUrl}" target="_blank" rel="noopener">${E(a.filename)}</a><small>${Math.ceil(a.size/1024)} KB</small>${FB(FL('Retirer','Remove','移除'),`demoRemoveFile('${a.id}',${gen})`)}</div>`).join('')}<div class="gbot-action-row"><label class="demo-upload-label">${FL('Choisir un fichier','Choose a file','选择并上传文件')}<input type="file" accept=".pdf,.png,.jpg,.jpeg" aria-label="${E(TL(slot.label))}" onchange="demoUploadFile(this,'${slot.key}',${gen})"></label>${FB(FL('Ajouter un exemple fictif','Add a fictional sample','上传演示样例'),`demoUploadSample('${slot.key}',${gen})`)}</div></div>`;}).join('')}<div class="gbot-action-row"><button class="gbot-apply-btn" onclick="demoReview()">${FL('Vérifier et voir le récapitulatif','Validate and review','校验并核对提交信息')}</button>${FB(FL('Modifier une information','Edit information','修改已填信息'),'demoReview(true)')}</div>${demoControls()}</div>`);
}
async function demoUploadBytes(file,slot,gen){
 if(GBOT_FLOW.busy||gen!==GBOT_FLOW.generation)return;
 if(file.size>10*1024*1024){demoError(new Error('body_too_large'));return;}
 GBOT_FLOW.busy=true;
 const {bubble}=gbotAppendMsg('bot','',true);
 try{
  const r=GBOT_FLOW.draft;
  const result=await demoApi(`/cases/${r.id}/attachments?slot=${encodeURIComponent(slot)}&name=${encodeURIComponent(file.name)}&version=${r.version}`,{method:'POST',headers:{'content-type':file.type||'application/octet-stream'},body:file});
  if(gen!==GBOT_FLOW.generation)return;
  GBOT_FLOW.draft=result;bubble.innerHTML=`✓ ${FL('Fichier réellement enregistré','File saved on the server','附件已实际保存')}：${E(file.name)}`;demoRenderUploads();
 }catch(error){bubble.closest('.gbot-msg-row')?.remove();demoError(error);}finally{GBOT_FLOW.busy=false;}
}
function demoUploadFile(input,slot,gen){const file=input.files?.[0];if(file)demoUploadBytes(file,slot,gen);}
async function demoUploadSample(slot,gen){
 if(GBOT_FLOW.busy||gen!==GBOT_FLOW.generation)return;
 const canvas=document.createElement('canvas');canvas.width=1000;canvas.height=700;const ctx=canvas.getContext('2d');
 ctx.fillStyle='#fff';ctx.fillRect(0,0,1000,700);ctx.strokeStyle='#1f5fae';ctx.lineWidth=6;ctx.strokeRect(30,30,940,640);ctx.fillStyle='#1f5fae';ctx.font='bold 44px Arial';ctx.fillText('DEMO DOCUMENT',70,110);ctx.fillStyle='#333';ctx.font='25px Arial';
 ['Fictional sample for local workflow testing','No government validity / No real identity data','Attachment category: '+slot,'Created for the Togo GovBot local demo'].forEach((line,i)=>ctx.fillText(line,70,210+i*70));
 const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)return;
 await demoUploadBytes(new File([blob],'DEMO-'+slot+'.png',{type:'image/png'}),slot,gen);
}
async function demoRemoveFile(id,gen){if(GBOT_FLOW.busy||gen!==GBOT_FLOW.generation)return;GBOT_FLOW.busy=true;try{GBOT_FLOW.draft=await demoApi(`/cases/${GBOT_FLOW.draft.id}/attachments/${id}`,{method:'DELETE',body:JSON.stringify({version:GBOT_FLOW.draft.version})});demoRenderUploads();}catch(e){demoError(e);}finally{GBOT_FLOW.busy=false;}}
function demoSummary(record,editable){return `<dl class="demo-summary">${demoFields(record).filter(f=>record.fields[f.key]!==undefined).map(f=>`<div><dt>${E(TL(f.label))}</dt><dd>${E(demoValue(f,record.fields[f.key]))}${editable?FB(FL('Modifier','Edit','修改'),`demoEdit('${f.key}')`):''}</dd></div>`).join('')}</dl>`;}
async function demoReview(editOnly=false){
 if(GBOT_FLOW.busy)return;GBOT_FLOW.busy=true;
 try{
  const validation=await demoApi(`/cases/${GBOT_FLOW.draft.id}/validate`,{method:'POST',body:'{}'});
  if(validation.version!==GBOT_FLOW.draft.version){GBOT_FLOW.draft=await demoApi('/cases/'+GBOT_FLOW.draft.id);throw new Error('version_conflict');}
  flowDeactivateControls();GBOT_FLOW.stage='review';GBOT_FLOW.currentField=null;GBOT_FLOW.reviewVersion=GBOT_FLOW.draft.version;
  const fields=DEMO_SCHEMA.services[GBOT_FLOW.service].fields;
  const errors=validation.errors.map(error=>error.field?demoFieldError(error.code,fields.find(f=>f.key===error.field)):FL('Pièce manquante : ','Missing attachment: ','缺少材料：')+TL(demoSlots().find(s=>s.key===error.slot)?.label));
  gbotAppendMsg('bot',`<div class="demo-current">${demoBadge()}<strong class="demo-title">${FL('Vérifier avant de soumettre','Review before submission','提交前核对')}</strong>${demoSummary(GBOT_FLOW.draft,true)}<p><strong>${FL('Frais publiés à titre indicatif','Published reference fee','公布参考费用')}：${E(demoFee())}</strong><br>${FL('Aucun paiement dans cette démonstration.','No payment is collected in this demo.','本演示不收取任何费用。')}</p><p>${FL('Pièces enregistrées','Stored attachments','已保存附件')}：${GBOT_FLOW.draft.attachments.length}</p>${errors.length?`<div class="gbot-notice-box">${errors.map(E).join('<br>')}</div>`:`<p class="demo-saved">✓ ${FL('Champs, formats et présence des pièces vérifiés. Authenticité et éligibilité officielle non certifiées.','Required fields, formats and attachment presence checked. Authenticity and official eligibility are not certified.','已检查必填项、格式、分支一致性及附件齐全性；不认证材料真实性或官方申请资格。')}</p>`}<div class="gbot-action-row">${!errors.length&&!editOnly?`<button class="gbot-apply-btn" onclick="demoSubmit()">${FL('Confirmer et soumettre le dossier DÉMO','Confirm and submit DEMO case','确认提交演示办件')}</button>`:''}${FB(FL('Revenir aux pièces','Back to attachments','返回材料上传'),'demoRenderUploads()')}${FB(FL('Continuer les champs','Continue filling','继续补填'),'demoQuestion(demoMissing())')}</div><p class="gbot-summary">${FL('Votre confirmation crée une soumission dans ce serveur local uniquement.','Your confirmation submits only to this local demo server.','确认后仅提交至本机演示后台，不会提交到多哥官方系统。')}</p>${demoControls()}</div>`);
 }catch(e){demoError(e);}finally{GBOT_FLOW.busy=false;}
}
async function demoSubmit(){
 if(GBOT_FLOW.busy||GBOT_FLOW.stage!=='review'||GBOT_FLOW.reviewVersion!==GBOT_FLOW.draft.version)return;
 GBOT_FLOW.busy=true;const {bubble}=gbotAppendMsg('bot','',true);
 try{
  const record=await demoApi(`/cases/${GBOT_FLOW.draft.id}/submit`,{method:'POST',body:JSON.stringify({version:GBOT_FLOW.reviewVersion,confirmed:true})});
  GBOT_FLOW.draft=record;GBOT_FLOW.active=false;GBOT_FLOW.stage='submitted';flowDeactivateControls();bubble.closest('.gbot-msg-row')?.remove();demoRenderSubmitted(record);
 }catch(error){bubble.closest('.gbot-msg-row')?.remove();demoError(error);}finally{GBOT_FLOW.busy=false;}
}
function demoRenderSubmitted(record){
 GBOT_FLOW.draft=record;GBOT_FLOW.service=record.service;GBOT_FLOW.active=false;GBOT_FLOW.stage='submitted';
 GBOT_ENGINE.lastIntent=record.service;gbotUpdateSidebarActive(record.service);
 gbotAppendMsg('bot',`<div class="gbot-apply-cta">${demoBadge()}<strong class="demo-title">✓ ${FL('Dossier démo soumis','Demo case submitted','演示办件已提交')}</strong><p>${E(demoTitle(record))}</p><strong class="demo-case-id">${E(record.id)}</strong><p>${E(demoStatus(record))}<br>${E(demoDate(record.submittedAt))}</p><p class="gbot-summary">${FL('Réellement conservé dans le serveur local ; aucun dépôt gouvernemental, paiement ou accord officiel.','Persisted in the local server; no government filing, payment or official approval.','已实际保存到本机演示后台；不代表官方申报、缴费或审批通过。')}</p><div class="gbot-action-row"><a class="gbot-apply-btn" href="${record.receiptUrl}?lang=${GBOT_ENGINE.lang}" target="_blank" rel="noopener">${FL('Voir / imprimer le récépissé','View / print receipt','查看 / 打印回执')}</a><a class="gbot-portal-url" href="${record.receiptUrl}?lang=${GBOT_ENGINE.lang}" download="${record.id}-receipt.html">${FL('Télécharger le récépissé','Download receipt','下载回执')}</a>${FB(FL('État du dossier','Case status','查询办件状态'),`demoCaseStatus('${record.id}')`)}</div>${gbotPortalAction(record.service)}<div class="gbot-flow-footer">${FB(FL('Mes dossiers démo','My demo cases','我的演示办件'),'demoShowCases()')}</div></div>`);
 gbotSetQR(GBOT_UI_L().greetingChips);
}
async function demoShowCases(){
 if(GBOT_FLOW.busy)return;GBOT_FLOW.busy=true;
 try{await demoInit();const result=await demoApi('/cases');flowDeactivateControls();GBOT_FLOW.active=false;GBOT_FLOW.stage='cases';
  gbotAppendMsg('bot',`<div>${demoBadge()}<strong class="demo-title">${FL('Mes dossiers dans ce navigateur','My cases in this browser','当前浏览器的演示办件')}</strong>${result.cases.length?result.cases.map(r=>`<div class="demo-case-row"><strong>${E(demoTitle(r))}</strong><small>${E(r.id)}</small><p>${E(demoStatus(r))} · ${E(demoDate(r.updatedAt))}</p>${r.status==='draft'?FB(FL('Reprendre','Resume','恢复草稿'),`demoResume('${r.id}')`):FB(FL('Récépissé et état','Receipt and status','查看回执与状态'),`demoCaseStatus('${r.id}')`)}</div>`).join(''):`<p>${FL('Aucun dossier enregistré.','No saved cases yet.','暂无已保存的办件。')}</p>`}</div>`);
 }catch(e){demoError(e);}finally{GBOT_FLOW.busy=false;}
}
async function demoCaseStatus(id){
 try{await demoInit();const r=await demoApi('/cases/'+encodeURIComponent(id));
  const labels={draft_created:FL('Brouillon créé','Draft created','草稿创建'),fields_updated:FL('Informations sauvegardées','Information saved','信息保存'),attachment_uploaded:FL('Pièce enregistrée','Attachment saved','材料上传'),attachment_removed:FL('Pièce retirée','Attachment removed','材料移除'),local_submission_received:FL('Soumission reçue localement','Local submission received','本地后台收到提交'),awaiting_local_review:FL('En attente de traitement local','Awaiting local review','待本地审核')};
  if(r.status==='submitted')demoRenderSubmitted(r);
  gbotAppendMsg('bot',`<strong>${E(r.id)} · ${E(demoStatus(r))}</strong><details class="demo-history"><summary>${FL('Afficher l’historique','Show processing history','查看处理时间线')}</summary><ol class="demo-timeline">${r.events.slice(-12).map(event=>`<li>${E(labels[event.type]||event.type)}<small>${E(demoDate(event.at))}</small></li>`).join('')}</ol></details><p class="gbot-summary">${FL('Cet historique reflète les opérations locales enregistrées ; aucune approbation officielle n’est simulée.','This timeline reflects stored local operations; it does not simulate official approval.','该时间线来自本地保存的实际操作记录，不自动模拟官方审批。')}</p>`);
 }catch(e){demoError(e);}
}
async function demoWelcomeDrafts(){try{await demoInit();const {cases}=await demoApi('/cases');const draft=cases.find(c=>c.status==='draft');if(draft&&!GBOT_FLOW.active)gbotAppendMsg('bot',`<p>${FL('Un brouillon est disponible.','A saved draft is available.','发现未完成的演示草稿。')} ${FB(FL('Reprendre','Resume','恢复草稿'),`demoResume('${draft.id}')`)}</p>`);}catch(e){demoError(e);}}
function gbotRestart(){flowDeactivateControls();GBOT_FLOW.active=false;GBOT_FLOW.awaitingInput=false;GBOT_FLOW.generation++;GBOT_FLOW.stage='paused';gbotSetQR(GBOT_UI_L().greetingChips);gbotAppendMsg('bot',`<p>${FL('Brouillon conservé. Reprenez-le depuis Mes dossiers démo.','Draft retained. Resume it from My demo cases.','草稿已保留，可从“我的演示办件”继续。')}</p>${FB(FL('Mes dossiers démo','My demo cases','我的演示办件'),'demoShowCases()')}`);}
async function demoAfterLanguageChange(){if(GBOT_FLOW.draft?.status==='draft'&&GBOT_FLOW.active){demoQuestion(demoMissing());}else demoWelcomeDrafts();}
async function demoFillExample(){
 if(GBOT_FLOW.busy||!GBOT_FLOW.draft)return;GBOT_FLOW.busy=true;
 const common={applicantName:'DEMO TEST USER',birthDate:'1990-06-15',phone:'+22890000000',email:'demo@example.invalid'};
 const examples={duplicate:{certificateFormat:'new',applicantRole:'self',documentType:'nationality',documentNumber:'DEMO-CNT-0001',copies:2,delivery:'centre',pickupLocation:'DEMO CENTRE LOME'},nationality:{basis:'descent',birthplace:'LOME (DEMO)',familyProof:'yes'},passport:{applicationType:'new',passportType:'ordinary',filingZone:'togo',filingLocation:'DGDN DEMO LOCATION',profession:'DEMO EMPLOYEE'},criminal:{applicantStatus:'bornTogo',documentType:'birth',documentNumber:'DEMO-BIRTH-0001',delivery:'centre',pickupLocation:'DEMO CENTRE LOME'},residence:{applicationType:'new',permitType:'student1',nationality:'DEMO COUNTRY',passportNumber:'DEMO-PASS-0001',residentialAddress:'DEMO ADDRESS LOME'},courtfees:{applicantRole:'individual',caseNature:'DEMO DOCUMENT CERTIFICATION',jurisdiction:'DEMO COURT LOME',caseSummary:'Fictional application for local demonstration only.'}};
 const allowed=new Set(DEMO_SCHEMA.services[GBOT_FLOW.service].fields.map(f=>f.key)),patch=Object.fromEntries(Object.entries({...common,...examples[GBOT_FLOW.service]}).filter(([k])=>allowed.has(k)));
 try{await demoPatch(patch);gbotAppendMsg('user',FL('Utiliser des informations fictives','Use fictional example information','填充虚构示例信息'));demoQuestion(demoMissing());}catch(e){demoError(e);}finally{GBOT_FLOW.busy=false;}
}

async function demoUploadAllSamples(){
 if(GBOT_FLOW.busy||GBOT_FLOW.stage!=='attachments')return;
 const gen=GBOT_FLOW.generation;
 for(const slot of demoSlots()){if(!GBOT_FLOW.draft.attachments.some(a=>a.slot===slot.key)){await demoUploadSample(slot.key,gen);if(gen!==GBOT_FLOW.generation)return;}}
 gbotAppendMsg('bot',FL('Les pièces fictives sont enregistrées. Vous pouvez demander la vérification.','Fictional sample attachments are saved. You can now request validation.','演示样例材料已保存。可以说“校验材料”，继续核对和提交。'));
}

async function demoShowReceipt(){
 try{await demoInit();let record=GBOT_FLOW.draft;if(record?.status!=='submitted'){record=(await demoApi('/cases')).cases.find(c=>c.status==='submitted');}if(record)demoRenderSubmitted(record);else gbotAppendMsg('bot',FL('Aucun dossier soumis avec récépissé.','No submitted case with a receipt yet.','暂无已提交办件的回执。'));}catch(e){demoError(e);}
}
