// ══════════════════════════════════════════════════════
//  GOVBOT ENGINE  —  scoped to chatbot popup only
//  No global namespace conflicts with eGov demo
// ══════════════════════════════════════════════════════

const GBOT_ENGINE = {
  cardCount: 0,
  requestId: 0,
  lang: 'en',
  lastIntent: null,
  turnCount: 0
};

// ── UI strings ────────────────────────────────────────
const GBOT_UI = {
  "fr": {
    "greeting": "Bonjour — je suis <strong>GovBot</strong>, votre assistant pour les démarches au Togo. Retrouvez les six services les plus utilisés du portail : conditions, documents, frais et étapes. Je peux recueillir vos informations et soumettre un dossier de démonstration local.",
    "greeting_short": "Quelle autre démarche souhaitez-vous explorer ?",
    "greetingChips": [
      "📜 Nationalité",
      "🛂 Passeport",
      "⚖️ Frais au tribunal",
      "📄 Casier judiciaire",
      "📑 Duplicata de nationalité",
      "🪪 Carte de séjour"
    ],
    "followupChips": [
      "📋 Documents requis",
      "📝 Étapes",
      "✅ Éligibilité",
      "💰 Frais",
      "⏱ Délai",
      "📅 Horaires",
      "❓ FAQ"
    ],
    "notFound": "Choisissez une des six démarches ci-dessus. Pour une autre démarche, consultez le catalogue officiel ; aucune réponse vérifiée n’est disponible ici pour ce sujet.",
    "more": "Souhaitez-vous connaître les documents, les frais ou préparer votre dossier ?",
    "sectionElig": "Éligibilité",
    "sectionReqs": "Documents requis",
    "sectionSteps": "Étapes de la démarche",
    "sectionFees": "Frais & Délai",
    "sectionHours": "Horaires",
    "sectionFaq": "Questions fréquentes",
    "noticeLabel": "À savoir",
    "portalBtn": "Fiche officielle",
    "applyBtn": "Remplir un dossier DÉMO",
    "applyBtnSub": "Remplissez les informations par dialogue, ajoutez les pièces et confirmez le dépôt local. Le dépôt officiel reste séparé.",
    "sbServices": "Services populaires",
    "liveAgent": "Assistance",
    "statusOnline": "Démo locale",
    "placeholder": "Posez votre question sur une démarche…",
    "feeLabel": "Frais",
    "timeLabel": "Délai publié",
    "sourceLabel": "Sources officielles",
    "checked": "Vérifié le 06/11/2026",
    "knowledge": "Fiche sourcée",
    "hoursUnknown": "Aucun horaire uniforme n’est confirmé pour ce parcours. Vérifiez le lieu de dépôt et les consignes de la fiche officielle.",
    "sourceNote": "Informations recueillies sur les sites officiels ; les instructions de votre formulaire font foi.",
    "catalog": "Catalogue officiel"
  },
  "en": {
    "greeting": "Hello — I am <strong>GovBot</strong>, your Togo public-services guide. Explore the six most-used services shown on the homepage: eligibility, documents, fees and steps. I can collect answers and submit a local demonstration case.",
    "greeting_short": "Which service would you like to explore?",
    "greetingChips": [
      "📜 Nationality certificate",
      "🛂 Passport",
      "⚖️ Court registration fees",
      "📄 Criminal-record extract",
      "📑 Nationality duplicate",
      "🪪 Residence permit"
    ],
    "followupChips": [
      "📋 Requirements",
      "📝 Steps",
      "✅ Eligibility",
      "💰 Fees",
      "⏱ Timeline",
      "📅 Office hours",
      "❓ FAQ"
    ],
    "notFound": "Choose one of the six services above. For other services, use the official catalogue; this guide has no verified answer for that subject.",
    "more": "Would you like documents, fees, or a preparation walkthrough?",
    "sectionElig": "Eligibility",
    "sectionReqs": "Documents required",
    "sectionSteps": "Procedure",
    "sectionFees": "Fees & Timeline",
    "sectionHours": "Office hours",
    "sectionFaq": "Frequently asked questions",
    "noticeLabel": "Please note",
    "portalBtn": "Official service",
    "applyBtn": "Fill a DEMO case",
    "applyBtnSub": "Provide answers and attachments in chat, then confirm a saved local case submission. Official filing remains separate.",
    "sbServices": "Popular services",
    "liveAgent": "Assistance",
    "statusOnline": "Local demo",
    "placeholder": "Ask about a Togo public service…",
    "feeLabel": "Fee",
    "timeLabel": "Published timeline",
    "sourceLabel": "Official sources",
    "checked": "Checked 6 Nov 2026",
    "knowledge": "Sourced guidance",
    "hoursUnknown": "No universal office hours are confirmed for this route. Check the filing location and official instructions.",
    "sourceNote": "Compiled from official sources; follow the instructions in your applicable official form.",
    "catalog": "Official catalogue"
  },
  "zh": {
    "greeting": "您好，我是 <strong>GovBot</strong> 多哥政务办事助手。这里已关联主页的 6 个常用事项，可查询申请条件、材料、费用和流程，也可以直接说“我要申请国籍证明副本”，开始填报演示办件。",
    "greeting_short": "还需要了解哪一项服务？",
    "greetingChips": [
      "📜 国籍证明",
      "🛂 护照申请",
      "⚖️ 法院案件登记费用",
      "📄 犯罪记录证明",
      "📑 国籍证明副本",
      "🪪 居留证申请"
    ],
    "followupChips": [
      "📋 所需材料",
      "📝 办理流程",
      "✅ 申请资格",
      "💰 收费标准",
      "⏱ 办理时限",
      "📅 办公时间",
      "❓ 常见问题"
    ],
    "notFound": "请选择上方已采集的 6 个事项。其他事项可查看官方目录；本助手暂没有该主题的已核实内容。",
    "more": "您想了解材料、费用，还是逐步演示办事准备？",
    "sectionElig": "申请资格",
    "sectionReqs": "所需材料",
    "sectionSteps": "办理流程",
    "sectionFees": "收费与时限",
    "sectionHours": "办公时间",
    "sectionFaq": "常见问题",
    "noticeLabel": "提示",
    "portalBtn": "官方事项详情",
    "applyBtn": "对话填报演示办件",
    "applyBtnSub": "通过对话填报信息、上传材料、校验并确认提交到本地演示后台，取得回执和办件编号。",
    "sbServices": "主页常用事项",
    "liveAgent": "办事帮助",
    "statusOnline": "本地演示",
    "placeholder": "请输入多哥政务事项相关问题…",
    "feeLabel": "费用",
    "timeLabel": "公布参考时限",
    "sourceLabel": "官方信息来源",
    "checked": "核查于 2026-11-06",
    "knowledge": "官方资料",
    "hoursUnknown": "未核实该路径统一的办公时间，请查看所选递交点及官方页面的通知。",
    "sourceNote": "内容整理自官方来源；具体申请以适用的官方表单要求为准。",
    "catalog": "官方事项目录"
  }
};

function GBOT_UI_L() { return GBOT_UI[GBOT_ENGINE.lang] || GBOT_UI.en; }

// ── sync language from eGov header ────────────────────
function gbotSyncLang(lang) {
  if(GBOT_FLOW.busy){document.getElementById('gbot-language').value=GBOT_ENGINE.lang;sessionStorage.setItem('togo-govbot-language',GBOT_ENGINE.lang);return;}
  const map = {en:'en',zh:'zh',fr:'fr'};
  const newLang = map[lang] || 'fr';
  const changed = newLang !== GBOT_ENGINE.lang;
  GBOT_ENGINE.lang = newLang;
  GBOT_ENGINE._pendingLangReset = changed; // flag for next open

  // If popup is currently open, apply immediately
  const popup = document.getElementById('chatbotPopup');
  const isOpen = popup && !popup.classList.contains('hidden');
  if (isOpen) {
    gbotApplyLangNow();
  }
}

function gbotApplyLangNow() {
  const resumeDraft=GBOT_FLOW.active&&GBOT_FLOW.draft?.status==='draft';
  GBOT_ENGINE.requestId++;
  GBOT_FLOW.generation++;
  GBOT_ESCALATION.active = false;
  const lang = GBOT_ENGINE.lang;
  const input = document.getElementById('gbot-chat-input');
  if (input) input.placeholder = GBOT_UI_L().placeholder;
  gbotBuildSidebar();
  const popup = document.getElementById('chatbotPopup');
  if (popup) popup.dir = lang === 'ar' ? 'rtl' : 'ltr';

  // Reset and re-greet in new language
  const area = document.getElementById('gbot-chat-messages');
  if (area) {
    area.innerHTML = '';
    area.dataset.seeded = '1';
  }
  gbotSetQR([]);
  GBOT_ENGINE.lastIntent = null;
  GBOT_FLOW.active = false;
  GBOT_ENGINE._pendingLangReset = false;
  gbotSetConversationLanguage(lang);
  setTimeout(() => {if(!area.querySelector('.gbot-msg-row'))gbotGreet();if(resumeDraft){GBOT_FLOW.active=true;demoAfterLanguageChange();}else demoWelcomeDrafts();}, 200);
}

// ── message helpers ────────────────────────────────────
function gbotAppendMsg(role, html, typing=false) {
  const area = document.getElementById('gbot-chat-messages');
  if (!area) return { bubble: document.createElement('div') };
  const row = document.createElement('div');
  row.className = 'gbot-msg-row ' + role;
  const avatar = document.createElement('div');
  avatar.className = 'gbot-avatar';
  avatar.textContent = role === 'bot' ? 'GB' : 'U';
  const bubble = document.createElement('div');
  bubble.className = 'gbot-bubble';
  bubble.innerHTML = typing
    ? '<div class="gbot-typing"><span></span><span></span><span></span></div>'
    : html;
  const wrap = document.createElement('div');
  wrap.className = 'gbot-msg-wrap';
  wrap.appendChild(bubble);
  row.appendChild(avatar);
  row.appendChild(wrap);
  area.appendChild(row);
  area.scrollTop = area.scrollHeight;
  return { bubble };
}

function gbotSetQR(chips) {
  const qr = document.getElementById('gbot-qr-area');
  if (!qr) return;
  qr.innerHTML = '';
  chips.forEach(c => {
    const btn = document.createElement('button');
    btn.className = 'gbot-qr-btn';
    btn.textContent = c;
    btn.onclick = () => gbotHandleInput(c);
    qr.appendChild(btn);
  });
}

function gbotEsc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ── RAG bar ───────────────────────────────────────────
function gbotAnimateRag(score) { /* KB bar removed */ }

// ── sidebar ───────────────────────────────────────────
const GBOT_SVC_KEYS = ['nationality','passport','courtfees','criminal','duplicate','residence'];

function gbotBuildSidebar() {
  const container = document.getElementById('gbot-sidebar-items');
  if (!container) return;
  const lbl = document.getElementById('gbot-sb-label');
  if (lbl) lbl.textContent = GBOT_UI_L().sbServices;
  const agentLbl = document.getElementById('gbot-agent-label');
  if (agentLbl) agentLbl.textContent = GBOT_UI_L().liveAgent || 'Live Agent';
  const onlineLbl = document.getElementById('gbot-online-label');
  if (onlineLbl) onlineLbl.textContent = GBOT_UI_L().statusOnline || 'Online';
  container.innerHTML = '';
  GBOT_SVC_KEYS.forEach(key => {
    const kbEntry = GBOT_KB[key];
    const d = kbEntry && (kbEntry[GBOT_ENGINE.lang] || kbEntry.en);
    const div = document.createElement('button');
    div.type = 'button';
    div.className = 'gbot-sidebar-item' + (key === GBOT_ENGINE.lastIntent ? ' active' : '');
    div.id = 'gbot-sb-' + key;
    div.innerHTML = `<span class="gbot-sb-icon">${kbEntry.icon}</span><span>${d ? d.title : key}</span>`;
    div.onclick = () => gbotSelectService(key);
    container.appendChild(div);
  });
}

function gbotUpdateSidebarActive(intent) {
  GBOT_SVC_KEYS.forEach(k => {
    const el = document.getElementById('gbot-sb-' + k);
    if (el) el.className = 'gbot-sidebar-item' + (k === intent ? ' active' : '');
  });
}

// ── greeting ──────────────────────────────────────────
function gbotGreet() {
  const ui = GBOT_UI_L();
  const chips = ui.greetingChips.map((c,i) =>
    `<button class="gbot-qr-btn" onclick="gbotSelectService('${GBOT_SVC_KEYS[i]}')" style="display:inline-flex;cursor:pointer">${gbotEsc(c)}</button>`
  ).join('');
  gbotAppendMsg('bot', ui.greeting + `<div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:10px">${chips}</div>`);
}

// ── service card ──────────────────────────────────────
function gbotBuildCard(intent, aspect) {
  const kbEntry = GBOT_KB[intent];
  if (!kbEntry) return `<p>${GBOT_UI_L().notFound}</p>`;
  const d = kbEntry[GBOT_ENGINE.lang] || kbEntry.en;
  const ui = GBOT_UI_L();
  const cardUid = ++GBOT_ENGINE.cardCount;

  const all = aspect === 'overview';
  const oElig = all || aspect === 'eligibility';
  const oReqs = all || aspect === 'requirements';
  const oSteps = all || aspect === 'steps';
  const oFees = all || aspect === 'fees' || aspect === 'time';
  const oHours = aspect === 'hours';
  const oFaq = aspect === 'faq';

  let sc = 0;
  function makeSection(icon, label, body, open) {
    const id = 'gbotsec' + cardUid + '-' + (++sc);
    return `<div class="gbot-info-section">
      <div class="gbot-section-hd" onclick="gbotToggleSec('${id}')">
        <span>${icon}</span><span>${label}</span>
        <span class="gbot-sec-tog${open?' open':''}" id="gtog${id}">▾</span>
      </div>
      <div class="gbot-section-bd" id="${id}" style="display:${open?'block':'none'}">${body}</div>
    </div>`;
  }

  let h = `<div class="gbot-rag-header">
    <div class="gbot-rag-pill"><div class="gbot-rag-dot"></div>${ui.knowledge}</div>
    <div class="gbot-rag-svc">${d.title}</div>
    <div class="gbot-rag-conf">${ui.checked}</div>
  </div>`;
  if (d.notice) h += `<div class="gbot-notice-box">⚠️ <span><strong>${ui.noticeLabel}:</strong> ${d.notice}</span></div>`;
  h += `<div class="gbot-summary">${d.summary}</div>`;

  if (d.eligibility) {
    const body = `<ul class="gbot-elig-list">${d.eligibility.map(e=>`<li class="gbot-elig-item"><span class="gbot-elig-chk">✓</span><span>${e}</span></li>`).join('')}</ul>`;
    h += makeSection('✅', ui.sectionElig, body, oElig);
  }
  const reqBody = `<ul class="gbot-req-list">${d.requirements.map((r,i)=>`<li class="gbot-req-item"><div class="gbot-req-num">${i+1}</div><span>${r}</span></li>`).join('')}</ul>`;
  h += makeSection('📋', ui.sectionReqs, reqBody, oReqs);
  const stepsBody = `<div class="gbot-step-list">${d.steps.map((s,i)=>`<div class="gbot-step-row"><div class="gbot-step-num">${i+1}</div><div>${s}</div></div>`).join('')}</div>`;
  h += makeSection('📝', ui.sectionSteps, stepsBody, oSteps);
  const feesBody = `<div class="gbot-meta-grid">
    <div class="gbot-meta-cell"><div class="gbot-meta-lbl">💰 ${ui.feeLabel}</div><div class="gbot-meta-val">${d.fee}</div>${d.fee_note?`<div class="gbot-meta-sub">${d.fee_note}</div>`:''}</div>
    <div class="gbot-meta-cell"><div class="gbot-meta-lbl">⏱ ${ui.timeLabel}</div><div class="gbot-meta-val">${d.time}</div>${d.time_express?`<div class="gbot-meta-sub">${d.time_express}</div>`:''}</div>
  </div>`;
  h += makeSection('💰', ui.sectionFees, feesBody, oFees);
  h += makeSection('📅', ui.sectionHours, `<p>${ui.hoursUnknown}</p>`, oHours);
  if (d.faq) {
    const faqBody = d.faq.map(f=>`<div class="gbot-faq-item"><div class="gbot-faq-q">Q: ${f.q}</div><div class="gbot-faq-a">${f.a}</div></div>`).join('');
    h += makeSection('❓', ui.sectionFaq, faqBody, oFaq);
  }
  h += `<div class="gbot-portal-link"><a class="gbot-portal-url" href="${d.portal}" target="_blank" rel="noopener noreferrer">🔗 ${ui.portalBtn} ↗</a></div>`;
  h += `<div class="gbot-source-note"><strong>${ui.sourceLabel} · ${ui.checked}</strong><p>${ui.sourceNote}</p>${kbEntry.sources.map((source,i)=>`<a href="${source.url}" target="_blank" rel="noopener noreferrer">${i+1}. ${gbotEsc(source.publisher)} ↗</a>`).join('<br>')}</div>`;

  // Apply CTA
  h += `<div class="gbot-apply-cta">
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
      <span style="font-size:1rem">🚀</span>
      <span style="font-weight:600;color:var(--gbot-text);font-size:0.86rem">${ui.applyBtn}</span>
    </div>
    <p style="font-size:0.78rem;color:var(--gbot-text-dim);margin-bottom:10px">${ui.applyBtnSub}</p>
    <div class="gbot-action-row"><button onclick="gbotStartFlow('${intent}')" class="gbot-apply-btn">▶ ${ui.applyBtn}</button>${gbotPortalAction(intent)}</div>
  </div>`;

  // Escalation
  h += `<button onclick="gbotStartEscalation('${intent}')" class="gbot-esc-btn">👤 ${GBOT_ESC_i18n[GBOT_ENGINE.lang]?.triggerBtn||'Speak to an Agent'}</button>`;
  h += `<p style="font-size:0.76rem;color:var(--gbot-text-dim);margin-top:8px">${ui.more}</p>`;
  return h;
}

window.gbotToggleSec = function(id) {
  const body = document.getElementById(id);
  const tog = document.getElementById('gtog' + id);
  if (!body) return;
  const open = body.style.display !== 'none';
  body.style.display = open ? 'none' : 'block';
  if (tog) tog.classList.toggle('open', !open);
};

// ── main input handler ────────────────────────────────
function gbotHandleInput(text, forcedIntent = null) {
  if (!text || !text.trim()) return;
  if(/^(我的办件|我的演示办件|查询状态|my cases|mes dossiers)$/i.test(text.trim())){gbotAppendMsg('user',gbotEsc(text));demoShowCases();return;}
  if(/^(查看回执|我的回执|show receipt|voir le r[eé]c[eé]piss[eé])$/i.test(text.trim())){gbotAppendMsg('user',gbotEsc(text));demoShowReceipt();return;}
  const caseId=text.match(/DEMO-\d{8}-[A-F0-9]{12}/i)?.[0];
  if(caseId){gbotAppendMsg('user',gbotEsc(text));demoCaseStatus(caseId.toUpperCase());return;}
  if (/[\u3400-\u9fff]/.test(text) && GBOT_ENGINE.lang !== 'zh') gbotSetConversationLanguage('zh');
  else if (/\b(what|how|passport|requirements|criminal record|residence permit|nationality certificate)\b/i.test(text) && GBOT_ENGINE.lang !== 'en') gbotSetConversationLanguage('en');
  else if (/\b(passeport|casier|nationalit[eé]|s[eé]jour|combien|documents requis)\b/i.test(text) && GBOT_ENGINE.lang !== 'fr') gbotSetConversationLanguage('fr');

  // Escalation intercept (highest priority)
  if (typeof GBOT_ESCALATION !== 'undefined' && GBOT_ESCALATION.active) {
    gbotAppendMsg('user', gbotEsc(text));
    gbotInterceptEscalation(text);
    return;
  }

  // Flow intercept
  if (GBOT_FLOW && GBOT_FLOW.active) {
    if (GBOT_FLOW.awaitingInput) {
      gbotInterceptFlow(text);
    }
    return;
  }

  gbotSetQR([]);
  const clean = text.replace(/^[\p{Emoji}\s]+/u, '').trim();
  gbotAppendMsg('user', gbotEsc(text));
  const { bubble } = gbotAppendMsg('bot', '', true);
  GBOT_ENGINE.turnCount++;

  const delay = 600 + Math.random() * 600;
  const requestId = GBOT_ENGINE.requestId;
  setTimeout(() => {
    if (requestId !== GBOT_ENGINE.requestId) { bubble.closest('.gbot-msg-row')?.remove(); return; }
    const detected = gbotDetectIntent(clean, GBOT_ENGINE.lang);
    const intent = forcedIntent || detected.intent;
    const score = detected.score;
    const aspect = forcedIntent ? 'overview' : gbotDetectAspect(clean, GBOT_ENGINE.lang);
    const unsupported = /卫生|餐饮|出生证|身份证|公司注册|社会救助|入学|护照.*身份证|hygiene|birth certificate|national id|company reg|social grant|school enroll|carte d.identit|permis hygi|inscription scolaire|bourse|logement|visa|permis de conduire|btcs|geospatial|radio lom[eé]/i.test(clean);
    const resolved = intent || (!unsupported && aspect !== 'overview' ? GBOT_ENGINE.lastIntent : null);
    gbotAnimateRag(score || (resolved ? 4 : 0));

    if (!resolved) {
      bubble.innerHTML = `<p>${GBOT_UI_L().notFound}</p>`;
      gbotSetQR(GBOT_UI_L().greetingChips);
      return;
    }
    GBOT_ENGINE.lastIntent = resolved;
    gbotUpdateSidebarActive(resolved);
    bubble.innerHTML = gbotFocusedAnswer(resolved, clean, aspect) + gbotBuildCard(resolved, aspect);
    const area = document.getElementById('gbot-chat-messages');
    if (area) area.scrollTop = area.scrollHeight;
    gbotSetQR(GBOT_UI_L().followupChips);
    if(!forcedIntent&&/我要办理|我想申请|我要申请|帮我办理|开始填报|apply for|start application|je souhaite|je veux demander/i.test(clean))gbotStartFlow(resolved);
  }, delay);
}

window.gbotHandleInput = gbotHandleInput;
window.gbotStartFlow = gbotStartFlow;

// ── send button / enter ────────────────────────────────
function gbotSend() {
  const input = document.getElementById('gbot-chat-input');
  if (!input) return;
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  gbotHandleInput(text);
}
window.gbotSend = gbotSend;

// ── init (called when popup first opens) ─────────────
function gbotInit() {
  const area = document.getElementById('gbot-chat-messages');
  if (!area) return;

  // If language changed while the popup was closed, reset and re-greet
  if (GBOT_ENGINE._pendingLangReset) {
    gbotApplyLangNow();
    return;
  }

  // First ever open
  if (!area.dataset.seeded) {
    area.dataset.seeded = '1';
    GBOT_ENGINE.lang = sessionStorage.getItem('togo-govbot-language') || 'en';
    gbotBuildSidebar();
    const popup = document.getElementById('chatbotPopup');
    if (popup) popup.dir = GBOT_ENGINE.lang === 'ar' ? 'rtl' : 'ltr';
    setTimeout(() => {if(!area.querySelector('.gbot-msg-row'))gbotGreet();demoWelcomeDrafts();}, 200);
  }
}
window.gbotInit = gbotInit;

function gbotSetConversationLanguage(lang) {
  GBOT_ENGINE.lang = lang;
  sessionStorage.setItem('togo-govbot-language', lang);
  gbotBuildSidebar();
  const casesButton=document.getElementById('demo-cases-button');
  if(casesButton)casesButton.textContent=({fr:'Mes dossiers',en:'My cases',zh:'我的办件'})[lang]||'Mes dossiers';
  const selector = document.getElementById('gbot-language');
  if (selector) selector.value = lang;
  document.getElementById('gbot-chat-input').placeholder = GBOT_UI_L().placeholder;
}
function gbotSelectService(key) {
  if (!GBOT_KB[key]) return;
  flowDeactivateControls();
  GBOT_FLOW.active = false;
  GBOT_FLOW.generation++;
  GBOT_ESCALATION.active = false;
  const entry = GBOT_KB[key][GBOT_ENGINE.lang] || GBOT_KB[key].fr;
  gbotHandleInput(entry.title, key);
}

// Answer a focused question first, then keep the original expandable service card.
function gbotFocusedAnswer(intent, text, aspect) {
  const d = GBOT_KB[intent][GBOT_ENGINE.lang] || GBOT_KB[intent].fr;
  const v = gbotNormalise(text);
  let answer = null;
  if (aspect === 'fees') answer = d.fee + ' — ' + d.notice;
  else if (aspect === 'time') answer = d.time;
  else if (aspect === 'hours') answer = GBOT_UI_L().hoursUnknown;
  else if (intent === 'duplicate' && /旧版|ancien|old format/.test(v)) answer = d.faq[0].a;
  else if (intent === 'duplicate' && /邮|poste|postage|delivery/.test(v)) answer = d.faq[2].a;
  else if (intent === 'nationality' && /出生|naissance|birth/.test(v)) answer = d.faq[0].a;
  else if (intent === 'passport' && /有效|validit|valid for/.test(v)) answer = d.faq[2].a;
  else if (intent === 'residence' && /身份证|identite|national id/.test(v)) answer = d.faq[0].a;
  else if (intent === 'criminal' && /有效|validit|expir|三个月|three months/.test(v)) answer = d.faq[2].a;
  else if (/全程|线下|entierement|fully online|in.person/.test(v) && ['nationality','passport'].includes(intent)) answer = d.faq[1].a;
  return answer ? `<div class="gbot-notice-box"><span>${gbotEsc(answer)}</span></div>` : '';
}
