(() => {
 const serviceRoutes = {"nationality": "/service/01KJNT5BN004M0AZCF7PW283VQ", "passport": "/service/01KFKEHS3KVS1VDVCFWVVBEQWM", "courtfees": "/service/01KPTAYWV1ZAYE012PKN63Q1MM", "criminal": "/service/01KJNQA87SE30X0ATQKSQEEVEA", "duplicate": "/service/01KSJSR8X21AM1WRC1JWMQE337", "residence": "/service/01KSV1K2HDKKYSS92R4V861B17"};
 const portalStyle=document.createElement('style');
 portalStyle.textContent='.chat-main-button{display:none!important}';
 document.head.append(portalStyle);
 const host=document.createElement('div');host.id='govbot-integration';
 const root=host.attachShadow({mode:'open'});
 root.innerHTML=`<style>
 :host{font-family:Arial,Helvetica,sans-serif;color:#1f2937}
 *{box-sizing:border-box}[hidden]{display:none!important}
 button{font:inherit;cursor:pointer}
 .launcher{position:fixed;right:24px;bottom:24px;z-index:2147483000;display:flex;align-items:center;gap:10px;border:2px solid #fff;border-radius:40px;padding:13px 20px;background:#1f5fae;color:#fff;box-shadow:0 8px 26px #102a4d40;font-size:15px;font-weight:600}
 .icon{font-size:28px;line-height:1}.launcher:focus-visible{outline:3px solid #1879c2;outline-offset:4px}
 dialog{position:fixed;inset:auto 24px 100px auto;margin:0;padding:0;width:min(1040px,calc(100vw - 48px));height:min(760px,calc(100vh - 124px));height:min(760px,calc(100dvh - 124px));max-width:none;max-height:none;border:1px solid #d8e0ea;border-radius:18px;overflow:hidden;box-shadow:0 20px 60px #102a4d40;background:#fff}
 dialog::backdrop{background:#102a4d33}iframe{display:block;width:100%;height:100%;border:0}
 @media(max-width:600px){.launcher{right:14px;bottom:max(14px,env(safe-area-inset-bottom));padding:12px 16px}dialog{inset:8px;margin:0;width:calc(100vw - 16px);height:calc(100vh - 16px);height:calc(100dvh - 16px);border-radius:14px}}
 </style><button class="launcher" type="button" aria-label="Ouvrir l’assistant intelligent" aria-haspopup="dialog" aria-expanded="false"><span class="icon" aria-hidden="true">🤖</span><span>Assistant intelligent</span></button><dialog aria-label="GovBot — Intelligent Q&A Demo"><iframe title="GovBot — Togo service guide" src="about:blank"></iframe></dialog>`;
 document.body.append(host);
 const button=root.querySelector('button'),dialog=root.querySelector('dialog'),frame=root.querySelector('iframe');
 const seatStyle=document.createElement('style');seatStyle.textContent=`.seat-launcher{position:fixed;right:24px;bottom:100px;z-index:2147482999;background:#fff;color:#1f5fae;border:1px solid #b8c7d9;border-radius:30px;padding:11px 19px;font-size:14px;font-weight:600}.seat-launch-dialog{inset:50% auto auto 50%;transform:translate(-50%,-50%);width:min(1380px,calc(100vw - 32px));height:calc(100dvh - 40px);padding:0;max-height:none}.seat-close{position:absolute;right:16px;top:8px;z-index:2;border:1px solid #ccd8d0;border-radius:50%;width:32px;height:32px;background:white;font-size:20px}.seat-launch-dialog iframe{width:100%;height:100%;border:0}@media(max-width:600px){.seat-launcher{right:14px;bottom:88px}.seat-launch-dialog{width:calc(100vw - 12px);height:calc(100dvh - 12px)}}`;
 seatStyle.textContent+=`.observer-launcher{position:fixed;right:24px;bottom:156px;z-index:2147482999;display:flex;align-items:center;gap:8px;background:#fff;color:#1f5fae;border:1px solid #b8c7d9;border-radius:30px;padding:11px 19px;font:600 14px Arial,Helvetica,sans-serif;text-decoration:none;box-shadow:0 5px 20px #102a4d14}.observer-launcher:focus-visible{outline:3px solid #2879c9;outline-offset:3px}.observer-launcher:hover{background:#eef5fc}@media(max-width:600px){.observer-launcher{right:14px;bottom:144px}}`;
 root.append(seatStyle);
 const observerLink=document.createElement('a');observerLink.className='observer-launcher';observerLink.href='/tangrat/observer?ui_lang=en';observerLink.target='_blank';observerLink.rel='noopener noreferrer';observerLink.textContent='🖥 观察台 ↗';observerLink.setAttribute('aria-label','Open observer in a new tab');root.append(observerLink);
 const seatButton=document.createElement('button');seatButton.type='button';seatButton.className='seat-launcher';seatButton.textContent='🎙 AI坐席';seatButton.setAttribute('aria-haspopup','dialog');seatButton.setAttribute('aria-expanded','false');
 const seatDialog=document.createElement('dialog');seatDialog.className='seat-launch-dialog';seatDialog.setAttribute('aria-label','Togo AI agent');seatDialog.innerHTML='<button type="button" class="seat-close" aria-label="Close AI agent">×</button><iframe title="Togo AI agent" src="about:blank" allow="microphone; autoplay"></iframe>';
 const dock=document.createElement('nav');dock.className='entry-dock';dock.setAttribute('aria-label','Assistant tools');
 const entryIcon=kind=>'<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+({text:'<path fill="currentColor" fill-opacity=".18" stroke="none" d="M5 3h14a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H9l-5 3v-3a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3Z"/><path d="M5 4h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H9l-5 3v-3a2 2 0 0 1-2-2V7a3 3 0 0 1 3-3Z"/><path d="M7 8h10M7 12h6"/>',voice:'<rect x="8" y="2" width="8" height="13" rx="4" fill="currentColor" fill-opacity=".18"/><path d="M5 11v1a7 7 0 0 0 14 0v-1M12 19v3M8 22h8M10.5 6h3M10.5 9h3"/>',observer:'<rect x="2" y="3" width="20" height="14" rx="3" fill="currentColor" fill-opacity=".18"/><path d="M12 17v4M7 21h10M5.5 11l3-3 3 3 5-5M16.5 6h2v2"/>'})[kind]+'</svg>';
 button.innerHTML=entryIcon('text')+'<span>Text assistant</span>';button.setAttribute('aria-label','Open text assistant');seatButton.innerHTML=entryIcon('voice')+'<span>AI agent</span>';observerLink.innerHTML=entryIcon('observer')+'<span>Observer</span>';
 for(const entry of [button,seatButton,observerLink]){entry.classList.add('entry-button');dock.append(entry);}root.append(dock);
 seatStyle.textContent+=`.entry-dock{position:fixed;right:24px;bottom:24px;z-index:2147483000;display:flex;flex-direction:column;gap:12px}.entry-dock>.entry-button{position:static;inset:auto;display:flex;align-items:center;justify-content:center;gap:10px;box-sizing:border-box;width:184px;height:48px;min-height:48px;margin:0;padding:0 18px;border:1px solid #1f5fae;border-radius:26px;background:#1f5fae;color:#fff;font:600 15px/1.2 Arial,Helvetica,sans-serif;text-decoration:none;box-shadow:0 5px 16px #102a4d20;white-space:nowrap;cursor:pointer;appearance:none;-webkit-appearance:none}.entry-dock>.entry-button:hover{background:#194f91}.entry-dock>.entry-button:focus-visible{outline:3px solid #83b4ed;outline-offset:3px}.entry-button svg{flex:0 0 24px;width:24px;height:24px;filter:drop-shadow(0 1px 1px #102a4d20)}@media(max-width:600px){.entry-dock{right:14px;bottom:max(14px,env(safe-area-inset-bottom));gap:10px}.entry-dock>.entry-button{width:156px;height:44px;min-height:44px;font-size:14px}}`;
 const seatFrame=seatDialog.querySelector('iframe');
 function closeSeat(){seatDialog.close();seatButton.setAttribute('aria-expanded','false');seatFrame.src='about:blank';seatButton.focus();}
 root.append(seatDialog);seatButton.onclick=()=>{seatFrame.src='/tangrat/?ui_lang=en';seatDialog.showModal();seatButton.setAttribute('aria-expanded','true');};seatDialog.querySelector('button').onclick=closeSeat;
 seatDialog.addEventListener('cancel',e=>{e.preventDefault();closeSeat();});
 addEventListener('message',e=>{if(e.origin===location.origin&&e.source===seatFrame.contentWindow&&e.data?.type==='tangrat:close')closeSeat();});

 function close(){if(dialog.open)dialog.close();button.setAttribute('aria-expanded','false');button.focus();}
 button.addEventListener('click',()=>{
  if(dialog.open)return close();
  dialog.showModal();button.setAttribute('aria-expanded','true');
  if(frame.getAttribute('src')==='about:blank')frame.src='/govbot/demo/assistant.html?ui_lang=en';
  else frame.contentWindow.postMessage({type:'govbot:open'},location.origin);
 });
 dialog.addEventListener('cancel',event=>{event.preventDefault();close();});
 dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)close();}});
 addEventListener('message',event=>{
  if(event.origin!==location.origin||event.source!==frame.contentWindow)return;
  if(event.data?.type==='govbot:close')return close();
  if(event.data?.type==='govbot:navigate'){
   const target=Object.hasOwn(serviceRoutes,event.data.service)?serviceRoutes[event.data.service]:null;
   if(!target)return;
   close();
   location.assign(target);
  }
 });
})();
