import assert from 'node:assert/strict';
import http from 'node:http';
import {mkdtemp,rm,readFile} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {createCaseApi} from '../server/case-api.mjs';
const dir=await mkdtemp(path.join(os.tmpdir(),'govbot-cases-test-'));
let server,base,cookie='',checks=0;
async function start(){const api=createCaseApi({dataDir:dir});server=http.createServer(async(req,res)=>{if(!await api(req,res)){res.writeHead(404);res.end();}});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));base='http://127.0.0.1:'+server.address().port;}
async function stop(){await new Promise(resolve=>server.close(resolve));}
async function call(route,{method='GET',body,headers={},session=cookie}={}){
 const response=await fetch(base+'/api/demo'+route,{method,headers:{...(session?{cookie:session}:{}),...(body&&!(body instanceof Buffer)?{'content-type':'application/json'}:{}),...headers},body:body instanceof Buffer?body:body?JSON.stringify(body):undefined});
 const set=response.headers.get('set-cookie');if(set&&!session)cookie=set.split(';')[0];
 const content=response.headers.get('content-type')||'';
 const data=content.includes('application/json')?await response.json():content.includes('text/html')?await response.text():Buffer.from(await response.arrayBuffer());
 return {status:response.status,data,headers:response.headers};
}
const check=(condition,label)=>{assert.ok(condition,label);checks++;console.log('PASS',label);};
const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j2aQAAAAASUVORK5CYII=','base64');
const info={applicantName:'DEMO TEST <USER>',birthDate:'1990-06-15',phone:'+22890000000',email:'demo@example.invalid'};
const fieldsets={
 duplicate:{certificateFormat:'new',applicantRole:'self',applicantName:info.applicantName,documentType:'nationality',documentNumber:'DEMO-CNT-001',copies:3,delivery:'centre',pickupLocation:'DEMO CENTRE',phone:info.phone,email:info.email},
 nationality:{...info,basis:'descent',birthplace:'LOME DEMO',familyProof:'yes'},
 passport:{...info,applicationType:'renew',passportType:'ordinary',filingZone:'togo',filingLocation:'DEMO LOCATION',profession:'DEMO WORK',oldPassportNumber:'DEMO-OLD-001'},
 criminal:{...info,applicantStatus:'bornTogo',documentType:'birth',documentNumber:'DEMO-BIRTH-001',delivery:'post',postalAddress:'DEMO POSTAL ADDRESS LOME'},
 residence:{...info,applicationType:'renew',permitType:'student1',nationality:'DEMO NATIONALITY',passportNumber:'DEMO-PASS-001',residentialAddress:'DEMO ADDRESS LOME'},
 courtfees:{applicantRole:'entity',applicantName:info.applicantName,entityName:'DEMO ORGANISATION',caseNature:'DEMO CERTIFICATION',jurisdiction:'DEMO COURT',caseSummary:'Fictional local application only.',phone:info.phone,email:info.email}
};
try{
 await start();
 let r=await call('/schema');const schemas=r.data.services;
 check(r.status===200&&Object.keys(schemas).length===6,'six public demo schemas and browser session');
 check(r.headers.get('set-cookie')?.includes('HttpOnly'),'session cookie is HttpOnly');
 const key=crypto.randomUUID();r=await call('/cases',{method:'POST',body:{service:'duplicate',clientRequestId:key}});let sample=r.data;
 check(r.status===201&&sample.status==='draft','duplicate sample draft is persisted');
 const same=await call('/cases',{method:'POST',body:{service:'duplicate',clientRequestId:key}});
 check(same.data.id===sample.id,'create retry is idempotent');
 r=await call('/cases/'+sample.id,{session:'govbot_demo='+'b'.repeat(64)});check(r.status===404,'another browser cannot read a case');
 r=await call('/cases/'+sample.id,{method:'PATCH',headers:{origin:'https://unrelated.example'},body:{version:1,fields:{phone:'123'}}});check(r.status===403,'cross-origin mutation is rejected');
 r=await call('/cases/'+sample.id,{method:'PATCH',body:{version:sample.version,fields:{phone:'abc'}}});check(r.status===422,'invalid phone is rejected by the server');
 r=await call('/cases/'+sample.id+'/submit',{method:'POST',body:{version:sample.version,confirmed:true}});check(r.status===422&&r.data.errors.length>0,'incomplete case cannot be submitted');
 r=await call('/cases/'+sample.id+'/submit',{method:'POST',body:{version:sample.version}});check(r.status===400,'explicit review confirmation is required');
 let submittedId;
 for(const [service,fields] of Object.entries(fieldsets)){
  let record=service==='duplicate'?sample:(await call('/cases',{method:'POST',body:{service,clientRequestId:crypto.randomUUID()}})).data;
  const originalVersion=record.version;
  r=await call('/cases/'+record.id,{method:'PATCH',body:{version:record.version,fields}});assert.equal(r.status,200,JSON.stringify(r.data));record=r.data;
  check(record.fields.applicantName===info.applicantName,service+': information saved');
  r=await call('/cases/'+record.id,{method:'PATCH',body:{version:originalVersion,fields:{phone:info.phone}}});check(r.status===409,service+': stale edits rejected');
  if(service==='duplicate'){
   r=await call(`/cases/${record.id}/attachments?slot=reference&name=bad.png&version=${record.version}`,{method:'POST',body:Buffer.from('not an image')});check(r.status===415,'fake file header rejected');
   r=await call(`/cases/${record.id}/attachments?slot=reference&name=large.png&version=${record.version}`,{method:'POST',body:Buffer.alloc(10*1024*1024+1)});check(r.status===413,'server rejects oversized attachments');
  }
  const slots=schemas[service].attachments.filter(slot=>!slot.when||Object.entries(slot.when).every(([k,v])=>typeof v==='object'?v.in.includes(fields[k]):fields[k]===v));
  for(const slot of slots.filter(s=>s.required||service==='duplicate')){
   r=await call(`/cases/${record.id}/attachments?slot=${slot.key}&name=DEMO-${slot.key}.png&version=${record.version}`,{method:'POST',body:png,headers:{'content-type':'image/png'}});assert.equal(r.status,201,JSON.stringify(r.data));record=r.data;
  }
  check(record.attachments.length>0,service+': uploaded files stored');
  if(service==='duplicate'){
   const old=record.attachments[0];
   r=await call(`/cases/${record.id}/attachments/${old.id}`,{method:'DELETE',body:{version:record.version}});check(r.status===200&&r.data.attachments.length===0,'draft attachment removal is persisted');record=r.data;
   r=await call(`/cases/${record.id}/attachments/${old.id}`);check(r.status===404,'removed attachment is inaccessible');
   r=await call(`/cases/${record.id}/attachments?slot=reference&name=DEMO-reference.png&version=${record.version}`,{method:'POST',body:png});assert.equal(r.status,201);record=r.data;
  }
  const item=record.attachments[0];r=await call(`/cases/${record.id}/attachments/${item.id}`);check(r.status===200&&r.data.equals(png),service+': attachment bytes can be downloaded');
  r=await call('/cases/'+record.id+'/validate',{method:'POST',body:{}});check(r.data.valid,service+': server-side final validation');
  const results=await Promise.all([1,2].map(()=>call(`/cases/${record.id}/submit`,{method:'POST',body:{version:record.version,confirmed:true}})));
  check(results.every(r=>r.status===200&&r.data.status==='submitted'&&r.data.id===record.id),service+': concurrent submit retries return one case');
  record=results[0].data;submittedId=record.id;
  if(service==='duplicate')check(record.feeAtSubmission.amount===3000&&!record.feeAtSubmission.charged,'duplicate sample: three-copy reference, no payment');
  r=await call('/cases/'+record.id+'/receipt?lang=zh');check(r.status===200&&r.data.includes('演示办件提交回执')&&r.data.includes('&lt;USER&gt;')&&!r.data.includes('DEMO TEST <USER>'),service+': escaped, marked receipt');
  r=await call('/cases/'+record.id,{method:'PATCH',body:{version:record.version,fields:{applicantName:'changed'}}});check(r.status===409,service+': submitted content is frozen');
 }
 r=await call('/cases');check(r.data.cases.length===6&&r.data.cases.every(c=>c.status==='submitted'),'six submitted records listed for this browser');
 await stop();await start();
 r=await call('/cases/'+submittedId);check(r.status===200&&r.data.status==='submitted'&&r.data.events.some(e=>e.type==='local_submission_received'),'status survives service restart');
 r=await call('/cases/'+submittedId+'/receipt?format=json');check(r.status===200&&r.data.id===submittedId,'receipt survives service restart');
 const schemaRecord=(await call('/cases',{method:'POST',body:{service:'duplicate',clientRequestId:crypto.randomUUID()}})).data;
 r=await call('/cases/'+schemaRecord.id,{method:'PATCH',body:{version:schemaRecord.version,fields:{applicantRole:'relative',holderName:'DEMO HOLDER',delivery:'post',postalAddress:'DEMO POSTAL'}}});let branch=r.data;
 r=await call('/cases/'+branch.id,{method:'PATCH',body:{version:branch.version,fields:{applicantRole:'self',delivery:'centre'}}});check(r.status===200&&!r.data.fields.holderName&&!r.data.fields.postalAddress,'dormant branch fields are removed');
 branch=r.data;r=await call('/cases/'+branch.id,{method:'PATCH',body:{version:branch.version,fields:{},skipFields:['email']}});check(r.status===200&&r.data.skippedFields.includes('email'),'optional skip persists');
 console.log(`${checks} integration checks passed. Data directory: temporary, removed after test.`);
}finally{if(server?.listening)await stop();await rm(dir,{recursive:true,force:true});}
