const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=require('node:path').resolve(__dirname,'..');
const context={window:{},document:{getElementById:()=>null},console,sessionStorage:{getItem:()=>null,setItem(){}},setTimeout};
vm.createContext(context);
for(const file of ['kb','intent','escalation','flows','engine'])vm.runInContext(fs.readFileSync(`${root}/web/demo/js/govbot/${file}.js`,'utf8'),context);
const evaluate=s=>vm.runInContext(s,context);
let passed=0;function test(name,fn){fn();passed++;console.log('PASS',name);}
test('Six services match the homepage IDs',()=>{
 assert.equal(evaluate('Object.keys(GBOT_KB).length'),6);
 assert.equal(evaluate('GBOT_KB.passport.service_id'),'01KFKEHS3KVS1VDVCFWVVBEQWM');
 assert.equal(evaluate('GBOT_KB.duplicate.service_id'),'01KSJSR8X21AM1WRC1JWMQE337');
});
const cases=[['国籍证明费用','nationality'],['国籍证明副本多少钱','duplicate'],['Demande du certificat de nationalité togolaise','nationality'],["Obtenir un duplicata d’un certificat de nationalité",'duplicate'],['nationality certificate duplicate fee','duplicate'],['passport renewal','passport'],['Demande de Passeport','passport'],['法院案件登记费用','courtfees'],["frais d’enrôlement au tribunal",'courtfees'],['criminal record requirements','criminal'],['casier judiciaire','criminal'],['居留证续期','residence'],['carte de séjour étudiant','residence'],['résidence permit','residence']];
for(const [query,intent] of cases)test('Intent: '+query,()=>assert.equal(evaluate(`gbotDetectIntent(${JSON.stringify(query)}).intent`),intent));
for(const [query,aspect] of [['所需材料','requirements'],['收费标准','fees'],['办理时限','time'],['申请资格','eligibility'],['办公时间','hours'],['办理流程','steps']])test('Followup aspect: '+query,()=>assert.equal(evaluate(`gbotDetectAspect(${JSON.stringify(query)})`),aspect));
for(const lang of ['zh','en','fr'])test('All cards have sources and correct currency in '+lang,()=>{
 evaluate(`GBOT_ENGINE.lang='${lang}'`);
 for(const key of ['nationality','passport','courtfees','criminal','duplicate','residence']){
  const card=evaluate(`gbotBuildCard('${key}','overview')`);
  assert.ok(card.includes('https://new.service-public.gouv.tg/service/'));
  assert.ok(card.includes('gbot-source-note'));
  assert.ok(!/gov\.example|USD|\$40|% match/.test(card));
 }
});
test('Cards use unique accordion IDs across turns',()=>{
 const a=evaluate("gbotBuildCard('passport','overview')"),b=evaluate("gbotBuildCard('passport','fees')");
 const ids=s=>[...s.matchAll(/id="(gbotsec[^"]+)"/g)].map(m=>m[1]);
 const all=[...ids(a),...ids(b)];assert.equal(new Set(all).size,all.length);
});
test('Parent navigation routes match all six knowledge entries',()=>{
 const code=fs.readFileSync(`${root}/web/launcher.js`,'utf8');
 const routes=JSON.parse(code.match(/const serviceRoutes = (\{[^;]+\});/)[1]);
 for(const [key,route] of Object.entries(routes))assert.equal(route,evaluate(`GBOT_KB['${key}'].route`));
 assert.equal(Object.keys(routes).length,6);
});
test('Cards and preparation expose same-page service navigation',()=>{
 const html=evaluate("gbotBuildCard('criminal','overview')");
 assert.ok(html.includes("gbotNavigatePortal('criminal')"));
 evaluate("GBOT_FLOW.service='duplicate'");
 assert.ok(evaluate('officialButton()').includes("gbotNavigatePortal('duplicate')"));
});
console.log(`${passed} checks passed.`);
