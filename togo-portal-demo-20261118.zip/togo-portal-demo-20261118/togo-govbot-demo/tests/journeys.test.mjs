import assert from 'node:assert/strict';
import http from 'node:http';
import {mkdtemp,rm} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {createCaseApi} from '../server/case-api.mjs';
const dir=await mkdtemp(path.join(os.tmpdir(),'govbot-journey-'));let server,base,cookie='',checks=0;
async function start(){const api=createCaseApi({dataDir:dir});server=http.createServer(async(q,s)=>{if(!await api(q,s)){s.writeHead(404);s.end();}});await new Promise(r=>server.listen(0,'127.0.0.1',r));base='http://127.0.0.1:'+server.address().port;}
async function call(route,method='GET',body,session=cookie){const r=await fetch(base+'/api/demo'+route,{method,headers:{...(session?{cookie:session}:{}),...(body?{'content-type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});const set=r.headers.get('set-cookie');if(set&&!session)cookie=set.split(';')[0];return {status:r.status,data:await r.json()};}
function check(value,label){assert.ok(value,label);checks++;console.log('PASS',label);}
try{
 await start();await call('/schema');
 const answers={destination:'DEMO destination',passportStatus:'valid',employerRequirement:'criminal',nationalityStatus:'needsCopy'};
 let r=await call('/journeys/preview','POST',{answers});check(r.status===200&&r.data.candidates.map(c=>c.service).join(',')==='duplicate,criminal','clarification maps to exact existing services');
 check((await call('/cases')).data.cases.length===0,'preview creates no cases');
 r=await call('/journeys','POST',{answers,services:['duplicate'],clientRequestId:crypto.randomUUID(),confirmed:false});check(r.status===400,'confirmation required for saving task package');
 r=await call('/journeys','POST',{answers,services:['residence'],clientRequestId:crypto.randomUUID(),confirmed:true});check(r.status===400,'cannot inject an unrelated task');
 const key=crypto.randomUUID();r=await call('/journeys','POST',{answers,services:['duplicate','criminal'],clientRequestId:key,confirmed:true});let plan=r.data;check(r.status===201&&plan.tasks.length===2,'confirmed task package saved');
 const repeat=await call('/journeys','POST',{answers,services:['duplicate','criminal'],clientRequestId:key,confirmed:true});check(repeat.data.id===plan.id,'task package creation is idempotent');
 check((await call('/cases')).data.cases.length===0,'confirmed package still does not auto-create cases');
 r=await call('/journeys','GET',undefined,'govbot_demo='+'c'.repeat(64));check(r.data.journeys.length===0,'task package isolated to owner');
 r=await call('/reminders');check(r.data.reminders.length===1&&r.data.reminders[0].kind==='next_task','next task reminder from confirmed plan');const nextId=r.data.reminders[0].id;
 check((await call('/reminders')).data.reminders[0].id===nextId,'reminders have stable deduplicated IDs');
 r=await call('/cases','POST',{service:'duplicate',clientRequestId:crypto.randomUUID()});let record=r.data;
 r=await call('/journeys/'+plan.id+'/link','POST',{version:plan.version,service:'criminal',caseId:record.id});check(r.status===400,'case service must match plan task');
 r=await call('/journeys/'+plan.id+'/link','POST',{version:plan.version,service:'duplicate',caseId:record.id});plan=r.data;check(plan.tasks[0].case.id===record.id,'task linked to actual local case');
 r=await call('/reminders');check(r.data.reminders.length===1&&r.data.reminders[0].kind==='unfinished_draft','linked draft does not produce duplicate next-task reminder');const id=r.data.reminders[0].id;
 await call('/reminders/dismiss','POST',{id});check((await call('/reminders')).data.reminders.length===0,'dismissed unchanged reminder stays hidden');
 r=await call('/cases/'+record.id,'PATCH',{version:record.version,fields:{certificateFormat:'new',applicantRole:'self',applicantName:'DEMO USER',documentType:'nationality',documentNumber:'DEMO-CNT-001',copies:1,delivery:'centre',pickupLocation:'DEMO CENTRE',phone:'+22890000000'}});record=r.data;
 check((await call('/reminders')).data.reminders.length===1,'changed draft revision can remind again');
 r=await call('/cases/'+record.id+'/submit','POST',{version:record.version,confirmed:true});check(r.data.status==='submitted','linked case follows real local submission');
 r=await call('/journeys');check(r.data.journeys[0].tasks[0].case.status==='submitted','plan reads actual submitted status');
 r=await call('/reminders');check(r.data.reminders.length===1&&r.data.reminders[0].service==='criminal','next task advances after local submission');
 await new Promise(resolve=>server.close(resolve));await start();check((await call('/journeys')).data.journeys[0].id===plan.id,'plan and task links survive restart');
 check((await call('/cases')).data.cases.length===1,'no extra cases created by refresh or reminders');
 console.log(checks+' journey/reminder integration checks passed.');
}finally{if(server?.listening)await new Promise(r=>server.close(r));await rm(dir,{recursive:true,force:true});}
