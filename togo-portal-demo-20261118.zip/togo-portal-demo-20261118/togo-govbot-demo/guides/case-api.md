# 本地办件 API 与官方集成边界

版本 1，根路径 `/api/demo`。请求同源，浏览器凭 HttpOnly/SameSite 本地会话 Cookie 自动关联办件；其他会话不能读取已知编号的记录。所有响应 `Cache-Control: no-store`。这不是多哥官方 API。

| 方法/路径 | 用途 |
|---|---|
| GET `/schema` | 六项字段、条件、三语标签和附件槽位/限制 |
| POST `/cases` | 创建草稿：`{service, clientRequestId}`；同会话同 key 重试返回原件 |
| GET `/cases` | 当前会话的全部草稿与已提交件 |
| GET `/cases/:id` | 详情、version、fields、attachments、校验错误、费用参考、事件 |
| PATCH `/cases/:id` | `{version,fields,skipFields?}`；逐次保存，旧 version 返回 409 |
| POST `/cases/:id/attachments?slot=…&name=…&version=…` | 原始二进制上传；大小/扩展名/文件头验证 |
| GET `/cases/:id/attachments/:attachmentId` | 当前会话下载附件 |
| DELETE `/cases/:id/attachments/:attachmentId` | 草稿移除附件，JSON `{version}` |
| POST `/cases/:id/validate` | `{}`；返回 required/format/branch/attachment 结构化错误，不提交 |
| POST `/cases/:id/submit` | `{version,confirmed:true}`；验证、提交、冻结；成功重试返回同一办件 |
| GET `/cases/:id/receipt?lang=zh` | 已提交件 HTML 回执，可查看/下载/打印 |
| GET `/cases/:id/receipt?format=json` | 已提交件结构化快照 |

`service`：`duplicate`、`nationality`、`passport`、`criminal`、`residence`、`courtfees`。具体字段由 `/schema` 定义，条件不再适用的字段在保存时移除。可选字段可通过 skipFields 跳过；不可跳过必填项。

状态：`draft` → 用户显式确认 → `submitted`。后者显示为“演示已提交，待本地审核”。事件包括创建、信息保存、上传、附件移除、收到本地提交、待本地审核。不存在虚构的官方审批事件。

关键错误：400 请求/确认参数不符；403 非同源操作；404 无此会话的办件或附件；409 草稿版本变化/已提交冻结；413 超过大小限制；415 不支持文件；422 字段错误或材料缺项。提交失败不会生成成功回执。

## 存储与将来接入

`server/case-api.mjs` 管理会话、持久化、并发版本、上传、校验和回执。

`server/case-schema.mjs` 管理字段与分支规则。它与官方知识库分开，避免将演示必填项误当成已核实官方要求。

`server/submission-adapter.mjs` 是提交适配边界。默认 `localDemoAdapter.submit(application)` 只返回本地接受结果，不发任何外部请求。传入的 application 包含 schemaVersion、id（可作为未来幂等键）、service、mode、fields、附件元数据和费用参考；不传浏览器会话归属或内部文件路径。

接官方系统前必须另行落实其表单映射、授权、登录、附件上传、政府请求幂等与对账、官方回执及状态查询。这里没有可直接启用的官方连接，也不会把参考收费转换为支付指令。

## 生活事件与主动提醒（2026-11-09）

同一会话与数据卷，根路径仍为 `/api/demo`：

| 方法/路径 | 用途 |
|---|---|
| POST `/journeys/preview` | `{answers}` 返回候选，不保存计划、不创建办件 |
| POST `/journeys` | `{answers,services,clientRequestId,confirmed:true}` 保存白名单任务包，幂等 |
| GET `/journeys` | 当前会话计划及关联办件的实际状态 |
| POST `/journeys/:id/link` | `{version,service,caseId}` 仅关联同会话同事项办件 |
| GET `/reminders` | 草稿、缺件、下一任务；稳定ID按记录版本去重 |
| POST `/reminders/dismiss` | `{id}` 持久化忽略当前提醒版本 |

`answers`：`destination`、`passportStatus`（valid/missing/expired/unknown）、`employerRequirement`（criminal/nationality/both/none/unknown）、`nationalityStatus`（hasProof/needsCopy/needsFirst/unknown）。候选规则见 `server/journey-rules.mjs`。计划存于 `/data/journeys`，提醒忽略记录存于 `/data/reminders`。任务包建议不是官方必办清单。

4176的 `/govbot/` 与 `/api/demo/` 同源代理至4175。iframe消息只接受同源且来源为指定父/子窗口的消息。桥接状态仅含阶段、编号、版本、字段计数、材料计数和事件类型/时间；不把姓名、证件号或附件内容放入流程追踪。
